--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3 (Debian 12.3-1.pgdg100+1)
-- Dumped by pg_dump version 12.3 (Debian 12.3-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.account_emailaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailaddress_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.account_emailaddress_id_seq OWNED BY public.account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.account_emailconfirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailconfirmation_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.account_emailconfirmation_id_seq OWNED BY public.account_emailconfirmation.id;


--
-- Name: accounts_additionalfield; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.accounts_additionalfield (
    id integer NOT NULL,
    key character varying(50) NOT NULL,
    type character varying(11) NOT NULL,
    text_lang1 character varying(256) NOT NULL,
    text_lang2 character varying(256) NOT NULL,
    help_lang1 text NOT NULL,
    help_lang2 text NOT NULL,
    required boolean NOT NULL,
    help_lang3 text NOT NULL,
    help_lang4 text NOT NULL,
    help_lang5 text NOT NULL,
    text_lang3 character varying(256) NOT NULL,
    text_lang4 character varying(256) NOT NULL,
    text_lang5 character varying(256) NOT NULL
);


ALTER TABLE public.accounts_additionalfield OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: accounts_additionalfield_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.accounts_additionalfield_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_additionalfield_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: accounts_additionalfield_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.accounts_additionalfield_id_seq OWNED BY public.accounts_additionalfield.id;


--
-- Name: accounts_additionalfieldvalue; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.accounts_additionalfieldvalue (
    id integer NOT NULL,
    value character varying(256) NOT NULL,
    field_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.accounts_additionalfieldvalue OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: accounts_additionalfieldvalue_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.accounts_additionalfieldvalue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_additionalfieldvalue_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: accounts_additionalfieldvalue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.accounts_additionalfieldvalue_id_seq OWNED BY public.accounts_additionalfieldvalue.id;


--
-- Name: accounts_consentfieldvalue; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.accounts_consentfieldvalue (
    id integer NOT NULL,
    consent boolean NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.accounts_consentfieldvalue OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: accounts_consentfieldvalue_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.accounts_consentfieldvalue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_consentfieldvalue_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: accounts_consentfieldvalue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.accounts_consentfieldvalue_id_seq OWNED BY public.accounts_consentfieldvalue.id;


--
-- Name: accounts_role; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.accounts_role (
    id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.accounts_role OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: accounts_role_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.accounts_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_role_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: accounts_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.accounts_role_id_seq OWNED BY public.accounts_role.id;


--
-- Name: accounts_role_manager; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.accounts_role_manager (
    id integer NOT NULL,
    role_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.accounts_role_manager OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: accounts_role_manager_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.accounts_role_manager_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_role_manager_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: accounts_role_manager_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.accounts_role_manager_id_seq OWNED BY public.accounts_role_manager.id;


--
-- Name: accounts_role_member; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.accounts_role_member (
    id integer NOT NULL,
    role_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.accounts_role_member OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: accounts_role_member_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.accounts_role_member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_role_member_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: accounts_role_member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.accounts_role_member_id_seq OWNED BY public.accounts_role_member.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: conditions_condition; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.conditions_condition (
    id integer NOT NULL,
    relation character varying(8) NOT NULL,
    target_text character varying(256) NOT NULL,
    comment text NOT NULL,
    source_id integer,
    target_option_id integer,
    key character varying(128) NOT NULL,
    uri character varying(640) NOT NULL,
    uri_prefix character varying(256) NOT NULL,
    locked boolean NOT NULL
);


ALTER TABLE public.conditions_condition OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: conditions_condition_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.conditions_condition_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.conditions_condition_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: conditions_condition_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.conditions_condition_id_seq OWNED BY public.conditions_condition.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_celery_beat_clockedschedule; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.django_celery_beat_clockedschedule (
    id integer NOT NULL,
    clocked_time timestamp with time zone NOT NULL
);


ALTER TABLE public.django_celery_beat_clockedschedule OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.django_celery_beat_clockedschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_clockedschedule_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.django_celery_beat_clockedschedule_id_seq OWNED BY public.django_celery_beat_clockedschedule.id;


--
-- Name: django_celery_beat_crontabschedule; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.django_celery_beat_crontabschedule (
    id integer NOT NULL,
    minute character varying(240) NOT NULL,
    hour character varying(96) NOT NULL,
    day_of_week character varying(64) NOT NULL,
    day_of_month character varying(124) NOT NULL,
    month_of_year character varying(64) NOT NULL,
    timezone character varying(63) NOT NULL
);


ALTER TABLE public.django_celery_beat_crontabschedule OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.django_celery_beat_crontabschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_crontabschedule_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.django_celery_beat_crontabschedule_id_seq OWNED BY public.django_celery_beat_crontabschedule.id;


--
-- Name: django_celery_beat_intervalschedule; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.django_celery_beat_intervalschedule (
    id integer NOT NULL,
    every integer NOT NULL,
    period character varying(24) NOT NULL
);


ALTER TABLE public.django_celery_beat_intervalschedule OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.django_celery_beat_intervalschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_intervalschedule_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.django_celery_beat_intervalschedule_id_seq OWNED BY public.django_celery_beat_intervalschedule.id;


--
-- Name: django_celery_beat_periodictask; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.django_celery_beat_periodictask (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    task character varying(200) NOT NULL,
    args text NOT NULL,
    kwargs text NOT NULL,
    queue character varying(200),
    exchange character varying(200),
    routing_key character varying(200),
    expires timestamp with time zone,
    enabled boolean NOT NULL,
    last_run_at timestamp with time zone,
    total_run_count integer NOT NULL,
    date_changed timestamp with time zone NOT NULL,
    description text NOT NULL,
    crontab_id integer,
    interval_id integer,
    solar_id integer,
    one_off boolean NOT NULL,
    start_time timestamp with time zone,
    priority integer,
    headers text NOT NULL,
    clocked_id integer,
    expire_seconds integer,
    CONSTRAINT django_celery_beat_periodictask_expire_seconds_check CHECK ((expire_seconds >= 0)),
    CONSTRAINT django_celery_beat_periodictask_priority_check CHECK ((priority >= 0)),
    CONSTRAINT django_celery_beat_periodictask_total_run_count_check CHECK ((total_run_count >= 0))
);


ALTER TABLE public.django_celery_beat_periodictask OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.django_celery_beat_periodictask_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_periodictask_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.django_celery_beat_periodictask_id_seq OWNED BY public.django_celery_beat_periodictask.id;


--
-- Name: django_celery_beat_periodictasks; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.django_celery_beat_periodictasks (
    ident smallint NOT NULL,
    last_update timestamp with time zone NOT NULL
);


ALTER TABLE public.django_celery_beat_periodictasks OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_celery_beat_solarschedule; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.django_celery_beat_solarschedule (
    id integer NOT NULL,
    event character varying(24) NOT NULL,
    latitude numeric(9,6) NOT NULL,
    longitude numeric(9,6) NOT NULL
);


ALTER TABLE public.django_celery_beat_solarschedule OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.django_celery_beat_solarschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_solarschedule_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.django_celery_beat_solarschedule_id_seq OWNED BY public.django_celery_beat_solarschedule.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: domain_attribute; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.domain_attribute (
    id integer NOT NULL,
    key character varying(128) NOT NULL,
    path character varying(512) NOT NULL,
    comment text NOT NULL,
    uri character varying(640) NOT NULL,
    parent_id integer,
    level integer NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    uri_prefix character varying(256) NOT NULL,
    locked boolean NOT NULL,
    CONSTRAINT domain_attributeentity_level_check CHECK ((level >= 0)),
    CONSTRAINT domain_attributeentity_lft_check CHECK ((lft >= 0)),
    CONSTRAINT domain_attributeentity_rght_check CHECK ((rght >= 0)),
    CONSTRAINT domain_attributeentity_tree_id_check CHECK ((tree_id >= 0))
);


ALTER TABLE public.domain_attribute OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: domain_attributeentity_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.domain_attributeentity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.domain_attributeentity_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: domain_attributeentity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.domain_attributeentity_id_seq OWNED BY public.domain_attribute.id;


--
-- Name: options_option; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.options_option (
    id integer NOT NULL,
    key character varying(128) NOT NULL,
    "order" integer NOT NULL,
    text_lang1 character varying(256) NOT NULL,
    text_lang2 character varying(256) NOT NULL,
    additional_input boolean NOT NULL,
    optionset_id integer NOT NULL,
    comment text NOT NULL,
    uri character varying(640) NOT NULL,
    uri_prefix character varying(256) NOT NULL,
    path character varying(512) NOT NULL,
    text_lang3 character varying(256) NOT NULL,
    text_lang4 character varying(256) NOT NULL,
    text_lang5 character varying(256) NOT NULL,
    locked boolean NOT NULL
);


ALTER TABLE public.options_option OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: options_option_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.options_option_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.options_option_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: options_option_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.options_option_id_seq OWNED BY public.options_option.id;


--
-- Name: options_optionset; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.options_optionset (
    id integer NOT NULL,
    key character varying(128) NOT NULL,
    "order" integer NOT NULL,
    comment text NOT NULL,
    uri character varying(640) NOT NULL,
    uri_prefix character varying(256) NOT NULL,
    provider_key character varying(128) NOT NULL,
    locked boolean NOT NULL
);


ALTER TABLE public.options_optionset OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: options_optionset_conditions; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.options_optionset_conditions (
    id integer NOT NULL,
    optionset_id integer NOT NULL,
    condition_id integer NOT NULL
);


ALTER TABLE public.options_optionset_conditions OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: options_optionset_conditions_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.options_optionset_conditions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.options_optionset_conditions_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: options_optionset_conditions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.options_optionset_conditions_id_seq OWNED BY public.options_optionset_conditions.id;


--
-- Name: options_optionset_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.options_optionset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.options_optionset_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: options_optionset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.options_optionset_id_seq OWNED BY public.options_optionset.id;


--
-- Name: overlays_overlay; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.overlays_overlay (
    id integer NOT NULL,
    url_name character varying(128) NOT NULL,
    current character varying(128) NOT NULL,
    site_id integer,
    user_id integer NOT NULL
);


ALTER TABLE public.overlays_overlay OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: overlays_overlay_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.overlays_overlay_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.overlays_overlay_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: overlays_overlay_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.overlays_overlay_id_seq OWNED BY public.overlays_overlay.id;


--
-- Name: projects_continuation; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.projects_continuation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    project_id integer NOT NULL,
    questionset_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.projects_continuation OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_continuation_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.projects_continuation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_continuation_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_continuation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.projects_continuation_id_seq OWNED BY public.projects_continuation.id;


--
-- Name: projects_integration; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.projects_integration (
    id integer NOT NULL,
    provider_key text NOT NULL,
    project_id integer NOT NULL
);


ALTER TABLE public.projects_integration OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_integration_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.projects_integration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_integration_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_integration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.projects_integration_id_seq OWNED BY public.projects_integration.id;


--
-- Name: projects_integrationoption; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.projects_integrationoption (
    id integer NOT NULL,
    key character varying(128) NOT NULL,
    value text NOT NULL,
    integration_id integer NOT NULL,
    secret boolean NOT NULL
);


ALTER TABLE public.projects_integrationoption OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_integrationoption_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.projects_integrationoption_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_integrationoption_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_integrationoption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.projects_integrationoption_id_seq OWNED BY public.projects_integrationoption.id;


--
-- Name: projects_invite; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.projects_invite (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    role character varying(12) NOT NULL,
    token character varying(20) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    project_id integer NOT NULL,
    user_id integer
);


ALTER TABLE public.projects_invite OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_invite_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.projects_invite_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_invite_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_invite_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.projects_invite_id_seq OWNED BY public.projects_invite.id;


--
-- Name: projects_issue; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.projects_issue (
    id integer NOT NULL,
    status character varying(12) NOT NULL,
    project_id integer NOT NULL,
    task_id integer NOT NULL
);


ALTER TABLE public.projects_issue OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_issue_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.projects_issue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_issue_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_issue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.projects_issue_id_seq OWNED BY public.projects_issue.id;


--
-- Name: projects_issueresource; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.projects_issueresource (
    id integer NOT NULL,
    url character varying(200) NOT NULL,
    integration_id integer NOT NULL,
    issue_id integer NOT NULL
);


ALTER TABLE public.projects_issueresource OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_issueresource_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.projects_issueresource_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_issueresource_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_issueresource_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.projects_issueresource_id_seq OWNED BY public.projects_issueresource.id;


--
-- Name: projects_membership; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.projects_membership (
    id integer NOT NULL,
    role character varying(12) NOT NULL,
    project_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.projects_membership OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_membership_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.projects_membership_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_membership_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_membership_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.projects_membership_id_seq OWNED BY public.projects_membership.id;


--
-- Name: projects_project; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.projects_project (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    title character varying(256) NOT NULL,
    description text NOT NULL,
    catalog_id integer,
    site_id integer,
    level integer NOT NULL,
    lft integer NOT NULL,
    parent_id integer,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    CONSTRAINT projects_project_level_check CHECK ((level >= 0)),
    CONSTRAINT projects_project_lft_check CHECK ((lft >= 0)),
    CONSTRAINT projects_project_rght_check CHECK ((rght >= 0)),
    CONSTRAINT projects_project_tree_id_check CHECK ((tree_id >= 0))
);


ALTER TABLE public.projects_project OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_project_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.projects_project_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_project_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.projects_project_id_seq OWNED BY public.projects_project.id;


--
-- Name: projects_project_views; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.projects_project_views (
    id integer NOT NULL,
    project_id integer NOT NULL,
    view_id integer NOT NULL
);


ALTER TABLE public.projects_project_views OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_project_views_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.projects_project_views_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_project_views_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_project_views_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.projects_project_views_id_seq OWNED BY public.projects_project_views.id;


--
-- Name: projects_snapshot; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.projects_snapshot (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    project_id integer,
    description text NOT NULL,
    title character varying(256) NOT NULL
);


ALTER TABLE public.projects_snapshot OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_snapshot_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.projects_snapshot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_snapshot_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_snapshot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.projects_snapshot_id_seq OWNED BY public.projects_snapshot.id;


--
-- Name: projects_value; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.projects_value (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    set_index integer NOT NULL,
    collection_index integer NOT NULL,
    text text NOT NULL,
    attribute_id integer,
    option_id integer,
    snapshot_id integer,
    project_id integer NOT NULL,
    unit character varying(64) NOT NULL,
    value_type character varying(8) NOT NULL,
    external_id character varying(256) NOT NULL,
    file character varying(100)
);


ALTER TABLE public.projects_value OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_value_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.projects_value_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_value_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: projects_value_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.projects_value_id_seq OWNED BY public.projects_value.id;


--
-- Name: questions_catalog; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.questions_catalog (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    "order" integer NOT NULL,
    title_lang1 character varying(256) NOT NULL,
    title_lang2 character varying(256) NOT NULL,
    comment text NOT NULL,
    key character varying(128) NOT NULL,
    uri character varying(640) NOT NULL,
    uri_prefix character varying(256) NOT NULL,
    title_lang3 character varying(256) NOT NULL,
    title_lang4 character varying(256) NOT NULL,
    title_lang5 character varying(256) NOT NULL,
    help_lang1 text NOT NULL,
    help_lang2 text NOT NULL,
    help_lang3 text NOT NULL,
    help_lang4 text NOT NULL,
    help_lang5 text NOT NULL,
    available boolean NOT NULL,
    locked boolean NOT NULL
);


ALTER TABLE public.questions_catalog OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_catalog_groups; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.questions_catalog_groups (
    id integer NOT NULL,
    catalog_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.questions_catalog_groups OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_catalog_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.questions_catalog_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_catalog_groups_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_catalog_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.questions_catalog_groups_id_seq OWNED BY public.questions_catalog_groups.id;


--
-- Name: questions_catalog_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.questions_catalog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_catalog_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.questions_catalog_id_seq OWNED BY public.questions_catalog.id;


--
-- Name: questions_catalog_sites; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.questions_catalog_sites (
    id integer NOT NULL,
    catalog_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.questions_catalog_sites OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_catalog_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.questions_catalog_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_catalog_sites_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_catalog_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.questions_catalog_sites_id_seq OWNED BY public.questions_catalog_sites.id;


--
-- Name: questions_question; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.questions_question (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    uri character varying(640),
    uri_prefix character varying(256) NOT NULL,
    key character varying(128),
    path character varying(512),
    comment text,
    is_collection boolean NOT NULL,
    "order" integer NOT NULL,
    help_lang1 text,
    help_lang2 text,
    text_lang1 text,
    text_lang2 text,
    widget_type character varying(12) NOT NULL,
    value_type character varying(8) NOT NULL,
    unit character varying(64) NOT NULL,
    attribute_id integer,
    questionset_id integer NOT NULL,
    maximum double precision,
    minimum double precision,
    step double precision,
    verbose_name_lang2 character varying(256) NOT NULL,
    verbose_name_lang1 character varying(256) NOT NULL,
    verbose_name_plural_lang2 character varying(256) NOT NULL,
    verbose_name_plural_lang1 character varying(256) NOT NULL,
    help_lang3 text,
    help_lang4 text,
    help_lang5 text,
    text_lang3 text,
    text_lang4 text,
    text_lang5 text,
    verbose_name_lang3 character varying(256) NOT NULL,
    verbose_name_lang4 character varying(256) NOT NULL,
    verbose_name_lang5 character varying(256) NOT NULL,
    verbose_name_plural_lang3 character varying(256) NOT NULL,
    verbose_name_plural_lang4 character varying(256) NOT NULL,
    verbose_name_plural_lang5 character varying(256) NOT NULL,
    locked boolean NOT NULL,
    is_optional boolean NOT NULL,
    default_text_lang1 text,
    default_text_lang2 text,
    default_text_lang3 text,
    default_text_lang4 text,
    default_text_lang5 text,
    default_option_id integer,
    default_external_id character varying(256) NOT NULL
);


ALTER TABLE public.questions_question OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_question_conditions; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.questions_question_conditions (
    id integer NOT NULL,
    question_id integer NOT NULL,
    condition_id integer NOT NULL
);


ALTER TABLE public.questions_question_conditions OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_question_optionsets; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.questions_question_optionsets (
    id integer NOT NULL,
    question_id integer NOT NULL,
    optionset_id integer NOT NULL
);


ALTER TABLE public.questions_question_optionsets OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_questionitem_conditions_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.questions_questionitem_conditions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_questionitem_conditions_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_questionitem_conditions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.questions_questionitem_conditions_id_seq OWNED BY public.questions_question_conditions.id;


--
-- Name: questions_questionitem_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.questions_questionitem_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_questionitem_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_questionitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.questions_questionitem_id_seq OWNED BY public.questions_question.id;


--
-- Name: questions_questionitem_optionsets_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.questions_questionitem_optionsets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_questionitem_optionsets_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_questionitem_optionsets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.questions_questionitem_optionsets_id_seq OWNED BY public.questions_question_optionsets.id;


--
-- Name: questions_questionset; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.questions_questionset (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    uri character varying(640) NOT NULL,
    uri_prefix character varying(256) NOT NULL,
    key character varying(128) NOT NULL,
    path character varying(512) NOT NULL,
    comment text NOT NULL,
    is_collection boolean NOT NULL,
    "order" integer NOT NULL,
    help_lang1 text NOT NULL,
    help_lang2 text NOT NULL,
    attribute_id integer,
    verbose_name_lang2 character varying(256) NOT NULL,
    verbose_name_lang1 character varying(256) NOT NULL,
    verbose_name_plural_lang2 character varying(256) NOT NULL,
    verbose_name_plural_lang1 character varying(256) NOT NULL,
    section_id integer NOT NULL,
    title_lang2 character varying(256) NOT NULL,
    title_lang1 character varying(256) NOT NULL,
    help_lang3 text NOT NULL,
    help_lang4 text NOT NULL,
    help_lang5 text NOT NULL,
    title_lang3 character varying(256) NOT NULL,
    title_lang4 character varying(256) NOT NULL,
    title_lang5 character varying(256) NOT NULL,
    verbose_name_lang3 character varying(256) NOT NULL,
    verbose_name_lang4 character varying(256) NOT NULL,
    verbose_name_lang5 character varying(256) NOT NULL,
    verbose_name_plural_lang3 character varying(256) NOT NULL,
    verbose_name_plural_lang4 character varying(256) NOT NULL,
    verbose_name_plural_lang5 character varying(256) NOT NULL,
    locked boolean NOT NULL
);


ALTER TABLE public.questions_questionset OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_questionset_conditions; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.questions_questionset_conditions (
    id integer NOT NULL,
    questionset_id integer NOT NULL,
    condition_id integer NOT NULL
);


ALTER TABLE public.questions_questionset_conditions OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_questionset_conditions_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.questions_questionset_conditions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_questionset_conditions_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_questionset_conditions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.questions_questionset_conditions_id_seq OWNED BY public.questions_questionset_conditions.id;


--
-- Name: questions_questionset_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.questions_questionset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_questionset_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_questionset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.questions_questionset_id_seq OWNED BY public.questions_questionset.id;


--
-- Name: questions_section; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.questions_section (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    "order" integer NOT NULL,
    title_lang1 character varying(256) NOT NULL,
    title_lang2 character varying(256) NOT NULL,
    catalog_id integer NOT NULL,
    comment text NOT NULL,
    key character varying(128) NOT NULL,
    uri character varying(640) NOT NULL,
    uri_prefix character varying(256) NOT NULL,
    path character varying(512) NOT NULL,
    title_lang3 character varying(256) NOT NULL,
    title_lang4 character varying(256) NOT NULL,
    title_lang5 character varying(256) NOT NULL,
    locked boolean NOT NULL
);


ALTER TABLE public.questions_section OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_section_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.questions_section_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_section_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: questions_section_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.questions_section_id_seq OWNED BY public.questions_section.id;


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialaccount OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.socialaccount_socialaccount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialaccount_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.socialaccount_socialaccount_id_seq OWNED BY public.socialaccount_socialaccount.id;


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL
);


ALTER TABLE public.socialaccount_socialapp OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.socialaccount_socialapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.socialaccount_socialapp_id_seq OWNED BY public.socialaccount_socialapp.id;


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id integer NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialapp_sites OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.socialaccount_socialapp_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_sites_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.socialaccount_socialapp_sites_id_seq OWNED BY public.socialaccount_socialapp_sites.id;


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialtoken OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.socialaccount_socialtoken_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialtoken_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.socialaccount_socialtoken_id_seq OWNED BY public.socialaccount_socialtoken.id;


--
-- Name: tasks_task; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.tasks_task (
    id integer NOT NULL,
    title_lang1 character varying(256) NOT NULL,
    title_lang2 character varying(256) NOT NULL,
    text_lang1 text NOT NULL,
    text_lang2 text NOT NULL,
    comment text NOT NULL,
    key character varying(128) NOT NULL,
    uri character varying(640) NOT NULL,
    uri_prefix character varying(256) NOT NULL,
    days_after integer,
    days_before integer,
    end_attribute_id integer,
    start_attribute_id integer,
    text_lang3 text NOT NULL,
    text_lang4 text NOT NULL,
    text_lang5 text NOT NULL,
    title_lang3 character varying(256) NOT NULL,
    title_lang4 character varying(256) NOT NULL,
    title_lang5 character varying(256) NOT NULL,
    available boolean NOT NULL,
    locked boolean NOT NULL
);


ALTER TABLE public.tasks_task OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: tasks_task_catalogs; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.tasks_task_catalogs (
    id integer NOT NULL,
    task_id integer NOT NULL,
    catalog_id integer NOT NULL
);


ALTER TABLE public.tasks_task_catalogs OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: tasks_task_catalogs_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.tasks_task_catalogs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_task_catalogs_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: tasks_task_catalogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.tasks_task_catalogs_id_seq OWNED BY public.tasks_task_catalogs.id;


--
-- Name: tasks_task_conditions; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.tasks_task_conditions (
    id integer NOT NULL,
    task_id integer NOT NULL,
    condition_id integer NOT NULL
);


ALTER TABLE public.tasks_task_conditions OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: tasks_task_conditions_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.tasks_task_conditions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_task_conditions_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: tasks_task_conditions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.tasks_task_conditions_id_seq OWNED BY public.tasks_task_conditions.id;


--
-- Name: tasks_task_groups; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.tasks_task_groups (
    id integer NOT NULL,
    task_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.tasks_task_groups OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: tasks_task_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.tasks_task_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_task_groups_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: tasks_task_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.tasks_task_groups_id_seq OWNED BY public.tasks_task_groups.id;


--
-- Name: tasks_task_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.tasks_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_task_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: tasks_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.tasks_task_id_seq OWNED BY public.tasks_task.id;


--
-- Name: tasks_task_sites; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.tasks_task_sites (
    id integer NOT NULL,
    task_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.tasks_task_sites OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: tasks_task_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.tasks_task_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_task_sites_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: tasks_task_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.tasks_task_sites_id_seq OWNED BY public.tasks_task_sites.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.users_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL
);


ALTER TABLE public.users_user OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.users_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.users_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.users_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: views_view; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.views_view (
    id integer NOT NULL,
    key character varying(128) NOT NULL,
    comment text NOT NULL,
    template text NOT NULL,
    uri character varying(640) NOT NULL,
    uri_prefix character varying(256) NOT NULL,
    help_lang2 text NOT NULL,
    help_lang1 text NOT NULL,
    title_lang2 character varying(256) NOT NULL,
    title_lang1 character varying(256) NOT NULL,
    help_lang3 text NOT NULL,
    help_lang4 text NOT NULL,
    help_lang5 text NOT NULL,
    title_lang3 character varying(256) NOT NULL,
    title_lang4 character varying(256) NOT NULL,
    title_lang5 character varying(256) NOT NULL,
    available boolean NOT NULL,
    locked boolean NOT NULL
);


ALTER TABLE public.views_view OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: views_view_catalogs; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.views_view_catalogs (
    id integer NOT NULL,
    view_id integer NOT NULL,
    catalog_id integer NOT NULL
);


ALTER TABLE public.views_view_catalogs OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: views_view_catalogs_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.views_view_catalogs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.views_view_catalogs_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: views_view_catalogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.views_view_catalogs_id_seq OWNED BY public.views_view_catalogs.id;


--
-- Name: views_view_groups; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.views_view_groups (
    id integer NOT NULL,
    view_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.views_view_groups OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: views_view_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.views_view_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.views_view_groups_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: views_view_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.views_view_groups_id_seq OWNED BY public.views_view_groups.id;


--
-- Name: views_view_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.views_view_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.views_view_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: views_view_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.views_view_id_seq OWNED BY public.views_view.id;


--
-- Name: views_view_sites; Type: TABLE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE TABLE public.views_view_sites (
    id integer NOT NULL,
    view_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.views_view_sites OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: views_view_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE SEQUENCE public.views_view_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.views_view_sites_id_seq OWNER TO "jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX";

--
-- Name: views_view_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER SEQUENCE public.views_view_sites_id_seq OWNED BY public.views_view_sites.id;


--
-- Name: account_emailaddress id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.account_emailaddress ALTER COLUMN id SET DEFAULT nextval('public.account_emailaddress_id_seq'::regclass);


--
-- Name: account_emailconfirmation id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('public.account_emailconfirmation_id_seq'::regclass);


--
-- Name: accounts_additionalfield id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_additionalfield ALTER COLUMN id SET DEFAULT nextval('public.accounts_additionalfield_id_seq'::regclass);


--
-- Name: accounts_additionalfieldvalue id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_additionalfieldvalue ALTER COLUMN id SET DEFAULT nextval('public.accounts_additionalfieldvalue_id_seq'::regclass);


--
-- Name: accounts_consentfieldvalue id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_consentfieldvalue ALTER COLUMN id SET DEFAULT nextval('public.accounts_consentfieldvalue_id_seq'::regclass);


--
-- Name: accounts_role id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role ALTER COLUMN id SET DEFAULT nextval('public.accounts_role_id_seq'::regclass);


--
-- Name: accounts_role_manager id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role_manager ALTER COLUMN id SET DEFAULT nextval('public.accounts_role_manager_id_seq'::regclass);


--
-- Name: accounts_role_member id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role_member ALTER COLUMN id SET DEFAULT nextval('public.accounts_role_member_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: conditions_condition id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.conditions_condition ALTER COLUMN id SET DEFAULT nextval('public.conditions_condition_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_celery_beat_clockedschedule id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_clockedschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_crontabschedule id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_crontabschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_intervalschedule id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_intervalschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_periodictask id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_periodictask ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_periodictask_id_seq'::regclass);


--
-- Name: django_celery_beat_solarschedule id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_solarschedule_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: domain_attribute id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.domain_attribute ALTER COLUMN id SET DEFAULT nextval('public.domain_attributeentity_id_seq'::regclass);


--
-- Name: options_option id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.options_option ALTER COLUMN id SET DEFAULT nextval('public.options_option_id_seq'::regclass);


--
-- Name: options_optionset id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.options_optionset ALTER COLUMN id SET DEFAULT nextval('public.options_optionset_id_seq'::regclass);


--
-- Name: options_optionset_conditions id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.options_optionset_conditions ALTER COLUMN id SET DEFAULT nextval('public.options_optionset_conditions_id_seq'::regclass);


--
-- Name: overlays_overlay id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.overlays_overlay ALTER COLUMN id SET DEFAULT nextval('public.overlays_overlay_id_seq'::regclass);


--
-- Name: projects_continuation id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_continuation ALTER COLUMN id SET DEFAULT nextval('public.projects_continuation_id_seq'::regclass);


--
-- Name: projects_integration id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_integration ALTER COLUMN id SET DEFAULT nextval('public.projects_integration_id_seq'::regclass);


--
-- Name: projects_integrationoption id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_integrationoption ALTER COLUMN id SET DEFAULT nextval('public.projects_integrationoption_id_seq'::regclass);


--
-- Name: projects_invite id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_invite ALTER COLUMN id SET DEFAULT nextval('public.projects_invite_id_seq'::regclass);


--
-- Name: projects_issue id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_issue ALTER COLUMN id SET DEFAULT nextval('public.projects_issue_id_seq'::regclass);


--
-- Name: projects_issueresource id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_issueresource ALTER COLUMN id SET DEFAULT nextval('public.projects_issueresource_id_seq'::regclass);


--
-- Name: projects_membership id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_membership ALTER COLUMN id SET DEFAULT nextval('public.projects_membership_id_seq'::regclass);


--
-- Name: projects_project id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_project ALTER COLUMN id SET DEFAULT nextval('public.projects_project_id_seq'::regclass);


--
-- Name: projects_project_views id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_project_views ALTER COLUMN id SET DEFAULT nextval('public.projects_project_views_id_seq'::regclass);


--
-- Name: projects_snapshot id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_snapshot ALTER COLUMN id SET DEFAULT nextval('public.projects_snapshot_id_seq'::regclass);


--
-- Name: projects_value id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_value ALTER COLUMN id SET DEFAULT nextval('public.projects_value_id_seq'::regclass);


--
-- Name: questions_catalog id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_catalog ALTER COLUMN id SET DEFAULT nextval('public.questions_catalog_id_seq'::regclass);


--
-- Name: questions_catalog_groups id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_catalog_groups ALTER COLUMN id SET DEFAULT nextval('public.questions_catalog_groups_id_seq'::regclass);


--
-- Name: questions_catalog_sites id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_catalog_sites ALTER COLUMN id SET DEFAULT nextval('public.questions_catalog_sites_id_seq'::regclass);


--
-- Name: questions_question id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question ALTER COLUMN id SET DEFAULT nextval('public.questions_questionitem_id_seq'::regclass);


--
-- Name: questions_question_conditions id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question_conditions ALTER COLUMN id SET DEFAULT nextval('public.questions_questionitem_conditions_id_seq'::regclass);


--
-- Name: questions_question_optionsets id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question_optionsets ALTER COLUMN id SET DEFAULT nextval('public.questions_questionitem_optionsets_id_seq'::regclass);


--
-- Name: questions_questionset id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_questionset ALTER COLUMN id SET DEFAULT nextval('public.questions_questionset_id_seq'::regclass);


--
-- Name: questions_questionset_conditions id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_questionset_conditions ALTER COLUMN id SET DEFAULT nextval('public.questions_questionset_conditions_id_seq'::regclass);


--
-- Name: questions_section id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_section ALTER COLUMN id SET DEFAULT nextval('public.questions_section_id_seq'::regclass);


--
-- Name: socialaccount_socialaccount id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialaccount ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialaccount_id_seq'::regclass);


--
-- Name: socialaccount_socialapp id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialapp ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_id_seq'::regclass);


--
-- Name: socialaccount_socialapp_sites id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_sites_id_seq'::regclass);


--
-- Name: socialaccount_socialtoken id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialtoken ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialtoken_id_seq'::regclass);


--
-- Name: tasks_task id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task ALTER COLUMN id SET DEFAULT nextval('public.tasks_task_id_seq'::regclass);


--
-- Name: tasks_task_catalogs id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_catalogs ALTER COLUMN id SET DEFAULT nextval('public.tasks_task_catalogs_id_seq'::regclass);


--
-- Name: tasks_task_conditions id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_conditions ALTER COLUMN id SET DEFAULT nextval('public.tasks_task_conditions_id_seq'::regclass);


--
-- Name: tasks_task_groups id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_groups ALTER COLUMN id SET DEFAULT nextval('public.tasks_task_groups_id_seq'::regclass);


--
-- Name: tasks_task_sites id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_sites ALTER COLUMN id SET DEFAULT nextval('public.tasks_task_sites_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Name: views_view id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view ALTER COLUMN id SET DEFAULT nextval('public.views_view_id_seq'::regclass);


--
-- Name: views_view_catalogs id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_catalogs ALTER COLUMN id SET DEFAULT nextval('public.views_view_catalogs_id_seq'::regclass);


--
-- Name: views_view_groups id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_groups ALTER COLUMN id SET DEFAULT nextval('public.views_view_groups_id_seq'::regclass);


--
-- Name: views_view_sites id; Type: DEFAULT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_sites ALTER COLUMN id SET DEFAULT nextval('public.views_view_sites_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
1	maweber@mpi-bremen.de	t	t	1
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: accounts_additionalfield; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.accounts_additionalfield (id, key, type, text_lang1, text_lang2, help_lang1, help_lang2, required, help_lang3, help_lang4, help_lang5, text_lang3, text_lang4, text_lang5) FROM stdin;
\.


--
-- Data for Name: accounts_additionalfieldvalue; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.accounts_additionalfieldvalue (id, value, field_id, user_id) FROM stdin;
\.


--
-- Data for Name: accounts_consentfieldvalue; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.accounts_consentfieldvalue (id, consent, user_id) FROM stdin;
\.


--
-- Data for Name: accounts_role; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.accounts_role (id, user_id) FROM stdin;
1	1
\.


--
-- Data for Name: accounts_role_manager; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.accounts_role_manager (id, role_id, site_id) FROM stdin;
\.


--
-- Data for Name: accounts_role_member; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.accounts_role_member (id, role_id, site_id) FROM stdin;
1	1	1
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.auth_group (id, name) FROM stdin;
1	editor
2	reviewer
3	api
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
1	1	93
2	1	94
3	1	95
4	1	96
5	1	97
6	1	98
7	1	99
8	1	100
9	1	101
10	1	102
11	1	103
12	1	104
13	1	105
14	1	106
15	1	107
16	1	108
17	1	113
18	1	114
19	1	115
20	1	116
21	1	109
22	1	110
23	1	111
24	1	112
25	1	117
26	1	118
27	1	119
28	1	120
29	1	121
30	1	122
31	1	123
32	1	124
33	1	125
34	1	126
35	1	127
36	1	128
37	1	129
38	1	130
39	1	131
40	1	132
41	1	20
42	1	8
43	2	96
44	2	100
45	2	104
46	2	108
47	2	112
48	2	116
49	2	120
50	2	124
51	2	128
52	2	132
53	2	20
54	2	8
55	3	176
56	3	93
57	3	94
58	3	95
59	3	96
60	3	97
61	3	98
62	3	99
63	3	100
64	3	101
65	3	102
66	3	103
67	3	104
68	3	105
69	3	106
70	3	107
71	3	108
72	3	113
73	3	114
74	3	115
75	3	116
76	3	109
77	3	110
78	3	111
79	3	112
80	3	117
81	3	118
82	3	119
83	3	120
84	3	121
85	3	122
86	3	123
87	3	124
88	3	125
89	3	126
90	3	127
91	3	128
92	3	129
93	3	130
94	3	131
95	3	132
96	3	133
97	3	134
98	3	135
99	3	136
100	3	137
101	3	138
102	3	139
103	3	140
104	3	141
105	3	142
106	3	143
107	3	144
108	3	145
109	3	146
110	3	147
111	3	148
112	3	149
113	3	150
114	3	151
115	3	152
116	3	153
117	3	154
118	3	155
119	3	156
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can view permission	1	view_permission
5	Can add group	2	add_group
6	Can change group	2	change_group
7	Can delete group	2	delete_group
8	Can view group	2	view_group
9	Can add content type	3	add_contenttype
10	Can change content type	3	change_contenttype
11	Can delete content type	3	delete_contenttype
12	Can view content type	3	view_contenttype
13	Can add session	4	add_session
14	Can change session	4	change_session
15	Can delete session	4	delete_session
16	Can view session	4	view_session
17	Can add site	5	add_site
18	Can change site	5	change_site
19	Can delete site	5	delete_site
20	Can view site	5	view_site
21	Can add log entry	6	add_logentry
22	Can change log entry	6	change_logentry
23	Can delete log entry	6	delete_logentry
24	Can view log entry	6	view_logentry
25	Can add email address	7	add_emailaddress
26	Can change email address	7	change_emailaddress
27	Can delete email address	7	delete_emailaddress
28	Can view email address	7	view_emailaddress
29	Can add email confirmation	8	add_emailconfirmation
30	Can change email confirmation	8	change_emailconfirmation
31	Can delete email confirmation	8	delete_emailconfirmation
32	Can view email confirmation	8	view_emailconfirmation
33	Can add social account	9	add_socialaccount
34	Can change social account	9	change_socialaccount
35	Can delete social account	9	delete_socialaccount
36	Can view social account	9	view_socialaccount
37	Can add social application	10	add_socialapp
38	Can change social application	10	change_socialapp
39	Can delete social application	10	delete_socialapp
40	Can view social application	10	view_socialapp
41	Can add social application token	11	add_socialtoken
42	Can change social application token	11	change_socialtoken
43	Can delete social application token	11	delete_socialtoken
44	Can view social application token	11	view_socialtoken
45	Can add crontab	12	add_crontabschedule
46	Can change crontab	12	change_crontabschedule
47	Can delete crontab	12	delete_crontabschedule
48	Can view crontab	12	view_crontabschedule
49	Can add interval	13	add_intervalschedule
50	Can change interval	13	change_intervalschedule
51	Can delete interval	13	delete_intervalschedule
52	Can view interval	13	view_intervalschedule
53	Can add periodic task	14	add_periodictask
54	Can change periodic task	14	change_periodictask
55	Can delete periodic task	14	delete_periodictask
56	Can view periodic task	14	view_periodictask
57	Can add periodic tasks	15	add_periodictasks
58	Can change periodic tasks	15	change_periodictasks
59	Can delete periodic tasks	15	delete_periodictasks
60	Can view periodic tasks	15	view_periodictasks
61	Can add solar event	16	add_solarschedule
62	Can change solar event	16	change_solarschedule
63	Can delete solar event	16	delete_solarschedule
64	Can view solar event	16	view_solarschedule
65	Can add clocked	17	add_clockedschedule
66	Can change clocked	17	change_clockedschedule
67	Can delete clocked	17	delete_clockedschedule
68	Can view clocked	17	view_clockedschedule
69	Can add Token	18	add_token
70	Can change Token	18	change_token
71	Can delete Token	18	delete_token
72	Can view Token	18	view_token
73	Can add token	19	add_tokenproxy
74	Can change token	19	change_tokenproxy
75	Can delete token	19	delete_tokenproxy
76	Can view token	19	view_tokenproxy
77	Can add Additional field	20	add_additionalfield
78	Can change Additional field	20	change_additionalfield
79	Can delete Additional field	20	delete_additionalfield
80	Can view Additional field	20	view_additionalfield
81	Can add Additional field value	21	add_additionalfieldvalue
82	Can change Additional field value	21	change_additionalfieldvalue
83	Can delete Additional field value	21	delete_additionalfieldvalue
84	Can view Additional field value	21	view_additionalfieldvalue
85	Can add Consent field value	22	add_consentfieldvalue
86	Can change Consent field value	22	change_consentfieldvalue
87	Can delete Consent field value	22	delete_consentfieldvalue
88	Can view Consent field value	22	view_consentfieldvalue
89	Can add Role	23	add_role
90	Can change Role	23	change_role
91	Can delete Role	23	delete_role
92	Can view Role	23	view_role
93	Can add Attribute	24	add_attribute
94	Can change Attribute	24	change_attribute
95	Can delete Attribute	24	delete_attribute
96	Can view Attribute	24	view_attribute
97	Can add Option	25	add_option
98	Can change Option	25	change_option
99	Can delete Option	25	delete_option
100	Can view Option	25	view_option
101	Can add Option set	26	add_optionset
102	Can change Option set	26	change_optionset
103	Can delete Option set	26	delete_optionset
104	Can view Option set	26	view_optionset
105	Can add Condition	27	add_condition
106	Can change Condition	27	change_condition
107	Can delete Condition	27	delete_condition
108	Can view Condition	27	view_condition
109	Can add Catalog	28	add_catalog
110	Can change Catalog	28	change_catalog
111	Can delete Catalog	28	delete_catalog
112	Can view Catalog	28	view_catalog
113	Can add Section	29	add_section
114	Can change Section	29	change_section
115	Can delete Section	29	delete_section
116	Can view Section	29	view_section
117	Can add Question set	30	add_questionset
118	Can change Question set	30	change_questionset
119	Can delete Question set	30	delete_questionset
120	Can view Question set	30	view_questionset
121	Can add Question	31	add_question
122	Can change Question	31	change_question
123	Can delete Question	31	delete_question
124	Can view Question	31	view_question
125	Can add Task	32	add_task
126	Can change Task	32	change_task
127	Can delete Task	32	delete_task
128	Can view Task	32	view_task
129	Can add View	33	add_view
130	Can change View	33	change_view
131	Can delete View	33	delete_view
132	Can view View	33	view_view
133	Can add Project	34	add_project
134	Can change Project	34	change_project
135	Can delete Project	34	delete_project
136	Can view Project	34	view_project
137	Can add Snapshot	35	add_snapshot
138	Can change Snapshot	35	change_snapshot
139	Can delete Snapshot	35	delete_snapshot
140	Can view Snapshot	35	view_snapshot
141	Can add Value	36	add_value
142	Can change Value	36	change_value
143	Can delete Value	36	delete_value
144	Can view Value	36	view_value
145	Can add Membership	37	add_membership
146	Can change Membership	37	change_membership
147	Can delete Membership	37	delete_membership
148	Can view Membership	37	view_membership
149	Can add Issue	38	add_issue
150	Can change Issue	38	change_issue
151	Can delete Issue	38	delete_issue
152	Can view Issue	38	view_issue
153	Can add Integration	39	add_integration
154	Can change Integration	39	change_integration
155	Can delete Integration	39	delete_integration
156	Can view Integration	39	view_integration
157	Can add Integration option	40	add_integrationoption
158	Can change Integration option	40	change_integrationoption
159	Can delete Integration option	40	delete_integrationoption
160	Can view Integration option	40	view_integrationoption
161	Can add Issue resource	41	add_issueresource
162	Can change Issue resource	41	change_issueresource
163	Can delete Issue resource	41	delete_issueresource
164	Can view Issue resource	41	view_issueresource
165	Can add Continuation	42	add_continuation
166	Can change Continuation	42	change_continuation
167	Can delete Continuation	42	delete_continuation
168	Can view Continuation	42	view_continuation
169	Can add Invite	43	add_invite
170	Can change Invite	43	change_invite
171	Can delete Invite	43	delete_invite
172	Can view Invite	43	view_invite
173	Can add user	44	add_user
174	Can change user	44	change_user
175	Can delete user	44	delete_user
176	Can view user	44	view_user
177	Can add Overlay	45	add_overlay
178	Can change Overlay	45	change_overlay
179	Can delete Overlay	45	delete_overlay
180	Can view Overlay	45	view_overlay
\.


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.


--
-- Data for Name: conditions_condition; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.conditions_condition (id, relation, target_text, comment, source_id, target_option_id, key, uri, uri_prefix, locked) FROM stdin;
1	eq		There are additional data management requirements.	4	117	additional_rdm_policy	https://rdmorganiser.github.io/terms/conditions/additional_rdm_policy	https://rdmorganiser.github.io/terms	f
2	eq		The data will be shared.	127	69	data_sharing	https://rdmorganiser.github.io/terms/conditions/data_sharing	https://rdmorganiser.github.io/terms	f
3	eq			142	94	infrastructure_resources	https://rdmorganiser.github.io/terms/conditions/infrastructure_resources	https://rdmorganiser.github.io/terms	f
4	eq	1	The project uses data or software that is protected by intellectual property rights.	162	\N	intellectual_property_rights	https://rdmorganiser.github.io/terms/conditions/intellectual_property_rights	https://rdmorganiser.github.io/terms	f
5	eq	1	The legal situation of different countries has to be considered.	160	\N	international	https://rdmorganiser.github.io/terms/conditions/international	https://rdmorganiser.github.io/terms	f
6	eq	1		160	\N	law_international	https://rdmorganiser.github.io/terms/conditions/law_international	https://rdmorganiser.github.io/terms	f
7	eq	1	Other sensitive data being used in the project.	110	\N	other_sensitive_data	https://rdmorganiser.github.io/terms/conditions/other_sensitive_data	https://rdmorganiser.github.io/terms	f
8	eq	1	Personal data is used in the project.	120	\N	personal_data	https://rdmorganiser.github.io/terms/conditions/personal_data	https://rdmorganiser.github.io/terms	f
9	eq	1		113	\N	personal_inf_bdsg_3_9	https://rdmorganiser.github.io/terms/conditions/personal_inf_bdsg_3_9	https://rdmorganiser.github.io/terms	f
10	eq			71	220	rights_owner_clear	https://rdmorganiser.github.io/terms/conditions/rights_owner_clear	https://rdmorganiser.github.io/terms	f
11	eq			71	219	rights_owner_unclear	https://rdmorganiser.github.io/terms/conditions/rights_owner_unclear	https://rdmorganiser.github.io/terms	f
12	eq			143	220	usage_support	https://rdmorganiser.github.io/terms/conditions/usage_support	https://rdmorganiser.github.io/terms	f
13	eq			146	215	versioning_tool_undecided	https://rdmorganiser.github.io/terms/conditions/versioning_tool_undecided	https://rdmorganiser.github.io/terms	f
17	eq		When the answer to Do you need access restriction for your data is 'yes'	276	330	access_restriction_data	http://example.com/terms/conditions/access_restriction_data	http://example.com/terms	f
18	eq			238	332	submit_physical_object	http://example.com/terms/conditions/submit_physical_object	http://example.com/terms	f
19	eq			287	337	object_dead_or_alive	http://example.com/terms/conditions/object_dead_or_alive	http://example.com/terms	f
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2021-07-13 18:53:14.056756+00	1	maweber	2	[{"changed": {"fields": ["groups", "user_permissions"]}}]	44	1
2	2021-07-13 19:37:26.053271+00	3	Cat1	1	[{"added": {}}]	28	1
3	2021-07-13 19:37:54.58403+00	3	Cat1/sec1	1	[{"added": {}}]	29	1
4	2021-07-13 19:40:11.469733+00	4	Cat1/sec1/set1	1	[{"added": {}}]	30	1
5	2021-07-13 19:40:53.678781+00	1	Cat1/sec1/set1/q1	1	[{"added": {}}]	31	1
6	2021-07-13 19:49:44.502471+00	1	Cat1/sec1/set1/q1	2	[{"changed": {"fields": ["help_lang1", "help_lang5", "text_lang1", "default_text_lang1", "verbose_name_lang1", "verbose_name_plural_lang1", "minimum", "optionsets"]}}]	31	1
7	2021-07-15 10:15:46.622423+00	1	maweber	2	[{"changed": {"fields": ["user_permissions"]}}]	44	1
\.


--
-- Data for Name: django_celery_beat_clockedschedule; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.django_celery_beat_clockedschedule (id, clocked_time) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_crontabschedule; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.django_celery_beat_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year, timezone) FROM stdin;
1	0	4	*	*	*	UTC
\.


--
-- Data for Name: django_celery_beat_intervalschedule; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.django_celery_beat_intervalschedule (id, every, period) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_periodictask; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.django_celery_beat_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id, solar_id, one_off, start_time, priority, headers, clocked_id, expire_seconds) FROM stdin;
1	celery.backend_cleanup	celery.backend_cleanup	[]	{}	\N	\N	\N	\N	t	\N	0	2021-07-16 10:48:34.017536+00		1	\N	\N	f	\N	\N	{}	\N	43200
\.


--
-- Data for Name: django_celery_beat_periodictasks; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.django_celery_beat_periodictasks (ident, last_update) FROM stdin;
1	2021-07-16 10:48:34.015289+00
\.


--
-- Data for Name: django_celery_beat_solarschedule; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.django_celery_beat_solarschedule (id, event, latitude, longitude) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	contenttypes	contenttype
4	sessions	session
5	sites	site
6	admin	logentry
7	account	emailaddress
8	account	emailconfirmation
9	socialaccount	socialaccount
10	socialaccount	socialapp
11	socialaccount	socialtoken
12	django_celery_beat	crontabschedule
13	django_celery_beat	intervalschedule
14	django_celery_beat	periodictask
15	django_celery_beat	periodictasks
16	django_celery_beat	solarschedule
17	django_celery_beat	clockedschedule
18	authtoken	token
19	authtoken	tokenproxy
20	accounts	additionalfield
21	accounts	additionalfieldvalue
22	accounts	consentfieldvalue
23	accounts	role
24	domain	attribute
25	options	option
26	options	optionset
27	conditions	condition
28	questions	catalog
29	questions	section
30	questions	questionset
31	questions	question
32	tasks	task
33	views	view
34	projects	project
35	projects	snapshot
36	projects	value
37	projects	membership
38	projects	issue
39	projects	integration
40	projects	integrationoption
41	projects	issueresource
42	projects	continuation
43	projects	invite
44	users	user
45	overlays	overlay
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2021-06-23 12:37:21.342469+00
2	contenttypes	0002_remove_content_type_name	2021-06-23 12:37:21.351934+00
3	auth	0001_initial	2021-06-23 12:37:21.380407+00
4	auth	0002_alter_permission_name_max_length	2021-06-23 12:37:21.413843+00
5	auth	0003_alter_user_email_max_length	2021-06-23 12:37:21.424898+00
6	auth	0004_alter_user_username_opts	2021-06-23 12:37:21.434495+00
7	auth	0005_alter_user_last_login_null	2021-06-23 12:37:21.444214+00
8	auth	0006_require_contenttypes_0002	2021-06-23 12:37:21.446851+00
9	auth	0007_alter_validators_add_error_messages	2021-06-23 12:37:21.455808+00
10	auth	0008_alter_user_username_max_length	2021-06-23 12:37:21.463033+00
11	users	0001_initial	2021-06-23 12:37:21.502508+00
12	account	0001_initial	2021-06-23 12:37:21.559591+00
13	account	0002_email_max_length	2021-06-23 12:37:21.583057+00
14	sites	0001_initial	2021-06-23 12:37:21.592221+00
15	sites	0002_alter_domain_unique	2021-06-23 12:37:21.603777+00
16	accounts	0001_initial	2021-06-23 12:37:21.633639+00
17	accounts	0002_detail_key_type_field_length_increased	2021-06-23 12:37:21.646101+00
18	accounts	0003_hint_renamed_to_help_text	2021-06-23 12:37:21.652675+00
19	accounts	0004_permission_added	2021-06-23 12:37:21.664423+00
20	accounts	0005_field_type	2021-06-23 12:37:21.668711+00
21	accounts	0006_permissions_removed	2021-06-23 12:37:21.67662+00
22	accounts	0007_additional_fields	2021-06-23 12:37:21.716841+00
23	accounts	0008_related_name	2021-06-23 12:37:21.746037+00
24	accounts	0009_proxyuser	2021-06-23 12:37:21.750636+00
25	accounts	0010_consentfieldvalue	2021-06-23 12:37:21.768146+00
26	accounts	0011_rename_en_to_lang1	2021-06-23 12:37:21.786755+00
27	accounts	0012_rename_de_to_lang2	2021-06-23 12:37:21.806267+00
28	accounts	0013_meta	2021-06-23 12:37:21.820951+00
29	accounts	0014_add_language_fields	2021-06-23 12:37:21.845133+00
30	accounts	0015_data_migration	2021-06-23 12:37:21.858172+00
31	accounts	0016_remove_null_true	2021-06-23 12:37:21.928168+00
32	accounts	0017_role	2021-06-23 12:37:21.956071+00
33	accounts	0018_blank_fields	2021-06-23 12:37:22.018426+00
34	accounts	0019_delete_proxyuser	2021-06-23 12:37:22.022163+00
35	admin	0001_initial	2021-06-23 12:37:22.043856+00
36	admin	0002_logentry_remove_auto_add	2021-06-23 12:37:22.064937+00
37	admin	0003_logentry_add_action_flag_choices	2021-06-23 12:37:22.076579+00
38	auth	0009_alter_user_last_name_max_length	2021-06-23 12:37:22.084855+00
39	auth	0010_alter_group_name_max_length	2021-06-23 12:37:22.0947+00
40	auth	0011_update_proxy_permissions	2021-06-23 12:37:22.108019+00
41	authtoken	0001_initial	2021-06-23 12:37:22.123601+00
42	authtoken	0002_auto_20160226_1747	2021-06-23 12:37:22.155633+00
43	authtoken	0003_tokenproxy	2021-06-23 12:37:22.159665+00
44	domain	0001_initial_after_reset	2021-06-23 12:37:22.227713+00
45	questions	0001_initial_after_reset	2021-06-23 12:37:22.32992+00
46	projects	0001_initial_after_reset	2021-06-23 12:37:22.432996+00
47	projects	0002_meta	2021-06-23 12:37:22.510576+00
48	projects	0003_meta	2021-06-23 12:37:22.52237+00
49	projects	0004_remove_current_snapshot	2021-06-23 12:37:22.547901+00
50	projects	0005_snapshot	2021-06-23 12:37:22.570585+00
51	projects	0006_project_values	2021-06-23 12:37:22.607279+00
52	projects	0007_data_migration	2021-06-23 12:37:22.635845+00
53	projects	0008_not_null	2021-06-23 12:37:22.656299+00
54	domain	0002_additional_input	2021-06-23 12:37:22.666562+00
55	domain	0003_condition	2021-06-23 12:37:22.700498+00
56	domain	0004_verbosename	2021-06-23 12:37:22.734096+00
57	domain	0005_meta	2021-06-23 12:37:22.742403+00
58	domain	0006_attributeentity_parent_collection	2021-06-23 12:37:22.759639+00
59	domain	0007_db_index	2021-06-23 12:37:22.779258+00
60	domain	0008_meta	2021-06-23 12:37:22.799584+00
61	domain	0009_remove_condition	2021-06-23 12:37:22.896663+00
62	conditions	0001_initial	2021-06-23 12:37:22.923065+00
63	conditions	0002_many_to_many_for_conditions	2021-06-23 12:37:22.960954+00
64	domain	0010_many_to_many_for_conditions	2021-06-23 12:37:22.983866+00
65	domain	0011_meta	2021-06-23 12:37:23.019585+00
66	domain	0012_renaming	2021-06-23 12:37:23.03973+00
67	domain	0013_mptt	2021-06-23 12:37:23.104926+00
68	domain	0014_is_attribute	2021-06-23 12:37:23.128929+00
69	domain	0015_label	2021-06-23 12:37:23.154344+00
70	domain	0016_label	2021-06-23 12:37:23.156842+00
71	domain	0017_url_value_type	2021-06-23 12:37:23.166577+00
72	domain	0018_validator	2021-06-23 12:37:23.175593+00
73	domain	0019_meta	2021-06-23 12:37:23.192275+00
74	options	0001_initial	2021-06-23 12:37:23.214936+00
75	projects	0009_options	2021-06-23 12:37:23.239526+00
76	options	0002_meta	2021-06-23 12:37:23.270819+00
77	domain	0020_meta	2021-06-23 12:37:23.28692+00
78	domain	0021_options	2021-06-23 12:37:23.311889+00
79	options	0003_data_migration	2021-06-23 12:37:23.351223+00
80	conditions	0003_meta	2021-06-23 12:37:23.362426+00
81	conditions	0004_condition_title	2021-06-23 12:37:23.375447+00
82	conditions	0005_empty_relation	2021-06-23 12:37:23.386765+00
83	conditions	0006_db_constraint_false	2021-06-23 12:37:23.427925+00
84	conditions	0007_ordering	2021-06-23 12:37:23.439013+00
85	conditions	0008_validator	2021-06-23 12:37:23.450029+00
86	conditions	0009_options	2021-06-23 12:37:23.469043+00
87	options	0004_conditions	2021-06-23 12:37:23.493911+00
88	options	0005_refactoring	2021-06-23 12:37:23.532222+00
89	options	0006_refactoring	2021-06-23 12:37:23.741446+00
90	conditions	0010_refactoring	2021-06-23 12:37:23.769737+00
91	conditions	0011_refactoring	2021-06-23 12:37:23.862362+00
92	conditions	0012_permissions	2021-06-23 12:37:23.874368+00
93	conditions	0013_meta	2021-06-23 12:37:23.924039+00
94	conditions	0014_meta	2021-06-23 12:37:23.94997+00
95	conditions	0015_move_attribute_to_attributeentity	2021-06-23 12:37:23.960499+00
96	conditions	0016_meta	2021-06-23 12:37:23.987454+00
97	conditions	0017_data_migration	2021-06-23 12:37:24.014902+00
98	conditions	0018_remove_null_true	2021-06-23 12:37:24.062478+00
99	conditions	0019_django2	2021-06-23 12:37:24.073014+00
100	conditions	0020_require_uri_prefix	2021-06-23 12:37:24.10997+00
101	conditions	0021_related_name	2021-06-23 12:37:24.128099+00
102	conditions	0022_condition_locked	2021-06-23 12:37:24.14044+00
103	django_celery_beat	0001_initial	2021-06-23 12:37:24.179234+00
104	django_celery_beat	0002_auto_20161118_0346	2021-06-23 12:37:24.205782+00
105	django_celery_beat	0003_auto_20161209_0049	2021-06-23 12:37:24.224398+00
106	django_celery_beat	0004_auto_20170221_0000	2021-06-23 12:37:24.230941+00
107	django_celery_beat	0005_add_solarschedule_events_choices	2021-06-23 12:37:24.237345+00
108	django_celery_beat	0006_auto_20180322_0932	2021-06-23 12:37:24.268198+00
109	django_celery_beat	0007_auto_20180521_0826	2021-06-23 12:37:24.283129+00
110	django_celery_beat	0008_auto_20180914_1922	2021-06-23 12:37:24.309318+00
111	django_celery_beat	0006_auto_20180210_1226	2021-06-23 12:37:24.327278+00
112	django_celery_beat	0006_periodictask_priority	2021-06-23 12:37:24.335963+00
113	django_celery_beat	0009_periodictask_headers	2021-06-23 12:37:24.345125+00
114	django_celery_beat	0010_auto_20190429_0326	2021-06-23 12:37:24.522206+00
115	django_celery_beat	0011_auto_20190508_0153	2021-06-23 12:37:24.538167+00
116	django_celery_beat	0012_periodictask_expire_seconds	2021-06-23 12:37:24.551566+00
117	django_celery_beat	0013_auto_20200609_0727	2021-06-23 12:37:24.55929+00
118	django_celery_beat	0014_remove_clockedschedule_enabled	2021-06-23 12:37:24.566398+00
119	django_celery_beat	0015_edit_solarschedule_events_choices	2021-06-23 12:37:24.573335+00
120	tasks	0001_initial	2021-06-23 12:37:24.594316+00
121	tasks	0002_many_to_many_for_conditions	2021-06-23 12:37:24.614803+00
122	tasks	0003_meta	2021-06-23 12:37:24.644704+00
123	tasks	0004_refactoring	2021-06-23 12:37:24.821072+00
124	tasks	0005_data_migration	2021-06-23 12:37:24.86163+00
125	tasks	0006_meta	2021-06-23 12:37:24.87514+00
126	tasks	0007_permissions	2021-06-23 12:37:24.886892+00
127	tasks	0008_remove_time_period	2021-06-23 12:37:24.91041+00
128	domain	0022_options	2021-06-23 12:37:24.937162+00
129	domain	0023_fix_label	2021-06-23 12:37:24.949001+00
130	domain	0024_meta	2021-06-23 12:37:24.969554+00
131	domain	0025_refactoring	2021-06-23 12:37:25.018433+00
132	domain	0026_refactoring	2021-06-23 12:37:25.396807+00
133	domain	0027_meta	2021-06-23 12:37:25.408277+00
134	domain	0028_path	2021-06-23 12:37:25.430657+00
135	domain	0029_meta	2021-06-23 12:37:25.442088+00
136	domain	0030_permissions	2021-06-23 12:37:25.480568+00
137	tasks	0009_timeframe	2021-06-23 12:37:25.51336+00
138	tasks	0010_meta	2021-06-23 12:37:25.578609+00
139	tasks	0011_task_text	2021-06-23 12:37:25.605023+00
140	tasks	0012_move_attribute_to_attributeentity	2021-06-23 12:37:25.637623+00
141	questions	0002_meta	2021-06-23 12:37:25.653149+00
142	questions	0003_renaming	2021-06-23 12:37:25.681562+00
143	questions	0004_full_title	2021-06-23 12:37:25.709667+00
144	questions	0005_label	2021-06-23 12:37:25.755336+00
145	questions	0006_auto_20160803_1619	2021-06-23 12:37:25.802829+00
146	questions	0007_refactoring	2021-06-23 12:37:26.243454+00
147	questions	0008_data_migration	2021-06-23 12:37:26.311356+00
148	questions	0009_meta	2021-06-23 12:37:26.410063+00
149	questions	0010_label	2021-06-23 12:37:26.48374+00
150	questions	0011_path	2021-06-23 12:37:26.550086+00
151	questions	0012_meta	2021-06-23 12:37:26.576051+00
152	questions	0013_permissions	2021-06-23 12:37:26.607634+00
153	questions	0014_meta	2021-06-23 12:37:26.693901+00
154	questions	0015_question_unit_and_type	2021-06-23 12:37:26.773747+00
155	questions	0016_data_migration	2021-06-23 12:37:26.808999+00
156	options	0007_meta	2021-06-23 12:37:26.828569+00
157	options	0008_option_path	2021-06-23 12:37:26.837638+00
158	options	0009_data_migration	2021-06-23 12:37:26.880495+00
159	options	0010_meta	2021-06-23 12:37:26.897839+00
160	options	0011_permissions	2021-06-23 12:37:26.91405+00
161	options	0012_meta	2021-06-23 12:37:26.95205+00
162	questions	0017_question_optionsets	2021-06-23 12:37:26.981193+00
163	questions	0018_data_migration	2021-06-23 12:37:27.02934+00
164	questions	0019_questionentity_conditions	2021-06-23 12:37:27.05929+00
165	questions	0020_data_migration	2021-06-23 12:37:27.108159+00
166	questions	0021_questionentity_is_collection	2021-06-23 12:37:27.125295+00
167	questions	0022_data_migration	2021-06-23 12:37:27.162369+00
168	questions	0023_option	2021-06-23 12:37:27.176366+00
169	projects	0010_add_db_contraint	2021-06-23 12:37:27.202685+00
170	projects	0011_refactoring	2021-06-23 12:37:27.51244+00
171	projects	0012_membership	2021-06-23 12:37:27.609511+00
172	projects	0013_data_migration	2021-06-23 12:37:27.654758+00
173	projects	0014_remove_owner	2021-06-23 12:37:27.679595+00
174	projects	0015_permissions	2021-06-23 12:37:27.725026+00
175	projects	0016_catalog_on_delete	2021-06-23 12:37:27.752172+00
176	projects	0017_value_unit_and_type	2021-06-23 12:37:27.788509+00
177	projects	0018_data_migration	2021-06-23 12:37:27.823918+00
178	projects	0019_option	2021-06-23 12:37:27.841821+00
179	projects	0020_data_migration	2021-06-23 12:37:27.939039+00
180	projects	0021_order	2021-06-23 12:37:27.957845+00
181	projects	0022_move_attribute_to_attributeentity	2021-06-23 12:37:27.984389+00
182	questions	0024_data_migration	2021-06-23 12:37:28.020698+00
183	options	0013_order	2021-06-23 12:37:28.03055+00
184	domain	0031_meta	2021-06-23 12:37:28.068668+00
185	domain	0032_remove_unit_and_type	2021-06-23 12:37:28.095467+00
186	domain	0033_remove_attribute_optionsets	2021-06-23 12:37:28.118818+00
187	domain	0034_remove_attributeentity_conditions	2021-06-23 12:37:28.142647+00
188	domain	0035_remove_is_collection_and_parent_collection	2021-06-23 12:37:28.174437+00
189	questions	0025_questionset_and_questionitem	2021-06-23 12:37:28.275185+00
190	questions	0026_data_migration	2021-06-23 12:37:28.380988+00
191	questions	0027_remove_question_entity_and_question	2021-06-23 12:37:28.608586+00
192	questions	0028_rename_question	2021-06-23 12:37:28.677004+00
193	questions	0029_verbose_name_and_range	2021-06-23 12:37:28.851045+00
194	questions	0030_data_migration	2021-06-23 12:37:28.89143+00
195	domain	0036_remove_range_and_verbosename	2021-06-23 12:37:28.936158+00
196	domain	0037_remove_attribute	2021-06-23 12:37:28.964174+00
197	domain	0038_rename_attributeentity_to_attribute	2021-06-23 12:37:29.039123+00
198	domain	0039_meta	2021-06-23 12:37:29.204747+00
199	domain	0040_meta	2021-06-23 12:37:29.218327+00
200	domain	0041_data_migration	2021-06-23 12:37:29.253954+00
201	domain	0042_remove_null_true	2021-06-23 12:37:29.301339+00
202	domain	0043_django2	2021-06-23 12:37:29.339171+00
203	domain	0044_mptt	2021-06-23 12:37:29.380921+00
204	domain	0045_require_uri_prefix	2021-06-23 12:37:29.425537+00
205	domain	0046_parent_cascade	2021-06-23 12:37:29.452706+00
206	domain	0047_attribute_locked	2021-06-23 12:37:29.466831+00
207	options	0014_rename_en_to_lang1	2021-06-23 12:37:29.490483+00
208	options	0015_rename_de_to_lang2	2021-06-23 12:37:29.516037+00
209	options	0016_meta	2021-06-23 12:37:29.536382+00
210	options	0017_add_language_fields	2021-06-23 12:37:29.587839+00
211	options	0018_data_migration	2021-06-23 12:37:29.624389+00
212	options	0019_remove_null_true	2021-06-23 12:37:29.825153+00
213	options	0020_django2	2021-06-23 12:37:29.869531+00
214	options	0021_data_migrations	2021-06-23 12:37:29.904545+00
215	options	0022_cascade_options	2021-06-23 12:37:29.929779+00
216	options	0023_require_uri_prefix	2021-06-23 12:37:29.985277+00
217	options	0024_related_name	2021-06-23 12:37:30.01262+00
218	options	0025_optionset_provider_key	2021-06-23 12:37:30.026165+00
219	options	0026_optionset_option_locked	2021-06-23 12:37:30.054909+00
220	questions	0031_rename_attribute_entity_to_attribute	2021-06-23 12:37:30.105274+00
221	questions	0032_meta	2021-06-23 12:37:30.155461+00
222	questions	0033_meta	2021-06-23 12:37:30.170206+00
223	questions	0034_move_questionset_to_section	2021-06-23 12:37:30.223828+00
224	questions	0035_data_migration	2021-06-23 12:37:30.321555+00
225	questions	0036_remove_subsection	2021-06-23 12:37:30.438009+00
226	questions	0037_rename_en_to_lang1	2021-06-23 12:37:30.648788+00
227	questions	0038_rename_de_to_lang2	2021-06-23 12:37:30.919816+00
228	questions	0039_meta	2021-06-23 12:37:31.163437+00
229	questions	0040_add_language_fields	2021-06-23 12:37:31.689819+00
230	questions	0041_data_migration	2021-06-23 12:37:31.728749+00
231	questions	0042_remove_null_true	2021-06-23 12:37:32.123838+00
232	questions	0043_django2	2021-06-23 12:37:32.165103+00
233	questions	0044_require_uri_prefix	2021-06-23 12:37:32.245094+00
234	questions	0045_catalog_sites	2021-06-23 12:37:32.270836+00
235	questions	0046_catalog_groups	2021-06-23 12:37:32.303867+00
236	questions	0047_manager	2021-06-23 12:37:32.330719+00
237	questions	0048_catalog_help	2021-06-23 12:37:32.392839+00
238	questions	0049_manager	2021-06-23 12:37:32.406423+00
239	questions	0050_data_migration	2021-06-23 12:37:32.443455+00
240	questions	0051_sites_blank	2021-06-23 12:37:32.464311+00
241	questions	0052_available	2021-06-23 12:37:32.536093+00
242	questions	0053_related_name	2021-06-23 12:37:32.67488+00
243	questions	0054_meta	2021-06-23 12:37:32.704458+00
244	tasks	0013_meta	2021-06-23 12:37:32.763145+00
245	tasks	0014_move_timeframe_to_task	2021-06-23 12:37:32.843013+00
246	tasks	0015_data_migration	2021-06-23 12:37:32.88707+00
247	tasks	0016_remove_timeframe	2021-06-23 12:37:32.975145+00
248	tasks	0017_rename_en_to_lang1	2021-06-23 12:37:33.093472+00
249	tasks	0018_rename_de_to_lang2	2021-06-23 12:37:33.146644+00
250	tasks	0019_meta	2021-06-23 12:37:33.204364+00
251	tasks	0020_add_language_fields	2021-06-23 12:37:33.352232+00
252	tasks	0021_data_migration	2021-06-23 12:37:33.388075+00
253	tasks	0022_remove_null_true	2021-06-23 12:37:33.656766+00
254	tasks	0023_django2	2021-06-23 12:37:33.674538+00
255	tasks	0024_require_uri_prefix	2021-06-23 12:37:33.72415+00
256	tasks	0025_task_sites	2021-06-23 12:37:33.77116+00
257	tasks	0026_task_groups	2021-06-23 12:37:33.816614+00
258	tasks	0027_manager	2021-06-23 12:37:33.864646+00
259	tasks	0028_data_migration	2021-06-23 12:37:33.903526+00
260	tasks	0029_sites_blank	2021-06-23 12:37:33.939868+00
261	tasks	0030_available	2021-06-23 12:37:33.969168+00
262	tasks	0031_related_name	2021-06-23 12:37:34.124572+00
263	views	0001_initial	2021-06-23 12:37:34.138186+00
264	views	0002_view_template	2021-06-23 12:37:34.144216+00
265	views	0003_refactoring	2021-06-23 12:37:34.153992+00
266	views	0004_refactoring	2021-06-23 12:37:34.19126+00
267	views	0005_meta	2021-06-23 12:37:34.210727+00
268	views	0006_title_and_help	2021-06-23 12:37:34.227133+00
269	views	0007_data_migration	2021-06-23 12:37:34.265794+00
270	views	0008_permissions	2021-06-23 12:37:34.271985+00
271	views	0009_meta	2021-06-23 12:37:34.280971+00
272	views	0010_rename_en_to_lang1	2021-06-23 12:37:34.292175+00
273	views	0011_rename_de_to_lang2	2021-06-23 12:37:34.303405+00
274	views	0012_meta	2021-06-23 12:37:34.319912+00
275	views	0013_add_language_fields	2021-06-23 12:37:34.3445+00
276	views	0014_data_migration	2021-06-23 12:37:34.381655+00
277	views	0015_remove_null_true	2021-06-23 12:37:34.444542+00
278	views	0016_django2	2021-06-23 12:37:34.450627+00
279	views	0017_require_uri_prefix	2021-06-23 12:37:34.491014+00
280	views	0018_view_sites	2021-06-23 12:37:34.527975+00
281	views	0019_view_groups	2021-06-23 12:37:34.574475+00
282	views	0020_manager	2021-06-23 12:37:34.60422+00
283	views	0021_view_catalogs	2021-06-23 12:37:34.6395+00
284	views	0022_manager	2021-06-23 12:37:34.671867+00
285	views	0023_data_migration	2021-06-23 12:37:34.709323+00
286	projects	0023_meta	2021-06-23 12:37:34.731263+00
287	projects	0024_data_migration	2021-06-23 12:37:34.829507+00
288	projects	0025_remove_null_true	2021-06-23 12:37:34.853696+00
289	projects	0026_django2	2021-06-23 12:37:34.932969+00
290	projects	0027_project_site	2021-06-23 12:37:34.974709+00
291	projects	0028_meta	2021-06-23 12:37:35.009993+00
292	projects	0029_remove_manager	2021-06-23 12:37:35.027072+00
293	projects	0030_project_views	2021-06-23 12:37:35.066222+00
294	projects	0031_project_tasks	2021-06-23 12:37:35.11603+00
295	projects	0032_data_migration	2021-06-23 12:37:35.168095+00
296	projects	0033_default_value_type	2021-06-23 12:37:35.195249+00
297	projects	0034_issue	2021-06-23 12:37:35.230217+00
298	projects	0035_data_migration	2021-06-23 12:37:35.341659+00
299	projects	0036_remove_project_tasks	2021-06-23 12:37:35.374693+00
300	projects	0037_project_tasks	2021-06-23 12:37:35.406744+00
301	projects	0038_integration_integrationoption	2021-06-23 12:37:35.480979+00
302	projects	0039_integrationoption_secret	2021-06-23 12:37:35.506099+00
303	projects	0040_issueresource	2021-06-23 12:37:35.545358+00
304	projects	0041_value_external_id	2021-06-23 12:37:35.586835+00
305	projects	0042_allow_site_null	2021-06-23 12:37:35.625495+00
306	projects	0043_meta	2021-06-23 12:37:35.664469+00
307	projects	0044_meta	2021-06-23 12:37:35.704139+00
308	projects	0045_value_file	2021-06-23 12:37:35.794906+00
309	projects	0046_project_mptt	2021-06-23 12:37:36.066581+00
310	projects	0047_continuation	2021-06-23 12:37:36.115734+00
311	projects	0048_meta	2021-06-23 12:37:36.234222+00
312	projects	0049_invite	2021-06-23 12:37:36.276629+00
313	questions	0055_catalog_locked	2021-06-23 12:37:36.35992+00
314	questions	0056_question_is_optional	2021-06-23 12:37:36.454818+00
315	questions	0057_question_default_text	2021-06-23 12:37:36.554953+00
316	questions	0058_question_default_option	2021-06-23 12:37:36.59291+00
317	questions	0059_question_default_external_id	2021-06-23 12:37:36.619438+00
318	sessions	0001_initial	2021-06-23 12:37:36.633514+00
319	sites	0003_set_site_domain_and_name	2021-06-23 12:37:36.689107+00
320	sites	0004_alter_options_ordering_domain	2021-06-23 12:37:36.70665+00
321	sites	0005_auto_20210505_1412	2021-06-23 12:37:36.721755+00
322	socialaccount	0001_initial	2021-06-23 12:37:36.873849+00
323	socialaccount	0002_token_max_lengths	2021-06-23 12:37:36.930365+00
324	socialaccount	0003_extra_data_default_dict	2021-06-23 12:37:36.940935+00
325	tasks	0032_task_catalogs	2021-06-23 12:37:36.984641+00
326	tasks	0033_task_locked	2021-06-23 12:37:37.102563+00
327	views	0024_sites_blank	2021-06-23 12:37:37.143654+00
328	views	0025_available	2021-06-23 12:37:37.165732+00
329	views	0026_view_locked	2021-06-23 12:37:37.188903+00
330	users	0002_auto_20210713_1144	2021-07-13 11:45:20.127321+00
331	overlays	0001_initial	2021-07-15 10:01:21.548773+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
us43qpqhxoqigf25ejrbeeuu4ihhfywo	OGYzYWRjMTc5MGRjMGI1MmIxNmM2YmFjZjc0MTk3Y2ZlOWZmZTY2Zjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhMDJkYWE2ZGNmY2YxNzMzMzhjYjE5YTU2M2JiMWJlOWJlZjE3YWI0In0=	2021-07-07 12:41:22.948106+00
5bznvucdnlfc6ql7ax9s513ndwqjng5o	OGYzYWRjMTc5MGRjMGI1MmIxNmM2YmFjZjc0MTk3Y2ZlOWZmZTY2Zjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhMDJkYWE2ZGNmY2YxNzMzMzhjYjE5YTU2M2JiMWJlOWJlZjE3YWI0In0=	2021-07-26 10:38:48.122888+00
bll4kby72e6q2m16z26ocdn9qlax02j0	OGYzYWRjMTc5MGRjMGI1MmIxNmM2YmFjZjc0MTk3Y2ZlOWZmZTY2Zjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhMDJkYWE2ZGNmY2YxNzMzMzhjYjE5YTU2M2JiMWJlOWJlZjE3YWI0In0=	2021-07-26 13:41:05.083193+00
55ecbqa3exy5q8d5xtqixlx2i98cx0f0	OGYzYWRjMTc5MGRjMGI1MmIxNmM2YmFjZjc0MTk3Y2ZlOWZmZTY2Zjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhMDJkYWE2ZGNmY2YxNzMzMzhjYjE5YTU2M2JiMWJlOWJlZjE3YWI0In0=	2021-07-27 11:48:41.042762+00
ru6quqo4yr9n7xk3xffc6pg2lrwzn5zr	OGYzYWRjMTc5MGRjMGI1MmIxNmM2YmFjZjc0MTk3Y2ZlOWZmZTY2Zjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhMDJkYWE2ZGNmY2YxNzMzMzhjYjE5YTU2M2JiMWJlOWJlZjE3YWI0In0=	2021-07-27 11:55:01.44201+00
i5yudunwilf6106cz5n6uvaa0l0uulri	YTFiOGRlMjllM2UxZjAwNmE0MDljNmExZmM5YzUyNzAwMzA4MzgxMDp7Il9zZXNzaW9uX2V4cGlyeSI6MCwiX2F1dGhfdXNlcl9pZCI6IjEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImEwMmRhYTZkY2ZjZjE3MzMzOGNiMTlhNTYzYmIxYmU5YmVmMTdhYjQiLCJfbGFuZ3VhZ2UiOiJlbiIsImltcG9ydF9maWxlX25hbWUiOiJyZG1vLnhtbCIsImltcG9ydF90bXBmaWxlX25hbWUiOiIvdG1wL3VwbG9hZF8xNjI2MjAyODYyMzMyXzUwMzM5LnhtbCIsImltcG9ydF9zdWNjZXNzX3VybCI6Imh0dHA6Ly8wLjAuMC4wOjgwMDAvcmRtby9kb21haW4vIn0=	2021-07-27 19:01:20.416053+00
y7c403samscgpbd8nf5hol5w594rddbj	OGYzYWRjMTc5MGRjMGI1MmIxNmM2YmFjZjc0MTk3Y2ZlOWZmZTY2Zjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhMDJkYWE2ZGNmY2YxNzMzMzhjYjE5YTU2M2JiMWJlOWJlZjE3YWI0In0=	2021-07-29 08:58:26.864094+00
gwmhl2rx237mj2lis2zzmyn1dehk2hc2	OGYzYWRjMTc5MGRjMGI1MmIxNmM2YmFjZjc0MTk3Y2ZlOWZmZTY2Zjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhMDJkYWE2ZGNmY2YxNzMzMzhjYjE5YTU2M2JiMWJlOWJlZjE3YWI0In0=	2021-07-29 11:26:38.822926+00
fb5n9ba2k2sif7k3cthiag0upkd4n2qe	OGYzYWRjMTc5MGRjMGI1MmIxNmM2YmFjZjc0MTk3Y2ZlOWZmZTY2Zjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhMDJkYWE2ZGNmY2YxNzMzMzhjYjE5YTU2M2JiMWJlOWJlZjE3YWI0In0=	2021-07-30 10:48:53.847553+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.django_site (id, domain, name) FROM stdin;
1	dmpt.gfbio.dev	GFBio DMPT
\.


--
-- Data for Name: domain_attribute; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.domain_attribute (id, key, path, comment, uri, parent_id, level, lft, rght, tree_id, uri_prefix, locked) FROM stdin;
2	additional_rdm_policy	project/additional_rdm_policy		https://rdmorganiser.github.io/terms/domain/project/additional_rdm_policy	1	1	2	7	1	https://rdmorganiser.github.io/terms	f
3	requirements	project/additional_rdm_policy/requirements		https://rdmorganiser.github.io/terms/domain/project/additional_rdm_policy/requirements	2	2	3	4	1	https://rdmorganiser.github.io/terms	f
4	yesno	project/additional_rdm_policy/yesno		https://rdmorganiser.github.io/terms/domain/project/additional_rdm_policy/yesno	2	2	5	6	1	https://rdmorganiser.github.io/terms	f
5	coordination	project/coordination		https://rdmorganiser.github.io/terms/domain/project/coordination	1	1	8	11	1	https://rdmorganiser.github.io/terms	f
6	name	project/coordination/name		https://rdmorganiser.github.io/terms/domain/project/coordination/name	5	2	9	10	1	https://rdmorganiser.github.io/terms	f
8	creation	project/costs/creation		https://rdmorganiser.github.io/terms/domain/project/costs/creation	7	2	13	18	1	https://rdmorganiser.github.io/terms	f
86	pids	project/dataset/pids		https://rdmorganiser.github.io/terms/domain/project/dataset/pids	39	2	175	186	1	https://rdmorganiser.github.io/terms	f
100	repository_arrangements	project/dataset/preservation/repository_arrangements		https://rdmorganiser.github.io/terms/domain/project/dataset/preservation/repository_arrangements	92	3	202	203	1	https://rdmorganiser.github.io/terms	f
101	reuse_duration	project/dataset/preservation/reuse_duration		https://rdmorganiser.github.io/terms/domain/project/dataset/preservation/reuse_duration	92	3	204	205	1	https://rdmorganiser.github.io/terms	f
102	yesno	project/dataset/preservation/yesno		https://rdmorganiser.github.io/terms/domain/project/dataset/preservation/yesno	92	3	206	207	1	https://rdmorganiser.github.io/terms	f
103	quality_assurance	project/dataset/quality_assurance		https://rdmorganiser.github.io/terms/domain/project/dataset/quality_assurance	39	2	215	216	1	https://rdmorganiser.github.io/terms	f
104	rate	project/dataset/rate		https://rdmorganiser.github.io/terms/domain/project/dataset/rate	39	2	217	218	1	https://rdmorganiser.github.io/terms	f
105	reproducibility	project/dataset/reproducibility		https://rdmorganiser.github.io/terms/domain/project/dataset/reproducibility	39	2	219	220	1	https://rdmorganiser.github.io/terms	f
106	reuse_scenario	project/dataset/reuse_scenario		https://rdmorganiser.github.io/terms/domain/project/dataset/reuse_scenario	39	2	221	222	1	https://rdmorganiser.github.io/terms	f
107	sensitive_data	project/dataset/sensitive_data		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data	39	2	223	250	1	https://rdmorganiser.github.io/terms	f
130	volume	project/dataset/size/volume		https://rdmorganiser.github.io/terms/domain/project/dataset/size/volume	128	3	268	269	1	https://rdmorganiser.github.io/terms	f
131	software_documentation	project/dataset/software_documentation		https://rdmorganiser.github.io/terms/domain/project/dataset/software_documentation	39	2	271	272	1	https://rdmorganiser.github.io/terms	f
132	storage	project/dataset/storage		https://rdmorganiser.github.io/terms/domain/project/dataset/storage	39	2	273	282	1	https://rdmorganiser.github.io/terms	f
143	usage_support	project/dataset/usage_support		https://rdmorganiser.github.io/terms/domain/project/dataset/usage_support	39	2	295	296	1	https://rdmorganiser.github.io/terms	f
144	usage_technology	project/dataset/usage_technology		https://rdmorganiser.github.io/terms/domain/project/dataset/usage_technology	39	2	297	298	1	https://rdmorganiser.github.io/terms	f
145	versioning_strategy	project/dataset/versioning_strategy		https://rdmorganiser.github.io/terms/domain/project/dataset/versioning_strategy	39	2	299	300	1	https://rdmorganiser.github.io/terms	f
146	versioning_tool	project/dataset/versioning_tool		https://rdmorganiser.github.io/terms/domain/project/dataset/versioning_tool	39	2	301	302	1	https://rdmorganiser.github.io/terms	f
147	versioning_yesno	project/dataset/versioning_yesno		https://rdmorganiser.github.io/terms/domain/project/dataset/versioning_yesno	39	2	303	304	1	https://rdmorganiser.github.io/terms	f
148	dmp	project/dmp		https://rdmorganiser.github.io/terms/domain/project/dmp	1	1	312	315	1	https://rdmorganiser.github.io/terms	f
149	name	project/dmp/name		https://rdmorganiser.github.io/terms/domain/project/dmp/name	148	2	313	314	1	https://rdmorganiser.github.io/terms	f
150	external_services	project/external_services		https://rdmorganiser.github.io/terms/domain/project/external_services	1	1	316	317	1	https://rdmorganiser.github.io/terms	f
151	funder	project/funder		https://rdmorganiser.github.io/terms/domain/project/funder	1	1	318	333	1	https://rdmorganiser.github.io/terms	f
152	id	project/funder/id		https://rdmorganiser.github.io/terms/domain/project/funder/id	151	2	319	320	1	https://rdmorganiser.github.io/terms	f
153	name	project/funder/name		https://rdmorganiser.github.io/terms/domain/project/funder/name	151	2	321	322	1	https://rdmorganiser.github.io/terms	f
9	non_personnel	project/costs/creation/non_personnel		https://rdmorganiser.github.io/terms/domain/project/costs/creation/non_personnel	8	3	14	15	1	https://rdmorganiser.github.io/terms	f
10	personnel	project/costs/creation/personnel		https://rdmorganiser.github.io/terms/domain/project/costs/creation/personnel	8	3	16	17	1	https://rdmorganiser.github.io/terms	f
11	ipr	project/costs/ipr		https://rdmorganiser.github.io/terms/domain/project/costs/ipr	7	2	19	24	1	https://rdmorganiser.github.io/terms	f
154	programme	project/funder/programme		https://rdmorganiser.github.io/terms/domain/project/funder/programme	151	2	323	328	1	https://rdmorganiser.github.io/terms	f
155	title	project/funder/programme/title		https://rdmorganiser.github.io/terms/domain/project/funder/programme/title	154	3	324	325	1	https://rdmorganiser.github.io/terms	f
156	url	project/funder/programme/url		https://rdmorganiser.github.io/terms/domain/project/funder/programme/url	154	3	326	327	1	https://rdmorganiser.github.io/terms	f
157	rdm_policy	project/funder/rdm_policy		https://rdmorganiser.github.io/terms/domain/project/funder/rdm_policy	151	2	329	330	1	https://rdmorganiser.github.io/terms	f
158	yesno	project/funder/yesno		https://rdmorganiser.github.io/terms/domain/project/funder/yesno	151	2	331	332	1	https://rdmorganiser.github.io/terms	f
159	legal_aspects	project/legal_aspects		https://rdmorganiser.github.io/terms/domain/project/legal_aspects	1	1	334	369	1	https://rdmorganiser.github.io/terms	f
210	basis_format	project/dataset/metadata/basis_format		https://fdm-bayern.org/eHumanities/domain/project/dataset/metadata/basis_format	72	3	164	169	1	https://fdm-bayern.org/eHumanities	f
211	encoding	project/dataset/metadata/basis_format/encoding		https://fdm-bayern.org/eHumanities/domain/project/dataset/metadata/basis_format/encoding	210	4	165	166	1	https://fdm-bayern.org/eHumanities	f
212	presentation	project/dataset/metadata/basis_format/presentation		https://fdm-bayern.org/eHumanities/domain/project/dataset/metadata/basis_format/presentation	210	4	167	168	1	https://fdm-bayern.org/eHumanities	f
213	edition_version	project/dataset/preservation/edition_version		https://fdm-bayern.org/eHumanities/domain/project/dataset/preservation/edition_version	92	3	208	209	1	https://fdm-bayern.org/eHumanities	f
214	editions	project/editions	Attribute für die Publikation von Editionen (insbes. digitale Publikationen) im DFG Fragebogen.	https://fdm-bayern.org/eHumanities/domain/project/editions	1	1	436	445	1	https://fdm-bayern.org/eHumanities	f
215	biblio_metadata	project/editions/biblio_metadata		https://fdm-bayern.org/eHumanities/domain/project/editions/biblio_metadata	214	2	437	438	1	https://fdm-bayern.org/eHumanities	f
216	openaccess	project/editions/openaccess		https://fdm-bayern.org/eHumanities/domain/project/editions/openaccess	214	2	439	440	1	https://fdm-bayern.org/eHumanities	f
217	publication_form	project/editions/publication_form		https://fdm-bayern.org/eHumanities/domain/project/editions/publication_form	214	2	441	442	1	https://fdm-bayern.org/eHumanities	f
218	technical_standards	project/editions/technical_standards		https://fdm-bayern.org/eHumanities/domain/project/editions/technical_standards	214	2	443	444	1	https://fdm-bayern.org/eHumanities	f
219	H2020	H2020		https://fdm-bayern.org/eHumanities/domain/H2020	\N	0	1	20	2	https://fdm-bayern.org/eHumanities	f
220	PI	H2020/PI		https://fdm-bayern.org/eHumanities/domain/H2020/PI	219	1	2	17	2	https://fdm-bayern.org/eHumanities	f
221	affiliation	H2020/PI/affiliation		https://fdm-bayern.org/eHumanities/domain/H2020/PI/affiliation	220	2	3	4	2	https://fdm-bayern.org/eHumanities	f
222	data_contact	H2020/PI/data_contact		https://fdm-bayern.org/eHumanities/domain/H2020/PI/data_contact	220	2	5	6	2	https://fdm-bayern.org/eHumanities	f
223	email	H2020/PI/email		https://fdm-bayern.org/eHumanities/domain/H2020/PI/email	220	2	7	8	2	https://fdm-bayern.org/eHumanities	f
224	given_name	H2020/PI/given_name		https://fdm-bayern.org/eHumanities/domain/H2020/PI/given_name	220	2	9	10	2	https://fdm-bayern.org/eHumanities	f
225	id	H2020/PI/id		https://fdm-bayern.org/eHumanities/domain/H2020/PI/id	220	2	11	12	2	https://fdm-bayern.org/eHumanities	f
226	name	H2020/PI/name		https://fdm-bayern.org/eHumanities/domain/H2020/PI/name	220	2	13	14	2	https://fdm-bayern.org/eHumanities	f
227	orcid	H2020/PI/orcid		https://fdm-bayern.org/eHumanities/domain/H2020/PI/orcid	220	2	15	16	2	https://fdm-bayern.org/eHumanities	f
228	fair	H2020/fair		https://fdm-bayern.org/eHumanities/domain/H2020/fair	219	1	18	19	2	https://fdm-bayern.org/eHumanities	f
229	fairprinciples	project/dataset/fairprinciples		https://fdm-bayern.org/eHumanities/domain/project/dataset/fairprinciples	39	2	305	308	1	https://fdm-bayern.org/eHumanities	f
230	findable	project/dataset/fairprinciples/findable		https://fdm-bayern.org/eHumanities/domain/project/dataset/fairprinciples/findable	229	3	306	307	1	https://fdm-bayern.org/eHumanities	f
231	keywords	project/dataset/keywords		https://fdm-bayern.org/eHumanities/domain/project/dataset/keywords	39	2	309	310	1	https://fdm-bayern.org/eHumanities	f
232	longterm_value	project/dataset/preservation/longterm_value		https://fdm-bayern.org/eHumanities/domain/project/dataset/preservation/longterm_value	92	3	210	211	1	https://fdm-bayern.org/eHumanities	f
233	repository_information	project/dataset/preservation/repository_information		https://fdm-bayern.org/eHumanities/domain/project/dataset/preservation/repository_information	92	3	212	213	1	https://fdm-bayern.org/eHumanities	f
234	gfbio	gfbio		http://example.com/terms/domain/gfbio	\N	0	1	104	3	http://example.com/terms	f
237	data_collection	gfbio/data_collection		http://example.com/terms/domain/gfbio/data_collection	234	1	2	33	3	http://example.com/terms	f
12	non_personnel	project/costs/ipr/non_personnel		https://rdmorganiser.github.io/terms/domain/project/costs/ipr/non_personnel	11	3	20	21	1	https://rdmorganiser.github.io/terms	f
13	personnel	project/costs/ipr/personnel		https://rdmorganiser.github.io/terms/domain/project/costs/ipr/personnel	11	3	22	23	1	https://rdmorganiser.github.io/terms	f
84	method	project/dataset/method		https://rdmorganiser.github.io/terms/domain/project/dataset/method	39	2	171	172	1	https://rdmorganiser.github.io/terms	f
85	origin	project/dataset/origin		https://rdmorganiser.github.io/terms/domain/project/dataset/origin	39	2	173	174	1	https://rdmorganiser.github.io/terms	f
7	costs	project/costs		https://rdmorganiser.github.io/terms/domain/project/costs	1	1	12	71	1	https://rdmorganiser.github.io/terms	f
14	metadata	project/costs/metadata		https://rdmorganiser.github.io/terms/domain/project/costs/metadata	7	2	25	30	1	https://rdmorganiser.github.io/terms	f
34	usage	project/costs/usage		https://rdmorganiser.github.io/terms/domain/project/costs/usage	7	2	65	70	1	https://rdmorganiser.github.io/terms	f
238	physical_object_yesno	gfbio/data_collection/object_0/physical_object_yesno		http://example.com/terms/domain/gfbio/data_collection/object_0/physical_object_yesno	261	3	4	5	3	http://example.com/terms	f
239	taxon_yesno	gfbio/data_collection/object_2/taxon_yesno		http://example.com/terms/domain/gfbio/data_collection/object_2/taxon_yesno	286	3	30	31	3	http://example.com/terms	f
240	general	gfbio/general		http://example.com/terms/domain/gfbio/general	234	1	34	75	3	http://example.com/terms	f
241	project_name	gfbio/general/project_name		http://example.com/terms/domain/gfbio/general/project_name	240	2	35	36	3	http://example.com/terms	f
242	research_category_type	gfbio/general/research_category_type		http://example.com/terms/domain/gfbio/general/research_category_type	240	2	37	38	3	http://example.com/terms	f
243	research_data_reproducible	gfbio/general/research_data_reproducible		http://example.com/terms/domain/gfbio/general/research_data_reproducible	240	2	39	42	3	http://example.com/terms	f
244	additional_information	gfbio/general/research_data_reproducible/additional_information		http://example.com/terms/domain/gfbio/general/research_data_reproducible/additional_information	243	3	40	41	3	http://example.com/terms	f
245	project_type	gfbio/general/project_type		http://example.com/terms/domain/gfbio/general/project_type	240	2	43	44	3	http://example.com/terms	f
246	project_abstract	gfbio/general/project_abstract		http://example.com/terms/domain/gfbio/general/project_abstract	240	2	45	46	3	http://example.com/terms	f
247	point_of_contact	gfbio/general/point_of_contact		http://example.com/terms/domain/gfbio/general/point_of_contact	240	2	47	54	3	http://example.com/terms	f
248	contact_person_name	gfbio/general/point_of_contact/contact_person_name		http://example.com/terms/domain/gfbio/general/point_of_contact/contact_person_name	247	3	48	49	3	http://example.com/terms	f
249	phone_number	gfbio/general/point_of_contact/phone_number		http://example.com/terms/domain/gfbio/general/point_of_contact/phone_number	247	3	50	51	3	http://example.com/terms	f
250	email	gfbio/general/point_of_contact/email		http://example.com/terms/domain/gfbio/general/point_of_contact/email	247	3	52	53	3	http://example.com/terms	f
251	PI	gfbio/general/PI		http://example.com/terms/domain/gfbio/general/PI	240	2	55	58	3	http://example.com/terms	f
252	name	gfbio/general/PI/name		http://example.com/terms/domain/gfbio/general/PI/name	251	3	56	57	3	http://example.com/terms	f
253	funder_or_programm_title	gfbio/general/funder_or_programm_title		http://example.com/terms/domain/gfbio/general/funder_or_programm_title	240	2	59	60	3	http://example.com/terms	f
254	coordinated_programme	gfbio/general/coordinated_programme		http://example.com/terms/domain/gfbio/general/coordinated_programme	240	2	61	64	3	http://example.com/terms	f
255	guideline_or_policy_for_data_management	gfbio/general/coordinated_programme/guideline_or_policy_for_data_management		http://example.com/terms/domain/gfbio/general/coordinated_programme/guideline_or_policy_for_data_management	254	3	62	63	3	http://example.com/terms	f
256	research_unit	gfbio/general/research_unit		http://example.com/terms/domain/gfbio/general/research_unit	240	2	65	68	3	http://example.com/terms	f
257	name	gfbio/general/research_unit/name		http://example.com/terms/domain/gfbio/general/research_unit/name	256	3	66	67	3	http://example.com/terms	f
258	budget	gfbio/general/budget		http://example.com/terms/domain/gfbio/general/budget	240	2	69	70	3	http://example.com/terms	f
259	policies_or_guidelines	gfbio/general/policies_or_guidelines		http://example.com/terms/domain/gfbio/general/policies_or_guidelines	240	2	71	74	3	http://example.com/terms	f
260	type	gfbio/general/policies_or_guidelines/type		http://example.com/terms/domain/gfbio/general/policies_or_guidelines/type	259	3	72	73	3	http://example.com/terms	f
261	object_0	gfbio/data_collection/object_0		http://example.com/terms/domain/gfbio/data_collection/object_0	237	2	3	6	3	http://example.com/terms	f
262	data_type	gfbio/data_collection/data_type		http://example.com/terms/domain/gfbio/data_collection/data_type	237	2	7	14	3	http://example.com/terms	f
263	sequence_data	gfbio/data_collection/data_type/sequence_data		http://example.com/terms/domain/gfbio/data_collection/data_type/sequence_data	262	3	8	9	3	http://example.com/terms	f
264	will_be_created	gfbio/data_collection/data_type/will_be_created		http://example.com/terms/domain/gfbio/data_collection/data_type/will_be_created	262	3	10	11	3	http://example.com/terms	f
265	file_formats	gfbio/data_collection/data_type/file_formats		http://example.com/terms/domain/gfbio/data_collection/data_type/file_formats	262	3	12	13	3	http://example.com/terms	f
266	data_volume	gfbio/data_collection/data_volume		http://example.com/terms/domain/gfbio/data_collection/data_volume	237	2	15	20	3	http://example.com/terms	f
267	estimated	gfbio/data_collection/data_volume/estimated		http://example.com/terms/domain/gfbio/data_collection/data_volume/estimated	266	3	16	17	3	http://example.com/terms	f
268	number_of_data_sets	gfbio/data_collection/data_volume/number_of_data_sets		http://example.com/terms/domain/gfbio/data_collection/data_volume/number_of_data_sets	266	3	18	19	3	http://example.com/terms	f
269	standards	gfbio/data_collection/standards		http://example.com/terms/domain/gfbio/data_collection/standards	237	2	21	24	3	http://example.com/terms	f
15	non_personnel	project/costs/metadata/non_personnel		https://rdmorganiser.github.io/terms/domain/project/costs/metadata/non_personnel	14	3	26	27	1	https://rdmorganiser.github.io/terms	f
16	personnel	project/costs/metadata/personnel		https://rdmorganiser.github.io/terms/domain/project/costs/metadata/personnel	14	3	28	29	1	https://rdmorganiser.github.io/terms	f
17	pid	project/costs/pid		https://rdmorganiser.github.io/terms/domain/project/costs/pid	7	2	31	36	1	https://rdmorganiser.github.io/terms	f
18	non_personnel	project/costs/pid/non_personnel		https://rdmorganiser.github.io/terms/domain/project/costs/pid/non_personnel	17	3	32	33	1	https://rdmorganiser.github.io/terms	f
19	personnel	project/costs/pid/personnel		https://rdmorganiser.github.io/terms/domain/project/costs/pid/personnel	17	3	34	35	1	https://rdmorganiser.github.io/terms	f
20	preservation	project/costs/preservation		https://rdmorganiser.github.io/terms/domain/project/costs/preservation	7	2	37	44	1	https://rdmorganiser.github.io/terms	f
21	cover_how	project/costs/preservation/cover_how		https://rdmorganiser.github.io/terms/domain/project/costs/preservation/cover_how	20	3	38	39	1	https://rdmorganiser.github.io/terms	f
22	non_personnel	project/costs/preservation/non_personnel		https://rdmorganiser.github.io/terms/domain/project/costs/preservation/non_personnel	20	3	40	41	1	https://rdmorganiser.github.io/terms	f
270	type	gfbio/data_collection/standards/type		http://example.com/terms/domain/gfbio/data_collection/standards/type	269	3	22	23	3	http://example.com/terms	f
271	documentation_and_metadata	gfbio/documentation_and_metadata		http://example.com/terms/domain/gfbio/documentation_and_metadata	234	1	76	79	3	http://example.com/terms	f
272	metadata_schema_type	gfbio/documentation_and_metadata/metadata_schema_type		http://example.com/terms/domain/gfbio/documentation_and_metadata/metadata_schema_type	271	2	77	78	3	http://example.com/terms	f
273	ethics_and_legal_compliance	gfbio/ethics_and_legal_compliance		http://example.com/terms/domain/gfbio/ethics_and_legal_compliance	234	1	80	93	3	http://example.com/terms	f
274	legal_requirement_type	gfbio/ethics_and_legal_compliance/legal_requirement_type		http://example.com/terms/domain/gfbio/ethics_and_legal_compliance/legal_requirement_type	273	2	81	82	3	http://example.com/terms	f
275	license_type	gfbio/ethics_and_legal_compliance/license_type		http://example.com/terms/domain/gfbio/ethics_and_legal_compliance/license_type	273	2	83	84	3	http://example.com/terms	f
276	acces_restriction_to_data	gfbio/ethics_and_legal_compliance/acces_restriction_to_data		http://example.com/terms/domain/gfbio/ethics_and_legal_compliance/acces_restriction_to_data	273	2	85	86	3	http://example.com/terms	f
277	preservation_and_sharing	gfbio/preservation_and_sharing		http://example.com/terms/domain/gfbio/preservation_and_sharing	234	1	94	103	3	http://example.com/terms	f
278	data_submission_to_GFBio	gfbio/preservation_and_sharing/data_submission_to_GFBio		http://example.com/terms/domain/gfbio/preservation_and_sharing/data_submission_to_GFBio	277	2	95	96	3	http://example.com/terms	f
279	data_backup	gfbio/preservation_and_sharing/data_backup		http://example.com/terms/domain/gfbio/preservation_and_sharing/data_backup	277	2	97	98	3	http://example.com/terms	f
280	place_long_term_archiving	gfbio/preservation_and_sharing/place_long_term_archiving		http://example.com/terms/domain/gfbio/preservation_and_sharing/place_long_term_archiving	277	2	99	100	3	http://example.com/terms	f
281	persistent_identifier_for_data	gfbio/preservation_and_sharing/persistent_identifier_for_data		http://example.com/terms/domain/gfbio/preservation_and_sharing/persistent_identifier_for_data	277	2	101	102	3	http://example.com/terms	f
282	lenght_of_access_restriction	gfbio/ethics_and_legal_compliance/data_sharing_restrictions/lenght_of_access_restriction		http://example.com/terms/domain/gfbio/ethics_and_legal_compliance/data_sharing_restrictions/lenght_of_access_restriction	284	3	88	89	3	http://example.com/terms	f
283	reason_to_exclusive_use_data	gfbio/ethics_and_legal_compliance/data_sharing_restrictions/reason_to_exclusive_use_data		http://example.com/terms/domain/gfbio/ethics_and_legal_compliance/data_sharing_restrictions/reason_to_exclusive_use_data	284	3	90	91	3	http://example.com/terms	f
284	data_sharing_restrictions	gfbio/ethics_and_legal_compliance/data_sharing_restrictions		http://example.com/terms/domain/gfbio/ethics_and_legal_compliance/data_sharing_restrictions	273	2	87	92	3	http://example.com/terms	f
285	object_1	gfbio/data_collection/object_1		http://example.com/terms/domain/gfbio/data_collection/object_1	237	2	25	28	3	http://example.com/terms	f
286	object_2	gfbio/data_collection/object_2		http://example.com/terms/domain/gfbio/data_collection/object_2	237	2	29	32	3	http://example.com/terms	f
287	object_dead_or_alive	gfbio/data_collection/object_1/object_dead_or_alive		http://example.com/terms/domain/gfbio/data_collection/object_1/object_dead_or_alive	285	3	26	27	3	http://example.com/terms	f
23	personnel	project/costs/preservation/personnel		https://rdmorganiser.github.io/terms/domain/project/costs/preservation/personnel	20	3	42	43	1	https://rdmorganiser.github.io/terms	f
24	sensitive_data	project/costs/sensitive_data		https://rdmorganiser.github.io/terms/domain/project/costs/sensitive_data	7	2	45	58	1	https://rdmorganiser.github.io/terms	f
25	anonymization	project/costs/sensitive_data/anonymization		https://rdmorganiser.github.io/terms/domain/project/costs/sensitive_data/anonymization	24	3	46	51	1	https://rdmorganiser.github.io/terms	f
26	non_personnel	project/costs/sensitive_data/anonymization/non_personnel		https://rdmorganiser.github.io/terms/domain/project/costs/sensitive_data/anonymization/non_personnel	25	4	47	48	1	https://rdmorganiser.github.io/terms	f
27	personnel	project/costs/sensitive_data/anonymization/personnel		https://rdmorganiser.github.io/terms/domain/project/costs/sensitive_data/anonymization/personnel	25	4	49	50	1	https://rdmorganiser.github.io/terms	f
28	security	project/costs/sensitive_data/security		https://rdmorganiser.github.io/terms/domain/project/costs/sensitive_data/security	24	3	52	57	1	https://rdmorganiser.github.io/terms	f
29	non_personnel	project/costs/sensitive_data/security/non_personnel		https://rdmorganiser.github.io/terms/domain/project/costs/sensitive_data/security/non_personnel	28	4	53	54	1	https://rdmorganiser.github.io/terms	f
30	personnel	project/costs/sensitive_data/security/personnel		https://rdmorganiser.github.io/terms/domain/project/costs/sensitive_data/security/personnel	28	4	55	56	1	https://rdmorganiser.github.io/terms	f
31	storage	project/costs/storage		https://rdmorganiser.github.io/terms/domain/project/costs/storage	7	2	59	64	1	https://rdmorganiser.github.io/terms	f
32	non_personnel	project/costs/storage/non_personnel		https://rdmorganiser.github.io/terms/domain/project/costs/storage/non_personnel	31	3	60	61	1	https://rdmorganiser.github.io/terms	f
33	personnel	project/costs/storage/personnel		https://rdmorganiser.github.io/terms/domain/project/costs/storage/personnel	31	3	62	63	1	https://rdmorganiser.github.io/terms	f
35	non_personnel	project/costs/usage/non_personnel		https://rdmorganiser.github.io/terms/domain/project/costs/usage/non_personnel	34	3	66	67	1	https://rdmorganiser.github.io/terms	f
36	personnel	project/costs/usage/personnel		https://rdmorganiser.github.io/terms/domain/project/costs/usage/personnel	34	3	68	69	1	https://rdmorganiser.github.io/terms	f
37	data_management	project/data_management		https://rdmorganiser.github.io/terms/domain/project/data_management	1	1	72	75	1	https://rdmorganiser.github.io/terms	f
38	name	project/data_management/name		https://rdmorganiser.github.io/terms/domain/project/data_management/name	37	2	73	74	1	https://rdmorganiser.github.io/terms	f
39	dataset	project/dataset		https://rdmorganiser.github.io/terms/domain/project/dataset	1	1	76	311	1	https://rdmorganiser.github.io/terms	f
40	collaboration_organisation	project/dataset/collaboration_organisation		https://rdmorganiser.github.io/terms/domain/project/dataset/collaboration_organisation	39	2	77	78	1	https://rdmorganiser.github.io/terms	f
41	collaboration_tools	project/dataset/collaboration_tools		https://rdmorganiser.github.io/terms/domain/project/dataset/collaboration_tools	39	2	79	80	1	https://rdmorganiser.github.io/terms	f
42	collaboration_yesno	project/dataset/collaboration_yesno		https://rdmorganiser.github.io/terms/domain/project/dataset/collaboration_yesno	39	2	81	82	1	https://rdmorganiser.github.io/terms	f
43	control_tool	project/dataset/control_tool		https://rdmorganiser.github.io/terms/domain/project/dataset/control_tool	39	2	83	84	1	https://rdmorganiser.github.io/terms	f
44	creation_methods	project/dataset/creation_methods		https://rdmorganiser.github.io/terms/domain/project/dataset/creation_methods	39	2	85	86	1	https://rdmorganiser.github.io/terms	f
45	creator	project/dataset/creator		https://rdmorganiser.github.io/terms/domain/project/dataset/creator	39	2	87	90	1	https://rdmorganiser.github.io/terms	f
46	name	project/dataset/creator/name		https://rdmorganiser.github.io/terms/domain/project/dataset/creator/name	45	3	88	89	1	https://rdmorganiser.github.io/terms	f
47	data_analysis_end	project/dataset/data_analysis_end		https://rdmorganiser.github.io/terms/domain/project/dataset/data_analysis_end	39	2	91	92	1	https://rdmorganiser.github.io/terms	f
48	data_analysis_start	project/dataset/data_analysis_start		https://rdmorganiser.github.io/terms/domain/project/dataset/data_analysis_start	39	2	93	94	1	https://rdmorganiser.github.io/terms	f
49	data_cleansing_end	project/dataset/data_cleansing_end		https://rdmorganiser.github.io/terms/domain/project/dataset/data_cleansing_end	39	2	95	96	1	https://rdmorganiser.github.io/terms	f
50	data_cleansing_start	project/dataset/data_cleansing_start		https://rdmorganiser.github.io/terms/domain/project/dataset/data_cleansing_start	39	2	97	98	1	https://rdmorganiser.github.io/terms	f
51	data_collection_end	project/dataset/data_collection_end		https://rdmorganiser.github.io/terms/domain/project/dataset/data_collection_end	39	2	99	100	1	https://rdmorganiser.github.io/terms	f
52	data_collection_start	project/dataset/data_collection_start		https://rdmorganiser.github.io/terms/domain/project/dataset/data_collection_start	39	2	101	102	1	https://rdmorganiser.github.io/terms	f
53	data_publication_date	project/dataset/data_publication_date		https://rdmorganiser.github.io/terms/domain/project/dataset/data_publication_date	39	2	103	104	1	https://rdmorganiser.github.io/terms	f
54	data_security	project/dataset/data_security		https://rdmorganiser.github.io/terms/domain/project/dataset/data_security	39	2	105	118	1	https://rdmorganiser.github.io/terms	f
55	access_permissions	project/dataset/data_security/access_permissions		https://rdmorganiser.github.io/terms/domain/project/dataset/data_security/access_permissions	54	3	106	107	1	https://rdmorganiser.github.io/terms	f
1	project	project		https://rdmorganiser.github.io/terms/domain/project	\N	0	1	446	1	https://rdmorganiser.github.io/terms	f
56	backup_responsible	project/dataset/data_security/backup_responsible		https://rdmorganiser.github.io/terms/domain/project/dataset/data_security/backup_responsible	54	3	108	111	1	https://rdmorganiser.github.io/terms	f
57	name	project/dataset/data_security/backup_responsible/name		https://rdmorganiser.github.io/terms/domain/project/dataset/data_security/backup_responsible/name	56	4	109	110	1	https://rdmorganiser.github.io/terms	f
58	backups	project/dataset/data_security/backups		https://rdmorganiser.github.io/terms/domain/project/dataset/data_security/backups	54	3	112	113	1	https://rdmorganiser.github.io/terms	f
59	risks	project/dataset/data_security/risks		https://rdmorganiser.github.io/terms/domain/project/dataset/data_security/risks	54	3	114	115	1	https://rdmorganiser.github.io/terms	f
60	security_measures	project/dataset/data_security/security_measures		https://rdmorganiser.github.io/terms/domain/project/dataset/data_security/security_measures	54	3	116	117	1	https://rdmorganiser.github.io/terms	f
61	description	project/dataset/description		https://rdmorganiser.github.io/terms/domain/project/dataset/description	39	2	119	120	1	https://rdmorganiser.github.io/terms	f
62	format	project/dataset/format		https://rdmorganiser.github.io/terms/domain/project/dataset/format	39	2	121	122	1	https://rdmorganiser.github.io/terms	f
63	id	project/dataset/id		https://rdmorganiser.github.io/terms/domain/project/dataset/id	39	2	123	124	1	https://rdmorganiser.github.io/terms	f
64	include_software	project/dataset/include_software		https://rdmorganiser.github.io/terms/domain/project/dataset/include_software	39	2	125	126	1	https://rdmorganiser.github.io/terms	f
65	integration	project/dataset/integration		https://rdmorganiser.github.io/terms/domain/project/dataset/integration	39	2	127	128	1	https://rdmorganiser.github.io/terms	f
66	interoperability	project/dataset/interoperability		https://rdmorganiser.github.io/terms/domain/project/dataset/interoperability	39	2	129	130	1	https://rdmorganiser.github.io/terms	f
67	ipr	project/dataset/ipr		https://rdmorganiser.github.io/terms/domain/project/dataset/ipr	39	2	131	140	1	https://rdmorganiser.github.io/terms	f
68	copyrights	project/dataset/ipr/copyrights		https://rdmorganiser.github.io/terms/domain/project/dataset/ipr/copyrights	67	3	132	133	1	https://rdmorganiser.github.io/terms	f
69	other_rights	project/dataset/ipr/other_rights		https://rdmorganiser.github.io/terms/domain/project/dataset/ipr/other_rights	67	3	134	135	1	https://rdmorganiser.github.io/terms	f
70	owner	project/dataset/ipr/owner		https://rdmorganiser.github.io/terms/domain/project/dataset/ipr/owner	67	3	136	139	1	https://rdmorganiser.github.io/terms	f
71	name	project/dataset/ipr/owner/name		https://rdmorganiser.github.io/terms/domain/project/dataset/ipr/owner/name	70	4	137	138	1	https://rdmorganiser.github.io/terms	f
72	metadata	project/dataset/metadata		https://rdmorganiser.github.io/terms/domain/project/dataset/metadata	39	2	141	170	1	https://rdmorganiser.github.io/terms	f
73	creation	project/dataset/metadata/creation		https://rdmorganiser.github.io/terms/domain/project/dataset/metadata/creation	72	3	142	143	1	https://rdmorganiser.github.io/terms	f
74	creation_automatic	project/dataset/metadata/creation_automatic		https://rdmorganiser.github.io/terms/domain/project/dataset/metadata/creation_automatic	72	3	144	145	1	https://rdmorganiser.github.io/terms	f
75	creation_manual	project/dataset/metadata/creation_manual		https://rdmorganiser.github.io/terms/domain/project/dataset/metadata/creation_manual	72	3	146	147	1	https://rdmorganiser.github.io/terms	f
76	creation_semi_automatic	project/dataset/metadata/creation_semi_automatic		https://rdmorganiser.github.io/terms/domain/project/dataset/metadata/creation_semi_automatic	72	3	148	149	1	https://rdmorganiser.github.io/terms	f
77	mappings	project/dataset/metadata/mappings		https://rdmorganiser.github.io/terms/domain/project/dataset/metadata/mappings	72	3	150	151	1	https://rdmorganiser.github.io/terms	f
78	public	project/dataset/metadata/public		https://rdmorganiser.github.io/terms/domain/project/dataset/metadata/public	72	3	152	153	1	https://rdmorganiser.github.io/terms	f
79	quality_assurance	project/dataset/metadata/quality_assurance		https://rdmorganiser.github.io/terms/domain/project/dataset/metadata/quality_assurance	72	3	154	155	1	https://rdmorganiser.github.io/terms	f
80	responsible_person	project/dataset/metadata/responsible_person		https://rdmorganiser.github.io/terms/domain/project/dataset/metadata/responsible_person	72	3	156	159	1	https://rdmorganiser.github.io/terms	f
81	name	project/dataset/metadata/responsible_person/name		https://rdmorganiser.github.io/terms/domain/project/dataset/metadata/responsible_person/name	80	4	157	158	1	https://rdmorganiser.github.io/terms	f
82	scope	project/dataset/metadata/scope		https://rdmorganiser.github.io/terms/domain/project/dataset/metadata/scope	72	3	160	161	1	https://rdmorganiser.github.io/terms	f
83	standards	project/dataset/metadata/standards		https://rdmorganiser.github.io/terms/domain/project/dataset/metadata/standards	72	3	162	163	1	https://rdmorganiser.github.io/terms	f
87	responsible_person	project/dataset/pids/responsible_person		https://rdmorganiser.github.io/terms/domain/project/dataset/pids/responsible_person	86	3	176	179	1	https://rdmorganiser.github.io/terms	f
88	name	project/dataset/pids/responsible_person/name		https://rdmorganiser.github.io/terms/domain/project/dataset/pids/responsible_person/name	87	4	177	178	1	https://rdmorganiser.github.io/terms	f
89	subentities	project/dataset/pids/subentities		https://rdmorganiser.github.io/terms/domain/project/dataset/pids/subentities	86	3	180	181	1	https://rdmorganiser.github.io/terms	f
90	system	project/dataset/pids/system		https://rdmorganiser.github.io/terms/domain/project/dataset/pids/system	86	3	182	183	1	https://rdmorganiser.github.io/terms	f
91	yesno	project/dataset/pids/yesno		https://rdmorganiser.github.io/terms/domain/project/dataset/pids/yesno	86	3	184	185	1	https://rdmorganiser.github.io/terms	f
92	preservation	project/dataset/preservation		https://rdmorganiser.github.io/terms/domain/project/dataset/preservation	39	2	187	214	1	https://rdmorganiser.github.io/terms	f
93	access_authentication	project/dataset/preservation/access_authentication		https://rdmorganiser.github.io/terms/domain/project/dataset/preservation/access_authentication	92	3	188	189	1	https://rdmorganiser.github.io/terms	f
94	certification	project/dataset/preservation/certification		https://rdmorganiser.github.io/terms/domain/project/dataset/preservation/certification	92	3	190	191	1	https://rdmorganiser.github.io/terms	f
95	data_archiving_date	project/dataset/preservation/data_archiving_date		https://rdmorganiser.github.io/terms/domain/project/dataset/preservation/data_archiving_date	92	3	192	193	1	https://rdmorganiser.github.io/terms	f
96	duration	project/dataset/preservation/duration		https://rdmorganiser.github.io/terms/domain/project/dataset/preservation/duration	92	3	194	195	1	https://rdmorganiser.github.io/terms	f
97	embargo_period	project/dataset/preservation/embargo_period		https://rdmorganiser.github.io/terms/domain/project/dataset/preservation/embargo_period	92	3	196	197	1	https://rdmorganiser.github.io/terms	f
98	purpose	project/dataset/preservation/purpose		https://rdmorganiser.github.io/terms/domain/project/dataset/preservation/purpose	92	3	198	199	1	https://rdmorganiser.github.io/terms	f
99	repository	project/dataset/preservation/repository		https://rdmorganiser.github.io/terms/domain/project/dataset/preservation/repository	92	3	200	201	1	https://rdmorganiser.github.io/terms	f
108	other	project/dataset/sensitive_data/other		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data/other	107	3	224	229	1	https://rdmorganiser.github.io/terms	f
109	description	project/dataset/sensitive_data/other/description		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data/other/description	108	4	225	226	1	https://rdmorganiser.github.io/terms	f
110	yesno	project/dataset/sensitive_data/other/yesno		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data/other/yesno	108	4	227	228	1	https://rdmorganiser.github.io/terms	f
111	personal_data	project/dataset/sensitive_data/personal_data		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data/personal_data	107	3	230	245	1	https://rdmorganiser.github.io/terms	f
112	anonymization	project/dataset/sensitive_data/personal_data/anonymization		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data/personal_data/anonymization	111	4	231	232	1	https://rdmorganiser.github.io/terms	f
113	bdsg_3_9	project/dataset/sensitive_data/personal_data/bdsg_3_9		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data/personal_data/bdsg_3_9	111	4	233	234	1	https://rdmorganiser.github.io/terms	f
114	consent	project/dataset/sensitive_data/personal_data/consent		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data/personal_data/consent	111	4	235	242	1	https://rdmorganiser.github.io/terms	f
115	extent	project/dataset/sensitive_data/personal_data/consent/extent		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data/personal_data/consent/extent	114	5	236	237	1	https://rdmorganiser.github.io/terms	f
116	record	project/dataset/sensitive_data/personal_data/consent/record		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data/personal_data/consent/record	114	5	238	239	1	https://rdmorganiser.github.io/terms	f
117	statement	project/dataset/sensitive_data/personal_data/consent/statement		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data/personal_data/consent/statement	114	5	240	241	1	https://rdmorganiser.github.io/terms	f
118	deletion	project/dataset/sensitive_data/personal_data/deletion		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data/personal_data/deletion	111	4	243	244	1	https://rdmorganiser.github.io/terms	f
119	personal_data_yesno	project/dataset/sensitive_data/personal_data_yesno		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data/personal_data_yesno	107	3	246	249	1	https://rdmorganiser.github.io/terms	f
120	yesno	project/dataset/sensitive_data/personal_data_yesno/yesno		https://rdmorganiser.github.io/terms/domain/project/dataset/sensitive_data/personal_data_yesno/yesno	119	4	247	248	1	https://rdmorganiser.github.io/terms	f
121	sharing	project/dataset/sharing		https://rdmorganiser.github.io/terms/domain/project/dataset/sharing	39	2	251	264	1	https://rdmorganiser.github.io/terms	f
122	conditions	project/dataset/sharing/conditions		https://rdmorganiser.github.io/terms/domain/project/dataset/sharing/conditions	121	3	252	253	1	https://rdmorganiser.github.io/terms	f
123	explanation	project/dataset/sharing/explanation		https://rdmorganiser.github.io/terms/domain/project/dataset/sharing/explanation	121	3	254	255	1	https://rdmorganiser.github.io/terms	f
124	findability	project/dataset/sharing/findability		https://rdmorganiser.github.io/terms/domain/project/dataset/sharing/findability	121	3	256	257	1	https://rdmorganiser.github.io/terms	f
125	restrictions_explanation	project/dataset/sharing/restrictions_explanation		https://rdmorganiser.github.io/terms/domain/project/dataset/sharing/restrictions_explanation	121	3	258	259	1	https://rdmorganiser.github.io/terms	f
126	sharing_license	project/dataset/sharing/sharing_license		https://rdmorganiser.github.io/terms/domain/project/dataset/sharing/sharing_license	121	3	260	261	1	https://rdmorganiser.github.io/terms	f
127	yesno	project/dataset/sharing/yesno		https://rdmorganiser.github.io/terms/domain/project/dataset/sharing/yesno	121	3	262	263	1	https://rdmorganiser.github.io/terms	f
128	size	project/dataset/size		https://rdmorganiser.github.io/terms/domain/project/dataset/size	39	2	265	270	1	https://rdmorganiser.github.io/terms	f
129	number_files	project/dataset/size/number_files		https://rdmorganiser.github.io/terms/domain/project/dataset/size/number_files	128	3	266	267	1	https://rdmorganiser.github.io/terms	f
133	naming_policy	project/dataset/storage/naming_policy		https://rdmorganiser.github.io/terms/domain/project/dataset/storage/naming_policy	132	3	274	275	1	https://rdmorganiser.github.io/terms	f
134	organisation_policy	project/dataset/storage/organisation_policy		https://rdmorganiser.github.io/terms/domain/project/dataset/storage/organisation_policy	132	3	276	277	1	https://rdmorganiser.github.io/terms	f
135	type	project/dataset/storage/type		https://rdmorganiser.github.io/terms/domain/project/dataset/storage/type	132	3	278	279	1	https://rdmorganiser.github.io/terms	f
136	uri	project/dataset/storage/uri		https://rdmorganiser.github.io/terms/domain/project/dataset/storage/uri	132	3	280	281	1	https://rdmorganiser.github.io/terms	f
137	structure	project/dataset/structure		https://rdmorganiser.github.io/terms/domain/project/dataset/structure	39	2	283	284	1	https://rdmorganiser.github.io/terms	f
138	title	project/dataset/title		https://rdmorganiser.github.io/terms/domain/project/dataset/title	39	2	285	286	1	https://rdmorganiser.github.io/terms	f
139	uri	project/dataset/uri		https://rdmorganiser.github.io/terms/domain/project/dataset/uri	39	2	287	288	1	https://rdmorganiser.github.io/terms	f
140	usage_description	project/dataset/usage_description		https://rdmorganiser.github.io/terms/domain/project/dataset/usage_description	39	2	289	290	1	https://rdmorganiser.github.io/terms	f
141	usage_frequency	project/dataset/usage_frequency		https://rdmorganiser.github.io/terms/domain/project/dataset/usage_frequency	39	2	291	292	1	https://rdmorganiser.github.io/terms	f
142	usage_infrastructure	project/dataset/usage_infrastructure		https://rdmorganiser.github.io/terms/domain/project/dataset/usage_infrastructure	39	2	293	294	1	https://rdmorganiser.github.io/terms	f
160	international_yesno	project/legal_aspects/international_yesno		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/international_yesno	159	2	335	336	1	https://rdmorganiser.github.io/terms	f
161	ipr	project/legal_aspects/ipr		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/ipr	159	2	337	340	1	https://rdmorganiser.github.io/terms	f
162	yesno	project/legal_aspects/ipr/yesno		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/ipr/yesno	161	3	338	339	1	https://rdmorganiser.github.io/terms	f
163	official_approval	project/legal_aspects/official_approval		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/official_approval	159	2	341	354	1	https://rdmorganiser.github.io/terms	f
164	data_access_committee	project/legal_aspects/official_approval/data_access_committee		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/official_approval/data_access_committee	163	3	342	343	1	https://rdmorganiser.github.io/terms	f
165	ethics_committee	project/legal_aspects/official_approval/ethics_committee		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/official_approval/ethics_committee	163	3	344	345	1	https://rdmorganiser.github.io/terms	f
166	statutatory_approval	project/legal_aspects/official_approval/statutatory_approval		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/official_approval/statutatory_approval	163	3	346	353	1	https://rdmorganiser.github.io/terms	f
167	agency	project/legal_aspects/official_approval/statutatory_approval/agency		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/official_approval/statutatory_approval/agency	166	4	347	348	1	https://rdmorganiser.github.io/terms	f
168	title	project/legal_aspects/official_approval/statutatory_approval/title		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/official_approval/statutatory_approval/title	166	4	349	350	1	https://rdmorganiser.github.io/terms	f
169	yesno	project/legal_aspects/official_approval/statutatory_approval/yesno		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/official_approval/statutatory_approval/yesno	166	4	351	352	1	https://rdmorganiser.github.io/terms	f
170	sensitive_data	project/legal_aspects/sensitive_data		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/sensitive_data	159	2	355	368	1	https://rdmorganiser.github.io/terms	f
171	other	project/legal_aspects/sensitive_data/other		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/sensitive_data/other	170	3	356	359	1	https://rdmorganiser.github.io/terms	f
172	yesno	project/legal_aspects/sensitive_data/other/yesno		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/sensitive_data/other/yesno	171	4	357	358	1	https://rdmorganiser.github.io/terms	f
173	personal_data	project/legal_aspects/sensitive_data/personal_data		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/sensitive_data/personal_data	170	3	360	363	1	https://rdmorganiser.github.io/terms	f
174	yesno	project/legal_aspects/sensitive_data/personal_data/yesno		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/sensitive_data/personal_data/yesno	173	4	361	362	1	https://rdmorganiser.github.io/terms	f
175	privacy_law	project/legal_aspects/sensitive_data/privacy_law		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/sensitive_data/privacy_law	170	3	364	365	1	https://rdmorganiser.github.io/terms	f
176	yesno	project/legal_aspects/sensitive_data/yesno		https://rdmorganiser.github.io/terms/domain/project/legal_aspects/sensitive_data/yesno	170	3	366	367	1	https://rdmorganiser.github.io/terms	f
177	partner	project/partner		https://rdmorganiser.github.io/terms/domain/project/partner	1	1	370	387	1	https://rdmorganiser.github.io/terms	f
178	agreement	project/partner/agreement		https://rdmorganiser.github.io/terms/domain/project/partner/agreement	177	2	371	372	1	https://rdmorganiser.github.io/terms	f
179	contact_person	project/partner/contact_person		https://rdmorganiser.github.io/terms/domain/project/partner/contact_person	177	2	373	378	1	https://rdmorganiser.github.io/terms	f
180	name	project/partner/contact_person/name		https://rdmorganiser.github.io/terms/domain/project/partner/contact_person/name	179	3	374	375	1	https://rdmorganiser.github.io/terms	f
181	phone	project/partner/contact_person/phone		https://rdmorganiser.github.io/terms/domain/project/partner/contact_person/phone	179	3	376	377	1	https://rdmorganiser.github.io/terms	f
182	id	project/partner/id		https://rdmorganiser.github.io/terms/domain/project/partner/id	177	2	379	380	1	https://rdmorganiser.github.io/terms	f
183	name	project/partner/name		https://rdmorganiser.github.io/terms/domain/project/partner/name	177	2	381	382	1	https://rdmorganiser.github.io/terms	f
184	rdm_policy	project/partner/rdm_policy		https://rdmorganiser.github.io/terms/domain/project/partner/rdm_policy	177	2	383	384	1	https://rdmorganiser.github.io/terms	f
185	responsibilities	project/partner/responsibilities		https://rdmorganiser.github.io/terms/domain/project/partner/responsibilities	177	2	385	386	1	https://rdmorganiser.github.io/terms	f
186	physical_objects	project/physical_objects		https://rdmorganiser.github.io/terms/domain/project/physical_objects	1	1	388	389	1	https://rdmorganiser.github.io/terms	f
187	preservation	project/preservation		https://rdmorganiser.github.io/terms/domain/project/preservation	1	1	390	413	1	https://rdmorganiser.github.io/terms	f
188	archive	project/preservation/archive		https://rdmorganiser.github.io/terms/domain/project/preservation/archive	187	2	391	402	1	https://rdmorganiser.github.io/terms	f
189	fair_archive	project/preservation/archive/fair_archive		https://rdmorganiser.github.io/terms/domain/project/preservation/archive/fair_archive	188	3	392	393	1	https://rdmorganiser.github.io/terms	f
190	nonprofit	project/preservation/archive/nonprofit		https://rdmorganiser.github.io/terms/domain/project/preservation/archive/nonprofit	188	3	394	399	1	https://rdmorganiser.github.io/terms	f
191	explanation	project/preservation/archive/nonprofit/explanation		https://rdmorganiser.github.io/terms/domain/project/preservation/archive/nonprofit/explanation	190	4	395	396	1	https://rdmorganiser.github.io/terms	f
192	yesno	project/preservation/archive/nonprofit/yesno		https://rdmorganiser.github.io/terms/domain/project/preservation/archive/nonprofit/yesno	190	4	397	398	1	https://rdmorganiser.github.io/terms	f
193	yesno	project/preservation/archive/yesno		https://rdmorganiser.github.io/terms/domain/project/preservation/archive/yesno	188	3	400	401	1	https://rdmorganiser.github.io/terms	f
194	responsible_person	project/preservation/responsible_person		https://rdmorganiser.github.io/terms/domain/project/preservation/responsible_person	187	2	403	406	1	https://rdmorganiser.github.io/terms	f
196	retained	project/preservation/retained		https://rdmorganiser.github.io/terms/domain/project/preservation/retained	187	2	407	408	1	https://rdmorganiser.github.io/terms	f
195	name	project/preservation/responsible_person/name		https://rdmorganiser.github.io/terms/domain/project/preservation/responsible_person/name	194	3	404	405	1	https://rdmorganiser.github.io/terms	f
197	selection_criteria	project/preservation/selection_criteria		https://rdmorganiser.github.io/terms/domain/project/preservation/selection_criteria	187	2	409	410	1	https://rdmorganiser.github.io/terms	f
198	selection_format	project/preservation/selection_format		https://rdmorganiser.github.io/terms/domain/project/preservation/selection_format	187	2	411	412	1	https://rdmorganiser.github.io/terms	f
199	research_field	project/research_field		https://rdmorganiser.github.io/terms/domain/project/research_field	1	1	414	417	1	https://rdmorganiser.github.io/terms	f
200	title	project/research_field/title		https://rdmorganiser.github.io/terms/domain/project/research_field/title	199	2	415	416	1	https://rdmorganiser.github.io/terms	f
201	research_question	project/research_question		https://rdmorganiser.github.io/terms/domain/project/research_question	1	1	418	423	1	https://rdmorganiser.github.io/terms	f
202	keywords	project/research_question/keywords		https://rdmorganiser.github.io/terms/domain/project/research_question/keywords	201	2	419	420	1	https://rdmorganiser.github.io/terms	f
203	title	project/research_question/title		https://rdmorganiser.github.io/terms/domain/project/research_question/title	201	2	421	422	1	https://rdmorganiser.github.io/terms	f
204	schedule	project/schedule		https://rdmorganiser.github.io/terms/domain/project/schedule	1	1	424	429	1	https://rdmorganiser.github.io/terms	f
205	project_end	project/schedule/project_end		https://rdmorganiser.github.io/terms/domain/project/schedule/project_end	204	2	425	426	1	https://rdmorganiser.github.io/terms	f
206	project_start	project/schedule/project_start		https://rdmorganiser.github.io/terms/domain/project/schedule/project_start	204	2	427	428	1	https://rdmorganiser.github.io/terms	f
207	support	project/support		https://rdmorganiser.github.io/terms/domain/project/support	1	1	430	435	1	https://rdmorganiser.github.io/terms	f
208	costs	project/support/costs		https://rdmorganiser.github.io/terms/domain/project/support/costs	207	2	431	432	1	https://rdmorganiser.github.io/terms	f
209	yesno	project/support/yesno		https://rdmorganiser.github.io/terms/domain/project/support/yesno	207	2	433	434	1	https://rdmorganiser.github.io/terms	f
\.


--
-- Data for Name: options_option; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.options_option (id, key, "order", text_lang1, text_lang2, additional_input, optionset_id, comment, uri, uri_prefix, path, text_lang3, text_lang4, text_lang5, locked) FROM stdin;
1	1	0	Calibration procedure	Kalibrierverfahren	t	1		https://rdmorganiser.github.io/terms/options/control_tools/1	https://rdmorganiser.github.io/terms	control_tools/1				f
2	2	1	Repeated measurements	Wiederholte Messungen	t	1		https://rdmorganiser.github.io/terms/options/control_tools/2	https://rdmorganiser.github.io/terms	control_tools/2				f
3	3	2	Standards for data recording	Datenaufzeichnungsstandards	t	1		https://rdmorganiser.github.io/terms/options/control_tools/3	https://rdmorganiser.github.io/terms	control_tools/3				f
4	4	3	Controlled vocabularies or standard terminology	Kontrollierte Vokabulare oder standardisierte Terminologien	t	1		https://rdmorganiser.github.io/terms/options/control_tools/4	https://rdmorganiser.github.io/terms	control_tools/4				f
5	5	4	Validation of the data collection	Validierung der Datenerfassung	t	1		https://rdmorganiser.github.io/terms/options/control_tools/5	https://rdmorganiser.github.io/terms	control_tools/5				f
6	6	5	Peer reviews of the data	Peer reviews der Daten	t	1		https://rdmorganiser.github.io/terms/options/control_tools/6	https://rdmorganiser.github.io/terms	control_tools/6				f
7	7	6	Others	Sonstiges	t	1		https://rdmorganiser.github.io/terms/options/control_tools/7	https://rdmorganiser.github.io/terms	control_tools/7				f
8	155	100	Other	Sonstiges	t	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/155	https://rdmorganiser.github.io/terms	data_protection_laws/155				f
9	21	1	Bundesdatenschutzgesetz (BDSG, Federal Data Protection Act)	Bundesdatenschutzgesetz (BDSG)	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/21	https://rdmorganiser.github.io/terms	data_protection_laws/21				f
10	22	2	Landesdatenschutzgesetz Baden-Württemberg (State Data Protection Act of Baden-Württemberg)	Landesdatenschutzgesetz Baden-Württemberg	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/22	https://rdmorganiser.github.io/terms	data_protection_laws/22				f
11	23	3	Landesdatenschutzgesetz Bayern (State Data Protection Act of Bavaria)	Landesdatenschutzgesetz Bayern	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/23	https://rdmorganiser.github.io/terms	data_protection_laws/23				f
12	24	4	Landesdatenschutzgesetz Berlin (State Data Protection Act of Berlin)	Landesdatenschutzgesetz Berlin	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/24	https://rdmorganiser.github.io/terms	data_protection_laws/24				f
13	25	5	Landesdatenschutzgesetz Bremen (State Data Protection Act of Bremen)	Landesdatenschutzgesetz Bremen	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/25	https://rdmorganiser.github.io/terms	data_protection_laws/25				f
14	26	6	Landesdatenschutzgesetz Brandenburg (State Data Protection Act of Brandenburg)	Landesdatenschutzgesetz Brandenburg	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/26	https://rdmorganiser.github.io/terms	data_protection_laws/26				f
15	27	7	Landesdatenschutzgesetz Hamburg (State Data Protection Act of Hamburg)	Landesdatenschutzgesetz Hamburg	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/27	https://rdmorganiser.github.io/terms	data_protection_laws/27				f
16	28	8	Landesdatenschutzgesetz Mecklenburg-Vorpommern (State Data Protection Act of Mecklenburg-Vorpommern)	Landesdatenschutzgesetz Mecklenburg-Vorpommern	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/28	https://rdmorganiser.github.io/terms	data_protection_laws/28				f
17	29	9	Landesdatenschutzgesetz Hessen (State Data Protection Act of Hesse)	Landesdatenschutzgesetz Hessen	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/29	https://rdmorganiser.github.io/terms	data_protection_laws/29				f
18	30	10	Landesdatenschutzgesetz Nordrhein-Westfalen (State Data Protection Act of North Rhine-Westphalia)	Landesdatenschutzgesetz Nordrhein-Westfalen	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/30	https://rdmorganiser.github.io/terms	data_protection_laws/30				f
19	31	11	Landesdatenschutzgesetz Rheinland-Pfalz (State Data Protection Act of Rhineland-Palatinate)	Landesdatenschutzgesetz Rheinland-Pfalz	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/31	https://rdmorganiser.github.io/terms	data_protection_laws/31				f
20	32	12	Landesdatenschutzgesetz Niedersachsen (State Data Protection Act of Lower Saxony)	Landesdatenschutzgesetz Niedersachsen	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/32	https://rdmorganiser.github.io/terms	data_protection_laws/32				f
21	33	13	Landesdatenschutzgesetz Saarland (State Data Protection Act of Saarland)	Landesdatenschutzgesetz Saarland	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/33	https://rdmorganiser.github.io/terms	data_protection_laws/33				f
22	34	14	Landesdatenschutzgesetz Sachsen (State Data Protection Act of Saxony)	Landesdatenschutzgesetz Sachsen	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/34	https://rdmorganiser.github.io/terms	data_protection_laws/34				f
23	35	15	Landesdatenschutzgesetz Sachsen-Anhalt (State Data Protection Act of Saxony-Anhalt)	Landesdatenschutzgesetz Sachsen-Anhalt	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/35	https://rdmorganiser.github.io/terms	data_protection_laws/35				f
24	36	16	Landesdatenschutzgesetz Schleswig-Holstein (State Data Protection Act of Schleswig-Holstein)	Landesdatenschutzgesetz Schleswig-Holstein	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/36	https://rdmorganiser.github.io/terms	data_protection_laws/36				f
25	37	17	Landesdatenschutzgesetz Thüringen (State Data Protection Act of Thuringia)	Landesdatenschutzgesetz Thüringen	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/37	https://rdmorganiser.github.io/terms	data_protection_laws/37				f
26	38	18	Sozialgesetzbuch X (Social Security Act X), e.g. for medical data	Sozialgesetzbuch X (z.B. für medizinische Daten)	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/38	https://rdmorganiser.github.io/terms	data_protection_laws/38				f
27	39	19	Bundesstatistikgesetz (Federal Statistics Act), e.g. for census data	Bundesstatistikgesetz (z.B. für Zensusdaten)	f	2		https://rdmorganiser.github.io/terms/options/data_protection_laws/39	https://rdmorganiser.github.io/terms	data_protection_laws/39				f
28	40	4	No	Nein	f	3		https://rdmorganiser.github.io/terms/options/dataset_anonymisation/40	https://rdmorganiser.github.io/terms	dataset_anonymisation/40				f
29	41	1	Yes, during the collection	Ja, während der Erhebung	f	3		https://rdmorganiser.github.io/terms/options/dataset_anonymisation/41	https://rdmorganiser.github.io/terms	dataset_anonymisation/41				f
30	42	3	Yes, after the data analysis / before publication	Ja, nach der Datenanalyse / vor der Publikation	f	3		https://rdmorganiser.github.io/terms/options/dataset_anonymisation/42	https://rdmorganiser.github.io/terms	dataset_anonymisation/42				f
31	43	2	Yes, before / at the beginning of the data analysis	Ja, vor / zu Beginn der Datenanalyse	f	3		https://rdmorganiser.github.io/terms/options/dataset_anonymisation/43	https://rdmorganiser.github.io/terms	dataset_anonymisation/43				f
32	127	2	Yes, by multiple persons of the same workgroup at the same institution	Ja, von mehreren Personen derselben Arbeitsgruppe an derselben Institution	f	4		https://rdmorganiser.github.io/terms/options/dataset_collaboration_options/127	https://rdmorganiser.github.io/terms	dataset_collaboration_options/127				f
33	128	3	No	Nein	f	4		https://rdmorganiser.github.io/terms/options/dataset_collaboration_options/128	https://rdmorganiser.github.io/terms	dataset_collaboration_options/128				f
34	129	1	Yes, by several persons at various institutions	Ja, von mehreren Personen an verschiedenen Institutionen	f	4		https://rdmorganiser.github.io/terms/options/dataset_collaboration_options/129	https://rdmorganiser.github.io/terms	dataset_collaboration_options/129				f
35	50	1	work of literature, scholarship or the arts	Werk der Literatur, Wissenschaft oder Kunst	f	5		https://rdmorganiser.github.io/terms/options/dataset_copyright_laws/50	https://rdmorganiser.github.io/terms	dataset_copyright_laws/50				f
36	51	2	translation or other edition of a work	Übersetzung oder andere Bearbeitung eines Werkes	f	5		https://rdmorganiser.github.io/terms/options/dataset_copyright_laws/51	https://rdmorganiser.github.io/terms	dataset_copyright_laws/51				f
37	52	3	collected edition or database work	Sammelwerk oder Datenbankwerk	f	5		https://rdmorganiser.github.io/terms/options/dataset_copyright_laws/52	https://rdmorganiser.github.io/terms	dataset_copyright_laws/52				f
38	55	6	Other	Andere	t	5		https://rdmorganiser.github.io/terms/options/dataset_copyright_laws/55	https://rdmorganiser.github.io/terms	dataset_copyright_laws/55				f
39	56	7	No	Nein	f	5		https://rdmorganiser.github.io/terms/options/dataset_copyright_laws/56	https://rdmorganiser.github.io/terms	dataset_copyright_laws/56				f
40	256	4	Other aspects in terms of interoperability	Weitere für die Interoperabilität wichtige Aspekte	t	6		https://rdmorganiser.github.io/terms/options/dataset_interoperability_options/256	https://rdmorganiser.github.io/terms	dataset_interoperability_options/256				f
41	257	2	The dataset is usable with availabe (open) software applications or software applications that are established and widely used in the respective community	Der Datensatz ist mit verfügbarer (offener) Software bzw. mit in der jeweiligen Community etablierter und vielgenutzter Software nutzbar	t	6		https://rdmorganiser.github.io/terms/options/dataset_interoperability_options/257	https://rdmorganiser.github.io/terms	dataset_interoperability_options/257				f
42	258	3	The dataset can easily be re-combined with different datasets from different origins	Der Datensatz kann ohne großen Aufwand mit verschiedenen anderen Datensätzen aus unterschiedlichen Quellen rekombiniert werden	t	6		https://rdmorganiser.github.io/terms/options/dataset_interoperability_options/258	https://rdmorganiser.github.io/terms	dataset_interoperability_options/258				f
43	259	1	The dataset adheres to standardised formats	Für den Datensatz werden standardisierte Formate genutzt	t	6		https://rdmorganiser.github.io/terms/options/dataset_interoperability_options/259	https://rdmorganiser.github.io/terms	dataset_interoperability_options/259				f
44	238	1	Yet to be determined	Noch zu klären	f	7		https://rdmorganiser.github.io/terms/options/dataset_license_options/238	https://rdmorganiser.github.io/terms	dataset_license_options/238				f
45	239	0	The dataset will be published under the followig license	Der Datensatz wird unter folgender Lizenz veröffentlicht	t	7		https://rdmorganiser.github.io/terms/options/dataset_license_options/239	https://rdmorganiser.github.io/terms	dataset_license_options/239				f
46	233	6	Other	Andere	t	8		https://rdmorganiser.github.io/terms/options/dataset_license_types/233	https://rdmorganiser.github.io/terms	dataset_license_types/233				f
47	71	1	Attribution (BY)	Namensnennung (BY)	f	8		https://rdmorganiser.github.io/terms/options/dataset_license_types/71	https://rdmorganiser.github.io/terms	dataset_license_types/71				f
48	73	2	Non-commercial (NC)	keine kommerzielle Nutzung (NC)	f	8		https://rdmorganiser.github.io/terms/options/dataset_license_types/73	https://rdmorganiser.github.io/terms	dataset_license_types/73				f
49	74	3	No derivative work (ND)	keine Bearbeitung (ND)	f	8		https://rdmorganiser.github.io/terms/options/dataset_license_types/74	https://rdmorganiser.github.io/terms	dataset_license_types/74				f
50	75	4	Share-alike (SA)	Weitergabe unter gleichen Bedingungen (SA)	f	8		https://rdmorganiser.github.io/terms/options/dataset_license_types/75	https://rdmorganiser.github.io/terms	dataset_license_types/75				f
51	cc0	5	Public domain (CC0)	Gemeinfrei (CC0)	f	8		https://rdmorganiser.github.io/terms/options/dataset_license_types/cc0	https://rdmorganiser.github.io/terms	dataset_license_types/cc0				f
52	147	2	Re-used	Nachgenutzt	f	9		https://rdmorganiser.github.io/terms/options/dataset_origin_options/147	https://rdmorganiser.github.io/terms	dataset_origin_options/147				f
53	148	1	Created	Erzeugt	f	9		https://rdmorganiser.github.io/terms/options/dataset_origin_options/148	https://rdmorganiser.github.io/terms	dataset_origin_options/148				f
54	56	1	patent	Patent	f	10		https://rdmorganiser.github.io/terms/options/dataset_other_rights/56	https://rdmorganiser.github.io/terms	dataset_other_rights/56				f
55	57	2	utility model	Gebrauchsmuster	f	10		https://rdmorganiser.github.io/terms/options/dataset_other_rights/57	https://rdmorganiser.github.io/terms	dataset_other_rights/57				f
56	58	3	trademark	Marke	f	10		https://rdmorganiser.github.io/terms/options/dataset_other_rights/58	https://rdmorganiser.github.io/terms	dataset_other_rights/58				f
57	59	4	plant variety rights protection	Sortenschutz	f	10		https://rdmorganiser.github.io/terms/options/dataset_other_rights/59	https://rdmorganiser.github.io/terms	dataset_other_rights/59				f
58	60	5	integrated circuit layout design protection	Halbleiterschutz	f	10		https://rdmorganiser.github.io/terms/options/dataset_other_rights/60	https://rdmorganiser.github.io/terms	dataset_other_rights/60				f
59	61	6	geographical indication	geographische Herkunftsangabe	f	10		https://rdmorganiser.github.io/terms/options/dataset_other_rights/61	https://rdmorganiser.github.io/terms	dataset_other_rights/61				f
60	62	7	registered design	eingetragenes Design	f	10		https://rdmorganiser.github.io/terms/options/dataset_other_rights/62	https://rdmorganiser.github.io/terms	dataset_other_rights/62				f
61	65	10	Other	Andere	t	10		https://rdmorganiser.github.io/terms/options/dataset_other_rights/65	https://rdmorganiser.github.io/terms	dataset_other_rights/65				f
62	66	11	No	Nein	f	10		https://rdmorganiser.github.io/terms/options/dataset_other_rights/66	https://rdmorganiser.github.io/terms	dataset_other_rights/66				f
63	2	0	yes, with little effort	ja, mit geringem Aufwand	f	11		https://rdmorganiser.github.io/terms/options/dataset_reproducible_options/2	https://rdmorganiser.github.io/terms	dataset_reproducible_options/2				f
64	3	1	yes, with moderate, but reasonable effort	ja, mit mäßigem, aber vertretbarem Auswand	f	11		https://rdmorganiser.github.io/terms/options/dataset_reproducible_options/3	https://rdmorganiser.github.io/terms	dataset_reproducible_options/3				f
65	4	2	no or only with disproportionate cost or effort	nein bzw. nur mit unverhältnismäßig großem Aufwand	f	11		https://rdmorganiser.github.io/terms/options/dataset_reproducible_options/4	https://rdmorganiser.github.io/terms	dataset_reproducible_options/4				f
66	5	3	no, the data is not reproducible per se	nein, die Daten sind per se nicht reproduzierbar	f	11		https://rdmorganiser.github.io/terms/options/dataset_reproducible_options/5	https://rdmorganiser.github.io/terms	dataset_reproducible_options/5				f
67	67	1	Yes, internally with everyone, as long as they don't pass on the data	Ja, intern mit allen, solange sie die Daten nicht veröffentlichen oder nach außen weitergeben	f	12		https://rdmorganiser.github.io/terms/options/dataset_sharing_options/67	https://rdmorganiser.github.io/terms	dataset_sharing_options/67				f
68	68	2	Yes, externally limited with individual approval	Ja, extern in begrenztem Umfang mit individueller Freigabe	f	12		https://rdmorganiser.github.io/terms/options/dataset_sharing_options/68	https://rdmorganiser.github.io/terms	dataset_sharing_options/68				f
69	69	3	Yes, externally for everyone	Ja, extern für alle	f	12		https://rdmorganiser.github.io/terms/options/dataset_sharing_options/69	https://rdmorganiser.github.io/terms	dataset_sharing_options/69				f
70	70	4	No	Nein	f	12		https://rdmorganiser.github.io/terms/options/dataset_sharing_options/70	https://rdmorganiser.github.io/terms	dataset_sharing_options/70				f
71	249	3	more than 100 TB	mehr als 100 TB	f	13		https://rdmorganiser.github.io/terms/options/dataset_size_options/249	https://rdmorganiser.github.io/terms	dataset_size_options/249				f
72	250	4	exact size	genau	t	13		https://rdmorganiser.github.io/terms/options/dataset_size_options/250	https://rdmorganiser.github.io/terms	dataset_size_options/250				f
73	251	1	less than 1 GB	weniger als ein GB	f	13		https://rdmorganiser.github.io/terms/options/dataset_size_options/251	https://rdmorganiser.github.io/terms	dataset_size_options/251				f
74	252	2	1 TB to 100 TB	1 TB bis 100 TB	f	13		https://rdmorganiser.github.io/terms/options/dataset_size_options/252	https://rdmorganiser.github.io/terms	dataset_size_options/252				f
75	253	5	not yet defined	noch nicht bestimmt	f	13		https://rdmorganiser.github.io/terms/options/dataset_size_options/253	https://rdmorganiser.github.io/terms	dataset_size_options/253				f
76	254	1	1 GB to 1 TB	1 GB bis 1 TB	f	13		https://rdmorganiser.github.io/terms/options/dataset_size_options/254	https://rdmorganiser.github.io/terms	dataset_size_options/254				f
77	165	3	Other	Sonstiges	t	14		https://rdmorganiser.github.io/terms/options/dataset_versioning_technology_options/165	https://rdmorganiser.github.io/terms	dataset_versioning_technology_options/165				f
78	166	1	Simple copying	Einfaches Kopieren	f	14		https://rdmorganiser.github.io/terms/options/dataset_versioning_technology_options/166	https://rdmorganiser.github.io/terms	dataset_versioning_technology_options/166				f
79	167	2	Version control system	Versionskontrollsystem	t	14		https://rdmorganiser.github.io/terms/options/dataset_versioning_technology_options/167	https://rdmorganiser.github.io/terms	dataset_versioning_technology_options/167				f
80	168	4	Not yet decided	Noch nicht entschieden	f	14		https://rdmorganiser.github.io/terms/options/dataset_versioning_technology_options/168	https://rdmorganiser.github.io/terms	dataset_versioning_technology_options/168				f
81	240	4	No, a review is not necessary, because	Nein, eine Begutachtung ist nicht notwendig, weil	t	15		https://rdmorganiser.github.io/terms/options/ethics_committee_approval_options/240	https://rdmorganiser.github.io/terms	ethics_committee_approval_options/240				f
82	241	1	Yes, approved under obligations which will be complied in the following way	Ja, begutachtet mit Auflagen, die folgendermaßen erfüllt werden	t	15		https://rdmorganiser.github.io/terms/options/ethics_committee_approval_options/241	https://rdmorganiser.github.io/terms	ethics_committee_approval_options/241				f
83	242	2	Not yet, but it is already in the review process	Noch nicht, es befindet sich aber bereits in Begutachtung	f	15		https://rdmorganiser.github.io/terms/options/ethics_committee_approval_options/242	https://rdmorganiser.github.io/terms	ethics_committee_approval_options/242				f
84	243	3	Not yet, it will be handed in for review by	Noch nicht, es wird zur Begutachtung eingereicht bis spätestens	t	15		https://rdmorganiser.github.io/terms/options/ethics_committee_approval_options/243	https://rdmorganiser.github.io/terms	ethics_committee_approval_options/243				f
85	244	0	Yes, reviewed and approved by the following committee	Ja, positiv begutachtet von folgender Kommission	t	15		https://rdmorganiser.github.io/terms/options/ethics_committee_approval_options/244	https://rdmorganiser.github.io/terms	ethics_committee_approval_options/244				f
86	245	3	Yes. The permit will be applied for by	Ja. Die Genehmigung wird beantragt bis spätestens	t	16		https://rdmorganiser.github.io/terms/options/ethics_permit_options/245	https://rdmorganiser.github.io/terms	ethics_permit_options/245				f
118	120	4	URN	URN	f	23		https://rdmorganiser.github.io/terms/options/pid_types/120	https://rdmorganiser.github.io/terms	pid_types/120				f
87	246	1	Yes. The permit has been received.	Ja. Die Genehmigung liegt bereits vor.	f	16		https://rdmorganiser.github.io/terms/options/ethics_permit_options/246	https://rdmorganiser.github.io/terms	ethics_permit_options/246				f
88	247	2	Yes. The permit has been applied for on	Ja. Die Genehmigung wurde beantragt am/im	t	16		https://rdmorganiser.github.io/terms/options/ethics_permit_options/247	https://rdmorganiser.github.io/terms	ethics_permit_options/247				f
89	248	0	No	Nein	f	16		https://rdmorganiser.github.io/terms/options/ethics_permit_options/248	https://rdmorganiser.github.io/terms	ethics_permit_options/248				f
90	44	2	Only for analysis / use of the data within the project	Nur zur Analyse/Nutzung der Daten im Rahmen des Projektes	f	17		https://rdmorganiser.github.io/terms/options/informed_consent_options/44	https://rdmorganiser.github.io/terms	informed_consent_options/44				f
91	45	1	For analysis / use of the data within the project as well as for re-use	Zur Analyse/Nutzung der Daten im Rahmen des Projektes sowie zur Nachnutzung	f	17		https://rdmorganiser.github.io/terms/options/informed_consent_options/45	https://rdmorganiser.github.io/terms	informed_consent_options/45				f
92	66	3	The "informed consent" is not obtained	Es wird keine “informierte Einwilligung” eingeholt	f	17		https://rdmorganiser.github.io/terms/options/informed_consent_options/66	https://rdmorganiser.github.io/terms	informed_consent_options/66				f
93	260	1	Infrastructure resources of  the usual workplace equipment are sufficient.	Die üblichen Infrastrukturressourcen des Arbeitsplatzes reichen aus.	f	18		https://rdmorganiser.github.io/terms/options/infrastructure_resources/260	https://rdmorganiser.github.io/terms	infrastructure_resources/260				f
94	261	2	The following infrastructure resources are needed	Es werden folgende Infrastrukturressourcen benötigt	t	18		https://rdmorganiser.github.io/terms/options/infrastructure_resources/261	https://rdmorganiser.github.io/terms	infrastructure_resources/261				f
95	100	1	Location	Ort	f	19		https://rdmorganiser.github.io/terms/options/mandatory_metadata_options/100	https://rdmorganiser.github.io/terms	mandatory_metadata_options/100				f
96	101	2	Content	Inhalt	f	19		https://rdmorganiser.github.io/terms/options/mandatory_metadata_options/101	https://rdmorganiser.github.io/terms	mandatory_metadata_options/101				f
97	102	3	Methodology	Methodik	f	19		https://rdmorganiser.github.io/terms/options/mandatory_metadata_options/102	https://rdmorganiser.github.io/terms	mandatory_metadata_options/102				f
98	103	4	Creation process	Erzeugungsprozess	f	19		https://rdmorganiser.github.io/terms/options/mandatory_metadata_options/103	https://rdmorganiser.github.io/terms	mandatory_metadata_options/103				f
99	104	5	Technology	Technologie	f	19		https://rdmorganiser.github.io/terms/options/mandatory_metadata_options/104	https://rdmorganiser.github.io/terms	mandatory_metadata_options/104				f
100	105	7	Time	Zeit	f	19		https://rdmorganiser.github.io/terms/options/mandatory_metadata_options/105	https://rdmorganiser.github.io/terms	mandatory_metadata_options/105				f
101	106	8	Sources	Quellen	f	19		https://rdmorganiser.github.io/terms/options/mandatory_metadata_options/106	https://rdmorganiser.github.io/terms	mandatory_metadata_options/106				f
102	107	9	Agents	Akteure	f	19		https://rdmorganiser.github.io/terms/options/mandatory_metadata_options/107	https://rdmorganiser.github.io/terms	mandatory_metadata_options/107				f
103	108	11	Other	Andere	t	19		https://rdmorganiser.github.io/terms/options/mandatory_metadata_options/108	https://rdmorganiser.github.io/terms	mandatory_metadata_options/108				f
104	109	10	Identifiers	Identifikatoren	f	19		https://rdmorganiser.github.io/terms/options/mandatory_metadata_options/109	https://rdmorganiser.github.io/terms	mandatory_metadata_options/109				f
105	255	6	Documentation of the software necessary to use the data	Dokumentation der zur Nutzung notwendigen Software	f	19		https://rdmorganiser.github.io/terms/options/mandatory_metadata_options/255	https://rdmorganiser.github.io/terms	mandatory_metadata_options/255				f
106	115	3	Manual check for completeness	Manuelle Prüfung auf Vollständigkeit	f	20		https://rdmorganiser.github.io/terms/options/metadata_check_options/115	https://rdmorganiser.github.io/terms	metadata_check_options/115				f
107	116	4	Other	Sonstiges	t	20		https://rdmorganiser.github.io/terms/options/metadata_check_options/116	https://rdmorganiser.github.io/terms	metadata_check_options/116				f
108	117	1	Automatic check for completeness	Automatische Prüfung auf Vollständigkeit	f	20		https://rdmorganiser.github.io/terms/options/metadata_check_options/117	https://rdmorganiser.github.io/terms	metadata_check_options/117				f
109	118	2	Manual check for correctness	Manuelle Prüfung auf Korrektheit	f	20		https://rdmorganiser.github.io/terms/options/metadata_check_options/118	https://rdmorganiser.github.io/terms	metadata_check_options/118				f
110	110	3	No fixed system for the description is used	Es wird kein festgelegtes System zur Beschreibung genutzt	f	21		https://rdmorganiser.github.io/terms/options/metadata_standards/110	https://rdmorganiser.github.io/terms	metadata_standards/110				f
111	111	1	Discipline-specific  standards, classifications etc. are used	Es werden disziplinspezifische Standards, Klassifikationen etc. genutzt	t	21		https://rdmorganiser.github.io/terms/options/metadata_standards/111	https://rdmorganiser.github.io/terms	metadata_standards/111				f
112	112	2	A custom description system is used (please briefly outline and, if necessary, indicate where it is documented in more detail)	Es wird ein eigenes Beschreibungssystem genutzt (bitte beschreiben Sie dieses kurz und geben, wenn nötig, an, wo es ausführlicher dokumentiert ist)	t	21		https://rdmorganiser.github.io/terms/options/metadata_standards/112	https://rdmorganiser.github.io/terms	metadata_standards/112				f
113	113	5	It has not yet been decided, with which system the metadata and contextual information will be described	Es wurde noch nicht entschieden, mit welchem System die Metadaten und Kontextinformationen beschrieben werden	f	21		https://rdmorganiser.github.io/terms/options/metadata_standards/113	https://rdmorganiser.github.io/terms	metadata_standards/113				f
114	114	4	Other	Sonstiges	t	21		https://rdmorganiser.github.io/terms/options/metadata_standards/114	https://rdmorganiser.github.io/terms	metadata_standards/114				f
115	144	1	No	Nein	f	22		https://rdmorganiser.github.io/terms/options/other_requirements_options/144	https://rdmorganiser.github.io/terms	other_requirements_options/144				f
116	145	2	To be clarified	Noch zu klären	f	22		https://rdmorganiser.github.io/terms/options/other_requirements_options/145	https://rdmorganiser.github.io/terms	other_requirements_options/145				f
117	146	0	Yes	Ja	f	22		https://rdmorganiser.github.io/terms/options/other_requirements_options/146	https://rdmorganiser.github.io/terms	other_requirements_options/146				f
119	121	6	Other	Anderes	t	23		https://rdmorganiser.github.io/terms/options/pid_types/121	https://rdmorganiser.github.io/terms	pid_types/121				f
120	122	2	PURL	PURL	f	23		https://rdmorganiser.github.io/terms/options/pid_types/122	https://rdmorganiser.github.io/terms	pid_types/122				f
121	123	1	Handle / DOI	Handle / DOI	f	23		https://rdmorganiser.github.io/terms/options/pid_types/123	https://rdmorganiser.github.io/terms	pid_types/123				f
122	124	3	ARK	ARK	f	23		https://rdmorganiser.github.io/terms/options/pid_types/124	https://rdmorganiser.github.io/terms	pid_types/124				f
123	154	5	ISLRN	ISLRN	f	23		https://rdmorganiser.github.io/terms/options/pid_types/154	https://rdmorganiser.github.io/terms	pid_types/154				f
124	130	2	Re-use in subsequent projects or by others	Nachnutzung in Folgeprojekten oder durch andere	f	24		https://rdmorganiser.github.io/terms/options/preservation_motivation_options/130	https://rdmorganiser.github.io/terms	preservation_motivation_options/130				f
125	131	1	Used in a publication / proof of good scientific practice	Grundlage einer Publikation / Nachweis guter wissenschaftlicher Praxis	f	24		https://rdmorganiser.github.io/terms/options/preservation_motivation_options/131	https://rdmorganiser.github.io/terms	preservation_motivation_options/131				f
126	132	3	Legal obligations	Aufgrund gesetzlicher Bestimmungen	f	24		https://rdmorganiser.github.io/terms/options/preservation_motivation_options/132	https://rdmorganiser.github.io/terms	preservation_motivation_options/132				f
127	133	4	Documentation, because it is relevant to society	Dokumentation aufgrund gesellschaftlicher Relevanz	f	24		https://rdmorganiser.github.io/terms/options/preservation_motivation_options/133	https://rdmorganiser.github.io/terms	preservation_motivation_options/133				f
128	134	5	Self-commitment	Selbstverpflichtung	f	24		https://rdmorganiser.github.io/terms/options/preservation_motivation_options/134	https://rdmorganiser.github.io/terms	preservation_motivation_options/134				f
129	135	6	Other	Andere	t	24		https://rdmorganiser.github.io/terms/options/preservation_motivation_options/135	https://rdmorganiser.github.io/terms	preservation_motivation_options/135				f
130	139	1	Own institution	Eigene Institution	f	25		https://rdmorganiser.github.io/terms/options/preservation_repository_options/139	https://rdmorganiser.github.io/terms	preservation_repository_options/139				f
131	140	2	Discipline specific data center	Disziplinspezifisches Datenzentrum	t	25		https://rdmorganiser.github.io/terms/options/preservation_repository_options/140	https://rdmorganiser.github.io/terms	preservation_repository_options/140				f
132	141	3	Generic data center	Generisches Datenzentrum	t	25		https://rdmorganiser.github.io/terms/options/preservation_repository_options/141	https://rdmorganiser.github.io/terms	preservation_repository_options/141				f
133	142	5	Other	Sonstiges	t	25		https://rdmorganiser.github.io/terms/options/preservation_repository_options/142	https://rdmorganiser.github.io/terms	preservation_repository_options/142				f
134	143	4	Has not yet been decided	Wurde noch nicht entschieden	f	25		https://rdmorganiser.github.io/terms/options/preservation_repository_options/143	https://rdmorganiser.github.io/terms	preservation_repository_options/143				f
135	169	101	Humanities and Social Sciences / Ancient Cultures	Geistes- und Sozialwissenschaften / Alte Kulturen	f	26		https://rdmorganiser.github.io/terms/options/research_fields/169	https://rdmorganiser.github.io/terms	research_fields/169				f
136	170	105	Humanities and Social Sciences / Literary Studies	Geistes- und Sozialwissenschaften / Literaturwissenschaft	f	26		https://rdmorganiser.github.io/terms/options/research_fields/170	https://rdmorganiser.github.io/terms	research_fields/170				f
137	171	103	Humanities and Social Sciences / Fine Arts, Music, Theatre and Media Studies	Geistes- und Sozialwissenschaften / Kunst-, Musik-, Theater- und Medienwissenschaften	f	26		https://rdmorganiser.github.io/terms/options/research_fields/171	https://rdmorganiser.github.io/terms	research_fields/171				f
138	172	106	Humanities and Social Sciences / Non-European Languages and Cultures, Social and Cultural Anthropology, Jewish Studies and Religious Studies	Geistes- und Sozialwissenschaften / Außereuropäische Sprachen und Kulturen, Sozial- und Kulturanthropologie, Judaistik und Religionswissenschaft	f	26		https://rdmorganiser.github.io/terms/options/research_fields/172	https://rdmorganiser.github.io/terms	research_fields/172				f
139	173	104	Humanities and Social Sciences / Linguistics	Geistes- und Sozialwissenschaften / Sprachwissenschaften	f	26		https://rdmorganiser.github.io/terms/options/research_fields/173	https://rdmorganiser.github.io/terms	research_fields/173				f
140	174	102	Humanities and Social Sciences / History	Geistes- und Sozialwissenschaften / Geschichtswissenschaften	f	26		https://rdmorganiser.github.io/terms/options/research_fields/174	https://rdmorganiser.github.io/terms	research_fields/174				f
141	175	107	Humanities and Social Sciences / Theology	Geistes- und Sozialwissenschaften / Theologie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/175	https://rdmorganiser.github.io/terms	research_fields/175				f
142	176	108	Humanities and Social Sciences / Philosophy	Geistes- und Sozialwissenschaften / Philosophie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/176	https://rdmorganiser.github.io/terms	research_fields/176				f
143	177	110	Humanities and Social Sciences / Psychology	Geistes- und Sozialwissenschaften / Psychologie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/177	https://rdmorganiser.github.io/terms	research_fields/177				f
144	178	109	Humanities and Social Sciences / Education Sciences	Geistes- und Sozialwissenschaften / Erziehungswissenschaft	f	26		https://rdmorganiser.github.io/terms/options/research_fields/178	https://rdmorganiser.github.io/terms	research_fields/178				f
145	179	111	Humanities and Social Sciences / Social Sciences	Geistes- und Sozialwissenschaften / Sozialwissenschaften	f	26		https://rdmorganiser.github.io/terms/options/research_fields/179	https://rdmorganiser.github.io/terms	research_fields/179				f
146	180	112	Humanities and Social Sciences / Economics	Geistes- und Sozialwissenschaften / Wirtschaftswissenschaften	f	26		https://rdmorganiser.github.io/terms/options/research_fields/180	https://rdmorganiser.github.io/terms	research_fields/180				f
147	181	113	Humanities and Social Sciences / Jurisprudence	Geistes- und Sozialwissenschaften / Rechtswissenschaften	f	26		https://rdmorganiser.github.io/terms/options/research_fields/181	https://rdmorganiser.github.io/terms	research_fields/181				f
148	182	201	Life Sciences / Basic Biological and Medical Research	Lebenswissenschaften / Grundlagen der Biologie und Medizin	f	26		https://rdmorganiser.github.io/terms/options/research_fields/182	https://rdmorganiser.github.io/terms	research_fields/182				f
149	183	202	Life Sciences / Plant Sciences	Lebenswissenschaften / Pflanzenwissenschaften	f	26		https://rdmorganiser.github.io/terms/options/research_fields/183	https://rdmorganiser.github.io/terms	research_fields/183				f
150	184	204	Life Sciences / Microbiology, Virology and Immunology	Lebenswissenschaften / Mikrobiologie, Virologie und Immunologie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/184	https://rdmorganiser.github.io/terms	research_fields/184				f
151	185	205	Life Sciences / Medicine	Lebenswissenschaften / Medizin	f	26		https://rdmorganiser.github.io/terms/options/research_fields/185	https://rdmorganiser.github.io/terms	research_fields/185				f
152	186	203	Life Sciences / Zoology	Lebenswissenschaften / Zoologie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/186	https://rdmorganiser.github.io/terms	research_fields/186				f
153	187	206	Life Sciences / Neurosciences	Lebenswissenschaften / Neurowissenschaft	f	26		https://rdmorganiser.github.io/terms/options/research_fields/187	https://rdmorganiser.github.io/terms	research_fields/187				f
154	188	207	Life Sciences / Agriculture, Forestry, Horticulture and Veterinary Medicine	Lebenswissenschaften / Agrar-, Forstwissenschaften, Gartenbau und Tiermedizin	f	26		https://rdmorganiser.github.io/terms/options/research_fields/188	https://rdmorganiser.github.io/terms	research_fields/188				f
155	189	301	Natural Sciences / Molecular Chemistry	Naturwissenschaften / Molekülchemie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/189	https://rdmorganiser.github.io/terms	research_fields/189				f
156	190	303	Natural Sciences / Physical and Theoretical Chemistry	Naturwissenschaften / Physikalische und Theoretische Chemie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/190	https://rdmorganiser.github.io/terms	research_fields/190				f
157	191	304	Natural Sciences / Analytical Chemistry, Method Development (Chemistry)	Naturwissenschaften / Analytik, Methodenentwicklung (Chemie)	f	26		https://rdmorganiser.github.io/terms/options/research_fields/191	https://rdmorganiser.github.io/terms	research_fields/191				f
158	192	302	Natural Sciences / Chemical Solid State and Surface Research	Naturwissenschaften / Chemische Festkörper- und Oberflächenforschung	f	26		https://rdmorganiser.github.io/terms/options/research_fields/192	https://rdmorganiser.github.io/terms	research_fields/192				f
159	193	305	Natural Sciences / Biological Chemistry and Food Chemistry	Naturwissenschaften / Biologische Chemie und Lebensmittelchemie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/193	https://rdmorganiser.github.io/terms	research_fields/193				f
160	194	306	Natural Sciences / Polymer Research	Naturwissenschaften / Polymerforschung	f	26		https://rdmorganiser.github.io/terms/options/research_fields/194	https://rdmorganiser.github.io/terms	research_fields/194				f
161	195	307	Natural Sciences / Condensed Matter Physics	Naturwissenschaften / Physik der kondensierten Materie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/195	https://rdmorganiser.github.io/terms	research_fields/195				f
162	196	308	Natural Sciences / Optics, Quantum Optics and Physics of Atoms, Molecules and Plasmas	Naturwissenschaften / Optik, Quantenoptik und Physik der Atome, Moleküle und Plasmen	f	26		https://rdmorganiser.github.io/terms/options/research_fields/196	https://rdmorganiser.github.io/terms	research_fields/196				f
163	197	310	Natural Sciences / Statistical Physics, Soft Matter, Biological Physics, Nonlinear Dynamics	Naturwissenschaften / Statistische Physik, Weiche Materie, Biologische Physik, Nichtlineare Dynamik	f	26		https://rdmorganiser.github.io/terms/options/research_fields/197	https://rdmorganiser.github.io/terms	research_fields/197				f
164	198	309	Natural Sciences / Particles, Nuclei and Fields	Naturwissenschaften / Teilchen, Kerne und Felder	f	26		https://rdmorganiser.github.io/terms/options/research_fields/198	https://rdmorganiser.github.io/terms	research_fields/198				f
165	199	311	Natural Sciences / Astrophysics and Astronomy	Naturwissenschaften / Astrophysik und Astronomie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/199	https://rdmorganiser.github.io/terms	research_fields/199				f
166	200	312	Natural Sciences / Mathematics	Naturwissenschaften / Mathematik	f	26		https://rdmorganiser.github.io/terms/options/research_fields/200	https://rdmorganiser.github.io/terms	research_fields/200				f
167	201	313	Natural Sciences / Atmospheric Science and Oceanography	Naturwissenschaften / Atmosphären- und Meeresforschung	f	26		https://rdmorganiser.github.io/terms/options/research_fields/201	https://rdmorganiser.github.io/terms	research_fields/201				f
168	202	314	Natural Sciences / Geology and Palaeontology	Naturwissenschaften / Geologie und Paläontologie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/202	https://rdmorganiser.github.io/terms	research_fields/202				f
169	203	315	Natural Sciences / Geophysics and Geodesy	Naturwissenschaften / Geophysik und Geodäsie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/203	https://rdmorganiser.github.io/terms	research_fields/203				f
170	204	316	Natural Sciences / Geochemistry, Mineralogy and Crystallography	Naturwissenschaften / Geochemie, Mineralogie und Kristallographie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/204	https://rdmorganiser.github.io/terms	research_fields/204				f
171	205	318	Natural Sciences / Water Research	Naturwissenschaften / Wasserforschung	f	26		https://rdmorganiser.github.io/terms/options/research_fields/205	https://rdmorganiser.github.io/terms	research_fields/205				f
172	206	317	Natural Sciences / Geography	Naturwissenschaften / Geographie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/206	https://rdmorganiser.github.io/terms	research_fields/206				f
173	207	401	Engineering Sciences / Production Technology	Ingenieurwissenschaften / Produktionstechnik	f	26		https://rdmorganiser.github.io/terms/options/research_fields/207	https://rdmorganiser.github.io/terms	research_fields/207				f
174	208	402	Engineering Sciences / Mechanics and Constructive Mechanical Engineering	Ingenieurwissenschaften / Mechanik und Konstruktiver Maschinenbau	f	26		https://rdmorganiser.github.io/terms/options/research_fields/208	https://rdmorganiser.github.io/terms	research_fields/208				f
175	209	403	Engineering Sciences / Process Engineering, Technical Chemistry	Ingenieurwissenschaften / Verfahrenstechnik, Technische Chemie	f	26		https://rdmorganiser.github.io/terms/options/research_fields/209	https://rdmorganiser.github.io/terms	research_fields/209				f
176	210	404	Engineering Sciences / Heat Energy Technology, Thermal Machines, Fluid Mechanics	Ingenieurwissenschaften / Wärmeenergietechnik, Thermische Maschinen, Strömungsmechanik	f	26		https://rdmorganiser.github.io/terms/options/research_fields/210	https://rdmorganiser.github.io/terms	research_fields/210				f
337	Object_Dead	1	Dead	Tot	f	60		http://example.com/terms/options/gfbio_Dead_or_Alive/Object_Dead	http://example.com/terms	gfbio_Dead_or_Alive/Object_Dead				f
177	211	405	Engineering Sciences / Materials Engineering	Ingenieurwissenschaften / Werkstofftechnik	f	26		https://rdmorganiser.github.io/terms/options/research_fields/211	https://rdmorganiser.github.io/terms	research_fields/211				f
178	212	406	Engineering Sciences / Materials Science	Ingenieurwissenschaften / Materialwissenschaft	f	26		https://rdmorganiser.github.io/terms/options/research_fields/212	https://rdmorganiser.github.io/terms	research_fields/212				f
179	213	407	Engineering Sciences / Systems Engineering	Ingenieurwissenschaften / Systemtechnik	f	26		https://rdmorganiser.github.io/terms/options/research_fields/213	https://rdmorganiser.github.io/terms	research_fields/213				f
180	214	408	Engineering Sciences / Electrical Engineering	Ingenieurwissenschaften / Elektrotechnik	f	26		https://rdmorganiser.github.io/terms/options/research_fields/214	https://rdmorganiser.github.io/terms	research_fields/214				f
181	215	409	Engineering Sciences / Computer Science	Ingenieurwissenschaften / Informatik	f	26		https://rdmorganiser.github.io/terms/options/research_fields/215	https://rdmorganiser.github.io/terms	research_fields/215				f
182	216	410	Engineering Sciences / Construction Engineering and Architecture	Ingenieurwissenschaften / Bauwesen und Architektur	f	26		https://rdmorganiser.github.io/terms/options/research_fields/216	https://rdmorganiser.github.io/terms	research_fields/216				f
183	84	1	Law: "Recht des Herstellers eines Tonträgers"	Recht des Herstellers eines Tonträgers	f	27		https://rdmorganiser.github.io/terms/options/software_copyright_laws/84	https://rdmorganiser.github.io/terms	software_copyright_laws/84				f
184	85	2	Law: "Recht des Verfassers sichtender wissenschaftlicher Ausgaben"	Recht des Verfassers sichtender wissenschaftlicher Ausgaben	f	27		https://rdmorganiser.github.io/terms/options/software_copyright_laws/85	https://rdmorganiser.github.io/terms	software_copyright_laws/85				f
185	86	3	Law: "Recht des Sendeunternehmers"	Recht des Sendeunternehmers	f	27		https://rdmorganiser.github.io/terms/options/software_copyright_laws/86	https://rdmorganiser.github.io/terms	software_copyright_laws/86				f
186	87	4	Law: "Recht des Datenbankherstellers"	Recht des Datenbankherstellers	f	27		https://rdmorganiser.github.io/terms/options/software_copyright_laws/87	https://rdmorganiser.github.io/terms	software_copyright_laws/87				f
187	88	6	Other copyright laws	Andere Urheberrechte	t	27		https://rdmorganiser.github.io/terms/options/software_copyright_laws/88	https://rdmorganiser.github.io/terms	software_copyright_laws/88				f
188	89	7	No	Nein	f	27		https://rdmorganiser.github.io/terms/options/software_copyright_laws/89	https://rdmorganiser.github.io/terms	software_copyright_laws/89				f
189	236	0	The code will be published under the following license	Der Code wird unter folgender Lizenz veröffentlicht	t	28		https://rdmorganiser.github.io/terms/options/software_license_options/236	https://rdmorganiser.github.io/terms	software_license_options/236				f
190	237	1	Yet to be decided	Noch zu klären	f	28		https://rdmorganiser.github.io/terms/options/software_license_options/237	https://rdmorganiser.github.io/terms	software_license_options/237				f
191	234	5	Other	Andere	t	29		https://rdmorganiser.github.io/terms/options/software_license_types/234	https://rdmorganiser.github.io/terms	software_license_types/234				f
192	80	3	No derivative work	keine Bearbeitung	f	29		https://rdmorganiser.github.io/terms/options/software_license_types/80	https://rdmorganiser.github.io/terms	software_license_types/80				f
193	81	1	Attribution	Namensnennung	f	29		https://rdmorganiser.github.io/terms/options/software_license_types/81	https://rdmorganiser.github.io/terms	software_license_types/81				f
194	82	2	Non-commercial	keine kommerzielle Nutzung	f	29		https://rdmorganiser.github.io/terms/options/software_license_types/82	https://rdmorganiser.github.io/terms	software_license_types/82				f
195	83	4	Share-alike	Weitergabe unter gleichen Bedingungen	f	29		https://rdmorganiser.github.io/terms/options/software_license_types/83	https://rdmorganiser.github.io/terms	software_license_types/83				f
196	149	1	Re-used	Nachgenutzt	f	30		https://rdmorganiser.github.io/terms/options/software_origin_options/149	https://rdmorganiser.github.io/terms	software_origin_options/149				f
197	150	0	Created	Erzeugt	f	30		https://rdmorganiser.github.io/terms/options/software_origin_options/150	https://rdmorganiser.github.io/terms	software_origin_options/150				f
198	90	1	Business names (company names and work titles)	geschäftliche Bezeichnungen (Unternehmenskennzeichen und Werktitel)	f	31		https://rdmorganiser.github.io/terms/options/software_other_rights/90	https://rdmorganiser.github.io/terms	software_other_rights/90				f
199	91	10	Other	Andere	t	31		https://rdmorganiser.github.io/terms/options/software_other_rights/91	https://rdmorganiser.github.io/terms	software_other_rights/91				f
200	92	10	No	Nein	f	31		https://rdmorganiser.github.io/terms/options/software_other_rights/92	https://rdmorganiser.github.io/terms	software_other_rights/92				f
201	93	3	Geographical indications	geografische Herkunftsangaben	f	31		https://rdmorganiser.github.io/terms/options/software_other_rights/93	https://rdmorganiser.github.io/terms	software_other_rights/93				f
202	94	4	Plant Variety Protection (Plant Varieties)	Sortenschutz (Pflanzenzüchtungen)	f	31		https://rdmorganiser.github.io/terms/options/software_other_rights/94	https://rdmorganiser.github.io/terms	software_other_rights/94				f
203	95	5	Patents	Patente	f	31		https://rdmorganiser.github.io/terms/options/software_other_rights/95	https://rdmorganiser.github.io/terms	software_other_rights/95				f
204	96	6	Semiconductor protection or protection of topographies	Halbleiterschutz bzw. Schutz von Topografien	f	31		https://rdmorganiser.github.io/terms/options/software_other_rights/96	https://rdmorganiser.github.io/terms	software_other_rights/96				f
205	97	7	Supplementary Protection Certificates	Ergänzende Schutzzertifikate	f	31		https://rdmorganiser.github.io/terms/options/software_other_rights/97	https://rdmorganiser.github.io/terms	software_other_rights/97				f
206	98	8	Utility models	Gebrauchsmuster	f	31		https://rdmorganiser.github.io/terms/options/software_other_rights/98	https://rdmorganiser.github.io/terms	software_other_rights/98				f
207	99	9	Trademark	Markenrecht	f	31		https://rdmorganiser.github.io/terms/options/software_other_rights/99	https://rdmorganiser.github.io/terms	software_other_rights/99				f
208	76	2	Yes, externally limited with individual approval	Ja, extern in begrenztem Umfang mit individueller Freigabe	f	32		https://rdmorganiser.github.io/terms/options/software_sharing_options/76	https://rdmorganiser.github.io/terms	software_sharing_options/76				f
209	77	4	No	Nein	f	32		https://rdmorganiser.github.io/terms/options/software_sharing_options/77	https://rdmorganiser.github.io/terms	software_sharing_options/77				f
210	78	3	Yes, externally for everyone	Ja, extern für alle	f	32		https://rdmorganiser.github.io/terms/options/software_sharing_options/78	https://rdmorganiser.github.io/terms	software_sharing_options/78				f
211	79	1	Yes, internally with everyone, as long as they don't pass on the code externally	Ja, intern mit allen, solange sie den Code nicht veröffentlichen oder nach außen weitergeben	f	32		https://rdmorganiser.github.io/terms/options/software_sharing_options/79	https://rdmorganiser.github.io/terms	software_sharing_options/79				f
212	161	2	Version control system	Versionskontrollsystem	t	33		https://rdmorganiser.github.io/terms/options/software_versioning_technology_options/161	https://rdmorganiser.github.io/terms	software_versioning_technology_options/161				f
213	162	1	Simple copying	Einfaches Kopieren	f	33		https://rdmorganiser.github.io/terms/options/software_versioning_technology_options/162	https://rdmorganiser.github.io/terms	software_versioning_technology_options/162				f
214	163	3	Other	Sonstiges	t	33		https://rdmorganiser.github.io/terms/options/software_versioning_technology_options/163	https://rdmorganiser.github.io/terms	software_versioning_technology_options/163				f
215	164	4	Not yet decided	Noch nicht entschieden	f	33		https://rdmorganiser.github.io/terms/options/software_versioning_technology_options/164	https://rdmorganiser.github.io/terms	software_versioning_technology_options/164				f
216	no	2	No	Nein	f	34		https://rdmorganiser.github.io/terms/options/yes_no_not_yet/no	https://rdmorganiser.github.io/terms	yes_no_not_yet/no				f
217	not_yet	3	Not yet	Noch nicht	f	34		https://rdmorganiser.github.io/terms/options/yes_no_not_yet/not_yet	https://rdmorganiser.github.io/terms	yes_no_not_yet/not_yet				f
218	yes	1	Yes	Ja	t	34		https://rdmorganiser.github.io/terms/options/yes_no_not_yet/yes	https://rdmorganiser.github.io/terms	yes_no_not_yet/yes				f
219	no	2	No	Nein	f	35		https://rdmorganiser.github.io/terms/options/yes_with_text_no/no	https://rdmorganiser.github.io/terms	yes_with_text_no/no				f
220	yes	1	Yes	Ja	t	35		https://rdmorganiser.github.io/terms/options/yes_with_text_no/yes	https://rdmorganiser.github.io/terms	yes_with_text_no/yes				f
221	golden	1			f	36		https://fdm-bayern.org/eHumanities/options/open_access/golden	https://fdm-bayern.org/eHumanities	open_access/golden				f
222	green	2			f	36		https://fdm-bayern.org/eHumanities/options/open_access/green	https://fdm-bayern.org/eHumanities	open_access/green				f
223	print	3			t	36		https://fdm-bayern.org/eHumanities/options/open_access/print	https://fdm-bayern.org/eHumanities	open_access/print				f
224	hybrid	2			f	37		https://fdm-bayern.org/eHumanities/options/publication_form/hybrid	https://fdm-bayern.org/eHumanities	publication_form/hybrid				f
225	online	3			f	37		https://fdm-bayern.org/eHumanities/options/publication_form/online	https://fdm-bayern.org/eHumanities	publication_form/online				f
226	print	1			f	37		https://fdm-bayern.org/eHumanities/options/publication_form/print	https://fdm-bayern.org/eHumanities	publication_form/print				f
227	gfbio_project_type_fieldwork	0	Field Work	Feldarbeit	f	39		http://example.com/terms/options/gfbio_project_type/gfbio_project_type_fieldwork	http://example.com/terms	gfbio_project_type/gfbio_project_type_fieldwork				f
228	gfbio_project_type_observational	1	Observational	Beobachtend	f	39	only applicable for GFBio current DMP questionnaire and catalog	http://example.com/terms/options/gfbio_project_type/gfbio_project_type_observational	http://example.com/terms	gfbio_project_type/gfbio_project_type_observational				f
229	gfbio_project_type_experimental	2	Experimental	Experimentell	f	39		http://example.com/terms/options/gfbio_project_type/gfbio_project_type_experimental	http://example.com/terms	gfbio_project_type/gfbio_project_type_experimental				f
230	gfbio_project_type_laboratory	3	Laboratory	Labor	f	39		http://example.com/terms/options/gfbio_project_type/gfbio_project_type_laboratory	http://example.com/terms	gfbio_project_type/gfbio_project_type_laboratory				f
231	gfbio_project_type_simulation	4	Simulation	Simulation	f	39		http://example.com/terms/options/gfbio_project_type/gfbio_project_type_simulation	http://example.com/terms	gfbio_project_type/gfbio_project_type_simulation				f
232	gfbio_project_type_assimilation	5	Assimilation	Assimilation	f	39		http://example.com/terms/options/gfbio_project_type/gfbio_project_type_assimilation	http://example.com/terms	gfbio_project_type/gfbio_project_type_assimilation				f
233	gfbio_project_type_modelling	6	Modelling	Modellierung	f	39		http://example.com/terms/options/gfbio_project_type/gfbio_project_type_modelling	http://example.com/terms	gfbio_project_type/gfbio_project_type_modelling				f
234	gfio_project_type_other	6	Other	Andere	f	39		http://example.com/terms/options/gfbio_project_type/gfio_project_type_other	http://example.com/terms	gfbio_project_type/gfio_project_type_other				f
235	gfbio_funding_type_dfg_igp	0	DFG Individual Grant Programs	DFG-Individualförderprogramme	f	40		http://example.com/terms/options/gfbio_funding_type/gfbio_funding_type_dfg_igp	http://example.com/terms	gfbio_funding_type/gfbio_funding_type_dfg_igp				f
236	gfbio_funding_type_dfg_cp	1	DFG Coordinated Programmes	DFG Koordinierte Programme	f	40		http://example.com/terms/options/gfbio_funding_type/gfbio_funding_type_dfg_cp	http://example.com/terms	gfbio_funding_type/gfbio_funding_type_dfg_cp				f
237	gfbio_funding_type_dfg_es	2	Excellence Strategy	Exzellenz-Strategie	f	40		http://example.com/terms/options/gfbio_funding_type/gfbio_funding_type_dfg_es	http://example.com/terms	gfbio_funding_type/gfbio_funding_type_dfg_es				f
238	gfbio_funding_type_dfg_ri	3	Research Infrastructure	Forschungsinfrastruktur	f	40		http://example.com/terms/options/gfbio_funding_type/gfbio_funding_type_dfg_ri	http://example.com/terms	gfbio_funding_type/gfbio_funding_type_dfg_ri				f
239	gfbio_funding_type_dfg_ip	4	DFG International Programmes	DFG Internationale Programme	f	40		http://example.com/terms/options/gfbio_funding_type/gfbio_funding_type_dfg_ip	http://example.com/terms	gfbio_funding_type/gfbio_funding_type_dfg_ip				f
240	gfbio_funding_type_other	5	Other	Andere	f	40		http://example.com/terms/options/gfbio_funding_type/gfbio_funding_type_other	http://example.com/terms	gfbio_funding_type/gfbio_funding_type_other				f
241	gfbio_funding_type_none	6	None	Keine	f	40		http://example.com/terms/options/gfbio_funding_type/gfbio_funding_type_none	http://example.com/terms	gfbio_funding_type/gfbio_funding_type_none				f
242	gfbio_guideline_dfg_handling_research_data	0	DFG Guidelines on the Handling of Research Data	DFG-Richtlinien zum Umgang mit Forschungsdaten	f	41		http://example.com/terms/options/gfbio_policies_or_guidelines/gfbio_guideline_dfg_handling_research_data	http://example.com/terms	gfbio_policies_or_guidelines/gfbio_guideline_dfg_handling_research_data				f
243	gfbio_guideline_dfg_handling_research_data_biodiversity	1	DFG Guidelines on the Handling of Research Data in Biodiversity Research	DFG-Richtlinien zum Umgang mit Forschungsdaten in der Biodiversitätsforschung	f	41		http://example.com/terms/options/gfbio_policies_or_guidelines/gfbio_guideline_dfg_handling_research_data_biodiversity	http://example.com/terms	gfbio_policies_or_guidelines/gfbio_guideline_dfg_handling_research_data_biodiversity				f
244	gfbio_guideline_dfg_safeguarding_good_practice	2	DFG Guidelines for Safeguarding Good Scientific Practice	DFG-Richtlinien zur Sicherung guter wissenschaftlicher Praxis	f	41		http://example.com/terms/options/gfbio_policies_or_guidelines/gfbio_guideline_dfg_safeguarding_good_practice	http://example.com/terms	gfbio_policies_or_guidelines/gfbio_guideline_dfg_safeguarding_good_practice				f
245	gfbio_guideline_other	3	Other	Andere	f	41	add 2 empty fields to be displayed when this option is selected: \nFirst field for. "Other Research Data Policy and Guideline"\nSecond for: "Link Research Data Policy or Guidelines"	http://example.com/terms/options/gfbio_policies_or_guidelines/gfbio_guideline_other	http://example.com/terms	gfbio_policies_or_guidelines/gfbio_guideline_other				f
246	gfbio_guideline_none	4	None	Keine	f	41		http://example.com/terms/options/gfbio_policies_or_guidelines/gfbio_guideline_none	http://example.com/terms	gfbio_policies_or_guidelines/gfbio_guideline_none				f
247	gfbio_reproducible_one time observation	0	One-time observation	Einmalige Observation	f	42		http://example.com/terms/options/gfbio_research data_reproducible/gfbio_reproducible_one time observation	http://example.com/terms	gfbio_research data_reproducible/gfbio_reproducible_one time observation				f
248	gfbio_reproducible_repeatable	1	Repeatable experiments	Wiederholbare Experimente	f	42		http://example.com/terms/options/gfbio_research data_reproducible/gfbio_reproducible_repeatable	http://example.com/terms	gfbio_research data_reproducible/gfbio_reproducible_repeatable				f
249	gfbio_reproducible_time series	2	Time series	Zeitreihen	f	42		http://example.com/terms/options/gfbio_research data_reproducible/gfbio_reproducible_time series	http://example.com/terms	gfbio_research data_reproducible/gfbio_reproducible_time series				f
250	gfbio_research unit_yes	0	I am a member of a research unit (Forschergruppe)	Ich bin Mitglied einer Forschergruppe	f	43		http://example.com/terms/options/gfbio_research unit membership/gfbio_research unit_yes	http://example.com/terms	gfbio_research unit membership/gfbio_research unit_yes				f
255	gfbio_data_type_text	0	Text (notes, surveys, etc.)	Text (Notizen, Umfragen usw.)	f	46		http://example.com/terms/options/gfbio_data_type/gfbio_data_type_text	http://example.com/terms	gfbio_data_type/gfbio_data_type_text				f
256	gfbio_data_type_models_and_code	1	Models, code	Modelle, Code	f	46		http://example.com/terms/options/gfbio_data_type/gfbio_data_type_models_and_code	http://example.com/terms	gfbio_data_type/gfbio_data_type_models_and_code				f
257	gfbio_data_type_GIS	2	GIS data	GIS Daten	f	46		http://example.com/terms/options/gfbio_data_type/gfbio_data_type_GIS	http://example.com/terms	gfbio_data_type/gfbio_data_type_GIS				f
258	gfbio_data_type_numeric	3	Numeric (spreadsheet, measurements, etc.)	Numerisch (Tabellenkalkulation, Messungen usw.)	f	46		http://example.com/terms/options/gfbio_data_type/gfbio_data_type_numeric	http://example.com/terms	gfbio_data_type/gfbio_data_type_numeric				f
259	gfbio_data_type_multimedia	4	Multimedia (images, sounds, video, etc.)	Multimedia (Bilder, Töne, Video usw.)	f	46		http://example.com/terms/options/gfbio_data_type/gfbio_data_type_multimedia	http://example.com/terms	gfbio_data_type/gfbio_data_type_multimedia				f
260	gfbio_data_type_molecular	5	Molecular Sequence Data	Molekulare Sequenzdaten	f	46		http://example.com/terms/options/gfbio_data_type/gfbio_data_type_molecular	http://example.com/terms	gfbio_data_type/gfbio_data_type_molecular				f
261	gfbio_data_type_other	6	Other	Andere	f	46		http://example.com/terms/options/gfbio_data_type/gfbio_data_type_other	http://example.com/terms	gfbio_data_type/gfbio_data_type_other				f
262	cannot estimate	0	Cannot estimate	Kann nicht schätzen	f	47		http://example.com/terms/options/gfbio_data_volume/cannot estimate	http://example.com/terms	gfbio_data_volume/cannot estimate				f
263	<1GB	1	<1GB	<1GB	f	47		http://example.com/terms/options/gfbio_data_volume/<1GB	http://example.com/terms	gfbio_data_volume/<1GB				f
264	<10GB	2	<10GB	<10GB	f	47		http://example.com/terms/options/gfbio_data_volume/<10GB	http://example.com/terms	gfbio_data_volume/<10GB				f
265	<1TB	3	<1TB	<1TB	f	47		http://example.com/terms/options/gfbio_data_volume/<1TB	http://example.com/terms	gfbio_data_volume/<1TB				f
266	<5TB	4	<5TB	<5TB	f	47		http://example.com/terms/options/gfbio_data_volume/<5TB	http://example.com/terms	gfbio_data_volume/<5TB				f
267	<10TB	5	<10TB	<10TB	f	47		http://example.com/terms/options/gfbio_data_volume/<10TB	http://example.com/terms	gfbio_data_volume/<10TB				f
268	>10TB	6	>10TB	>10TB	f	47		http://example.com/terms/options/gfbio_data_volume/>10TB	http://example.com/terms	gfbio_data_volume/>10TB				f
269	gfbio_data_sets_numer_cannot_estimate	0	Cannot estimate	Kann nicht schätzen	f	48		http://example.com/terms/options/gfbio_data_sets_number/gfbio_data_sets_numer_cannot_estimate	http://example.com/terms	gfbio_data_sets_number/gfbio_data_sets_numer_cannot_estimate				f
270	<10	1	<10	<10	f	48		http://example.com/terms/options/gfbio_data_sets_number/<10	http://example.com/terms	gfbio_data_sets_number/<10				f
271	<100	2	<100	<100	f	48		http://example.com/terms/options/gfbio_data_sets_number/<100	http://example.com/terms	gfbio_data_sets_number/<100				f
272	<1000	4	<1000	<1000	f	48		http://example.com/terms/options/gfbio_data_sets_number/<1000	http://example.com/terms	gfbio_data_sets_number/<1000				f
273	>1000	5	>1000	>1000	f	48		http://example.com/terms/options/gfbio_data_sets_number/>1000	http://example.com/terms	gfbio_data_sets_number/>1000				f
274	gfbio_metadata_type_abcd	0	Access to Biological Collections Data, 2.06	Access to Biological Collections Data, 2.06	f	49	The following text should be additional information for this option:\n\nhttp://www.biocase.org/products/schema_repository/index.shtml\n\nThe Access to Biological Collections Data schema (ABCD) is the core standard of any BioCASe related network. Its primary use case is the publication of rich natural history collections specimen data, but it can also be used for general species occurrence datasets. It is XML-based (eXtensible Mark-up Language), meaning it stores the information in a structure that can be easily processed by software. The current major version 2.06 has been widely adopted by networks and is an accepted standard of Biodiversity Information Standards (also known as Taxonomic Databases Working Group ).	http://example.com/terms/options/gfbio_metadata_type/gfbio_metadata_type_abcd	http://example.com/terms	gfbio_metadata_type/gfbio_metadata_type_abcd				f
275	gfbio_metadata_type_dublin_core	1	Dublin Core, 1.1	Dublin Core, 1.1	f	49	the following should be included as provisionary information for this option:\n\nDublin Core (DC) is a metadata standard that was originally developed for libraries but its elements have been reused in many other formats as well, e.g. DWC. Dublin Core Metadata Element Set contains 15 elements and is an accepted ISO standard (ISO 15836:2009).	http://example.com/terms/options/gfbio_metadata_type/gfbio_metadata_type_dublin_core	http://example.com/terms	gfbio_metadata_type/gfbio_metadata_type_dublin_core				f
276	gfbio_metadata_type_darwin_core	2	Darwin Core, 2013-10-25	Darwin Core, 2013-10-25	f	49	the following should be included as provisionary information for this option:\n\nThe Darwin Core (DwC) is body of standards. It includes a glossary of terms intended to facilitate the sharing of information about biological diversity by providing reference definitions, examples, and commentaries. The Darwin Core is primarily based on taxa, their occurrence in nature as documented by observations, specimens, and samples, and related information. DwC is an accepted standard of Biodiversity Information Standards (also known as Taxonomic Databases Working Group ).	http://example.com/terms/options/gfbio_metadata_type/gfbio_metadata_type_darwin_core	http://example.com/terms	gfbio_metadata_type/gfbio_metadata_type_darwin_core				f
277	gfbio_metadata_type_europeana_data_model	3	Europeana Data Model, 5.2.3	Europeana Data Model, 5.2.3	f	49	the following should be included as provisionary information for this option:\n\nhttps://pro.europeana.eu/page/edm-documentation\n\nThe Europeana Data Model (EDM) aims at being an integration medium for collecting, connecting and enriching the descriptions provided by Europeana content providers.	http://example.com/terms/options/gfbio_metadata_type/gfbio_metadata_type_europeana_data_model	http://example.com/terms	gfbio_metadata_type/gfbio_metadata_type_europeana_data_model				f
278	gfbio_metadata_type_ecological_metadata_language	4	Ecological Metadata Language, 2.1.1	Ecological Metadata Language, 2.1.1	f	49	the following should be included as provisionary information for this option:\n\nThe Ecological Metadata Language (EML) is a set of XML Schema documents that allow for the structural expression of metadata necessary to document a typical data set in ecological sciences.	http://example.com/terms/options/gfbio_metadata_type/gfbio_metadata_type_ecological_metadata_language	http://example.com/terms	gfbio_metadata_type/gfbio_metadata_type_ecological_metadata_language				f
279	gfbio_metadata_type_europeana_sematic_elements	5	Europeana Semantic Elements, 3.4.1	Europeana Semantic Elements, 3.4.1	f	49	the following should be included as provisionary information for this option:\n\nhttps://pro.europeana.eu/page/ese-documentation\n\nEuropeana Semantic Elements (ESE) is a format, which provides a basic set of elements for describing objects in the cultural heritage domain in a way that is usable for Europeana.	http://example.com/terms/options/gfbio_metadata_type/gfbio_metadata_type_europeana_sematic_elements	http://example.com/terms	gfbio_metadata_type/gfbio_metadata_type_europeana_sematic_elements				f
280	gfbio_metadata_type_infrastructure_spatial_information_europe	6	Infrastructure for Spatial Information in the European Community, Directive 2007/2/EC	Infrastructure for Spatial Information in the European Community, Directive 2007/2/EC	f	49	Additional information to be included as part of the question when the option is presented:\n\nhttp://inspire.ec.europa.eu/about-inspire/563\n\nAim of the INSPIRE Directive is to create a European Union spatial data infrastructure that will help to make spatial or geographical information more accessible and interoperable for a wide range of purposes of EU environmental policies and policies or activities which may have an impact on the environment. On 15 May 2007 the INPIRE Directive came into force and will be implemented in various stages, with full implementation required by 2021.	http://example.com/terms/options/gfbio_metadata_type/gfbio_metadata_type_infrastructure_spatial_information_europe	http://example.com/terms	gfbio_metadata_type/gfbio_metadata_type_infrastructure_spatial_information_europe				f
281	gfbio_metadata_type_ISO_19115_geographic_information	7	ISO 19115 Geographic information (Metadata), 2014	ISO 19115 Geographic information (Metadata), 2014	f	49	To add when the option is presented:\n\nhttps://www.iso.org/standard/53798.html\n\nISO 19115-1:2014 Geographic information (Metadata) is a standard of the ISO (the International Organization for Standardization) and defines the schema required for describing geographic information and services by means of metadata. It provides information about the identification, the extent, the quality, the spatial and temporal aspects, the content, the spatial reference, the portrayal, distribution, and other properties of digital geographic data and services.	http://example.com/terms/options/gfbio_metadata_type/gfbio_metadata_type_ISO_19115_geographic_information	http://example.com/terms	gfbio_metadata_type/gfbio_metadata_type_ISO_19115_geographic_information				f
282	gfbio_metadata_type_MIxS	8	Minimum Information about any (x) Sequence, 4.0	Minimum Information about any (x) Sequence, 4.0	f	49	To add to the option:\n\nThe MIxS standard (Minimum Information about any (x) Sequence) is an overarching framework providing a single entry point to all minimum information checklists from the Genomic Standards Consortium (GSC) and to the environmental packages. MIxS includes the technology-specific checklists from the previous MIGS (Minimum Information about a Genome Sequence) and MIMS (Minimum Information about a Metagenome Sequence) standards. It provides a way to introduce additional checklists such as MIMARKS (Minimum Information about a Marker Gene Sequence), and allows annotation of sample data using environmental packages. MIxS was published in Nature Biotechnology in 2011.	http://example.com/terms/options/gfbio_metadata_type/gfbio_metadata_type_MIxS	http://example.com/terms	gfbio_metadata_type/gfbio_metadata_type_MIxS				f
283	gfbio_metdata_type_other_metadata	9	Other metadata or documentation	Andere Metadaten oder Dokumentation	t	49		http://example.com/terms/options/gfbio_metadata_type/gfbio_metdata_type_other_metadata	http://example.com/terms	gfbio_metadata_type/gfbio_metdata_type_other_metadata				f
284	gfbio_legal_requiremnts_IUCN	0	IUCN Red List of Threatened Species	IUCN Red List of Threatened Species	f	50	this and other options of the option set, have additional information to be displayed!	http://example.com/terms/options/gfbio_legal_requirements/gfbio_legal_requiremnts_IUCN	http://example.com/terms	gfbio_legal_requirements/gfbio_legal_requiremnts_IUCN				f
285	gfbio_legal_requirements_sensitive_personal_information	1	Sensitive Personal Information	Sensible persönliche Informationen	f	50		http://example.com/terms/options/gfbio_legal_requirements/gfbio_legal_requirements_sensitive_personal_information	http://example.com/terms	gfbio_legal_requirements/gfbio_legal_requirements_sensitive_personal_information				f
286	gfbio_legal_requirements_nagoya_protocol	2	Nagoya Protocol	Nagoya Protokoll	f	50		http://example.com/terms/options/gfbio_legal_requirements/gfbio_legal_requirements_nagoya_protocol	http://example.com/terms	gfbio_legal_requirements/gfbio_legal_requirements_nagoya_protocol				f
287	gfbio_legal_requirements_uncertain	3	Uncertain	Unsicher	f	50		http://example.com/terms/options/gfbio_legal_requirements/gfbio_legal_requirements_uncertain	http://example.com/terms	gfbio_legal_requirements/gfbio_legal_requirements_uncertain				f
288	gfbio_legal_requirements_other	4	Other	Andere	t	50		http://example.com/terms/options/gfbio_legal_requirements/gfbio_legal_requirements_other	http://example.com/terms	gfbio_legal_requirements/gfbio_legal_requirements_other				f
289	gfbio_legal_requirements_not_applicable	5	Not applicable	Nicht zutreffend	f	50		http://example.com/terms/options/gfbio_legal_requirements/gfbio_legal_requirements_not_applicable	http://example.com/terms	gfbio_legal_requirements/gfbio_legal_requirements_not_applicable				f
290	gfbio_license_CC_BY	0	CC BY: Creative Commons Attribution-4.0	CC BY: Creative Commons Attribution-4.0	f	51	this information should appear when clicking in this option:\n\nhttps://creativecommons.org/licenses/by/4.0/	http://example.com/terms/options/gfbio_license/gfbio_license_CC_BY	http://example.com/terms	gfbio_license/gfbio_license_CC_BY				f
291	gfbio_license_CC_BY_NC	1	CC BY-NC: Creative Commons Attribution- NonCommercial-4.0	CC BY-NC: CReative Commons Attribution- NonCommercial-4.0	f	51	https://creativecommons.org/licenses/by-nc/4.0/	http://example.com/terms/options/gfbio_license/gfbio_license_CC_BY_NC	http://example.com/terms	gfbio_license/gfbio_license_CC_BY_NC				f
292	gfbio_license_CC_BY_NC_ND	2	CC BY-NC-ND: Creative Commons Attribution-NonCommercial-NoDerivs-4.0	CC BY-NC-ND: Creative Commons Attribution-NonCommercial-NoDerivs-4.0	f	51	to add when clicking in the option:\n\nhttps://creativecommons.org/licenses/by-nc-nd/4.0/	http://example.com/terms/options/gfbio_license/gfbio_license_CC_BY_NC_ND	http://example.com/terms	gfbio_license/gfbio_license_CC_BY_NC_ND				f
293	gfbio_license_CC_NY_NC_SA	3	CC BY-NC-SA: Creative Commons Attribution-NonCommercial-ShareAlike-4.0	CC BY-NC-SA: Creative Commons Attribution-NonCommercial-ShareAlike-4.0	f	51	to add when clicking in the question:\n\nhttps://creativecommons.org/licenses/by-nc-sa/4.0/	http://example.com/terms/options/gfbio_license/gfbio_license_CC_NY_NC_SA	http://example.com/terms	gfbio_license/gfbio_license_CC_NY_NC_SA				f
294	CC_BY_ND	4	CC BY-ND: Creative Commons Attribution-NoDerivs-4.0	CC BY-ND: Creative Commons Attribution-NoDerivs-4.0	f	51	to add when clicking in option:\n\nhttps://creativecommons.org/licenses/by-nd/4.0/	http://example.com/terms/options/gfbio_license/CC_BY_ND	http://example.com/terms	gfbio_license/CC_BY_ND				f
295	gfbio_license_CC_BY_SA	5	CC BY-SA: Creative Commons Attribution-ShareAlike-4.0	CC BY-SA: Creative Commons Attribution-ShareAlike-4.0	f	51	to add when clicking in option:\n\n\nhttps://creativecommons.org/licenses/by-sa/4.0/	http://example.com/terms/options/gfbio_license/gfbio_license_CC_BY_SA	http://example.com/terms	gfbio_license/gfbio_license_CC_BY_SA				f
296	gfbio_license_CC0	6	CC0: Creative Commons Zero-1.0	CC0: Creative Commons Zero-1.0	f	51	to add when clicking in option:\n\n\nhttps://creativecommons.org/publicdomain/zero/1.0/	http://example.com/terms/options/gfbio_license/gfbio_license_CC0	http://example.com/terms	gfbio_license/gfbio_license_CC0				f
297	gfbio_license_other	7	Other License	Andere Lizenz	t	51		http://example.com/terms/options/gfbio_license/gfbio_license_other	http://example.com/terms	gfbio_license/gfbio_license_other				f
298	gfbio_license_not_applicable	8	Not applicable	Nicht zutreffend	f	51		http://example.com/terms/options/gfbio_license/gfbio_license_not_applicable	http://example.com/terms	gfbio_license/gfbio_license_not_applicable				f
299	gfbio_time_data_submission_to_GFBio_data_linked_to_article	0	Data linked to an article (or another kind of publication) will be submitted before or at the same time as the publication of the article.	Daten, die mit einem Artikel (oder einer anderen Art von Publikation) verknüpft sind, werden vor oder gleichzeitig mit der Veröffentlichung des Artikels eingereicht.	f	52		http://example.com/terms/options/gfbio_time_data_submission_to_GFBio/gfbio_time_data_submission_to_GFBio_data_linked_to_article	http://example.com/terms	gfbio_time_data_submission_to_GFBio/gfbio_time_data_submission_to_GFBio_data_linked_to_article				f
300	gfbio_time_data_submission_to_GFBio_continuous_submission_datasets	1	Datasets will continously be submitted during the project´s runtime.	Die Datensätze werden während der Laufzeit des Projekts fortlaufend eingereicht.	f	52		http://example.com/terms/options/gfbio_time_data_submission_to_GFBio/gfbio_time_data_submission_to_GFBio_continuous_submission_datasets	http://example.com/terms	gfbio_time_data_submission_to_GFBio/gfbio_time_data_submission_to_GFBio_continuous_submission_datasets				f
301	gfbio_time_data_submission_to_GFBio_end_project_submission_datasets	2	All datasets will be submitted at the end of the project.	Alle Datensätze werden am Ende des Projekts eingereicht.	f	52		http://example.com/terms/options/gfbio_time_data_submission_to_GFBio/gfbio_time_data_submission_to_GFBio_end_project_submission_datasets	http://example.com/terms	gfbio_time_data_submission_to_GFBio/gfbio_time_data_submission_to_GFBio_end_project_submission_datasets				f
302	gfbio_time_data_submission_to_GFBio_one_year_end_project_submission_datasets	3	All datasets will be submitted no later than one year after the project's end.	Alle Datensätze werden spätestens ein Jahr nach Projektende eingereicht.	f	52		http://example.com/terms/options/gfbio_time_data_submission_to_GFBio/gfbio_time_data_submission_to_GFBio_one_year_end_project_submission_datasets	http://example.com/terms	gfbio_time_data_submission_to_GFBio/gfbio_time_data_submission_to_GFBio_one_year_end_project_submission_datasets				f
303	gfbio_time_data_submission_to_GFBio_other_submission_plan	4	Other submission plan	Anderer Einreichplan	f	52		http://example.com/terms/options/gfbio_time_data_submission_to_GFBio/gfbio_time_data_submission_to_GFBio_other_submission_plan	http://example.com/terms	gfbio_time_data_submission_to_GFBio/gfbio_time_data_submission_to_GFBio_other_submission_plan				f
304	gfbio_data_long_term_archiving_GFBio_Data_Centers	0	GFBio Data Centers	GFBio-Datenzentren	f	53		http://example.com/terms/options/gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_GFBio_Data_Centers	http://example.com/terms	gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_GFBio_Data_Centers				f
305	gfbio_data_long_term_archiving_BGBM	1	BGBM	BGBM	f	53		http://example.com/terms/options/gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_BGBM	http://example.com/terms	gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_BGBM				f
306	gfbio_data_long_term_archiving_DZMZ	2	DZMZ	DZMZ	f	53		http://example.com/terms/options/gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_DZMZ	http://example.com/terms	gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_DZMZ				f
307	gfbio_data_long_term_archiving_ENA	3	ENA	ENA	f	53		http://example.com/terms/options/gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_ENA	http://example.com/terms	gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_ENA				f
308	gfbio_data_long_term_archiving_MfN	4	MfN	MfN	f	53		http://example.com/terms/options/gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_MfN	http://example.com/terms	gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_MfN				f
309	gfbio_data_long_term_archiving_PANGAEA	5	PANGAEA	PANGAEA	f	53		http://example.com/terms/options/gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_PANGAEA	http://example.com/terms	gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_PANGAEA				f
310	gfbio_data_long_term_archiving_SGN	5	SGN	SGN	f	53		http://example.com/terms/options/gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_SGN	http://example.com/terms	gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_SGN				f
311	gfbio_data_long_term_archiving_SMNS	6	SMNS	SMNS	f	53		http://example.com/terms/options/gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_SMNS	http://example.com/terms	gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_SMNS				f
312	gfbio_data_long_term_archiving_SNSB	8	SNSB	SNSB	f	53		http://example.com/terms/options/gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_SNSB	http://example.com/terms	gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_SNSB				f
313	gfbio_data_long_term_archiving_ZFMK	9	ZFMK	ZFMK	f	53		http://example.com/terms/options/gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_ZFMK	http://example.com/terms	gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_ZFMK				f
314	gfbio_data_long_term_archiving_Other	9	Other	Andere	f	53		http://example.com/terms/options/gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_Other	http://example.com/terms	gfbio_data_long_term_archiving/gfbio_data_long_term_archiving_Other				f
315	gfbio_research_category_type_algae_&_protists	0	Algae & Protists	Algen & Protisten	f	54		http://example.com/terms/options/gfbio_research_category_type/gfbio_research_category_type_algae_&_protists	http://example.com/terms	gfbio_research_category_type/gfbio_research_category_type_algae_&_protists				f
316	gfbio_research_category_type_bacteriology_virology	1	Bacteriology, Virology	Bakteriologie, Virologie	f	54		http://example.com/terms/options/gfbio_research_category_type/gfbio_research_category_type_bacteriology_virology	http://example.com/terms	gfbio_research_category_type/gfbio_research_category_type_bacteriology_virology				f
317	gfbio_research_category_type_botany	2	Botany	Botanik	f	54		http://example.com/terms/options/gfbio_research_category_type/gfbio_research_category_type_botany	http://example.com/terms	gfbio_research_category_type/gfbio_research_category_type_botany				f
318	gfbio_research_category_type_ecology_&_environment	3	Ecology & Environment	Ökologie & Umwelt	f	54		http://example.com/terms/options/gfbio_research_category_type/gfbio_research_category_type_ecology_&_environment	http://example.com/terms	gfbio_research_category_type/gfbio_research_category_type_ecology_&_environment				f
319	gfbio_research_category_type_geoscience	4	Geoscience	Geowissenschaften	f	54		http://example.com/terms/options/gfbio_research_category_type/gfbio_research_category_type_geoscience	http://example.com/terms	gfbio_research_category_type/gfbio_research_category_type_geoscience				f
320	gfbio_research_category_type_microbiology	5	Microbiology	Mikrobiologie	f	54		http://example.com/terms/options/gfbio_research_category_type/gfbio_research_category_type_microbiology	http://example.com/terms	gfbio_research_category_type/gfbio_research_category_type_microbiology				f
321	gfbio_research_category_type_mycology	6	Mycology	Mykologie	f	54		http://example.com/terms/options/gfbio_research_category_type/gfbio_research_category_type_mycology	http://example.com/terms	gfbio_research_category_type/gfbio_research_category_type_mycology				f
322	gfbio_research_category_type_paleontology	7	Paleontology	Paläontologie	f	54		http://example.com/terms/options/gfbio_research_category_type/gfbio_research_category_type_paleontology	http://example.com/terms	gfbio_research_category_type/gfbio_research_category_type_paleontology				f
323	gfbio_research_category_type_zoology	8	Zoology	Zoologie	f	54		http://example.com/terms/options/gfbio_research_category_type/gfbio_research_category_type_zoology	http://example.com/terms	gfbio_research_category_type/gfbio_research_category_type_zoology				f
324	gfbio_research_category_type_other	9	Other	Andere	f	54		http://example.com/terms/options/gfbio_research_category_type/gfbio_research_category_type_other	http://example.com/terms	gfbio_research_category_type/gfbio_research_category_type_other				f
325	options	0	Same as point of contact for project data	Dasselbe wie die Kontaktstelle für Projektdaten	f	55		http://example.com/terms/options/gfbio_principal_investigators/options	http://example.com/terms	gfbio_principal_investigators/options				f
326	yes_recommended	0	Yes (recommended)	Ja (empfohlen)	f	56		http://example.com/terms/options/gfbio_persistent_identifier_to_data/yes_recommended	http://example.com/terms	gfbio_persistent_identifier_to_data/yes_recommended				f
327	No	1	No	Nein	f	56		http://example.com/terms/options/gfbio_persistent_identifier_to_data/No	http://example.com/terms	gfbio_persistent_identifier_to_data/No				f
328	do_not_know_yet	2	Don't know yet	Weiß ich noch nicht	f	56		http://example.com/terms/options/gfbio_persistent_identifier_to_data/do_not_know_yet	http://example.com/terms	gfbio_persistent_identifier_to_data/do_not_know_yet				f
329	other	1	Other	Andere	t	55		http://example.com/terms/options/gfbio_principal_investigators/other	http://example.com/terms	gfbio_principal_investigators/other				f
330	acces_restriction_data_yes01	0	yes	ja	f	57		http://example.com/terms/options/gfbio_access_restriction_data/acces_restriction_data_yes01	http://example.com/terms	gfbio_access_restriction_data/acces_restriction_data_yes01				f
331	access_restriction_data_no02	1	no	nein	f	57		http://example.com/terms/options/gfbio_access_restriction_data/access_restriction_data_no02	http://example.com/terms	gfbio_access_restriction_data/access_restriction_data_no02				f
332	submit_physical_object_yes	0	yes	ja	f	58		http://example.com/terms/options/gfbio_physical_object_yesno/submit_physical_object_yes	http://example.com/terms	gfbio_physical_object_yesno/submit_physical_object_yes				f
333	submit_physical_object_no	-1	no	nein	f	58		http://example.com/terms/options/gfbio_physical_object_yesno/submit_physical_object_no	http://example.com/terms	gfbio_physical_object_yesno/submit_physical_object_no				f
334	taxon_based_yes	0	yes	no	f	59		http://example.com/terms/options/gfbio_taxon_based_yesno/taxon_based_yes	http://example.com/terms	gfbio_taxon_based_yesno/taxon_based_yes				f
335	taxon_based_no	1	no	nein	f	59		http://example.com/terms/options/gfbio_taxon_based_yesno/taxon_based_no	http://example.com/terms	gfbio_taxon_based_yesno/taxon_based_no				f
336	object_Alive	0	Alive	Lebendig	f	60		http://example.com/terms/options/gfbio_Dead_or_Alive/object_Alive	http://example.com/terms	gfbio_Dead_or_Alive/object_Alive				f
\.


--
-- Data for Name: options_optionset; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.options_optionset (id, key, "order", comment, uri, uri_prefix, provider_key, locked) FROM stdin;
1	control_tools	0	Übersicht über Methoden zur Kontrolle und Dokumentation der Konsistenz und Qualität von erhobenen Daten	https://rdmorganiser.github.io/terms/options/control_tools	https://rdmorganiser.github.io/terms		f
2	data_protection_laws	0		https://rdmorganiser.github.io/terms/options/data_protection_laws	https://rdmorganiser.github.io/terms		f
3	dataset_anonymisation	0		https://rdmorganiser.github.io/terms/options/dataset_anonymisation	https://rdmorganiser.github.io/terms		f
4	dataset_collaboration_options	0		https://rdmorganiser.github.io/terms/options/dataset_collaboration_options	https://rdmorganiser.github.io/terms		f
5	dataset_copyright_laws	0		https://rdmorganiser.github.io/terms/options/dataset_copyright_laws	https://rdmorganiser.github.io/terms		f
6	dataset_interoperability_options	0		https://rdmorganiser.github.io/terms/options/dataset_interoperability_options	https://rdmorganiser.github.io/terms		f
7	dataset_license_options	0		https://rdmorganiser.github.io/terms/options/dataset_license_options	https://rdmorganiser.github.io/terms		f
8	dataset_license_types	0		https://rdmorganiser.github.io/terms/options/dataset_license_types	https://rdmorganiser.github.io/terms		f
9	dataset_origin_options	0		https://rdmorganiser.github.io/terms/options/dataset_origin_options	https://rdmorganiser.github.io/terms		f
10	dataset_other_rights	0		https://rdmorganiser.github.io/terms/options/dataset_other_rights	https://rdmorganiser.github.io/terms		f
11	dataset_reproducible_options	0		https://rdmorganiser.github.io/terms/options/dataset_reproducible_options	https://rdmorganiser.github.io/terms		f
12	dataset_sharing_options	0		https://rdmorganiser.github.io/terms/options/dataset_sharing_options	https://rdmorganiser.github.io/terms		f
13	dataset_size_options	0		https://rdmorganiser.github.io/terms/options/dataset_size_options	https://rdmorganiser.github.io/terms		f
14	dataset_versioning_technology_options	0		https://rdmorganiser.github.io/terms/options/dataset_versioning_technology_options	https://rdmorganiser.github.io/terms		f
15	ethics_committee_approval_options	0		https://rdmorganiser.github.io/terms/options/ethics_committee_approval_options	https://rdmorganiser.github.io/terms		f
16	ethics_permit_options	0		https://rdmorganiser.github.io/terms/options/ethics_permit_options	https://rdmorganiser.github.io/terms		f
17	informed_consent_options	0		https://rdmorganiser.github.io/terms/options/informed_consent_options	https://rdmorganiser.github.io/terms		f
18	infrastructure_resources	0		https://rdmorganiser.github.io/terms/options/infrastructure_resources	https://rdmorganiser.github.io/terms		f
19	mandatory_metadata_options	0		https://rdmorganiser.github.io/terms/options/mandatory_metadata_options	https://rdmorganiser.github.io/terms		f
20	metadata_check_options	0		https://rdmorganiser.github.io/terms/options/metadata_check_options	https://rdmorganiser.github.io/terms		f
21	metadata_standards	0		https://rdmorganiser.github.io/terms/options/metadata_standards	https://rdmorganiser.github.io/terms		f
22	other_requirements_options	0		https://rdmorganiser.github.io/terms/options/other_requirements_options	https://rdmorganiser.github.io/terms		f
23	pid_types	0		https://rdmorganiser.github.io/terms/options/pid_types	https://rdmorganiser.github.io/terms		f
24	preservation_motivation_options	0		https://rdmorganiser.github.io/terms/options/preservation_motivation_options	https://rdmorganiser.github.io/terms		f
25	preservation_repository_options	0		https://rdmorganiser.github.io/terms/options/preservation_repository_options	https://rdmorganiser.github.io/terms		f
26	research_fields	0		https://rdmorganiser.github.io/terms/options/research_fields	https://rdmorganiser.github.io/terms		f
27	software_copyright_laws	0		https://rdmorganiser.github.io/terms/options/software_copyright_laws	https://rdmorganiser.github.io/terms		f
28	software_license_options	0		https://rdmorganiser.github.io/terms/options/software_license_options	https://rdmorganiser.github.io/terms		f
29	software_license_types	0		https://rdmorganiser.github.io/terms/options/software_license_types	https://rdmorganiser.github.io/terms		f
30	software_origin_options	0		https://rdmorganiser.github.io/terms/options/software_origin_options	https://rdmorganiser.github.io/terms		f
31	software_other_rights	0		https://rdmorganiser.github.io/terms/options/software_other_rights	https://rdmorganiser.github.io/terms		f
32	software_sharing_options	0		https://rdmorganiser.github.io/terms/options/software_sharing_options	https://rdmorganiser.github.io/terms		f
33	software_versioning_technology_options	0		https://rdmorganiser.github.io/terms/options/software_versioning_technology_options	https://rdmorganiser.github.io/terms		f
34	yes_no_not_yet	0		https://rdmorganiser.github.io/terms/options/yes_no_not_yet	https://rdmorganiser.github.io/terms		f
35	yes_with_text_no	0		https://rdmorganiser.github.io/terms/options/yes_with_text_no	https://rdmorganiser.github.io/terms		f
36	open_access	0		https://fdm-bayern.org/eHumanities/options/open_access	https://fdm-bayern.org/eHumanities		f
37	publication_form	0		https://fdm-bayern.org/eHumanities/options/publication_form	https://fdm-bayern.org/eHumanities		f
39	gfbio_project_type	-5	only applicable for the GFBio questionnaire and /or the catalog	http://example.com/terms/options/gfbio_project_type	http://example.com/terms		f
40	gfbio_funding_type	-10	only for the GFBio questionnaire and/or catalog	http://example.com/terms/options/gfbio_funding_type	http://example.com/terms		f
41	gfbio_policies_or_guidelines	-6		http://example.com/terms/options/gfbio_policies_or_guidelines	http://example.com/terms		f
42	gfbio_research data_reproducible	-3		http://example.com/terms/options/gfbio_research data_reproducible	http://example.com/terms		f
43	gfbio_research unit membership	-2		http://example.com/terms/options/gfbio_research unit membership	http://example.com/terms		f
46	gfbio_data_type	-13		http://example.com/terms/options/gfbio_data_type	http://example.com/terms		f
47	gfbio_data_volume	-12		http://example.com/terms/options/gfbio_data_volume	http://example.com/terms		f
48	gfbio_data_sets_number	-14		http://example.com/terms/options/gfbio_data_sets_number	http://example.com/terms		f
49	gfbio_metadata_type	-7		http://example.com/terms/options/gfbio_metadata_type	http://example.com/terms		f
50	gfbio_legal_requirements	-9		http://example.com/terms/options/gfbio_legal_requirements	http://example.com/terms		f
51	gfbio_license	-8		http://example.com/terms/options/gfbio_license	http://example.com/terms		f
52	gfbio_time_data_submission_to_GFBio	-1		http://example.com/terms/options/gfbio_time_data_submission_to_GFBio	http://example.com/terms		f
53	gfbio_data_long_term_archiving	-15		http://example.com/terms/options/gfbio_data_long_term_archiving	http://example.com/terms		f
54	gfbio_research_category_type	-4		http://example.com/terms/options/gfbio_research_category_type	http://example.com/terms		f
55	gfbio_principal_investigators	-16		http://example.com/terms/options/gfbio_principal_investigators	http://example.com/terms		f
56	gfbio_persistent_identifier_to_data	-17		http://example.com/terms/options/gfbio_persistent_identifier_to_data	http://example.com/terms		f
57	gfbio_access_restriction_data	-19		http://example.com/terms/options/gfbio_access_restriction_data	http://example.com/terms		f
58	gfbio_physical_object_yesno	-20		http://example.com/terms/options/gfbio_physical_object_yesno	http://example.com/terms		f
59	gfbio_taxon_based_yesno	-21		http://example.com/terms/options/gfbio_taxon_based_yesno	http://example.com/terms		f
60	gfbio_Dead_or_Alive	-11	In response to the question in 'Data Collection': Is your object dead or alive?	http://example.com/terms/options/gfbio_Dead_or_Alive	http://example.com/terms		f
\.


--
-- Data for Name: options_optionset_conditions; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.options_optionset_conditions (id, optionset_id, condition_id) FROM stdin;
\.


--
-- Data for Name: overlays_overlay; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.overlays_overlay (id, url_name, current, site_id, user_id) FROM stdin;
1	projects		1	1
2	project		1	1
\.


--
-- Data for Name: projects_continuation; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.projects_continuation (id, created, updated, project_id, questionset_id, user_id) FROM stdin;
\.


--
-- Data for Name: projects_integration; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.projects_integration (id, provider_key, project_id) FROM stdin;
\.


--
-- Data for Name: projects_integrationoption; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.projects_integrationoption (id, key, value, integration_id, secret) FROM stdin;
\.


--
-- Data for Name: projects_invite; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.projects_invite (id, email, role, token, "timestamp", project_id, user_id) FROM stdin;
\.


--
-- Data for Name: projects_issue; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.projects_issue (id, status, project_id, task_id) FROM stdin;
1	open	1	1
2	open	1	2
3	open	1	4
4	open	1	3
5	open	1	5
6	open	1	6
7	open	1	7
8	open	1	8
9	open	1	9
10	open	1	10
11	open	1	11
\.


--
-- Data for Name: projects_issueresource; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.projects_issueresource (id, url, integration_id, issue_id) FROM stdin;
\.


--
-- Data for Name: projects_membership; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.projects_membership (id, role, project_id, user_id) FROM stdin;
1	owner	1	1
\.


--
-- Data for Name: projects_project; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.projects_project (id, created, updated, title, description, catalog_id, site_id, level, lft, parent_id, rght, tree_id) FROM stdin;
1	2021-07-13 19:41:13.985389+00	2021-07-15 10:22:27.135211+00	P1	P1	3	1	0	1	\N	2	1
\.


--
-- Data for Name: projects_project_views; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.projects_project_views (id, project_id, view_id) FROM stdin;
1	1	1
2	1	2
3	1	3
4	1	4
5	1	5
6	1	6
7	1	7
\.


--
-- Data for Name: projects_snapshot; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.projects_snapshot (id, created, updated, project_id, description, title) FROM stdin;
1	2021-07-15 10:14:27.156333+00	2021-07-15 10:14:27.156341+00	1		one
\.


--
-- Data for Name: projects_value; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.projects_value (id, created, updated, set_index, collection_index, text, attribute_id, option_id, snapshot_id, project_id, unit, value_type, external_id, file) FROM stdin;
\.


--
-- Data for Name: questions_catalog; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.questions_catalog (id, created, updated, "order", title_lang1, title_lang2, comment, key, uri, uri_prefix, title_lang3, title_lang4, title_lang5, help_lang1, help_lang2, help_lang3, help_lang4, help_lang5, available, locked) FROM stdin;
3	2021-07-13 19:37:25.951553+00	2021-07-13 19:37:25.951563+00	0	Cat1			Cat1	http://0.0.0.0:8000/questions/Cat1	http://0.0.0.0:8000/				cat					t	f
8	2020-04-14 14:47:19.58+00	2020-04-14 14:47:19.58+00	0	RDMO	RDMO		rdmo	https://rdmorganiser.github.io/terms/questions/rdmo	https://rdmorganiser.github.io/terms									t	f
9	2020-04-14 14:58:23.031+00	2020-05-12 08:10:37.987+00	9	DFG	DFG	Dieser Fragenkatalog ist eine Teilmenge des Katalogs "RDMO" und enthält nur die Fragen, die die Anforderungen in den "Leitlinien zum Umgang mit Forschungsdaten" der DFG, http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten, abdecken. Die Fragen sind somit ausgesucht für Datenmanagementpläne, die Förderanträgen an die Deutsche Forschungsgemeinschaft (DFG) beigelegt werden sollen und keine fachspezifischen Zusatzanforderungen zu erfüllen haben.	dfg	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo									t	f
10	2020-04-14 14:59:58.996+00	2020-04-14 14:59:58.996+00	4	Educational Sci. + DFG	Bildungswissensch. + DFG	Dieser Fragenkatalog ist eine Teilmenge des Katalogs "RDMO" und enthält nur die Fragen, die die Anforderungen\n\n - im Memorandum des Fachkollegiums „Erziehungswissenschaft“ der DFG "Bereitstellung und Nutzung quantitativer Forschungsdaten in der Bildungsforschung", https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf, und\n\n - in den "Leitlinien zum Umgang mit Forschungsdaten" der DFG, http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten \n\nabdecken. Die Fragen sind somit ausgesucht für bildungswissenschaftliche Datenmanagementpläne, die Förderanträgen an die Deutsche Forschungsgemeinschaft (DFG) beigelegt werden sollen.	edu_dfg	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo									t	f
12	2020-04-14 15:07:37.546+00	2020-04-14 15:07:37.546+00	30	Horizon 2020 Grants	Horizon 2020 Katalog	Data management plan questionnaire for ERC Horizon 2020 grants. In bold font: questions of the ERC H2020 DMP template. In normal font: Comments and guidance for answering the questions. For further support you can always contact the\n\t\t\t<a>Link.</a>	Horizon2020	https://fdm-bayern.org/eHumanities/questions/Horizon2020	https://fdm-bayern.org/eHumanities									t	f
18	2020-04-29 09:13:51.87+00	2020-11-08 14:54:36.634+00	5	GFBio test catalog	GFBio Testkatalog	This catalog is a test catalog, created manually.\n\nIt is based on the current questionnaire available on the DMPT of GFBio. \n\nOther information for the criteria on the question sets here: https://gfbio.biowikifarm.net/internal/DMPT_Draft_Meeting_in_G%C3%B6ttingen_08.06.2016#.284.29_Questionnaire.2C_content.CB.90_Synopsis	GFBio test	http://example.com/terms/questions/GFBio test	http://example.com/terms									t	f
19	2020-05-12 07:54:41.919+00	2020-05-12 10:43:27.032+00	6	Alternative GFBio Test Catalog	Alternative GFBio Test Catalog		Alternative GFBio	http://example.com/terms/questions/Alternative GFBio	http://example.com/terms									t	f
21	2020-10-28 14:09:43.083+00	2020-10-28 14:09:43.083+00	290	DFG Biodiversity research	DFG Biodiversitätsforschung		biodiversity_dfg	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg	https://rdmorganiser.github.io/terms									t	f
22	2020-11-08 14:50:37.93+00	2020-11-08 14:50:37.93+00	0				Test GFBio_2	http://example.com/terms/questions/Test GFBio_2	http://example.com/terms									t	f
\.


--
-- Data for Name: questions_catalog_groups; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.questions_catalog_groups (id, catalog_id, group_id) FROM stdin;
1	3	1
\.


--
-- Data for Name: questions_catalog_sites; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.questions_catalog_sites (id, catalog_id, site_id) FROM stdin;
3	3	1
\.


--
-- Data for Name: questions_question; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.questions_question (id, created, updated, uri, uri_prefix, key, path, comment, is_collection, "order", help_lang1, help_lang2, text_lang1, text_lang2, widget_type, value_type, unit, attribute_id, questionset_id, maximum, minimum, step, verbose_name_lang2, verbose_name_lang1, verbose_name_plural_lang2, verbose_name_plural_lang1, help_lang3, help_lang4, help_lang5, text_lang3, text_lang4, text_lang5, verbose_name_lang3, verbose_name_lang4, verbose_name_lang5, verbose_name_plural_lang3, verbose_name_plural_lang4, verbose_name_plural_lang5, locked, is_optional, default_text_lang1, default_text_lang2, default_text_lang3, default_text_lang4, default_text_lang5, default_option_id, default_external_id) FROM stdin;
3	2021-07-15 13:10:27.599345+00	2021-07-15 13:17:38.543729+00	http://example.com/terms/questions/Cat1/sec1/set1/q2	http://example.com/terms	q2	Cat1/sec1/set1/q2	q2l sdföon sdäpfg soädifn	f	1	\N	\N	\N	\N	text	text		4	4	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	t	\N	\N	\N	\N	\N	\N	
1	2021-07-13 19:40:53.613684+00	2021-07-15 13:19:45.161579+00	http://0.0.0.0:8000/questions/Cat1/sec1/set1/q1	http://0.0.0.0:8000/	q1	Cat1/sec1/set1/q1	vcbfdsh sdrb dfb df	f	0	Question no 1		Ques1		text	text		\N	4	\N	3	\N		Q1		Q1s			ues										f	f	Default q1					\N	
4	2021-07-15 13:32:21.056079+00	2021-07-15 13:32:21.056087+00	http://example.com/terms/questions/Cat1/sec1/set1/q3	http://example.com/terms	q3	Cat1/sec1/set1/q3	\N	f	2	\N	\N	\N	\N	yesno	boolean		\N	4	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
141	2020-04-14 14:47:22.414+00	2020-04-14 14:47:22.414+00	https://rdmorganiser.github.io/terms/questions/rdmo/content-classification/data-dataset/description	https://rdmorganiser.github.io/terms	description	rdmo/content-classification/data-dataset/description		f	1	Please briefly describe the data type and / or the method used to create or collect the data, for example: 1. Line (new line char: "Enter") 2. Line (new line char: "double space") 3. Line (new line char:\n\t\t\t"&#xA;") 4. Line (new line char: "&#xD;") * quantitative online survey * 3D model / digital reconstruction of a stone age settlement * software developed within the project	Bitte beschreiben Sie hier kurz, um welchen Datentyp es sich handelt und mit welcher Methode die Daten erhoben oder erstellt wurden, z.B.: * quantitative Online-Befragung * 3D-Modellierung / digitale Rekonstruktion einer\n\t\t\tsteinzeitlichen Siedlung * Software, die im Projekt entwickelt wird	What kind of dataset is it?	Um was für einen Datensatz handelt es sich?	textarea	text		61	58	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
142	2020-04-14 14:47:22.459+00	2020-04-14 14:47:22.459+00	https://rdmorganiser.github.io/terms/questions/rdmo/content-classification/data-existing_data/creator_name	https://rdmorganiser.github.io/terms	creator_name	rdmo/content-classification/data-existing_data/creator_name		f	2	\N	\N	If re-used, who created the dataset?	Wenn nachgenutzt, wer hat den Datensatz erzeugt?	textarea	text		46	59	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
143	2020-04-14 14:47:22.508+00	2020-04-14 14:47:22.508+00	https://rdmorganiser.github.io/terms/questions/rdmo/content-classification/data-existing_data/origin	https://rdmorganiser.github.io/terms	origin	rdmo/content-classification/data-existing_data/origin		f	1	\N	\N	Is the dataset being created or re-used?	Wird der Datensatz selbst erzeugt oder nachgenutzt?	radio	text		85	59	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
144	2020-04-14 14:47:22.605+00	2020-04-14 14:47:22.605+00	https://rdmorganiser.github.io/terms/questions/rdmo/content-classification/data-existing_data/uri	https://rdmorganiser.github.io/terms	uri	rdmo/content-classification/data-existing_data/uri		f	3	\N	\N	If re-used, under which address, PID or URL can the dataset be found?	Wenn nachgenutzt, unter welcher Adresse, PID oder URL ist der Datensatz verfügbar?	text	text		139	59	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
145	2020-04-14 14:47:22.662+00	2020-04-14 14:47:22.662+00	https://rdmorganiser.github.io/terms/questions/rdmo/content-classification/data-reproducibility/reproducibility	https://rdmorganiser.github.io/terms	reproducibility	rdmo/content-classification/data-reproducibility/reproducibility		f	2	Some data can, technically, be created anew at any time, as is the case with scientific experiments or digitised versions of analog objects (as long as the originals are still there and in good shape). However, this can consume a\n\t\t\tconsiderable amount of time and cost. With respect to long-term preservation, the effort of re-creation has to be weighed up against the effort of long-term preservation. Other data cannot be collected or created anew. Examples are all kinds of\n\t\t\t"time stamped" observations, be they from social science, astrophysics or any other discipline. Observations represent a certain phenomenon at a certain time and / or place and are therefore not repeatable. Their value for re-use as well as\n\t\t\tthe loss in case of failed preservation is much higher than that of reproducible data.	Manche Daten können im Prinzip jederzeit neu erstellt werden. Beispiele hierfür sind etwa naturwissenschaftliche Experimentdaten oder auch Digitalisate analoger Objekte (solange die Originale nicht verlorengehen). Der Aufwand und die\n\t\t\tKosten hierfür können natürlich durchaus beträchtlich sein. Im Hinblick auf die Frage der Notwendigkeit einer späteren Langzeitarchivierung sollte in diesen Fällen der Aufwand einer erneuten Erstellung gegen den Aufwand der Langzeitarchivierung\n\t\t\tabgewogen werden. Andere Daten wiederum lassen sich per se nicht erneut erheben. Dies ist etwa bei jeglicher Art von episodischer Beobachtungen, sei es sozialwissenschaftlicher oder naturwissenschaftlicher Art, der Fall, da diese ein bestimmtes\n\t\t\tPhänomen an einem bestimmten Zeitpunkt und/oder Ort abbilden und somit i.d.R. nicht wiederholbar sind. Ihr Wert für die Nachnutzung durch andere wie auch der Verlust bei einer nicht erfolgten oder misslungenen Langzeitarchivierung ist ungleich höher\n\t\t\tals bei reproduzierbaren Daten.	Is the dataset reproducible in the sense that it could be created / collected anew in case it got lost?	Ist der Datensatz reproduzierbar, d. h. ließe sich er sich, wenn er verloren ginge, erneut erstellen oder erheben?	radio	text		105	60	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
146	2020-04-14 14:47:22.77+00	2020-04-14 14:47:22.77+00	https://rdmorganiser.github.io/terms/questions/rdmo/content-classification/data-reuse/scenario	https://rdmorganiser.github.io/terms	scenario	rdmo/content-classification/data-reuse/scenario		f	1	It is important to set the fundamental course as to whether or not the data will be permitted for reuse. Of course, the potential for subsequent use can not be the sole decision criterion, but legal impediments, such as Privacy,\n\t\t\tcopyright and business secrets must be taken into account. Otherwise, consider the re-use potential against the disadvantages, e.g. a decrease in the readiness to participate and the expected extra effort of a data publication.	Wichtig ist die grundsätzliche Weichenstellung, ob die Daten zur Nachnutzung zugelassen werden oder nicht. Selbstverständlich kann das Nachnutzungspotential dabei nicht alleiniges Entscheidungskriterium sein, sondern rechtliche\n\t\t\tHinderungsgründe, wie z.B. Datenschutz, Urheberrecht und die Wahrung von Geschäftsgeheimnissen, müssen berücksichtigt werden. Wägen Sie ansonsten das Nachnutzungspotential gegen die Nachteile ab, beispielsweise gegen ein Absinken der\n\t\t\tTeilnahmebereitschaft und den zu erwartenden Mehraufwand einer Datenveröffentlichung.	Which individuals, groups or institutions could be interested in re-using this dataset? What consequences does the re-use potential have for the provision of the data later?	Für welche Personen, Gruppen oder Institutionen könnte dieser Datensatz (für die Nachnutzung) von Interesse sein? Welche Konsequenzen hat das Nachnutzungspotential später für die Bereitstellung der Daten?	textarea	text		106	61	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
147	2020-04-14 14:47:22.834+00	2020-04-14 14:47:22.834+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/collaborative-work-collaboration/organisation	https://rdmorganiser.github.io/terms	organisation	rdmo/data-usage/collaborative-work-collaboration/organisation		f	8	\N	\N	How is the collaborative work on the same files organised?	Wie ist das kollaborative Arbeiten an denselben Dateien geregelt?	textarea	text		40	62	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
148	2020-04-14 14:47:22.883+00	2020-04-14 14:47:22.883+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/collaborative-work-collaboration/tools	https://rdmorganiser.github.io/terms	tools	rdmo/data-usage/collaborative-work-collaboration/tools		f	7	\N	\N	Which platform / tools is / are used for collaboratively working on data and publications?	Welche Plattform, welche Werkzeuge werden zum kollaborativen Arbeiten an Daten und Publikationen genutzt?	textarea	text		41	62	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
149	2020-04-14 14:47:22.931+00	2020-04-14 14:47:22.931+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/collaborative-work-collaboration/yesno	https://rdmorganiser.github.io/terms	yesno	rdmo/data-usage/collaborative-work-collaboration/yesno		f	6	\N	\N	Will the data be collaboratively used?	Werden die Daten kollaborativ genutzt?	radio	text		42	62	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
150	2020-04-14 14:47:23.031+00	2020-04-14 14:47:23.031+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/costs-dataset/creation_non_personnel	https://rdmorganiser.github.io/terms	creation_non_personnel	rdmo/data-usage/costs-dataset/creation_non_personnel		f	2	Please estimate the effort in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel-costs for data management associated with the creation or acquisiton of data in the project?	Welche Sachkosten für das Datenmanagement entstehen im Rahmen der Erhebung, Erstellung oder Akquise der Daten im Projekt?	text	float	Euro	9	63	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
151	2020-04-14 14:47:23.135+00	2020-04-14 14:47:23.135+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/costs-dataset/creation_personnel	https://rdmorganiser.github.io/terms	creation_personnel	rdmo/data-usage/costs-dataset/creation_personnel		f	1	Please estimate the effort in person months ( 1 PM = monthly working time of a full-time employee).	Bitte schätzen sie den Aufwand in Personenmonaten ( 1 PM = Monatsarbeitszeit eines Vollzeitbeschäftigten).	What are the personnel costs for data management associated with the creation or acquisition of data in the project?	Welcher Personalaufwand für das Datenmanagement entsteht im Rahmen der Erhebung, Erstellung oder Akquise der Daten im Projekt?	range	float	PM	10	63	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
152	2020-04-14 14:47:23.185+00	2020-04-14 14:47:23.185+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/costs-dataset/storage_non_personnel	https://rdmorganiser.github.io/terms	storage_non_personnel	rdmo/data-usage/costs-dataset/storage_non_personnel		f	6	Please estimate the costs in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel costs associated with the storage of the data sets during the project?	Welche Sachkosten entstehen im Zusammenhang mit der Speicherung der Datensätze während des Projektes?	text	float	Euro	32	63	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
153	2020-04-14 14:47:23.233+00	2020-04-14 14:47:23.233+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/costs-dataset/storage_personnel	https://rdmorganiser.github.io/terms	storage_personnel	rdmo/data-usage/costs-dataset/storage_personnel		f	5	Please estimate the effort in person months ( 1 PM = monthly working time of a full-time employee).	Bitte schätzen sie den Aufwand in Personenmonaten. (1 PM = Monatsarbeitszeit eines Vollzeitbeschäftigten)	What are the personnel costs associated with data storage and data security in the project?	Welcher Personalaufwand entsteht im Zusammenhang mit der Speicherung der Daten und Maßnahmen zur Datensicherheit während des Projektes?	range	float	PM	33	63	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
154	2020-04-14 14:47:23.283+00	2020-04-14 14:47:23.283+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/costs-dataset/usage_non_personnel	https://rdmorganiser.github.io/terms	usage_non_personnel	rdmo/data-usage/costs-dataset/usage_non_personnel		f	4	Please estimate the costs in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel-costs for data management associated with the usage of data in the project?	Welche Sachkosten für das Datenmanagement entstehen im Zusammenhang mit der Nutzung der Daten im Projekt?	text	float	Euro	35	63	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
155	2020-04-14 14:47:23.334+00	2020-04-14 14:47:23.334+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/costs-dataset/usage_personnel	https://rdmorganiser.github.io/terms	usage_personnel	rdmo/data-usage/costs-dataset/usage_personnel		f	3	Please estimate the effort in person months ( 1 PM = monthly working time of a full-time employee).	Bitte schätzen sie den Aufwand in Personenmonaten. (1 PM = Monatsarbeitszeit eines Vollzeitbeschäftigten)	What are the personnel costs for data management associated with the the usage of data in the project?	Welcher Personalaufwand für das Datenmanagement entsteht im Zusammenhang mit der Nutzung der Daten im Projekt?	range	float	PM	36	63	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
156	2020-04-14 14:47:23.383+00	2020-04-14 14:47:23.383+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-sharing-and-re-use-interoperability/interoperability	https://rdmorganiser.github.io/terms	interoperability	rdmo/data-usage/data-sharing-and-re-use-interoperability/interoperability	wortlaut noch relativ nah an Original-H2020-Frage	t	1	\N	\N	Is this dataset interoperable, i.e. allowing data exchange and re-use between researchers, institutions, organisations, countries etc.?	Ist der Datensatz interoperabel, d.h. geeignet für den Datenaustausch und die Nachnutzung zwischen bzw. von unterschiedlichen Forschenden, Institutionen, Oranisationen und Ländern?	checkbox	option		66	64	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
157	2020-04-14 14:47:23.492+00	2020-04-14 14:47:23.492+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-sharing-and-re-use-publication/conditions	https://rdmorganiser.github.io/terms	conditions	rdmo/data-usage/data-sharing-and-re-use-publication/conditions		t	3	The options refer to the licenses of the <a href="https://creativecommons.org/share-your-work/licensing-types-examples/" target=_blank">Creative Commons family</a>.	Die Auswahlmöglichkeiten orientieren sich an Lizenzen der <a href="http://de.creativecommons.org/was-ist-cc/" target=_blank">Creative-Commons-Familie</a>.	If yes, under which terms of use or license will the dataset be published or shared?	Wenn ja, unter welchen Nutzungsbedingungen oder welcher Lizenz sollen die Daten veröffentlicht bzw. geteilt werden?	checkbox	text		122	65	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
158	2020-04-14 14:47:23.59+00	2020-04-14 14:47:23.59+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-sharing-and-re-use-publication/data_publication_date	https://rdmorganiser.github.io/terms	data_publication_date	rdmo/data-usage/data-sharing-and-re-use-publication/data_publication_date		f	6	\N	\N	When will the data be published (if they are)?	Wann werden die Daten veröffentlicht?	date	datetime		53	65	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
159	2020-04-14 14:47:23.682+00	2020-04-14 14:47:23.682+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-sharing-and-re-use-publication/explanation	https://rdmorganiser.github.io/terms	explanation	rdmo/data-usage/data-sharing-and-re-use-publication/explanation		f	2	\N	\N	If no, please explain why not. Please differentiate between legal and contractual reasons and voluntary restrictions.	Wenn nicht, begründen Sie dies bitte und unterscheiden Sie dabei zwischen rechtlichen und/oder vertraglichen Gründen und freiwilligen Einschränkungen.	textarea	text		123	65	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
160	2020-04-14 14:47:23.734+00	2020-04-14 14:47:23.734+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-sharing-and-re-use-publication/restrictions_explanation	https://rdmorganiser.github.io/terms	restrictions_explanation	rdmo/data-usage/data-sharing-and-re-use-publication/restrictions_explanation		f	4	\N	\N	If there are any restrictions on the re-use of this dataset, please explain why.	Sollte die Nachnutzung dieses Datensatzes Einschränkungen unterliegen, erläutern Sie bitte die Gründe.	textarea	text		125	65	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
161	2020-04-14 14:47:23.797+00	2020-04-14 14:47:23.797+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-sharing-and-re-use-publication/yesno	https://rdmorganiser.github.io/terms	yesno	rdmo/data-usage/data-sharing-and-re-use-publication/yesno		f	1	\N	\N	Will this dataset be published or shared?	Soll dieser Datensatz veröffentlicht oder geteilt werden?	radio	boolean		127	65	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
162	2020-04-14 14:47:23.886+00	2020-04-14 14:47:23.886+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-storage-and-security-data_security/access_permissions	https://rdmorganiser.github.io/terms	access_permissions	rdmo/data-usage/data-storage-and-security-data_security/access_permissions		f	1	e.g. project members, partners of the project, only in-house, external partners	z.B. Projektmitglieder, Projektpartner, nur Interne, externe Partner	Who is allowed to access the dataset?	Wer darf auf den Datensatz zugreifen?	textarea	text		55	66	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
163	2020-04-14 14:47:23.944+00	2020-04-14 14:47:23.944+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-storage-and-security-data_security/backups	https://rdmorganiser.github.io/terms	backups	rdmo/data-usage/data-storage-and-security-data_security/backups		f	2	This question refers to backups while the data is being worked with. Questions of long-term preservation will be adressed in the respective section.	Die Frage bezieht sich auf Backups während der Zeit, in denen mit den Daten gearbeitet wird. Fragen der Langzeitarchivierung werden gesondert im entsprechenden Abschnitt behandelt.	How and how often will backups of the data be created?	Wie und wie oft werden Backups der Daten erstellt?	textarea	text		58	66	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
164	2020-04-14 14:47:23.992+00	2020-04-14 14:47:23.992+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-storage-and-security-data_security/name	https://rdmorganiser.github.io/terms	name	rdmo/data-usage/data-storage-and-security-data_security/name		t	3	This question refers to backups while the data is being worked with. Questions of long-term preservation will be adressed in the respective section.	Die Frage bezieht sich auf Backups während der Zeit, in denen mit den Daten gearbeitet wird. Fragen der Langzeitarchivierung werden gesondert im entsprechenden Abschnitt behandelt.	Who is responsible for the backups?	Wer ist verantwortlich für die Erstellung der Backups?	text	text		57	66	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
165	2020-04-14 14:47:24.043+00	2020-04-14 14:47:24.043+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-storage-and-security-data_security/security_measures	https://rdmorganiser.github.io/terms	security_measures	rdmo/data-usage/data-storage-and-security-data_security/security_measures		f	4	\N	\N	Which measures or provisions are in place to ensure data security (e.g. protection against unauthorized access, data recovery, transfer of sensitive data)?	Welche Maßnahmen zur Gewährleistung der Datensicherheit werden getroffen (z. B. Schutz vor unbefugtem Zugriff, Datenwiederherstellung, Übertragung sensibler Daten)?	textarea	text		60	66	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
166	2020-04-14 14:47:24.092+00	2020-04-14 14:47:24.092+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-storage-and-security-storage/naming_policy	https://rdmorganiser.github.io/terms	naming_policy	rdmo/data-usage/data-storage-and-security-storage/naming_policy		f	4	\N	\N	Is there a internal project guideline for naming the data? If so, please briefly outline the naming conventions and, if necessary, link to the documentation.	Gibt es eine projektinterne Richtlinie zur Benennung der Daten? Wenn ja, bitte skizzieren Sie sie kurz und verlinken Sie ggf. zu einer ausführlicheren Dokumentation.	radio	text		133	67	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
167	2020-04-14 14:47:24.204+00	2020-04-14 14:47:24.204+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-storage-and-security-storage/organisation_policy	https://rdmorganiser.github.io/terms	organisation_policy	rdmo/data-usage/data-storage-and-security-storage/organisation_policy		f	3	\N	\N	Are there internal project guidelines for a consistent organisation of the data? If so, where they are documented?	Gibt es projektinterne Richtlinien zur einheitlichen Organisation der Daten? Wenn ja, wo sind diese festgehalten?	radio	text		134	67	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
168	2020-04-14 14:47:24.299+00	2020-04-14 14:47:24.299+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-storage-and-security-storage/type	https://rdmorganiser.github.io/terms	type	rdmo/data-usage/data-storage-and-security-storage/type		f	1	\N	\N	Where is the dataset stored during the project?	Wo wird der Datensatz während des Projektes gespeichert?	textarea	text		135	67	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
169	2020-04-14 14:47:24.359+00	2020-04-14 14:47:24.359+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-storage-and-security-storage/uri	https://rdmorganiser.github.io/terms	uri	rdmo/data-usage/data-storage-and-security-storage/uri		f	2	\N	\N	Under which URL can the dataset be accessed during the project?	Unter welcher URL kann der Datensatz während des Projektes abgerufen werden?	text	text		136	67	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
170	2020-04-14 14:47:24.407+00	2020-04-14 14:47:24.407+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/quality-assurance-dataset/measures	https://rdmorganiser.github.io/terms	measures	rdmo/data-usage/quality-assurance-dataset/measures		f	7	Examples are checks for completeness, data reconciliation, sampling procedures. These measures serve to identify documentation errors and arithmetical anomalies.	Beispiele sind Überprüfung auf Vollständigkeit, Datenabgleich, Stichprobenverfahren. Diese Maßnahmen dienen dazu Dokumentationsfehler und rechnerische Auffälligkeiten zu ermitteln.	Which measures of quality assurance are taken for this dataset?	Welche Maßnahmen zur Qualitätssicherung werden für diesen Datensatz ergriffen?	textarea	text		103	68	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
171	2020-04-14 14:47:24.458+00	2020-04-14 14:47:24.458+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/quality-assurance-integration/integration	https://rdmorganiser.github.io/terms	integration	rdmo/data-usage/quality-assurance-integration/integration	the stipulation that re-used and created data are of the same type (= and thus capable to be integrated) is problematic, since this implies properties of the data that are not a given. May be this shoud be reformulated to : Is the between\n\t\t\tre-used and created data ensures (which goes into the provenance realm)	f	0	For example, how is the origin and quality of the data documented?	Wie wird z. B. Herkunft und Qualität der Daten dokumentiert?	Is the integration between the re-used and newly created data ensured? If yes, by which means?	Wird die Integration zwischen nachgenutzten und erzeugten Daten gewährleistet? Wenn ja, wie?	textarea	text		65	69	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
172	2020-04-14 14:47:24.507+00	2020-04-14 14:47:24.507+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/scenarios-usage/description	https://rdmorganiser.github.io/terms	description	rdmo/data-usage/scenarios-usage/description		f	0	\N	\N	How / for what purpose will this dataset be used during the project?	Wozu / wie wird dieser Datensatz während des Projektes genutzt?	textarea	text		140	70	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
173	2020-04-14 14:47:24.558+00	2020-04-14 14:47:24.558+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/scenarios-usage/frequency	https://rdmorganiser.github.io/terms	frequency	rdmo/data-usage/scenarios-usage/frequency		f	3	\N	\N	How often will this dataset be used?	Wie häufig wird dieser Datensatz genutzt?	text	text		141	70	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
174	2020-04-14 14:47:24.622+00	2020-04-14 14:47:24.622+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/scenarios-usage/infrastructure	https://rdmorganiser.github.io/terms	infrastructure	rdmo/data-usage/scenarios-usage/infrastructure		f	4	\N	\N	To what extent will infrastructure resources be required (e.g. CPU hours, bandwidth, storage space... etc.).	In welchem Umfang werden Infrastrukturressourcen benötigt (CPU-Stunden, Bandbreite, Speicherplatz etc.)?	radio	text		142	70	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
175	2020-04-14 14:47:24.711+00	2020-04-14 14:47:24.711+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/scenarios-usage/support	https://rdmorganiser.github.io/terms	support	rdmo/data-usage/scenarios-usage/support		f	5	\N	\N	Are there actual or potential usage scenarios that could benefit from support by a data management or IT expert, or that even require such support?	Gibt es beabsichtigte (ggf. auch potentielle) Nutzungsszenarien, für die die Unterstützung durch Datenmanagement- oder IT-ExpertInnen sinnvoll oder notwendig ist?	radio	text		143	70	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
176	2020-04-14 14:47:24.821+00	2020-05-14 10:58:57.058+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/funding-funder/funder_policy	https://rdmorganiser.github.io/terms	funder_policy	rdmo/general/funding-funder/funder_policy		f	2	Funders of research also increasingly specify requirements regarding the management of research data in funded projects. Examples are the <a\n\t\t\thref="https://www.dfg.de/en/research_funding/proposal_review_decision/applicants/research_data/index.html" target=_blank">DFG Guidelines on the Handling of Reserach Data</a> or the <a\n\t\t\thref="http://ec.europa.eu/research/participants/data/ref/h2020/grants_manual/hi/oa_pilot/h2020-hi-oa-data-mgt_en.pdf" target=_blank">Guidelines on Data Management in Horizon 2020</a> of the European Commission.	Auch Forschungsförderer stellen zunehmend Anforderungen an das Datenmanagement in von ihnen geförderten Projekten. Beispiele sind die <a\n\t\t\thref="https://www.dfg.de/foerderung/antrag_gutachter_gremien/antragstellende/nachnutzung_forschungsdaten/index.html" target=_blank">DFG-Leitlinien zum Umgang mit Forschungsdaten</a> oder die <a\n\t\t\thref="http://ec.europa.eu/research/participants/data/ref/h2020/grants_manual/hi/oa_pilot/h2020-hi-oa-data-mgt_en.pdf" target=_blank">Guidelines on Data Management in Horizon 2020</a> der Europäischen Komission.	Does the funder have rules or recommendations for data management? If yes, please briefly outline them and refer to more detailed sources of information if necessary. Please also indicate, if the rules / guidelines are mandatory or optional.	Gibt es von Seiten des Forschungsförderers Vorgaben oder Richtlinien bezüglich des Umgangs mit den im Projekt erhobenen Forschungsdaten? Wenn ja, skizzieren Sie diese kurz und verweisen Sie ggf. auf weiterführende Informationen. Geben\n\t\t\tSie bitte auch an, welchen Grad an Verbindlichkeit sie haben.	textarea	text		157	71	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
177	2020-04-14 14:47:24.874+00	2020-05-14 10:58:56.97+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/funding-funder/name	https://rdmorganiser.github.io/terms	name	rdmo/general/funding-funder/name		f	0	\N	\N	Who is funding the project?	Wer fördert das Projekt?	text	text		153	71	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
178	2020-04-14 14:47:24.924+00	2020-05-14 10:58:57.021+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/funding-funder/title	https://rdmorganiser.github.io/terms	title	rdmo/general/funding-funder/title		f	1	\N	\N	Is the project within a special funding programme?	In welcher Förderlinie und/oder welchem Förderprogramm wird das Projekt gefördert?	text	text		155	71	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
179	2020-04-14 14:47:24.972+00	2020-05-14 10:58:57.24+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/other-requirements-requirements/requirements	https://rdmorganiser.github.io/terms	requirements	rdmo/general/other-requirements-requirements/requirements		f	0	Please briefly outline them and refer to more detailed sources of information if necessary. Please also indicate, if the rules / guidelines are mandatory or optional.	Bitte skizzieren Sie sie kurz und verweisen Sie ggf. auf weiterführende Informationen. Geben Sie bitte auch an, welchen Grad an Verbindlichkeit sie haben.	Which are these additional requirements regarding data management?	Welche Anforderungen an das Datenmanagement sind dies?	textarea	text		3	72	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
180	2020-04-14 14:47:25.028+00	2020-05-14 10:58:57.151+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/other-requirements-yesno/yesno	https://rdmorganiser.github.io/terms	yesno	rdmo/general/other-requirements-yesno/yesno		f	0	Examples of discipline-specific requirements are: - <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/guidelines_biodiversity_research.pdf" target=_blank">Guidelines on the Handling\n\t\t\tof Research Data in Biodiversity Research</a> - <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target=_blank">Guidelines for the\n\t\t\tprovision and use of quantitative data in education research (German)</a> - <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/foerderkriterien_editionen_literaturwissenschaft.pdf"\n\t\t\ttarget=_blank">Elegibility criteria for funding for scholarly editions in the literary studies (German)</a> - Recommendations on <a\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_sprachkorpora.pdf" target=_blank">data standards and tools</a> as well as <a\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_recht.pdf" target=_blank">legal aspects</a> associated with language corpora (German)	Beispiele für fachspezifische Empfehlungen und Richtlinien sind: - <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_biodiversitaetsforschung.pdf"\n\t\t\ttarget=_blank">Richtlinien zum Umgang mit Forschungsdaten in der Biodiversitätsforschung</a> - Empfehlungen zur <a\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target=_blank">Bereitstellung und Nutzung quantitativer Daten in der Bildungsforschung</a> -\n\t\t\t<a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/foerderkriterien_editionen_literaturwissenschaft.pdf" target=_blank">Förderkriterien für wissenschaftliche Editionen in der\n\t\t\tLiteraturwissenschaft</a> - Empfehlungen zu - <a href="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_sprachkorpora.pdf"\n\t\t\ttarget=_blank">datentechnischen Standards und Tools</a> sowie zu - <a href="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_recht.pdf"\n\t\t\ttarget=_blank">rechtlichen Fragen</a> bei der Erhebung von Sprachkorpora	Are there requirements regarding the data management from other parties (e.g. the scholarly/scientific community)?	Gibt es von weiteren Seiten (z. B. von der Fachcommunity) Anforderungen an das Datenmanagement, die beachtet werden müssen?	radio	boolean		4	73	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
181	2020-04-14 14:47:25.138+00	2020-05-14 10:58:56.697+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/project-partners-name/name	https://rdmorganiser.github.io/terms	name	rdmo/general/project-partners-name/name		t	0	\N	\N	Which persons or institutions are responsible for the project coordination?	Welche Personen oder Institutionen sind verantwortlich für die Projektkoordination?	text	text		6	74	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
182	2020-04-14 14:47:25.189+00	2020-05-14 10:58:56.876+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/project-partners-partner/contact	https://rdmorganiser.github.io/terms	contact	rdmo/general/project-partners-partner/contact		t	3	Please give the name and an email address.	Bitte geben Sie den Namen und eine Email Adresse an.	Who is/are the contact person(s) for data management questions?	Wer ist bei diesem Partner der/die Ansprechpartner/in für das Datenmanagement?	text	text		180	75	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
183	2020-04-14 14:47:25.239+00	2020-05-14 10:58:56.786+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/project-partners-partner/name	https://rdmorganiser.github.io/terms	name	rdmo/general/project-partners-partner/name		f	0	Please insert the name of project partner in detail.	Bitte geben Sie hier den ausführlichen Namen des Projektpartners an.	Project partner	Projektpartner	text	text		183	75	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
195	2020-04-14 14:47:26.039+00	2020-04-14 14:47:26.039+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/intellectual-property-rights-dataset/owner	https://rdmorganiser.github.io/terms	owner	rdmo/legal-and-ethics/intellectual-property-rights-dataset/owner		f	3	\N	\N	Was investigated who the rights owner is?	Wurde der/die Rechteinhaber/in recherchiert?	radio	option		71	81	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
184	2020-04-14 14:47:25.303+00	2020-05-14 10:58:56.833+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/project-partners-partner/rdm_policy	https://rdmorganiser.github.io/terms	rdm_policy	rdmo/general/project-partners-partner/rdm_policy		f	1	More and more universities and scientific institutions adopt research data management policies. These contain, among other things, recommendations and / or demands concerning the handling of research data by researchers of the\n\t\t\tinstitution, for example the <a href="http://www.uni-goettingen.de/en/488918.html" target=_blank">Research data policy of the Georg-August University Goettingen</a>.	Immer mehr Hochschulen und wissenschaftliche Einrichtungen verabschieden Leitlinien oder Richtlinien (oft auch als „Policies“ bezeichnet) zum Forschungsdatenmanagement. Diese enthalten unter anderem Empfehlungen und/oder Vorgaben zum\n\t\t\tUmgang mit Forschungsdaten, die die Wissenschaftlerinnen und Wissenschaftler der Einrichtung beachten sollten oder müssen (je nach Grad der Verbindlichkeit), zum Beispiel die <a\n\t\t\thref="http://www.uni-goettingen.de/de/01-juli-2014-forschungsdaten-leitlinie-der-universitaet-goettingen-einschl-umg/488918.html" target=_blank">Leitlinien zum Umgang mit Forschungsdaten</a> der Georg-August-Universität\n\t\t\tGöttingen.	Does your institution have rules or guidelines for the handling of research data? If yes, please briefly outline them and refer to more detailed sources of information if necessary. Please also indicate, if the rules / guidelines are\n\t\t\tmandatory or optional.	Gibt es an Ihrer Einrichtung Regeln oder Richtlinien zum Umgang mit den im Projekt erhobenen Forschungsdaten? Wenn ja, skizzieren Sie diese kurz und verweisen Sie ggf. auf weiterführende Informationen. Geben Sie bitte auch an, welchen\n\t\t\tGrad an Verbindlichkeit sie haben.	textarea	text		184	75	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
185	2020-04-14 14:47:25.352+00	2020-05-14 10:58:56.592+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/project-schedule-schedule/project_end	https://rdmorganiser.github.io/terms	project_end	rdmo/general/project-schedule-schedule/project_end		f	2	\N	\N	When does the project end?	Wann endet die Projektlaufzeit?	date	datetime		205	76	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
186	2020-04-14 14:47:25.403+00	2020-05-14 10:58:56.552+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/project-schedule-schedule/project_start	https://rdmorganiser.github.io/terms	project_start	rdmo/general/project-schedule-schedule/project_start		f	0	Provide the anticipated starting date, if the project did not started yet.	Geben Sie das voraussichtliche Datum an, falls das Projekt noch nciht gestartet ist.	When does the project start?	Wann beginnt die Projektlaufzeit?	date	datetime		206	76	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
187	2020-04-14 14:47:25.454+00	2020-05-14 10:58:56.495+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/topic-research_field/research_field	https://rdmorganiser.github.io/terms	research_field	rdmo/general/topic-research_field/research_field	for Germany, the classification works, but we might consider also DDC as an option	t	0	The list of disciplines follows the <a href="http://www.dfg.de/en/dfg_profile/statutory_bodies/review_boards/subject_areas/index.jsp" target=_blank">subject classification of the DFG (German Research Foundation)</a>.	Die Liste der Disziplinen entspricht der <a href="http://www.dfg.de/dfg_profil/gremien/fachkollegien/faecher/" target=_blank">Fachsystematik der Deutschen Forschungsgemeinschaft (DFG)</a>.	Which research field(s) does this project belong to?	Welcher Disziplin / welchen Disziplinen ist das Projekt zuzuordnen?	select	text		200	77	\N	\N	\N	Forschungsdisziplin	discipline	Forschungsdisziplinen	disciplines	\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
188	2020-04-14 14:47:25.566+00	2020-05-18 10:45:47.481+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/topic-research_question/keywords	https://rdmorganiser.github.io/terms	keywords	rdmo/general/topic-research_question/keywords		t	2	\N	\N	Please give some keywords describing the research question.	Bitte geben Sie einige Schlagworte zur Forschungsfrage an.	text	text		202	78	\N	\N	\N	Schlagwort	keyword	Schlagwörter	keywords	\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
189	2020-04-14 14:47:25.618+00	2020-05-18 10:44:22.969+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/topic-research_question/title	https://rdmorganiser.github.io/terms	title	rdmo/general/topic-research_question/title		f	1	Describe briefly the project and its aims.	Bitte beschreiben Sie kurz das Projekt und dessen Ziele.	What is the main research question of the project?	Wie lautet die primäre Forschungsfrage des Projektes?	textarea	text		203	78	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
190	2020-04-14 14:47:25.668+00	2020-04-14 14:47:25.668+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/general-legal-issues-international_yesno/international_yesno	https://rdmorganiser.github.io/terms	international_yesno	rdmo/legal-and-ethics/general-legal-issues-international_yesno/international_yesno		f	0	If you answer this question with "Yes", please get in touch with the legal department or a respective contact person at your institution to clarify if this has consequences for the project and its data management and if yes,\n\t\t\twhat consequences these are.	Falls Sie diese Frage mit "Ja" beantworten, setzen Sie sich bitte mit der Rechtsabteilung bzw. einem/r entsprechenden Ansprechpartner/in an Ihrer Institution in Verbindung, um zu klären, ob sich daraus Konsequenzen für Ihr\n\t\t\tProjekt ergeben und wenn ja, welche dies sind.	Does the legal situation of different countries have to be considered?	Muss die rechtliche Situation verschiedener Länder berücksichtigt werden?	yesno	boolean		160	79	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
191	2020-04-14 14:47:25.718+00	2020-04-14 14:47:25.718+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/intellectual-property-rights-costs/non_personnel	https://rdmorganiser.github.io/terms	non_personnel	rdmo/legal-and-ethics/intellectual-property-rights-costs/non_personnel		f	3	Please estimate the costs in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel-costs regarding intellectual property rights in the project?	Welche Sachkosten entstehen im Zusammenhang mit Urheber- und verwandten Schutzrechten im Projekt?	text	float	Euro	12	80	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
192	2020-04-14 14:47:25.768+00	2020-04-14 14:47:25.768+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/intellectual-property-rights-costs/personnel	https://rdmorganiser.github.io/terms	personnel	rdmo/legal-and-ethics/intellectual-property-rights-costs/personnel		f	1	Please estimate the effort in person months.	Bitte schätzen sie den Aufwand in Personenmonaten.	What are the personnel costs associated with intellectual property rights in the project?	Welcher Personalaufwand entsteht im Zusammenhang mit Urheber- oder verwandten Schutzrechten im Projekt?	range	float	PM	13	80	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
193	2020-04-14 14:47:25.836+00	2020-04-14 14:47:25.836+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/intellectual-property-rights-dataset/copyrights	https://rdmorganiser.github.io/terms	copyrights	rdmo/legal-and-ethics/intellectual-property-rights-dataset/copyrights		t	0	\N	\N	Does copyright law apply to this dataset?	Be- oder entstehen an diesem Datensatz Urheberrechte?	checkbox	text		68	81	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
194	2020-04-14 14:47:25.932+00	2020-04-14 14:47:25.932+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/intellectual-property-rights-dataset/other_rights	https://rdmorganiser.github.io/terms	other_rights	rdmo/legal-and-ethics/intellectual-property-rights-dataset/other_rights		t	2	\N	\N	Do other intellectual property rights apply to this dataset?	Be- oder entstehen an diesem Datensatz andere Schutzrechte?	checkbox	text		69	81	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
196	2020-04-14 14:47:26.133+00	2020-04-14 14:47:26.133+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/intellectual-property-rights-yesno/yesno	https://rdmorganiser.github.io/terms	yesno	rdmo/legal-and-ethics/intellectual-property-rights-yesno/yesno		f	0	Data or software can be subject to intellectual or industrial property rights. Applicable laws differ broadly even within EU. According to the German copyright law (UrhG) works of literature, scholarship and the arts that can be\n\t\t\tregarded as a “personal intellectual creation” are protected by copyright. Copyright protection expires 70 years after the death of the copyright holder. Mere data, e.g. measured data or survey data, and metadata (except in some cases descriptive\n\t\t\tmetadata) are not protected by copyright. § 2 of the UrhG lists the following kinds of protected works (list is not concluded): * linguistic works such as written works, speeches and computer programs * works of music * pantomimic works including\n\t\t\tworks of the art of dance * works or the fine arts including works of architecture and the applied arts as well as sketches of such works * works of photography and cinematography * descriptions and illustrations of scholarly or technical nature such\n\t\t\tas drawings, plans, maps, sketches, tables and three-dimensional represenations According to § 3, copyright is also applicable to translations and other modifications or adaptions of a work if they are individual intellectual creations of the editor.\n\t\t\tFinally, according to § 4 copyright also extents to collected editions and database works. Collected editions are “collections of work, data or other independent elements that are individual intellectual creations based on the selection and\n\t\t\tarrangement of the elements”. Database works are defined as “collected editions, the elements of which are arranged in a systematic or methodical way and can be accessed individually by electronic means or in other ways”. Other relevant property\n\t\t\trights can be trademarks, patents, utility models, plant variety rights protection, integrated circuit layout design protection, geographical indications or registered designs.	Daten oder Software können Urheber- oder anderen Schutzrechten unterliegen. Die Rechtslage kann selbst in der EU von Land zu Land erheblich abweichen. In Deutschland sind nach dem Urheberrechtsgesetz (UrhG) Werke der Literatur,\n\t\t\tWissenschaft und Kunst, die eine „persönliche geistige Schöpfung“ darstellen, urheberrechtlich geschützt. Der urheberrechtliche Schutz erlischt 70 Jahre nach dem Tod der bzw. des Urheberin/s. Reine Daten, z.B. Messdaten oder Surveydaten, aber auch\n\t\t\tMetadaten (bis auf ggf. „beschreibende“ Metadaten) sind hingegen nicht schutzfähig. In § 2 nennt das UrhG folgende geschützte Werkarten, wobei die Aufzählung nicht abschließend ist: * Sprachwerke, wie Schriftwerke, Reden und Computerprogramme * Werke\n\t\t\tder Musik * pantomimische Werke einschließlich Werke der Tanzkunst * Werke der bildenden Künste einschließlich der Werke der Baukunst und der angewandten Kunst und Entwürfe solcher Werke * Lichtbildwerke einschließlich der Werke, die ähnlich wie\n\t\t\tLichtbildwerke geschaffen werden * Darstellungen wissenschaftlicher oder technischer Art wie Zeichnungen, Pläne, Karten, Skizzen, Tabellen und plastische Darstellungen. Nach § 3 sind auch „Übersetzungen und andere Bearbeitungen“ von Werken geschützt,\n\t\t\tdie persönliche geistige Schöpfungen des Bearbeiters sind“. Schließlich sind nach § 4 auch Sammelwerke und Datenbankwerke geschützt, was im Bereich Forschungsdaten durchaus relevant sein kann. Sammelbankwerke werden dabei definiert als „Sammlungen\n\t\t\tvon Werken, Daten oder anderen unabhängigen Elementen, die aufgrund der Auswahl oder Anordnung der Elemente eine persönliche geistige Schöpfung sind“. Bei einem „Datenbankwerk im Sinne des Gesetzes“ handelt es sich um ein „Sammelwerk, dessen Elemente\n\t\t\tsystematisch oder methodisch angeordnet und einzeln mit Hilfe elektronischer Mittel oder auf andere Weise zugänglich sind“. Weitere relevante Schutzrechte können gewerbliche Schutzrechte wie Patente, Gebrauchsmuster, Sortenschutz [bei\n\t\t\tPflanzenzüchtungen], Halbleiterschutz, Marken, geographische Herkunftsangaben, eingetragene Designs oder geschäftliche Bezeichnungen sein.	Does the project use and/or produce data that is protected by intellectual or industrial property rights?	Werden Daten genutzt und/oder erstellt, die durch Urheber- oder verwandte Schutzrechte geschützt sind?	yesno	boolean		162	82	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
197	2020-04-14 14:47:26.194+00	2020-04-14 14:47:26.194+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-costs/anonymization_non_personnel	https://rdmorganiser.github.io/terms	anonymization_non_personnel	rdmo/legal-and-ethics/sensitive-data-costs/anonymization_non_personnel		f	2	Please estimate the costs in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel-costs associated with the anonymization of sensitive data in the project?	Welche Sachkosten entstehen im Zusammenhang mit der Anonymisierung von sensiblen Daten im Projekt?	text	float	Euro	26	83	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
198	2020-04-14 14:47:26.245+00	2020-04-14 14:47:26.245+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-costs/anonymization_personnel	https://rdmorganiser.github.io/terms	anonymization_personnel	rdmo/legal-and-ethics/sensitive-data-costs/anonymization_personnel		f	1	Please estimate the effort in person months (1 PM = monthly working time of a full-time employee).	Bitte schätzen sie den Aufwand in Personenmonaten (1 PM = Monatsarbeitszeit eines Vollzeitbeschäftigten).	What are the personnel costs associated with the anonymization of sensitive data in the project?	Welcher Personalaufwand entsteht für die Anonymisierung von sensiblen Daten im Projekt?	range	float	PM	27	83	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
199	2020-04-14 14:47:26.295+00	2020-04-14 14:47:26.295+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-costs/security_non_personnel	https://rdmorganiser.github.io/terms	security_non_personnel	rdmo/legal-and-ethics/sensitive-data-costs/security_non_personnel		f	4	Please estimate the costs in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel-costs for other (non-technical) security measures for sensitive data for the project?	Wie hoch sind die weiteren Sachkosten für weiter (nicht-technische) Sicherheitsmaßnahmen für sensible Daten im Projekt?	text	float	Euro	29	83	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
200	2020-04-14 14:47:26.361+00	2020-04-14 14:47:26.361+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-costs/security_personnel	https://rdmorganiser.github.io/terms	security_personnel	rdmo/legal-and-ethics/sensitive-data-costs/security_personnel		f	3	Please estimate the effort in person months.	Bitte schätzen Sie den Aufwand in Personenmonaten.	What are the personnel costs associated with other (non-technical) security measures for sensitive data in the project?	Welcher Personalaufwand entsteht im Zusammenhang mit weiteren (nicht-technischen) Sicherheitsmaßnahmen für sensible Daten im Projekt?	range	float	PM	30	83	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
201	2020-04-14 14:47:26.409+00	2020-04-14 14:47:26.409+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-official_approval/agency	https://rdmorganiser.github.io/terms	agency	rdmo/legal-and-ethics/sensitive-data-official_approval/agency		f	4	\N	\N	If yes, which is the responsible agency?	Wenn ja, welche ist die ausstellende Behörde?	text	text		167	84	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
202	2020-04-14 14:47:26.462+00	2020-04-14 14:47:26.462+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-official_approval/data_access_committee	https://rdmorganiser.github.io/terms	data_access_committee	rdmo/legal-and-ethics/sensitive-data-official_approval/data_access_committee		f	5	\N	\N	Is a data access committee needed to handle access requests to the published data of the project?	Wird eine Datenzugangs-Kommission benötigt, die bei Zugriffsanfragen auf vom Projekt veröffentlichte Daten entscheidet, ob Zugang gewährt wird oder nicht?	yesno	boolean		164	84	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
203	2020-04-14 14:47:26.507+00	2020-04-14 14:47:26.507+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-official_approval/ethics_committee	https://rdmorganiser.github.io/terms	ethics_committee	rdmo/legal-and-ethics/sensitive-data-official_approval/ethics_committee		f	1	\N	\N	Has the project been approved by a research ethics committee?	Wurde das Forschungsvorhaben von einer Ethikkommission begutachtet?	radio	option		165	84	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
204	2020-04-14 14:47:26.611+00	2020-04-14 14:47:26.611+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-official_approval/title	https://rdmorganiser.github.io/terms	title	rdmo/legal-and-ethics/sensitive-data-official_approval/title		f	3	\N	\N	If yes, which permit?	Wenn ja, um welche Genehmigung handelt es sich?	text	text		168	84	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
205	2020-04-14 14:47:26.66+00	2020-04-14 14:47:26.66+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-official_approval/yesno	https://rdmorganiser.github.io/terms	yesno	rdmo/legal-and-ethics/sensitive-data-official_approval/yesno		f	2	\N	\N	Is a statutatory approval / permit needed for the research?	Wird für das Forschungsvorhaben eine offizielle Genehmigung benötigt?	radio	boolean		169	84	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
206	2020-04-14 14:47:26.756+00	2020-04-14 14:47:26.756+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-other/description	https://rdmorganiser.github.io/terms	description	rdmo/legal-and-ethics/sensitive-data-other/description		f	1	\N	\N	If yes, please describe the non-personal sensitive data used in the project.	Wenn ja, um welche nicht personenbezogenen sensiblen Daten handelt es sich?	textarea	text		109	85	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
235	2020-04-14 14:47:28.901+00	2020-04-14 14:47:28.901+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-costs/non_personnel	https://rdmorganiser.github.io/terms	non_personnel	rdmo/storage-and-long-term-preservation/long-term-preservation-costs/non_personnel		f	2	Please estimate the costs in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel-costs regarding long-term preservation for the project?	Welche Sachkosten entstehen im Zusammenhang mit Langzeitarchivierung für dieses Projekt?	text	float	Euro	22	94	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
207	2020-04-14 14:47:26.865+00	2020-04-14 14:47:26.865+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-other/funder_policy	https://rdmorganiser.github.io/terms	funder_policy	rdmo/legal-and-ethics/sensitive-data-other/funder_policy		f	2	Funders of research also increasingly specify requirements regarding the management of research data in funded projects. Examples are the <a\n\t\t\thref="https://www.dfg.de/en/research_funding/proposal_review_decision/applicants/research_data/index.html" target=_blank">DFG Guidelines on the Handling of Reserach Data</a> or the <a\n\t\t\thref="http://ec.europa.eu/research/participants/data/ref/h2020/grants_manual/hi/oa_pilot/h2020-hi-oa-data-mgt_en.pdf" target=_blank">Guidelines on Data Management in Horizon 2020</a> of the European Commission.	Auch Forschungsförderer stellen zunehmend Anforderungen an das Datenmanagement in von ihnen geförderten Projekten. Beispiele sind die <a\n\t\t\thref="https://www.dfg.de/foerderung/antrag_gutachter_gremien/antragstellende/nachnutzung_forschungsdaten/" target=_blank">DFG-Leitlinien zum Umgang mit Forschungsdaten</a> oder die <a\n\t\t\thref="http://ec.europa.eu/research/participants/data/ref/h2020/grants_manual/hi/oa_pilot/h2020-hi-oa-data-mgt_en.pdf" target=_blank">Guidelines on Data Management in Horizon 2020</a> der Europäischen Komission.	Does the funder have rules or recommendations for data management? If yes, please briefly outline them and refer to more detailed sources of information if necessary. Please also indicate, if the rules / guidelines are mandatory or optional.	Gibt es von Seiten des Forschungsförderers Vorgaben oder Richtlinien bezüglich des Umgangs mit den im Projekt erhobenen Forschungsdaten? Wenn ja, skizzieren Sie diese kurz und verweisen Sie ggf. auf weiterführende Informationen. Geben\n\t\t\tSie bitte auch an, welchen Grad an Verbindlichkeit sie haben.	textarea	text		157	85	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
208	2020-04-14 14:47:26.912+00	2020-04-14 14:47:26.912+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-other/yesno	https://rdmorganiser.github.io/terms	yesno	rdmo/legal-and-ethics/sensitive-data-other/yesno		f	0	Examples are data that contain trade or business secrets or geoinformation on endangered species.	Beispiele hierfür sind etwa Daten, die Betriebs- oder Geschäftsgeheimnisse oder Ortsangaben zu bedrohten Tier- oder Pflanzenarten enthalten.	Does this dataset contain sensitive data other than personal data?	Enthält dieser Datensatz nicht-personenbezogene sensible Daten?	yesno	boolean		110	85	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
209	2020-04-14 14:47:26.962+00	2020-04-14 14:47:26.962+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-personal_data/anonymization	https://rdmorganiser.github.io/terms	anonymization	rdmo/legal-and-ethics/sensitive-data-personal_data/anonymization		f	2	\N	\N	Will the data be anonymised or pseudonymised?	Werden die Daten anonymisiert oder pseudonymisiert?	radio	text		112	86	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
210	2020-04-14 14:47:27.065+00	2020-04-14 14:47:27.065+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-personal_data/bdsg_3_9	https://rdmorganiser.github.io/terms	bdsg_3_9	rdmo/legal-and-ethics/sensitive-data-personal_data/bdsg_3_9		f	1	According to the GDPR, this includes “personal data revealing racial or ethnic origin, political opinions, religious or philosophical beliefs, or trade union membership, and the processing of genetic data, biometric data for the\n\t\t\tpurpose of uniquely identifying a natural person, data concerning health or data concerning a natural person’s sex life or sexual orientation“ <a href="https://eur-lex.europa.eu/legal-content/en/TXT/?uri=CELEX:32016R0679"\n\t\t\ttarget=_blank">(Art. 9(1) GPDR)</a>. Such data is considered to be particularly sensitive and requires even more stringent protective measures than those required for personal data in general. If you answer "Yes" to this\n\t\t\tquestion, please contact the data protection officer of your institution to find out what additional protection measures are necessary. * <a href="https://dsb.ruhr-uni-bochum.de/" target=_blank">Ruhr-University Bochum</a> *\n\t\t\t<a href="https://www.uni-due.de/verwaltung/organisation/just_datenschutz.php" target=_blank">Universityt of Duisburg-Essen</a> * <a\n\t\t\thref="https://www.tu-dortmund.de/universitaet/organisation/beauftragte-vertrauenspersonen/#accordion-2213-764" target=_blank">TU Dortmund University</a>	Hierunter fallen laut DSGVO personenbezogene „Daten, aus denen die rassische und ethnische Herkunft, politische Meinungen, religiöse oder weltanschauliche überzeugungen oder die Gewerkschaftszugehörigkeit hervorgehen, sowie die\n\t\t\tVerarbeitung von genetischen Daten, biometrischen Daten zur eindeutigen Identifizierung einer natürlichen Person, Gesundheitsdaten oder Daten zum Sexualleben oder der sexuellen Orientierung einer natürlichen Person “ <a\n\t\t\thref="https://eur-lex.europa.eu/legal-content/en/TXT/?uri=CELEX:32016R0679" target=_blank">(Art. 9 DSGVO, Abs. 1)</a>. Solche Daten gelten als besonders sensibel und erfordern noch strengere Schutzmaßnahmen, als bei\n\t\t\tpersonenbezogenen Daten generell bereits erforderlich sind. Wenn Sie diese Frage mit "Ja" beantworten, informieren Sie sich bei der/dem Datenschutzbeauftragten Ihrer Institution, welche zusätzlichen Schutzmaßnahmen notwendig sind. * <a\n\t\t\thref="https://dsb.ruhr-uni-bochum.de/" target=_blank">Ruhr-Universität Bochum</a> * <a href="https://www.uni-due.de/verwaltung/organisation/just_datenschutz.php" target=_blank">Universität\n\t\t\tDuisburg-Essen</a> * <a href="https://www.tu-dortmund.de/universitaet/organisation/beauftragte-vertrauenspersonen/#accordion-2213-764" target=_blank">Technische Unversität Dortmund</a>	Does the dataset contain personal data of special categories?	Enthält der Datensatz personenbezogene Daten besonderer Kategorien?	yesno	boolean		113	86	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
211	2020-04-14 14:47:27.129+00	2020-04-14 14:47:27.129+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-personal_data/deletion	https://rdmorganiser.github.io/terms	deletion	rdmo/legal-and-ethics/sensitive-data-personal_data/deletion		f	6	\N	\N	By when will the (unanonymised or unpseudonymised) original data be safely deleted?	Bis wann werden die (unanonymisierten bzw. unpseudonymisierten) Originaldaten spätestens sicher vernichtet?	date	datetime		118	86	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
212	2020-04-14 14:47:27.177+00	2020-04-14 14:47:27.177+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-personal_data/extent	https://rdmorganiser.github.io/terms	extent	rdmo/legal-and-ethics/sensitive-data-personal_data/extent		f	3	he collection, processing, archiving and publication of personal data is only admissible, if there is a corresponding 'informed consent' of the person concerned. Only in very few exceptional cases, this is not needed. Where required,\n\t\t\tplease get in touch with the data protection officer of your institution for further information on the necessary conditions for consent. * <a href="https://dsb.ruhr-uni-bochum.de/" target=_blank">Ruhr-University Bochum</a>\n\t\t\t* <a href="https://www.uni-due.de/verwaltung/organisation/just_datenschutz.php" target=_blank">University of Duisburg-Essen</a> * <a\n\t\t\thref="https://www.tu-dortmund.de/universitaet/organisation/beauftragte-vertrauenspersonen/#accordion-2213-764" target=_blank">TU Dortmund University</a>	Grundsätzlich gilt, dass eine Erhebung, Verarbeitung, Archivierung und Veröffentlichung personenbezogener Daten nur zulässig ist, wenn eine entsprechende „informierte Einwilligung“ der Betroffenen vorliegt. Nur in ganz wenigen\n\t\t\tAusnahmefällen wird diese nicht benötigt. Bitte informieren Sie sich ggf. bei der/dem Datenschutzbeauftragten Ihrer Institution über die notwendigen Bedingungen für die Einwilligung. * <a href="https://dsb.ruhr-uni-bochum.de/"\n\t\t\ttarget=_blank">Ruhr-Universität Bochum</a> * <a href="https://www.uni-due.de/verwaltung/organisation/just_datenschutz.php" target=_blank">Universität von Duisburg-Essen</a> * <a\n\t\t\thref="https://www.tu-dortmund.de/universitaet/organisation/beauftragte-vertrauenspersonen/#accordion-2213-764" target=_blank">Technische Unversität Dortmund</a>	To what extent is the "informed consent" obtained from the persons concerned?	In welchem Umfang wird die "informierte Einwilligung" der Betroffenen eingeholt?	radio	text		115	86	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
213	2020-04-14 14:47:27.29+00	2020-04-14 14:47:27.29+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-personal_data/record	https://rdmorganiser.github.io/terms	record	rdmo/legal-and-ethics/sensitive-data-personal_data/record		f	5	\N	\N	Where and how is the "informed consent" documented?	Wo und wie sind die "informierten Einwilligungen" abgelegt?	textarea	text		116	86	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
214	2020-04-14 14:47:27.341+00	2020-04-14 14:47:27.341+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-personal_data/statement	https://rdmorganiser.github.io/terms	statement	rdmo/legal-and-ethics/sensitive-data-personal_data/statement		f	4	\N	\N	If no "informed consent" is obtained, please give the reasons for not doing so.	Wenn keine "informierte Einwilligung" eingeholt wird, begründen Sie dies bitte.	textarea	text		117	86	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
249	2020-04-14 14:47:29.72+00	2020-04-14 14:47:29.72+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-dates/data_analysis_end	https://rdmorganiser.github.io/terms	data_analysis_end	rdmo/technical-classification/data-dates/data_analysis_end		f	6	\N	\N	When does data analysis end?	Wann endet die Datenanalyse?	date	datetime		47	97	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
215	2020-04-14 14:47:27.395+00	2020-04-14 14:47:27.395+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-personal_data_yesno/yesno	https://rdmorganiser.github.io/terms	yesno	rdmo/legal-and-ethics/sensitive-data-personal_data_yesno/yesno		f	1	The handling and processing of personal data is regulated by law. The uniform application throughout the EU is based on the <a href="https://eur-lex.europa.eu/legal-content/en/TXT/?uri=CELEX:32016R0679"\n\t\t\ttarget=_blank">EU General Data Protection Regulation (GDPR)</a>. It allows for regulatory leeway at national level. In Germany, this is regulated by the<a href="http://www.gesetze-im-internet.de/englisch_bdsg/index.html"\n\t\t\ttarget=_blank"> Federal Data Protection Act (BDSG)</a> , and for universities, the individual data protection laws of the individual federal states apply, e.g. <a\n\t\t\thref="https://recht.nrw.de/lmi/owa/br_text_anzeigen?v_id=3520071121100436275" target=_blank"> the data protection law of North Rhine-Westphalia (DSG NRW)</a>. The european GDPR defines personal data as all information relating\n\t\t\tto an identified or identifiable natural person (Art. 4(1) GPDR). A person is <b>identified</b> if it is clearly identifiable to whom the data belongs. A person becomes <b>identifiable</b> if it can be identified by means of\n\t\t\tadditional information. More information (in German only) can be found on the websites of the data protection officers of the UA Ruhr. * <a href="https://dsb.ruhr-uni-bochum.de/" target=_blank">Ruhr-University Bochum</a> *\n\t\t\t<a href="https://www.uni-due.de/verwaltung/organisation/just_datenschutz.php" target=_blank">University of Duisburg-Essen</a> * <a\n\t\t\thref="https://www.tu-dortmund.de/universitaet/organisation/beauftragte-vertrauenspersonen/#accordion-2213-764" target=_blank">TU Dortmund University</a>	Der Umgang und die Verarbeitung personenbezogener Daten ist gesetzlich geregelt. Die EU-weit einheitliche Anwendung erfolgt nach der <a href="https://eur-lex.europa.eu/legal-content/en/TXT/?uri=CELEX:32016R0679"\n\t\t\ttarget=_blank">EU-Datenschutz-Grundverordnung (DSGVO)</a>. Sie gestattet Regelungsspielräume auf nationaler Ebene. In Deutschland regelt dies das <a href="http://www.gesetze-im-internet.de/bdsg_2018/"\n\t\t\ttarget=_blank">Bundesdatenschutzgesetz (BDSG)</a>. Für Hochschulen gelten zum großen Teil die individuellen Datenschutzgesetze der Länder, z.B. das <a\n\t\t\thref="https://recht.nrw.de/lmi/owa/br_text_anzeigen?v_id=3520071121100436275" target=_blank">Datenschutzgesetz Nordrhein-Westfalen (DSG NRW)</a>. Die europäische DSGVO definiert personenbezogene Daten als alle Informationen,\n\t\t\tdie sich auf eine identifizierte oder identifizierbare natürliche Person beziehen (Art. 4 DSGVO, Abs. 1). <b>Identifiziert </b>ist eine Person, wenn eindeutig erkennbar ist, zu welcher Person die Daten gehören.\n\t\t\t<b>Identifizierbar</b> wird eine Person, wenn sie mittels Zusatzinformationen identifiziert werden kann. Mehr Informationen zum Thema finden Sie auf den Webseiten der Datenschutzbeauftragten der UA Ruhr. * <a\n\t\t\thref="https://dsb.ruhr-uni-bochum.de/" target=_blank">Ruhr-Universität Bochum</a> * <a href="https://www.uni-due.de/verwaltung/organisation/just_datenschutz.php" target=_blank">Universität von\n\t\t\tDuisburg-Essen</a> * <a href="https://www.tu-dortmund.de/universitaet/organisation/beauftragte-vertrauenspersonen/#accordion-2213-764" target=_blank">Technische Universität Dortmund</a>	Does this dataset contain personal data?	Enthält dieser Datensatz personenbezogene Daten?	yesno	boolean		120	87	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
216	2020-04-14 14:47:27.466+00	2020-04-14 14:47:27.466+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-privacy_law/privacy_law	https://rdmorganiser.github.io/terms	privacy_law	rdmo/legal-and-ethics/sensitive-data-privacy_law/privacy_law		t	0	The <a href="https://eur-lex.europa.eu/legal-content/en/TXT/?uri=CELEX:32016R0679" target=_blank">EU General Data Protection Regulation (GDPR)</a> takes precedence over national law. It applies since\n\t\t\t25.05.2018. For universities, state data protection laws continue to apply, which may be designed to comply with certain provisions of the GDPR, e. g. the <a href="https://recht.nrw.de/lmi/owa/br_text_anzeigen?v_id=3520071121100436275"\n\t\t\ttarget=_blank"> the data protection law of North Rhine-Westphalia (DSG NRW)</a>. In certain areas, specific laws apply. These override the State Federal and <a\n\t\t\thref="http://www.gesetze-im-internet.de/englisch_bdsg/index.html" target=_blank"> Federal Data Protection Acts</a>. * The Social Security Act X for medical data * The Federal Statistics Act for census data * For educational\n\t\t\tresearch in NRW the education act NRW A research project might be affected by multiple laws.	Die <a href="https://eur-lex.europa.eu/legal-content/en/TXT/?uri=CELEX:32016R0679" target=_blank">EU Datenschutzgrundverordnung (DSGVO)</a> hat Vorrang vor nationalem Recht. Sie findet seit dem 25.05.2018\n\t\t\tAnwendung. Für Hochschulen finden weiterhin die Landesdatenschutzgesetze Anwendung, die bestimmte Regelungen der DSGVO ausgestalten können, z.B. <a href="https://recht.nrw.de/lmi/owa/br_text_anzeigen?v_id=3520071121100436275"\n\t\t\ttarget=_blank">Datenschutzgesetz Nordrhein-Westfalen (DSG NRW)</a>. In bestimmten Bereichen gelten spezifische Gesetze, die über den Landesdatenschutzgesetzen bzw. <a href="http://www.gesetze-im-internet.de/bdsg_2018/"\n\t\t\ttarget=_blank">Bundesdatenschutzgesetz (BDSG)</a> stehen. *Für medizinischen Daten ist bspw. das Zehnte Sozialgesetzbuch (SGB X) anwendbar, * Für Daten des Mikrozensus das Bundesstatistikgesetz (BStatG). * Für Forschung in Schulen in\n\t\t\tNRW das Schulgesetz NRW (SchulG NRW) Demzufolge können je nach Forschungsprojekt auch mehrere Gesetze betroffen sein.	Which laws are to be considered beside the European GDPR regarding data protection issues for the research project?	Welche Gesetze sind neben der europäischen DSGVO bezüglich der Fragen des Datenschutzes für das Projekt zu beachten?	checkbox	text		175	88	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
217	2020-04-14 14:47:27.576+00	2020-04-14 14:47:27.576+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/metadata-costs/non_personnel	https://rdmorganiser.github.io/terms	non_personnel	rdmo/metadata-and-referencing/metadata-costs/non_personnel		f	2	Please estimate the costs in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel-costs associated with the creation of metadata and context information in the project?	Welche Sachkosten entstehen im Zusammenhang mit der Erstellung von Metadaten und Kontextinformation im Projekt?	text	float	Euro	15	89	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
218	2020-04-14 14:47:27.622+00	2020-04-14 14:47:27.622+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/metadata-costs/personnel	https://rdmorganiser.github.io/terms	personnel	rdmo/metadata-and-referencing/metadata-costs/personnel		f	1	Please estimate the effort in person months ( 1 PM = monthly working time of a full-time employee)	Bitte schätzen sie den Aufwand in Personenmonaten (1 PM = Monatsarbeitszeit eines Vollzeitbeschäftigten).	What are the personnel costs associated with the the creation of metadata and context information in the project?	Welcher Personalaufwand entsteht im Zusammenhang mit der Erstellung von Metadaten und Kontextinformation im Projekt?	range	float	PM	16	89	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
219	2020-04-14 14:47:27.674+00	2020-04-14 14:47:27.674+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/metadata-dataset/creation_automatic	https://rdmorganiser.github.io/terms	creation_automatic	rdmo/metadata-and-referencing/metadata-dataset/creation_automatic		f	3	\N	\N	Which metadata are collected automatically?	Welche Metadaten werden automatisch erhoben?	textarea	text		74	90	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
220	2020-04-14 14:47:27.743+00	2020-04-14 14:47:27.743+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/metadata-dataset/creation_manual	https://rdmorganiser.github.io/terms	creation_manual	rdmo/metadata-and-referencing/metadata-dataset/creation_manual		f	5	A metadata editor is suitable for this.	Dafür bietet sich ein Metadaeneditor an.	Which metadata are collected manually?	Welche Metadaten werden manuell erhoben?	textarea	text		75	90	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
221	2020-04-14 14:47:27.788+00	2020-04-14 14:47:27.788+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/metadata-dataset/creation_semi_automatic	https://rdmorganiser.github.io/terms	creation_semi_automatic	rdmo/metadata-and-referencing/metadata-dataset/creation_semi_automatic		f	4	So what metadata are automatically collected by the computer/software, but must be checked?	Welche Metadaten werden also durch den Computer / die Software automatisch erhoben, müssen aber überprüft werden?	Which metadata are collected semi-automatically?	Welche Metadaten werden semi-automatisch erhoben?	textarea	text		76	90	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
222	2020-04-14 14:47:27.839+00	2020-04-14 14:47:27.839+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/metadata-dataset/mappings	https://rdmorganiser.github.io/terms	mappings	rdmo/metadata-and-referencing/metadata-dataset/mappings	original H2020 question	f	2	This information is needed for a Horizon 2020 data management plan.	Diese Information wird für einen Horizon 2020 Datenmanagementplan benötigt.	In case it is unavoidable that you use uncommon or generate project-specific ontologies or vocabularies, will you provide mappings to more commonly used ontologies?	Sollte es unvermeidbar sein, projektspezifische oder seltene Ontologien, Metadatenschemata oder Vokabulare zu nutzen, werden Mappings zu gängigen Ontologien etc. erstellt?	yesno	boolean		77	90	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
223	2020-04-14 14:47:27.886+00	2020-04-14 14:47:27.886+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/metadata-dataset/quality_assurance	https://rdmorganiser.github.io/terms	quality_assurance	rdmo/metadata-and-referencing/metadata-dataset/quality_assurance		t	6	\N	\N	Are metadata and context information being checked for correctness and completeness?	Werden Metadaten und Kontextinformation auf Korrektheit und Vollständigkeit geprüft?	checkbox	text		79	90	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
224	2020-04-14 14:47:27.987+00	2020-04-14 14:47:27.987+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/metadata-dataset/responsible_person	https://rdmorganiser.github.io/terms	responsible_person	rdmo/metadata-and-referencing/metadata-dataset/responsible_person		t	7	\N	\N	Who is responsible for documenting the metadata and context information and for checking if they are correct and complete?	Wer ist verantwortlich für die Dokumentation und Prüfung der Metadaten und Kontextinformationen auf Richtigkeit und Vollständigkeit?	text	text		81	90	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
225	2020-04-14 14:47:28.249+00	2020-04-14 14:47:28.249+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/metadata-dataset/scope	https://rdmorganiser.github.io/terms	scope	rdmo/metadata-and-referencing/metadata-dataset/scope	probably we should introduce a separate question for being findable and re-used	t	0	\N	\N	Which information is necessary for other parties to understand the data (that is, to understand their collection or creation, analysis, and research results obtained on its basis) and to re-use it?	Welche Informationen sind für Außenstehende notwendig, um die Daten zu verstehen (d. h. ihre Erhebung bzw. Entstehung, Analyse sowie die auf ihrer Basis gewonnenen Forschungsergebnisse nachvollziehen) und nachnutzen zu können?	checkbox	text		82	90	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
226	2020-04-14 14:47:28.332+00	2020-04-14 14:47:28.332+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/metadata-dataset/standards	https://rdmorganiser.github.io/terms	standards	rdmo/metadata-and-referencing/metadata-dataset/standards		t	1	\N	\N	Which standards, ontologies, classifications etc. are used to describe the data and context information?	Welche Standards, Ontologien, Klassifikationen etc. werden zur Beschreibung der Daten und Kontextinformation genutzt?	checkbox	text		83	90	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
227	2020-04-14 14:47:28.419+00	2020-04-14 14:47:28.419+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/structure-granularity-and-referencing-costs/non_personnel	https://rdmorganiser.github.io/terms	non_personnel	rdmo/metadata-and-referencing/structure-granularity-and-referencing-costs/non_personnel		f	3	Please estimate the costs in Euro.	Bitte schätzen sie die Kosten in Euro.	What is the amount of non-personnel-costs associated with persistent identifiers in the project?	Welche Sachkosten entstehen im Zusammenhang mit persistenten Identifikatoren im Projekt?	text	float	Euro	18	91	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
228	2020-04-14 14:47:28.463+00	2020-04-14 14:47:28.463+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/structure-granularity-and-referencing-costs/personnel	https://rdmorganiser.github.io/terms	personnel	rdmo/metadata-and-referencing/structure-granularity-and-referencing-costs/personnel		f	1	Please estimate the effort in person months ( 1 PM = monthly working time of a full-time employee).	Bitte schätzen sie den Aufwand in Personenmonaten (1 PM = Monatsarbeitszeit eines Vollzeitbeschäftigten).	What are the personnel costs associated with of persistent identifiers in the project?	Welcher Personalaufwand entsteht im Zusammenhang mit der Vergabe von persistenten Identifikatoren im Projekt?	range	float	PM	19	91	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
229	2020-04-14 14:47:28.512+00	2020-04-14 14:47:28.512+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/structure-granularity-and-referencing-pids/name	https://rdmorganiser.github.io/terms	name	rdmo/metadata-and-referencing/structure-granularity-and-referencing-pids/name		t	4	A prerequisite for PIDs to work as promised is that they - as well as the objects they refer to - are maintained in a continuous and reliable way.. This means, for example, that if the object location changes, this information is\n\t\t\tupdated. When the data are stored in a data centre or repository, these tasks are usually taken care of by the data centre / repository. However, to be sure, the responsibilities should be checked beforehand.	Die Voraussetzung dafür, dass persistente Identifikatoren auch wirklich halten, was sie versprechen, ist, dass sie - wie auch die Objekte, auf die referenziert wird - dauerhaft und verlässlich gepflegt werden. D.h. beispielsweise,\n\t\t\tdass bei einer Änderung des Speicherortes des Objekts die Information über den neuen Speicherort entsprechend aktualisiert werden muss. Werden die Daten in einem Datenzentrum oder -repositorium gespeichert, wird diese Verantwortung i.d.R. von diesem\n\t\t\tübernommen. Um sicher zu sein, sollten die Verantwortlichkeiten jedoch in jedem Fall geprüft bzw. geklärt werden.	Who is responsible for the maintenance of the PIDs and the object maintenance (i.e. who is responsible notifying the PID-Service about object relocation and the new address)?	Wer ist verantwortlich für die Pflege der PIDs und die Objektpflege (d. h. die Langzeitarchivierung des Objekts und somit dafür, dem PID-Service einen Objektumzug und die neue Adresse mitzuteilen)?	text	text		88	92	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
230	2020-04-14 14:47:28.576+00	2020-04-14 14:47:28.576+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/structure-granularity-and-referencing-pids/subentities	https://rdmorganiser.github.io/terms	subentities	rdmo/metadata-and-referencing/structure-granularity-and-referencing-pids/subentities		f	3	\N	\N	Which (sub-) entities / sub units should be referenced using identifiers? Which of those identifiers should be persistent and citable?	Welche (Sub-)Entitäten / Untereinheiten sollten sinnvollerweise eigene Identifikatoren erhalten? Welche dieser Identifikatoren sollten dauerhaft und zitierfähig sein?	textarea	text		89	92	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
231	2020-04-14 14:47:28.619+00	2020-04-14 14:47:28.619+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/structure-granularity-and-referencing-pids/system	https://rdmorganiser.github.io/terms	system	rdmo/metadata-and-referencing/structure-granularity-and-referencing-pids/system		f	2	\N	\N	Which system of persistent identifiers shall be used?	Welches System von persistenten Identifikatoren soll genutzt werden?	radio	text		90	92	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
232	2020-04-14 14:47:28.701+00	2020-04-14 14:47:28.701+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/structure-granularity-and-referencing-pids/yesno	https://rdmorganiser.github.io/terms	yesno	rdmo/metadata-and-referencing/structure-granularity-and-referencing-pids/yesno		f	0	\N	\N	Will persistent identifiers (PIDs) be used for this data set?	Sollen für diesen Datensatz persistente Identifikatoren (PIDs) genutzt werden?	yesno	boolean		91	92	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
233	2020-04-14 14:47:28.753+00	2020-04-14 14:47:28.753+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/structure-granularity-and-referencing-structure/structure	https://rdmorganiser.github.io/terms	structure	rdmo/metadata-and-referencing/structure-granularity-and-referencing-structure/structure		f	0	\N	\N	What is the structure of the data? How are the individual components of the dataset related to each other? How is the dataset related to other datasets used in the project?	Wie sind die Daten strukturiert? In welchem Verhältnis stehen die einzelnen Komponenten zueinander? In welchem Verhältnis steht der Datensatz zu anderen im Projekt erhobenen oder genutzten Datensätzen?	textarea	text		137	93	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
234	2020-04-14 14:47:28.844+00	2020-04-14 14:47:28.844+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-costs/cover_how	https://rdmorganiser.github.io/terms	cover_how	rdmo/storage-and-long-term-preservation/long-term-preservation-costs/cover_how		f	2	\N	\N	How will the datamanagement costs of the project be covered?	Wie werden die Kosten für das Datenmanagement im Projekt aufgebracht?	textarea	text		21	94	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
250	2020-04-14 14:47:29.776+00	2020-04-14 14:47:29.776+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-dates/data_analysis_start	https://rdmorganiser.github.io/terms	data_analysis_start	rdmo/technical-classification/data-dates/data_analysis_start		f	5	\N	\N	When does data analysis start?	Wann beginnt die Datenanalyse?	date	datetime		48	97	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
236	2020-04-14 14:47:28.949+00	2020-04-14 14:47:28.949+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-costs/personnel	https://rdmorganiser.github.io/terms	personnel	rdmo/storage-and-long-term-preservation/long-term-preservation-costs/personnel		f	1	Please estimate the effort in person months (1 PM = monthly working time of a full-time employee).	Bitte schätzen sie den Aufwand in Personenmonaten (1 PM = Monatsarbeitszeit eines Vollzeitbeschäftigten).	What are the personnel costs associated with long-term preservation for the project?	Welcher Personalaufwand entsteht im Zusammenhang mit Langzeitarchivierung für dieses Projekt?	range	float	PM	23	94	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
237	2020-04-14 14:47:28.996+00	2020-04-14 14:47:28.996+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/access_authentication	https://rdmorganiser.github.io/terms	access_authentication	rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/access_authentication	Original from H2020 FAIR Data Management Plan	f	9	\N	\N	How will the identity of the person accessing the data will be ascertained?	Wie wird die Identität von Personen, die auf die Daten zugreifen, verifiziert?	textarea	text		93	95	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
238	2020-04-14 14:47:29.041+00	2020-04-14 14:47:29.041+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/certification	https://rdmorganiser.github.io/terms	certification	rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/certification		f	6	If the dataset is archived at several places, you may answer this question with yes, if this applies to at least one of these.	Wurde der Datensatz an mehreren Orten archiviert, kann die Frage bejaht werden, wenn dies auf mindestens eine der Optionen zutrifft.	Is the repository or data centre chosen certified (e.g. Data Seal of Approval, nestor Seal or ISO 16363)?	Handelt es sich dabei um ein zertifiziertes Repositorium oder Datenzentrum (z.B. durch das Data Seal of Approval, nestor-Siegel oder ISO 16363)?	yesno	boolean		94	95	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
239	2020-04-14 14:47:29.113+00	2020-04-14 14:47:29.113+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/data_archiving_date	https://rdmorganiser.github.io/terms	data_archiving_date	rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/data_archiving_date		f	10	\N	\N	By when will the data be archived?	Wann werden die Daten archiviert?	date	datetime		95	95	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
240	2020-04-14 14:47:29.216+00	2020-04-14 14:47:29.216+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/duration	https://rdmorganiser.github.io/terms	duration	rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/duration		f	3	\N	\N	How long will the data be stored?	Wie lange müssen die Daten aufbewahrt werden?	text	text		96	95	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
241	2020-04-14 14:47:29.271+00	2020-04-14 14:47:29.271+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/embargo_period	https://rdmorganiser.github.io/terms	embargo_period	rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/embargo_period		f	8	\N	\N	Shall there be an embargo period before the data are made available?	Sollen die Daten erst nach Ablauf einer Sperrfrist zugänglich gemacht werden?	textarea	text		97	95	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
242	2020-04-14 14:47:29.317+00	2020-04-14 14:47:29.317+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/purpose	https://rdmorganiser.github.io/terms	purpose	rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/purpose		t	2	\N	\N	What are the reasons this dataset has to be preserved for the long-term?	Aus welchen Gründen müssen die Daten langfristig aufbewahrt werden?	checkbox	text		98	95	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
243	2020-04-14 14:47:29.398+00	2020-04-14 14:47:29.398+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/repository	https://rdmorganiser.github.io/terms	repository	rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/repository		t	5	\N	\N	Where will the data (including metadata, documentation and, if applicable, relevant code) be stored or archived after the end of the project?	Wo werden die Daten (einschließlich Metadaten, Dokumentation und ggf. relevantem Code bzw. relevanter Software) nach Projektende gespeichert bzw. archiviert?	checkbox	text		99	95	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
244	2020-04-14 14:47:29.478+00	2020-04-14 14:47:29.478+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/repository_arrangements	https://rdmorganiser.github.io/terms	repository_arrangements	rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/repository_arrangements		f	7	(original question from Horizon 2020 FAIR Data Management Plan)	\N	Have you explored appropriate arrangements with the identified repository?	Wurde mit dem Repositorium oder Datenzentrum bereits angemessene Archivierungslösungen besprochen?	yesno	boolean		100	95	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
245	2020-04-14 14:47:29.53+00	2020-04-14 14:47:29.53+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/reuse_duration	https://rdmorganiser.github.io/terms	reuse_duration	rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/reuse_duration	Original H2020 question	f	4	\N	\N	How long is it intended that the data remains re-usable.	Wie lang sollen die Daten nach Projektende (nach)nutzbar sein?	text	text		101	95	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
246	2020-04-14 14:47:29.587+00	2020-04-14 14:47:29.587+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/yesno	https://rdmorganiser.github.io/terms	yesno	rdmo/storage-and-long-term-preservation/long-term-preservation-datasets/yesno		f	1	\N	\N	Does this dataset have to preserved for the long-term?	Muss dieser Datensatz langfristig aufbewahrt werden?	yesno	boolean		102	95	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
247	2020-04-14 14:47:29.629+00	2020-04-14 14:47:29.629+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/selection-criteria/responsible_person	https://rdmorganiser.github.io/terms	responsible_person	rdmo/storage-and-long-term-preservation/selection-criteria/responsible_person		t	1	\N	\N	Who selects the data to be archived?	Durch wen erfolgt die Auswahl?	text	text		195	96	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
248	2020-04-14 14:47:29.672+00	2020-04-14 14:47:29.672+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/selection-criteria/selection_criteria	https://rdmorganiser.github.io/terms	selection_criteria	rdmo/storage-and-long-term-preservation/selection-criteria/selection_criteria		f	0	Examples: data are a basis for a publication, for re-use, legal or contractual conditions, documentation (socially or politically relevant)	Beispiele: die Daten sind Grundlage einer Publikation, für Nachnutzung, rechtliche oder vertragliche Auflagen, Dokumentation (gesellschaftlich oder politisch relevant)	What are the criteria / rules for the selection of the data to be archived (after the end of the project)?	Auf Basis welcher Kriterien / Regeln werden die Daten zur Archivierung (nach Projektende) ausgesucht?	textarea	text		197	96	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
251	2020-04-14 14:47:29.834+00	2020-04-14 14:47:29.834+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-dates/data_cleansing_end	https://rdmorganiser.github.io/terms	data_cleansing_end	rdmo/technical-classification/data-dates/data_cleansing_end		f	4	\N	\N	When does data cleansing / data preparation end?	Wann endet die Datenbereinigung / -aufbereitung?	date	datetime		49	97	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
252	2020-04-14 14:47:29.884+00	2020-04-14 14:47:29.884+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-dates/data_cleansing_start	https://rdmorganiser.github.io/terms	data_cleansing_start	rdmo/technical-classification/data-dates/data_cleansing_start		f	3	\N	\N	When does data cleansing / data preparation start?	Wann beginnt die Datenbereinigung / -aufbereitung?	date	datetime		50	97	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
253	2020-04-14 14:47:29.932+00	2020-04-14 14:47:29.932+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-dates/data_collection_end	https://rdmorganiser.github.io/terms	data_collection_end	rdmo/technical-classification/data-dates/data_collection_end		f	2	\N	\N	When does data collection or creation end?	Wann endet die Erhebung bzw. Erstellung der Daten?	date	datetime		51	97	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
254	2020-04-14 14:47:29.991+00	2020-04-14 14:47:29.991+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-dates/data_collection_start	https://rdmorganiser.github.io/terms	data_collection_start	rdmo/technical-classification/data-dates/data_collection_start		f	1	\N	\N	When does data collection or creation start?	Wann beginnt die Erhebung bzw. Erstellung der Daten?	date	datetime		52	97	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
255	2020-04-14 14:47:30.042+00	2020-04-14 14:47:30.042+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-formats/format	https://rdmorganiser.github.io/terms	format	rdmo/technical-classification/data-formats/format		f	4	When choosing a data format, one should consider the consequences for collaborative use, long-term preservation as well as re-use. It is advisable to prefer formats that are standardised, open, non-proprietary and well-established in\n\t\t\tthe respective scholarly community. More criteria and detailed explanations can be found e.g. in the <a href="https://www.forschungsdaten.org/images/b/b0/Leitfaden_Data-Management-WissGrid.pdf" target=_blank">WissGrid-Leitfaden,\n\t\t\tpp. 22 f.</a>).	Bei der Wahl des Dateiformates sollten auch die Konsequenzen für die kollaborative Nutzung, die Langzeitarchivierung sowie die Nachnutzung beachtet werden. Es empfiehlt sich, möglichst standardisierte, nicht-proprietäre und allgemein\n\t\t\tbzw. in der spezifischen Community verbreitete Formate zu nutzen. Weitere Kriterien sowie detaillierte Erläuterungen sind z.B. im <a href="https://www.forschungsdaten.org/images/b/b0/Leitfaden_Data-Management-WissGrid.pdf"\n\t\t\ttarget=_blank">WissGrid-Leitfaden, S. 22 f.</a>) zu finden.	Which file formats are used?	In welchen Formaten liegen die Daten vor?	textarea	text		62	98	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
256	2020-04-14 14:47:30.094+00	2020-04-14 14:47:30.094+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-tools/creation_methods	https://rdmorganiser.github.io/terms	creation_methods	rdmo/technical-classification/data-tools/creation_methods		f	1	This information is necessary to be able to reconstruct the process by which the data was generated. It is also a prerequisite to judge the objectivity, reliability and validity of the dataset. For reproducible data, it is also\n\t\t\trequired to re-generate the data if need be.	Diese Informationen sind für alle Arten von Daten relevant, um ihre Genese nachvollziehen zu können. Bei reproduzierbaren Daten kommt ein weiterer Aspekt hinzu. Diese müssen nicht notwendigerweise aufbewahrt werden - allerdings müssen\n\t\t\talle Geräte, Software und auch Informationen über die Vorgehensweise erhalten bleiben, die notwendig sind, um die Daten erneut erstellen zu können.	Which tools, software, technologies or processes are used to generate or collect the data?	Welche Instrumente, Software, Technologien oder Verfahren werden zur Erzeugung oder Erfassung der Daten genutzt?	textarea	text		44	99	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
257	2020-04-14 14:47:30.15+00	2020-04-14 14:47:30.15+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-tools/documentation	https://rdmorganiser.github.io/terms	documentation	rdmo/technical-classification/data-tools/documentation		f	3	\N	\N	Is documentation about relevant software needed to use the data?	Wird die Dokumentation von ggf. zur Nutzung notwendiger Software benötigt, um die Daten zu nutzen?	yesno	boolean		131	99	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
258	2020-04-14 14:47:30.194+00	2020-04-14 14:47:30.194+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-tools/usage_technology	https://rdmorganiser.github.io/terms	usage_technology	rdmo/technical-classification/data-tools/usage_technology		f	2	To be able to re-use data (e.g. to replicate studies, for meta analysis or to solve new research questions), along with the data the software, equipment and knowledge about special methods to use the data are required . Just as with\n\t\t\tthe formats, the recommendation is: the more standardised, open and established, the better for re-use.	Um Daten nachnutzen zu können, bspw. für die Replikation von Studien, Metaanalysen oder die Beantwortung neuer Forschungsfragen, werden neben den Daten selbst auch die Software, Geräte etc. und das Wissen über spezielle Verfahren zur\n\t\t\tNutzung benötigt. Ebenso wie bei den Formaten gilt hier: je standardisierter, offener und etablierter diese sind, desto einfacher ist i.d.R. eine Nachnutzung möglich.	Which software, processes or technologies are necessary to use the data?	Welche Software, Verfahren oder Technologien sind notwendig, um die Daten zu nutzen?	textarea	text		144	99	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
259	2020-04-14 14:47:30.241+00	2020-04-14 14:47:30.241+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-versioning/strategy	https://rdmorganiser.github.io/terms	strategy	rdmo/technical-classification/data-versioning/strategy		f	2	Please briefly describe the project-internal regulations for the versioning of data sets (e.g.: What kind of changes require a new version? How are changes documented? What are the naming rules for different versions?)	Bitte beschreiben Sie hier kurz projektinterne Regelungen zur Versionierung von Datensätzen (z.B.: Welche Änderungen machen eine neue Version erforderlich? Wie werden die Änderungen dokumentiert? Wie werden die verschiedenen Versionen benannt?)	Which versioning strategy is applied for this dataset?	Welche Versionierungsstrategie wird für diesen Datensatz angewandt?	textarea	text		145	100	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
260	2020-04-14 14:47:30.29+00	2020-04-14 14:47:30.29+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-versioning/tool	https://rdmorganiser.github.io/terms	tool	rdmo/technical-classification/data-versioning/tool		f	3	\N	\N	Which technology or tool is used for versioning?	Welche Technologie bzw. welches Tool wird zur Versionierung verwendet?	radio	text		146	100	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
261	2020-04-14 14:47:30.404+00	2020-04-14 14:47:30.404+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-versioning/yesno	https://rdmorganiser.github.io/terms	yesno	rdmo/technical-classification/data-versioning/yesno		f	1	\N	\N	Are different versions of the dataset created?	Werden verschiedene Versionen des Datensatzes erzeugt?	yesno	boolean		147	100	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
262	2020-04-14 14:47:30.455+00	2020-04-14 14:47:30.455+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-volume/rate	https://rdmorganiser.github.io/terms	rate	rdmo/technical-classification/data-volume/rate		f	2	Optional. This is only of concern if the data production rate reaches TB scale.	Optional. Dies ist nur relevant, wenn das Wachstum die TB-Größenordnung erreicht.	How much data is produced per year?	Wie hoch ist die erwartete Erzeugungsrate der Daten pro Jahr?	text	integer		104	101	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
263	2020-04-14 14:47:30.507+00	2020-04-14 14:47:30.507+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-volume/volume	https://rdmorganiser.github.io/terms	volume	rdmo/technical-classification/data-volume/volume		f	1	\N	\N	What is the actual or expected size of the dataset?	Was ist die tatsächliche oder erwartete Größe des Datensatzes?	radio	float		130	101	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
264	2020-04-14 14:58:24.037+00	2020-05-12 08:10:43.09+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/content-classification/data-dataset/description	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	description	dfg/content-classification/data-dataset/description		f	1	Please briefly describe the data type and / or the method used to create or collect the data, for example: \n\n* quantitative online survey \n\n* 3D model / digital reconstruction of a stone age settlement \n\n* software developed within the project	Bitte beschreiben Sie hier kurz, um welchen Datentyp es sich handelt und mit welcher Methode die Daten erhoben oder erstellt wurden, z.B.: \n\n* quantitative Online-Befragung \n\n* 3D-Modellierung / digitale Rekonstruktion einer steinzeitlichen Siedlung \n\n* Software, die im Projekt entwickelt wird	What kind of dataset is it?	Um was für einen Datensatz handelt es sich?	textarea	text		61	102	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
265	2020-04-14 14:58:24.083+00	2020-05-12 08:10:43.144+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/content-classification/data-reuse/scenario	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	scenario	dfg/content-classification/data-reuse/scenario		f	1	It is important to set the fundamental course as to whether or not the data will be permitted for reuse. Of course, the potential for subsequent use can not be the sole decision criterion, but legal impediments, such as Privacy, copyright and business secrets must be taken into account. Otherwise, consider the re-use potential against the disadvantages, e.g. a decrease in the readiness to participate and the expected extra effort of a data publication.	Wichtig ist die grundsätzliche Weichenstellung, ob die Daten zur Nachnutzung zugelassen werden oder nicht. Selbstverständlich kann das Nachnutzungspotential dabei nicht alleiniges Entscheidungskriterium sein, sondern rechtliche Hinderungsgründe, wie z.B. Datenschutz, Urheberrecht und die Wahrung von Geschäftsgeheimnissen, müssen berücksichtigt werden. Wägen Sie ansonsten das Nachnutzungspotential gegen die Nachteile ab, beispielsweise gegen ein Absinken der Teilnahmebereitschaft und den zu erwartenden Mehraufwand einer Datenveröffentlichung.	Which individuals, groups or institutions could be interested in re-using this dataset? What are possible scenarios? What consequences does the re-use potential have for the provision of the data later?	Für welche Personen, Gruppen oder Institutionen könnte dieser Datensatz (für die Nachnutzung) von Interesse sein? Für welche Szenarien ist dies denkbar? Welche Konsequenzen hat das Nachnutzungspotential später für die Bereitstellung der Daten?	textarea	text		106	103	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
266	2020-04-14 14:58:24.148+00	2020-05-12 08:10:43.188+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/data-usage/data-sharing-and-re-use-publication/conditions	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	conditions	dfg/data-usage/data-sharing-and-re-use-publication/conditions		t	3	The options refer to the licenses of the <a href="https://creativecommons.org/share-your-work/licensing-types-examples/" target=_blank">Creative Commons family</a>.	Die Auswahlmöglichkeiten orientieren sich an Lizenzen der <a href="http://de.creativecommons.org/" target=_blank">Creative-Commons-Familie</a>.	If yes, under which terms of use or license will the dataset be published or shared?	Wenn ja, unter welchen Nutzungsbedingungen oder welcher Lizenz sollen die Daten veröffentlicht bzw. geteilt werden?	checkbox	text		122	104	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
267	2020-04-14 14:58:24.245+00	2020-05-12 08:10:43.327+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/data-usage/data-sharing-and-re-use-publication/data_publication_date	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	data_publication_date	dfg/data-usage/data-sharing-and-re-use-publication/data_publication_date		f	6	\N	\N	When will the data be published (if they are)?	Wann werden die Daten veröffentlicht?	date	datetime		53	104	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
268	2020-04-14 14:58:24.334+00	2020-05-12 08:10:43.459+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/data-usage/data-sharing-and-re-use-publication/explanation	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	explanation	dfg/data-usage/data-sharing-and-re-use-publication/explanation		f	2	\N	\N	If no, please explain why not. Please differentiate between legal and contractual reasons and voluntary restrictions.	Wenn nicht, begründen Sie dies bitte und unterscheiden Sie dabei zwischen rechtlichen und/oder vertraglichen Gründen und freiwilligen Einschränkungen.	textarea	text		123	104	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
269	2020-04-14 14:58:24.389+00	2020-05-12 08:10:43.51+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/data-usage/data-sharing-and-re-use-publication/yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	yesno	dfg/data-usage/data-sharing-and-re-use-publication/yesno		f	1	\N	\N	Will this dataset be published or shared?	Soll dieser Datensatz veröffentlicht oder geteilt werden?	radio	boolean		127	104	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
270	2020-04-14 14:58:24.501+00	2020-05-12 08:10:43.643+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/data-usage/data-storage-and-security-storage/type	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	type	dfg/data-usage/data-storage-and-security-storage/type		f	1	If parts of the documentation or related software (custom development) are not stored with the data, also indicate where they are stored. This applies to the documentation of the software too.	Falls Teile der Dokumentation oder zugehöriger, selbst entwickelter Software nicht mit dem Datensatz zusammen gespeichert sind, sollten Sie auch angeben, wo diese gespeichert sind. Das gilt auch für die Dokumentation der Software.	Where is the dataset stored during the project?	Wo wird der Datensatz während des Projektes gespeichert?	textarea	text		135	105	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
271	2020-04-14 14:58:24.552+00	2020-05-12 08:10:43.688+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/data-usage/quality-assurance-dataset/measures	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	measures	dfg/data-usage/quality-assurance-dataset/measures		f	7	\N	\N	Which measures of quality assurance are taken for this dataset?	Welche Maßnahmen zur Qualitätssicherung werden für diesen Datensatz ergriffen?	textarea	text		103	106	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
280	2020-04-14 14:58:25.234+00	2020-05-12 08:10:44.485+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/storage-and-long-term-preservation/long-term-preservation-datasets/purpose	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	purpose	dfg/storage-and-long-term-preservation/long-term-preservation-datasets/purpose		t	2	\N	\N	What are the reasons this dataset has to be preserved for the long-term?	Aus welchen Gründen müssen die Daten langfristig aufbewahrt werden?	checkbox	text		98	113	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
272	2020-04-14 14:58:24.602+00	2020-05-12 08:10:43.735+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/general/other-requirements-requirements/requirements	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	requirements	dfg/general/other-requirements-requirements/requirements		f	0	Please briefly outline them and refer to more detailed sources of information if necessary. Please also indicate, if the rules / guidelines are mandatory or optional.	Bitte skizzieren Sie sie kurz und verweisen Sie ggf. auf weiterführende Informationen. Geben Sie bitte auch an, welchen Grad an Verbindlichkeit sie haben.	Which are these additional requirements regarding data management?	Welche Anforderungen an das Datenmanagement sind dies?	textarea	text		3	107	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
273	2020-04-14 14:58:24.653+00	2020-05-12 08:10:43.78+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/general/other-requirements-yesno/yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	yesno	dfg/general/other-requirements-yesno/yesno		f	0	Examples of discipline-specific requirements are: \n\n- <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/guidelines_biodiversity_research.pdf" target=_blank">Guidelines on the Handling of Research\n                                Data in Biodiversity Research</a> \n\n- <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/foerderkriterien_editionen_literaturwissenschaft.pdf" target=_blank">Elegibility criteria for funding for\n                                scholarly editions in the literary studies (German)</a> \n\n- Recommendations on <a href="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_sprachkorpora.pdf"\n                                target=_blank">data standards and tools</a> as well as <a href="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_recht.pdf" target=_blank">legal\n                                aspects</a> associated with language corpora (German)	Beispiele für fachspezifische Empfehlungen und Richtlinien sind: \n\n- <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_biodiversitaetsforschung.pdf" target=_blank">Richtlinien zum Umgang mit Forschungsdaten in der Biodiversitätsforschung</a>\n\n- <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/foerderkriterien_editionen_literaturwissenschaft.pdf" target=_blank">Förderkriterien für wissenschaftliche Editionen in der Literaturwissenschaft</a> \n\n- Empfehlungen zu <a href="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_sprachkorpora.pdf" target=_blank">datentechnischen Standards und Tools</a>\n                                sowie zu <a href="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_recht.pdf" target=_blank">rechtlichen Fragen</a> bei der Erhebung von Sprachkorpora	Are there requirements regarding the data management from your scholarly/scientific community?	Gibt es von Seiten Ihrer Fachcommunity Anforderungen an das Datenmanagement, die beachtet werden müssen?	radio	boolean		4	108	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
274	2020-04-14 14:58:24.764+00	2020-05-12 08:10:43.918+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/legal-and-ethics/intellectual-property-rights-dataset/copyrights	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	copyrights	dfg/legal-and-ethics/intellectual-property-rights-dataset/copyrights		t	0	\N	\N	Does copyright law apply to this dataset?	Be- oder entstehen an diesem Datensatz Urheberrechte?	checkbox	text		68	109	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
275	2020-04-14 14:58:24.865+00	2020-05-12 08:10:44.059+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/legal-and-ethics/intellectual-property-rights-dataset/other_rights	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	other_rights	dfg/legal-and-ethics/intellectual-property-rights-dataset/other_rights		t	2	\N	\N	Do other intellectual property rights apply to this dataset?	Be- oder entstehen an diesem Datensatz andere Schutzrechte?	checkbox	text		69	109	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
276	2020-04-14 14:58:24.965+00	2020-05-12 08:10:44.2+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/legal-and-ethics/intellectual-property-rights-yesno/yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	yesno	dfg/legal-and-ethics/intellectual-property-rights-yesno/yesno		f	0	Data or software can be subject to intellectual or industrial property rights. Applicable laws differ broadly even within EU. According to the German copyright law (UrhG) works of literature, scholarship and the arts that can be regarded as a “personal intellectual creation” are protected by copyright. Copyright protection expires 70 years after the death of the copyright holder. Mere data, e.g. measured data or survey data, and metadata (except in some cases descriptive metadata) are not protected by copyright. § 2 of the UrhG lists the following kinds of protected works (list is not concluded): \n\n* linguistic works such as written works, speeches and computer programs \n\n* works of music \n\n* pantomimic works including works of the art of dance \n\n* works or the fine arts including works of architecture and the applied arts as well as sketches of such works \n\n* works of photography and cinematography \n\n* descriptions and illustrations of scholarly or technical nature such as drawings, plans, maps, sketches, tables and three-dimensional represenations \n\nAccording to § 3, copyright is also applicable to translations and other modifications or adaptions of a work if they are individual intellectual creations of the editor. Finally, according to § 4 copyright also extents to collected editions and database works. Collected editions are “collections of work, data or other independent elements that are individual intellectual creations based on the selection and arrangement of the elements”. Database works are defined as “collected editions, the elements of which are arranged in a systematic or methodical way and can be accessed individually by electronic means or in other ways”. Other relevant property rights can be trademarks, patents, utility models, plant variety rights protection, integrated circuit layout design protection, geographical indications or registered designs.	Daten oder Software können Urheber- oder anderen Schutzrechten unterliegen. Die Rechtslage kann selbst in der EU von Land zu Land erheblich abweichen. In Deutschland sind nach dem Urheberrechtsgesetz (UrhG) Werke der Literatur, Wissenschaft und Kunst, die eine „persönliche geistige Schöpfung“ darstellen, urheberrechtlich geschützt. Der urheberrechtliche Schutz erlischt 70 Jahre nach dem Tod der bzw. des Urheberin/s. Reine Daten, z.B. Messdaten oder Surveydaten, aber auch Metadaten (bis auf ggf. „beschreibende“ Metadaten) sind hingegen nicht schutzfähig. In § 2 nennt das UrhG folgende geschützte Werkarten, wobei die Aufzählung nicht abschließend ist: \n\n* Sprachwerke, wie Schriftwerke, Reden und Computerprogramme \n\n* Werke der Musik \n\n* pantomimische Werke einschließlich Werke der Tanzkunst \n\n* Werke der bildenden Künste einschließlich der Werke der Baukunst und der angewandten Kunst und Entwürfe solcher Werke \n\n* Lichtbildwerke einschließlich der Werke, die ähnlich wie Lichtbildwerke geschaffen werden \n\n* Darstellungen wissenschaftlicher oder technischer Art wie Zeichnungen, Pläne, Karten, Skizzen, Tabellen und plastische Darstellungen. \n\nNach § 3 sind auch „Übersetzungen und andere Bearbeitungen“ von Werken geschützt, die persönliche geistige Schöpfungen des Bearbeiters sind“. Schließlich sind nach § 4 auch Sammelwerke und Datenbankwerke geschützt, was im Bereich Forschungsdaten durchaus relevant sein kann. Sammelbankwerke werden dabei definiert als „Sammlungen von Werken, Daten oder anderen unabhängigen Elementen, die aufgrund der Auswahl oder Anordnung der Elemente eine persönliche geistige Schöpfung sind“. Bei einem „Datenbankwerk im Sinne des Gesetzes“ handelt es sich um ein „Sammelwerk, dessen Elemente systematisch oder methodisch angeordnet und einzeln mit Hilfe elektronischer Mittel oder auf andere Weise zugänglich sind“. Weitere relevante Schutzrechte können gewerbliche Schutzrechte wie Patente, Gebrauchsmuster, Sortenschutz [bei Pflanzenzüchtungen], Halbleiterschutz, Marken, geographische Herkunftsangaben, eingetragene Designs oder geschäftliche Bezeichnungen sein.	Does the project use and/or produce data that is protected by intellectual or industrial property rights?	Werden Daten genutzt und/oder erstellt, die durch Urheber- oder verwandte Schutzrechte geschützt sind?	yesno	boolean		162	110	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
277	2020-04-14 14:58:25.038+00	2020-05-12 08:10:44.262+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/legal-and-ethics/sensitive-data-personal_data/anonymization	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	anonymization	dfg/legal-and-ethics/sensitive-data-personal_data/anonymization		f	2	\N	\N	Will the data be anonymised or pseudonymised?	Werden die Daten anonymisiert oder pseudonymisiert?	radio	text		112	111	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
278	2020-04-14 14:58:25.132+00	2020-05-12 08:10:44.393+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/legal-and-ethics/sensitive-data-personal_data_yesno/yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	yesno	dfg/legal-and-ethics/sensitive-data-personal_data_yesno/yesno		f	1	The EU General Data Protection Regulation (GDPR) defines in Art. 4 personal data as "any information relating to an identified or identifiable natural person". An identifiable natural person is "one who can be identified, directly or indirectly, in particular by reference to an identifier such as a name, an identification number, location data, an online identifier or to one or more factors specific to the physical, physiological, genetic, mental, economic, cultural or social identity of that natural person".	Die EU Datenschutz-Grundverordnung (DSGVO) definiert in Art. 4 personenbezogene Daten als "alle Informationen, die sich auf eine identifizierte oder identifizierbare natürliche Person beziehen". Als identifizierbar wird "eine natürliche Person angesehen, die direkt oder indirekt, insbesondere mittels Zuordnung zu einer Kennung wie einem Namen, zu einer Kennnummer, zu Standortdaten, zu einer Online-Kennung oder zu einem oder mehreren besonderen Merkmalen identifiziert werden kann, die Ausdruck der physischen, physiologischen, genetischen, psychischen, wirtschaftlichen, kulturellen oder sozialen Identität dieser natürlichen Person sind".	Does this dataset contain personal data?	Enthält dieser Datensatz personenbezogene Daten?	yesno	boolean		120	112	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
279	2020-04-14 14:58:25.183+00	2020-05-12 08:10:44.438+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/storage-and-long-term-preservation/long-term-preservation-datasets/duration	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	duration	dfg/storage-and-long-term-preservation/long-term-preservation-datasets/duration		f	3	\N	\N	How long will the data be stored?	Wie lange müssen die Daten aufbewahrt werden?	text	text		96	113	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
281	2020-04-14 14:58:25.33+00	2020-05-12 08:10:44.625+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/storage-and-long-term-preservation/long-term-preservation-datasets/repository	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	repository	dfg/storage-and-long-term-preservation/long-term-preservation-datasets/repository		t	5	\N	\N	Where will the data (including metadata, documentation and, if applicable, relevant code) be stored or archived after the end of the project?	Wo werden die Daten (einschließlich Metadaten, Dokumentation und ggf. relevantem Code bzw. relevanter Software) nach Projektende gespeichert bzw. archiviert?	checkbox	text		99	113	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
282	2020-04-14 14:58:25.504+00	2020-05-12 08:10:44.764+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/storage-and-long-term-preservation/long-term-preservation-datasets/yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	yesno	dfg/storage-and-long-term-preservation/long-term-preservation-datasets/yesno		f	1	\N	\N	Does this dataset have to preserved for the long-term?	Muss dieser Datensatz langfristig aufbewahrt werden?	yesno	boolean		102	113	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
283	2020-04-14 14:58:25.562+00	2020-05-12 08:10:44.81+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/technical-classification/data-formats/format	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	format	dfg/technical-classification/data-formats/format		f	4	When choosing a data format, one should consider the consequences for collaborative use, long-term preservation as well as re-use. It is advisable to prefer formats that are standardised, open, non-proprietary and well-established in the respective scholarly community. A table with recommended file formats can be found in Kristin Briney, <i>Data Management for Researchers</i>, Pelargic, 2015, pages 133-134.	Bei der Wahl des Dateiformates sollten auch die Konsequenzen für die kollaborative Nutzung, die Langzeitarchivierung sowie die Nachnutzung beachtet werden. Es empfiehlt sich, möglichst standardisierte, nicht-proprietäre und allgemein bzw. in der spezifischen Community verbreitete Formate zu nutzen. Weitere Kriterien sowie detaillierte Erläuterungen sind z.B. im <a href="http://nestor.sub.uni-goettingen.de/handbuch/"  target=_blank">nestor Handbuch</a> zu finden.	Which file formats are used?	In welchen Formaten liegen die Daten vor?	textarea	text		62	114	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
284	2020-04-14 15:00:00.174+00	2020-04-14 15:00:00.174+00	http://example.com/terms/questions/edu_dfg/content-classification/data-reuse/existing	http://example.com/terms	existing	edu_dfg/content-classification/data-reuse/existing	Neue, noch nicht im Katalog RDMO enthaltene Frage, die aufgrund einer Anforderung in 'Bereitstellung und Nutzung quantitativer Forschungsdaten in der Bildungsforschung: Memorandum des Fachkollegiums „Erziehungswissenschaft“ der DFG' aufgenommen wurde	f	3	From <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf"\n                                target=_blank">Bereitstellung und Nutzung quantitativer Forschungsdaten in der Bildungsforschung: Memorandum des Fachkollegiums „Erziehungswissenschaft“ der DFG</a>: \n\nFor project applications that involve the collection of new data, it should always be checked whether comparable data sets are already available and available that could be used to investigate the research questions. If this is the case, it may be necessary to prove why re-use is not meaningful and that new data should be collected. This point would then also be included as an object of the review.	Aus <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf"\n                                target=_blank">Bereitstellung und Nutzung quantitativer Forschungsdaten in der Bildungsforschung: Memorandum des Fachkollegiums „Erziehungswissenschaft“ der DFG</a>: \n\n"Bei  Projektanträgen, die eine Erhebung neuer Daten beinhalten, sollte grundsätzlich geprüft  werden, ob nicht bereits  vergleichbare Datensätze vorliegen und  verfügbar sind,  die sich zur Untersuchung der Forschungsfragen eignen könnten.  Sofern  dies der Fall ist, wäre ggf. der Nachweis zu führen, warum eine Nachnutzung nicht sinnvoll ist und neue Daten erhoben werden sollen. Dieser Punkt wäre dann auch als Gegenstand der Begutachtung einzubeziehen."	If created, are already existing, similar research data available and why is their subsequent use not possible or useful here?	Wenn selbst erzeugt, sind bereits existierende, ähnliche Forschungsdaten verfügbar und warum ist deren Nachnutzung hier nicht möglich bzw. sinnvoll?	textarea	text		\N	117	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
285	2020-04-14 15:00:00.238+00	2020-04-14 15:00:00.238+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/content-classification/data-dataset/description	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	description	edu_dfg/content-classification/data-dataset/description		f	1	Please briefly describe the data type and / or the method used to create or collect the data, for example: \n\n* quantitative online survey \n\n* video recordings \n\n* teaching material or software developed within the project	Bitte beschreiben Sie hier kurz, um welchen Datentyp es sich handelt und mit welcher Methode die Daten erhoben oder erstellt wurden, z.B.: \n\n* quantitative Online-Befragung \n\n* Videoaufnahmen \n\n* Lernmaterialien oder Software, die im Projekt entwickelt wird	What kind of dataset is it?	Um was für einen Datensatz handelt es sich?	textarea	text		61	115	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
286	2020-04-14 15:00:00.287+00	2020-04-14 15:00:00.287+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/content-classification/data-existing_data/creator_name	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	creator_name	edu_dfg/content-classification/data-existing_data/creator_name		f	2	\N	\N	If re-used, who created the dataset?	Wenn nachgenutzt, wer hat den Datensatz erzeugt?	textarea	text		46	116	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
287	2020-04-14 15:00:00.336+00	2020-04-14 15:00:00.336+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/content-classification/data-existing_data/origin	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	origin	edu_dfg/content-classification/data-existing_data/origin		f	1	\N	\N	Is the dataset being created or re-used?	Wird der Datensatz selbst erzeugt oder nachgenutzt?	radio	text		85	116	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
288	2020-04-14 15:00:00.449+00	2020-04-14 15:00:00.449+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/content-classification/data-existing_data/uri	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	uri	edu_dfg/content-classification/data-existing_data/uri		f	3	\N	\N	If re-used, under which address, PID or URL can the dataset be found?	Wenn nachgenutzt, unter welcher Adresse, PID oder URL ist der Datensatz verfügbar?	text	text		139	116	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
297	2020-04-14 15:00:01.07+00	2020-04-14 15:00:01.07+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/doc/general/documentation_on_request	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	documentation_on_request	edu_dfg/doc/general/documentation_on_request		f	2	According to <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target=_blank">Memorandum des Fachkollegiums „Erziehungswissenschaft“ der DFG</a>, the provision is expressly provided upon request in the case of the following <i>forms of deployment</ i>:\n\na) Archiving and on demand user-friendly provision directly by the data producer for the purpose of checking published results (in the sense of good scientific practice)\n\nb) Archiving, extended documentation (codebook) and on demand user-friendly provision directly by the data producers for further scientific analysis\n\nSo do not be afraid to mention here the parts of the data documentation that will not be available together with the actual data, but later.	Im <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target=_blank">Memorandum des Fachkollegiums „Erziehungswissenschaft“ der DFG</a>, ist die Bereitstellung auf Anfrage ausdrücklich vorgesehen im Falle der folgenden <i>Formen der Bereitstellung</i>:\n\na) <i>Archivierung und auf Nachfrage nutzerfreundliche Bereitstellung direkt durch den Datenproduzenten zwecks Prüfung   publizierter Ergebnisse (im Sinne guter wissenschaftlicher Praxis). </i>\n\nb) <i>Archivierung, erweiterte Dokumentation (Codebuch) und auf Nachfrage nutzerfreundliche Bereitstellung direkt durch die  Datenproduzenten zwecks weiterführender wissenschaftlicher Analysen.</i>\n\nScheuen Sie sich also nicht, hier die Teile der Datendokumentation zu nennen, die nicht gleich zusammen mit den eigentlichen Daten zur Verfügung stehen werden, sondern erst später.	Which components of the data documentation are provided on request?	Welche Komponenten der Datendokumentation werden erst auf Anfrage bereitgestellt?	textarea	text		\N	121	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
289	2020-04-14 15:00:00.5+00	2020-04-14 15:00:00.5+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/content-classification/data-reuse/scenario	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	scenario	edu_dfg/content-classification/data-reuse/scenario		f	1	According to the <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target=_blank">Memorandum of the review board Educational Science of the DFG (in German)</a> you should weigh up the re-use potential against the deployment effort, choose one of the following three possible consequences and justify your selection:\n\na) Archiving and on demand user-friendly provision directly by the data producer for the purpose of checking published results (in the sense of good scientific practice)\n\nb) Archiving, extended documentation (codebook) and on demand user-friendly provision directly by the data producers for further scientific analysis\n\nc) Well-documented transfer to a research data center for archiving and general provision to the scientific community according to the regulations of the respective research data centre\n\nOf course, legal obstacles (privacy, intellectual property rights, contracts) must be taken into account.	Im <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target=_blank">Memorandum des Fachkollegiums „Erziehungswissenschaft“ der DFG</a> werden Sie ersucht, das Nachnutzungspotential gegen den Bereitstellungsaufwand abzuwägen, unter den folgenden drei möglichen Konsequenzen eine auszuwählen und Ihre Auswahl zu begründen:\n\na) Archivierung und auf Nachfrage nutzerfreundliche Bereitstellung direkt durch den Datenproduzenten zwecks Prüfung   publizierter Ergebnisse (im Sinne guter wissenschaftlicher Praxis)\n\nb) Archivierung,  erweiterte  Dokumentation  (Codebuch) und auf  Nachfrage  nutzerfreundliche  Bereitstellung  direkt  durch  die  Datenproduzenten  zwecks  weiterführender wissenschaftlicher Analysen\n\nc) Gut  dokumentierte  Übergabe an ein Forschungsdatenzentrum zwecks Archivierung und allgemeiner Bereitstellung an die  Scientific Community nach den Regularien des jeweiligen FDZ\n\nSelbstverständlich müssen rechtliche Hinderungsgründe (Datenschutz, Urheberrecht, Verträge) berücksichtigt werden.	If created, which individuals, groups or institutions could be interested in re-using this dataset? What are possible scenarios? What consequences does the re-use potential have for the provision of the data later?	Wenn selbst erzeugt, für welche Personen, Gruppen oder Institutionen könnte dieser Datensatz (für die Nachnutzung) von Interesse sein? Für welche Szenarien ist dies denkbar? Welche Konsequenzen hat das Nachnutzungspotential später für die Bereitstellung der Daten?	textarea	text		106	117	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
290	2020-04-14 15:00:00.552+00	2020-04-14 15:00:00.552+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/data-usage/data-sharing-and-re-use-publication/conditions	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	conditions	edu_dfg/data-usage/data-sharing-and-re-use-publication/conditions		t	3	The options refer to the licenses of the <a href="https://creativecommons.org/share-your-work/licensing-types-examples/" target=_blank">Creative Commons family</a>.	Die Auswahlmöglichkeiten orientieren sich an Lizenzen der <a href="http://de.creativecommons.org/" target=_blank">Creative-Commons-Familie</a>.	If yes, under which terms of use or license will the dataset be published or shared?	Wenn ja, unter welchen Nutzungsbedingungen oder welcher Lizenz sollen die Daten veröffentlicht bzw. geteilt werden?	checkbox	text		122	118	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
291	2020-04-14 15:00:00.663+00	2020-04-14 15:00:00.663+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/data-usage/data-sharing-and-re-use-publication/data_publication_date	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	data_publication_date	edu_dfg/data-usage/data-sharing-and-re-use-publication/data_publication_date		f	6	\N	\N	When will the data be published (if they are)?	Wann werden die Daten veröffentlicht?	date	datetime		53	118	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
292	2020-04-14 15:00:00.753+00	2020-04-14 15:00:00.753+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/data-usage/data-sharing-and-re-use-publication/explanation	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	explanation	edu_dfg/data-usage/data-sharing-and-re-use-publication/explanation		f	2	\N	\N	If no, please explain why not. Please differentiate between legal and contractual reasons and voluntary restrictions.	Wenn nicht, begründen Sie dies bitte und unterscheiden Sie dabei zwischen rechtlichen und/oder vertraglichen Gründen und freiwilligen Einschränkungen.	textarea	text		123	118	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
293	2020-04-14 15:00:00.823+00	2020-04-14 15:00:00.823+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/data-usage/data-sharing-and-re-use-publication/yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	yesno	edu_dfg/data-usage/data-sharing-and-re-use-publication/yesno		f	1	\N	\N	Will this dataset be published or shared?	Soll dieser Datensatz veröffentlicht oder geteilt werden?	radio	boolean		127	118	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
294	2020-04-14 15:00:00.905+00	2020-04-14 15:00:00.905+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/data-usage/data-storage-and-security-storage/type	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	type	edu_dfg/data-usage/data-storage-and-security-storage/type		f	1	If parts of the documentation or related software (custom development) are not stored with the data, also indicate where they are stored. This applies to the documentation of the software too.	Falls Teile der Dokumentation oder zugehöriger, selbst entwickelter Software nicht mit dem Datensatz zusammen gespeichert sind, sollten Sie auch angeben, wo diese gespeichert sind. Das gilt auch für die Dokumentation der Software.	Where is the dataset stored during the project?	Wo wird der Datensatz während des Projektes gespeichert?	textarea	text		135	119	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
295	2020-04-14 15:00:00.954+00	2020-04-14 15:00:00.954+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/data-usage/quality-assurance-dataset/measures	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	measures	edu_dfg/data-usage/quality-assurance-dataset/measures		f	7	\N	\N	Which measures of quality assurance are taken for this dataset?	Welche Maßnahmen zur Qualitätssicherung werden für diesen Datensatz ergriffen?	textarea	text		103	120	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
296	2020-04-14 15:00:01.007+00	2020-04-14 15:00:01.007+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/doc/general/documentation	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	documentation	edu_dfg/doc/general/documentation		f	1	According to <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target=_blank">Memorandum des Fachkollegiums „Erziehungswissenschaft“ der DFG (in German)</a>, the documentation of data records can be designed in different ways: It can range from raw data with traceable labels and a codebook to datasets that contain raw data as well as scales and metadata and that contain detailed technical reports and scale manuals (meta and paradata).\n\nIn this field, enter the components of the data documentation that are available with the data set and are not only supplied on request in the context of good scientific practice later.	Laut <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target=_blank">Memorandum des Fachkollegiums „Erziehungswissenschaft“ der DFG</a> kann die Dokumentation von Datensätzen unterschiedlich aufwändig gestaltet werden: "Diese reicht von Rohdaten mit nachvollziehbaren Labels und einem Codebuch bis hin zu Datensätzen, die neben Rohdaten auch Skalen und Metadaten umfassen und zu denen detaillierte technische Berichte und Skalenhandbücher vorliegen (also Meta- und Paradaten)."\n\nTragen Sie in dieses Feld die Bestandteile der Datendokumentation ein, die mit dem Datensatz zur Verfügung stehen und nicht nur später auf Anfrage geliefert werden.	Which components of the data documentation are available together with the dataset?	Welche Komponenten der Datendokumentation stehen zusammen mit dem Datensatz zur Verfügung?	textarea	text		\N	121	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
298	2020-04-14 15:00:01.61+00	2020-04-14 15:00:01.61+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/doc/general/scope	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	scope	edu_dfg/doc/general/scope	probably we should introduce a separate question for being findable and re-used	t	0	\N	\N	Which information is necessary for other parties to understand the data (that is, to understand their collection or creation, analysis, and research results obtained on its basis) and to re-use it?	Welche Informationen sind für Außenstehende notwendig, um die Daten zu verstehen (d. h. ihre Erhebung bzw. Entstehung, Analyse sowie die auf ihrer Basis gewonnenen Forschungsergebnisse nachvollziehen) und nachnutzen zu können?	checkbox	text		82	121	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
299	2020-04-14 15:00:01.675+00	2020-04-14 15:00:01.675+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/general/other-requirements-requirements/requirements	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	requirements	edu_dfg/general/other-requirements-requirements/requirements		f	0	Please briefly outline them and refer to more detailed sources of information if necessary. At least the ones mentioned in the <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target=_blank">Memorandum des Fachkollegiums „Erziehungswissenschaft“ der DFG</a> should be met.	Bitte skizzieren Sie sie kurz und verweisen Sie ggf. auf weiterführende Informationen. Zumindest die im <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target=_blank">Memorandum des Fachkollegiums „Erziehungswissenschaft“ der DFG</a>  genannten Anforderungen sollten erfüllt werden.	Which are these additional requirements regarding data management?	Welche Anforderungen an das Datenmanagement sind dies?	textarea	text		3	122	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
300	2020-04-14 15:00:01.721+00	2020-04-14 15:00:01.721+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/general/other-requirements-yesno/yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	yesno	edu_dfg/general/other-requirements-yesno/yesno		f	0	This catalog contains only the questions that the requirements\n\n* <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target=_blank">Guidelines for the provision and use of quantitative\n                                data in education research</a> (in German) and\n\n* <a href ="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/guidelines_research_data.pdf" target=_blank>DFG Guidelines on the Handling of Research Data</a> (for all subjects)\n\ncover. The questions are thus selected for educational data management plans, which should be enclosed with grant applications to the German Research Foundation (DFG). The DFG expects its projects to meet these requirements. In addition, there are other recommendations or requirements that may be of interest to you, for example\n\n* <a href="http://wiki.bildungsserver.de/bilder/upload/checkliste_datenmanagement.pdf" target=_blank">Checkliste zur Erstellung eines Datenmanagementplans in der empirischen Bildungsforschung</a> (in German)\n\n* the checklists in Uwe Jensen, Sebastian Netscher, Katrin Weller, <i>Forschungsdatenmanagement sozialwissenschaftlicher Umfragedaten</i> (in German), Verlag Barbara Budich, 2019, ISBN 978-3-8474-2233-4, <a href="https://doi.org/10.3224/84742233" target=_blank>DOI 10.3224/84742233</a>	Dieser Fragenkatalog enthält nur die Fragen, die die Anforderungen\n\n* im Memorandum des Fachkollegiums „Erziehungswissenschaft“ der DFG <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target=_blank">Bereitstellung und Nutzung quantitativer Forschungsdaten in der Bildungsforschung</a>, und\n\n* in den fachübergreifenden <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten.pdf" target=_blank>Leitlinien zum Umgang mit Forschungsdaten</a> der DFG\n\nabdecken. Die Fragen sind somit ausgesucht für bildungswissenschaftliche Datenmanagementpläne, die Förderanträgen an die Deutsche Forschungsgemeinschaft (DFG) beigelegt werden sollen. Die DFG erwartet, dass in von ihr geförderten Projekten diese Anforderungen erfüllt werden. Darüber hinaus gibt es weitere Empfehlungen bzw. Anforderungen, die für Sie von Interesse sein könnten, beispielsweise\n\n* die <a href="http://wiki.bildungsserver.de/bilder/upload/checkliste_datenmanagement.pdf" target=_blank">Checkliste zur Erstellung eines Datenmanagementplans in der empirischen Bildungsforschung</a>\n\n* die Checklisten in Uwe Jensen, Sebastian Netscher, Katrin Weller, <i>Forschungsdatenmanagement sozialwissenschaftlicher Umfragedaten</i>, Verlag Barbara Budich, 2019, ISBN 978-3-8474-2233-4, <a href="https://doi.org/10.3224/84742233" target=_blank>DOI 10.3224/84742233</a>	Are there requirements regarding the data management from other parties (e.g. the scholarly/scientific community)?	Gibt es von weiteren Seiten (z. B. von der Fachcommunity) Anforderungen an das Datenmanagement, die beachtet werden müssen?	radio	boolean		4	123	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
301	2020-04-14 15:00:01.828+00	2020-04-14 15:00:01.828+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/legal-and-ethics/intellectual-property-rights-dataset/copyrights	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	copyrights	edu_dfg/legal-and-ethics/intellectual-property-rights-dataset/copyrights		t	0	\N	\N	Does copyright law apply to this dataset?	Be- oder entstehen an diesem Datensatz Urheberrechte?	checkbox	text		68	124	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
302	2020-04-14 15:00:01.928+00	2020-04-14 15:00:01.928+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/legal-and-ethics/intellectual-property-rights-dataset/other_rights	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	other_rights	edu_dfg/legal-and-ethics/intellectual-property-rights-dataset/other_rights		t	2	\N	\N	Do other intellectual property rights apply to this dataset?	Be- oder entstehen an diesem Datensatz andere Schutzrechte?	checkbox	text		69	124	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
303	2020-04-14 15:00:02.044+00	2020-04-14 15:00:02.044+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/legal-and-ethics/intellectual-property-rights-yesno/yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	yesno	edu_dfg/legal-and-ethics/intellectual-property-rights-yesno/yesno		f	0	Data or software can be subject to intellectual or industrial property rights. Applicable laws differ broadly even within EU. According to the German copyright law (UrhG) works of literature, scholarship and the arts that can be regarded as a “personal intellectual creation” are protected by copyright. Copyright protection expires 70 years after the death of the copyright holder. Mere data, e.g. measured data or survey data, and metadata (except in some cases descriptive metadata) are not protected by copyright. § 2 of the UrhG lists the following kinds of protected works (list is not concluded): \n\n* linguistic works such as written works, speeches and computer programs \n\n* works of music \n\n* pantomimic works including works of the art of dance \n\n* works or the fine arts including works of architecture and the applied arts as well as sketches of such works \n\n* works of photography and cinematography \n\n* descriptions and illustrations of scholarly or technical nature such as drawings, plans, maps, sketches, tables and three-dimensional represenations \n\nAccording to § 3, copyright is also applicable to translations and other modifications or adaptions of a work if they are individual intellectual creations of the editor. Finally, according to § 4 copyright also extents to collected editions and database works. Collected editions are “collections of work, data or other independent elements that are individual intellectual creations based on the selection and arrangement of the elements”. Database works are defined as “collected editions, the elements of which are arranged in a systematic or methodical way and can be accessed individually by electronic means or in other ways”. Other relevant property rights can be trademarks, patents, utility models, plant variety rights protection, integrated circuit layout design protection, geographical indications or registered designs.	Daten oder Software können Urheber- oder anderen Schutzrechten unterliegen. Die Rechtslage kann selbst in der EU von Land zu Land erheblich abweichen. In Deutschland sind nach dem Urheberrechtsgesetz (UrhG) Werke der Literatur, Wissenschaft und Kunst, die eine „persönliche geistige Schöpfung“ darstellen, urheberrechtlich geschützt. Der urheberrechtliche Schutz erlischt 70 Jahre nach dem Tod der bzw. des Urheberin/s. Reine Daten, z.B. Messdaten oder Surveydaten, aber auch Metadaten (bis auf ggf. „beschreibende“ Metadaten) sind hingegen nicht schutzfähig. In § 2 nennt das UrhG folgende geschützte Werkarten, wobei die Aufzählung nicht abschließend ist: \n\n* Sprachwerke, wie Schriftwerke, Reden und Computerprogramme \n\n* Werke der Musik \n\n* pantomimische Werke einschließlich Werke der Tanzkunst \n\n* Werke der bildenden Künste einschließlich der Werke der Baukunst und der angewandten Kunst und Entwürfe solcher Werke \n\n* Lichtbildwerke einschließlich der Werke, die ähnlich wie Lichtbildwerke geschaffen werden \n\n* Darstellungen wissenschaftlicher oder technischer Art wie Zeichnungen, Pläne, Karten, Skizzen, Tabellen und plastische Darstellungen. \n\nNach § 3 sind auch „Übersetzungen und andere Bearbeitungen“ von Werken geschützt, die persönliche geistige Schöpfungen des Bearbeiters sind“. Schließlich sind nach § 4 auch Sammelwerke und Datenbankwerke geschützt, was im Bereich Forschungsdaten durchaus relevant sein kann. Sammelbankwerke werden dabei definiert als „Sammlungen von Werken, Daten oder anderen unabhängigen Elementen, die aufgrund der Auswahl oder Anordnung der Elemente eine persönliche geistige Schöpfung sind“. Bei einem „Datenbankwerk im Sinne des Gesetzes“ handelt es sich um ein „Sammelwerk, dessen Elemente systematisch oder methodisch angeordnet und einzeln mit Hilfe elektronischer Mittel oder auf andere Weise zugänglich sind“. Weitere relevante Schutzrechte können gewerbliche Schutzrechte wie Patente, Gebrauchsmuster, Sortenschutz [bei Pflanzenzüchtungen], Halbleiterschutz, Marken, geographische Herkunftsangaben, eingetragene Designs oder geschäftliche Bezeichnungen sein.	Does the project use and/or produce data that is protected by intellectual or industrial property rights?	Werden Daten genutzt und/oder erstellt, die durch Urheber- oder verwandte Schutzrechte geschützt sind?	yesno	boolean		162	125	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
304	2020-04-14 15:00:02.115+00	2020-04-14 15:00:02.115+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/legal-and-ethics/sensitive-data-personal_data/anonymization	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	anonymization	edu_dfg/legal-and-ethics/sensitive-data-personal_data/anonymization		f	2	\N	\N	Will the data be anonymised or pseudonymised?	Werden die Daten anonymisiert oder pseudonymisiert?	radio	text		112	126	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
370	2020-04-14 15:07:40.828+00	2020-04-14 15:07:40.828+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/re_useable-re_use/licence	https://fdm-bayern.org/eHumanities	licence	Horizon2020/FAIR/re_useable-re_use/licence		f	0	<div> <i> <b>EC Guidance:</b> The <a href="https://b2share.eudat.eu/" target="_blank">EUDAT B2SHARE</a> tool includes a built-in license wizard that facilitates the selection of an adequate license\n\t\t\tfor research data. </i> </div> Additional information on licenses can be found here:<a href="https://choosealicense.com/" target="_blank">"Choose a License"</a> and <a href="https://creativecommons.org/choose/"\n\t\t\ttarget="_blank">creativecommons.org</a>. For more advice on licenses in general and their implications for your research data you can contact the <a target="_blank" href="KONTAKTSTELLE_LINK">KONTAKTSTELLE_NAME_ENG</a>. <br\n\t\t\t/><br />\n\t\t	<div> <i> <b>EC Guidance:</b> Das <a href="https://b2share.eudat.eu/" target="_blank">EUDAT B2SHARE</a> Tool umfasst einen eingebauten Lizenz-Wizard, der es erleichtert eine passende Lizenz für\n\t\t\teinen Datensatz zu finden. </i> </div> <br /> Weitere Hilfen für die Auswahl einer Lizenz finden Sie hier: <a href="https://choosealicense.com/" target="_blank">"Choose a License"</a> und <a\n\t\t\thref="https://creativecommons.org/choose/" target="_blank">creativecommons.org</a>. <br /><br /> Für Beratung zu Lizenzen und deren Auswirkungen auf Forschungsdaten wenden Sie sich gerne jederzeit an: <a target="_blank"\n\t\t\thref="KONTAKTSTELLE_LINK">KONTAKTSTELLE_NAME_DEU</a> . <br /><br /> Beachten Sie, dass die einzigen Creative Commons Lizenzen, die vollständig mit offenen Daten im Sinne des EU Open Data Pilot kompatibel sind, CC0 oder CC BY 4.0\n\t\t\tsind. Die "No Derivatives (ND)" und "Non-Commercial (NC)" Klauseln schränken die Nachnutzung bereits deutlich ein.	How will the data be licensed to permit the widest re-use possible?	Unter welcher Lizenz wird der Datensatz stehen, um eine möglichst weitreichende Nachnutzung zu ermöglichen?	textarea	text		126	153	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
305	2020-04-14 15:00:02.201+00	2020-04-14 15:00:02.201+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/legal-and-ethics/sensitive-data-personal_data_yesno/yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	yesno	edu_dfg/legal-and-ethics/sensitive-data-personal_data_yesno/yesno		f	1	The EU General Data Protection Regulation (GDPR) defines in Art. 4 personal data as "any information relating to an identified or identifiable natural person". An identifiable natural person is "one who can be identified, directly or indirectly, in particular by reference to an identifier such as a name, an identification number, location data, an online identifier or to one or more factors specific to the physical, physiological, genetic, mental, economic, cultural or social identity of that natural person".	Die EU Datenschutz-Grundverordnung (DSGVO) definiert in Art. 4 personenbezogene Daten als "alle Informationen, die sich auf eine identifizierte oder identifizierbare natürliche Person beziehen". Als identifizierbar wird "eine natürliche Person angesehen, die direkt oder indirekt, insbesondere mittels Zuordnung zu einer Kennung wie einem Namen, zu einer Kennnummer, zu Standortdaten, zu einer Online-Kennung oder zu einem oder mehreren besonderen Merkmalen identifiziert werden kann, die Ausdruck der physischen, physiologischen, genetischen, psychischen, wirtschaftlichen, kulturellen oder sozialen Identität dieser natürlichen Person sind".	Does this dataset contain personal data?	Enthält dieser Datensatz personenbezogene Daten?	yesno	boolean		120	127	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
306	2020-04-14 15:00:02.257+00	2020-04-14 15:00:02.257+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/duration	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	duration	edu_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/duration		f	3	\N	\N	How long will the data be stored?	Wie lange müssen die Daten aufbewahrt werden?	text	text		96	128	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
307	2020-04-14 15:00:02.304+00	2020-04-14 15:00:02.304+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/embargo_period	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	embargo_period	edu_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/embargo_period		f	8	An embargo period is an exclusion period for subsequent use by third parties. The memorandum of the review board "Educational Science" of the DFG <a href = "https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target = _ blank ">"Bereitstellung und Nutzung quantitativer Forschungsdaten in der Bildungsforschung" (in German)</a> states the following: \n\n<i>Internationally, the standard seems to be the expectation that the transfer of the complete data set of a study takes place about 2 years after the collection of the data (or after transfer of the data records to the primary scientists by a commissioned survey institute). For longer-term longitudinal surveys this period refers to the respective survey wave. In well-founded exceptions, which may relate above all to unreasonable hardships for junior researchers, it should be possible to extend the deadline. However, this should never exceed 3 to 4 years.\n\nAdditionally, it should be possible to block the subsequent use of data which are still being processed in the context of qualification work for a period of generally 12 months.</i>	Eine Sperrfrist ist eine Ausschlussfrist für die Nachnutzung durch Dritte. Im Memorandum des Fachkollegiums „Erziehungswissenschaft“ der DFG <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf" target=_blank">"Bereitstellung und Nutzung quantitativer Forschungsdaten in der Bildungsforschung"</a> heißt es dazu:\n\n<i>International scheint sich als Standard die Erwartung zu etablieren, wonach die Übergabe des Gesamtdatensatzes einer Studie  etwa 2 Jahre nach Erhebung der Daten (bzw. nach Übergabe der Datensätze an die Primärwissenschaftlerinnen und –wissenschaftler durch ein beauftragtes Erhebungsinstitut) erfolgt. Bei längerfristigen Längsschnitterhebungen bezieht sich diese Frist auf die  jeweilige Erhebungswelle.  In gut begründeten Ausnahmen, die sich vor allem auf unzumutbare Härten für Nachwuchswissenschaftlerinnen und Nachwuchswissenschaftler beziehen können, sollte es möglich sein, die Frist zu verlängern.  Diese sollte jedoch in keinem Fall 3 bis 4 Jahre überschreiten.\n\nDarüber hinaus sollte es möglich sein, für den Zeitraum von in der Regel 12 Monaten die Nachnutzung von Daten zur Bearbeitung von solchen Forschungsfragen zu sperren, die zu dem Zeitpunkt noch im Rahmen von Qualifikationsarbeiten bearbeitet werden (dies sehen z.B. die Regelungen des FDZ am IQB vor).</i>	Shall there be an embargo period before the data are made available? If yes, why? How long should the embargo period be?	Sollen die Daten erst nach Ablauf einer Sperrfrist zugänglich gemacht werden? Falls ja, warum? Wie lang soll die Sperrfrist sein?	textarea	text		97	128	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
308	2020-04-14 15:00:02.416+00	2020-04-14 15:00:02.416+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/purpose	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	purpose	edu_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/purpose		t	2	\N	\N	What are the reasons this dataset has to be preserved for the long-term?	Aus welchen Gründen müssen die Daten langfristig aufbewahrt werden?	checkbox	text		98	128	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
309	2020-04-14 15:00:02.487+00	2020-04-14 15:00:02.487+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/repository	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	repository	edu_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/repository		t	5	\N	\N	Where will the data (including metadata, documentation and, if applicable, relevant code) be stored or archived after the end of the project?	Wo werden die Daten (einschließlich Metadaten, Dokumentation und ggf. relevantem Code bzw. relevanter Software) nach Projektende gespeichert bzw. archiviert?	checkbox	text		99	128	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
310	2020-04-14 15:00:02.585+00	2020-04-14 15:00:02.585+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	yesno	edu_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/yesno		f	1	\N	\N	Does this dataset have to preserved for the long-term?	Muss dieser Datensatz langfristig aufbewahrt werden?	yesno	boolean		102	128	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
311	2020-04-14 15:00:02.634+00	2020-04-14 15:00:02.635+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/technical-classification/data-formats/format	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	format	edu_dfg/technical-classification/data-formats/format		f	4	When choosing a data format, one should consider the consequences for collaborative use, long-term preservation as well as re-use. It is advisable to prefer formats that are standardised, open, non-proprietary and well-established in the respective scholarly community. A table with recommended file formats can be found in Kristin Briney, <i>Data Management for Researchers</i>, Pelargic, 2015, pages 133-134.	Bei der Wahl des Dateiformates sollten auch die Konsequenzen für die kollaborative Nutzung, die Langzeitarchivierung sowie die Nachnutzung beachtet werden. Es empfiehlt sich, möglichst standardisierte, nicht-proprietäre und allgemein bzw. in der spezifischen Community verbreitete Formate zu nutzen. Weitere Kriterien sowie detaillierte Erläuterungen sind z.B. im <a href="http://nestor.sub.uni-goettingen.de/handbuch/"  target=_blank">nestor Handbuch</a> zu finden.	Which file formats are used?	In welchen Formaten liegen die Daten vor?	textarea	text		62	129	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
371	2020-04-14 15:07:40.867+00	2020-04-14 15:07:40.867+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/re_useable-re_use/publ_date	https://fdm-bayern.org/eHumanities	publ_date	Horizon2020/FAIR/re_useable-re_use/publ_date		f	1	\N	\N	When will the data be made available for re-use?	Wann wird der Datensatz zur Nachnutzung zur Verfügung stehen?	textarea	datetime		53	153	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
380	2020-04-14 15:07:41.397+00	2020-04-14 15:07:41.397+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/costs/data-longtermcost/longterm_cost_other	https://fdm-bayern.org/eHumanities	longterm_cost_other	Horizon2020/costs/data-longtermcost/longterm_cost_other		f	1	Give the costs in **Euro** and consider the project as a whole (not for the individual dataset).	Geben Sie die Kosten in **Euro** an, die im Gesamtprojekt anfallen.	Estimate the non-personnel costs for long-term preservation.	Schätzen Sie die sonstigen Kosten für die Langzeitsicherung.	text	float	Euro	22	156	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
350	2020-04-14 15:07:39.052+00	2020-04-14 15:07:39.052+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/Ethics/general-informed_consent/consents	https://fdm-bayern.org/eHumanities	consents	Horizon2020/Ethics/general-informed_consent/consents		f	0	Basically, the collection, processing, archiving and publication of personal data is only admissible, when the “informed consent” of the person in question has been obtained. There are a few exceptions in which this is not the case\n\t\t\t(see, also for more information: <a href="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_recht.pdf" target=_blank">Informationen zu rechtlichen Aspekten bei\n\t\t\tder Handhabung von Sprachkorpora</a>, p. 6). <br /> The working paper of RatSWD <a target="_blank" href="https://www.ratswd.de/dl/RatSWD_WP_264.pdf">"Die informierte Einwilligung als Voraussetzung für die (Nach-)nutzung von\n\t\t\tForschungsdaten"</a> (in German) discusses informed consent in the context of GDPR and various ethics policies.	Grundsätzlich gilt, dass eine Erhebung, Verarbeitung, Archivierung und Veröffentlichung (sensibler) personenbezogener Daten in den meisten Fällen nur zulässig ist, wenn eine entsprechende „informierte Einwilligung“ der Betroffenen\n\t\t\tvorliegt. Nur in ganz wenigen, jeweils in den Datenschutzgesetzen definierten Ausnahmefällen wird diese nicht benötigt (für weitere Informationen vgl. auch <a\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_recht.pdf" target=_blank">Informationen zu rechtlichen Aspekten bei der Handhabung von\n\t\t\tSprachkorpora</a>, S. 6). <br /> Das Working Paper des RatSWD <a target="_blank" href="https://www.ratswd.de/dl/RatSWD_WP_264.pdf">"Die informierte Einwilligung als Voraussetzung für die (Nach-)nutzung von Forschungsdaten"</a>\n\t\t\tdiskutiert die Einwilligung im Kontext der DS-GVO und der Ethik-Richtlinien verschiedener Fachgesellschaften.	Is informed consent for data sharing and long term preservation included in questionnaires dealing with personal data?	Ist die informierte Einwilligung für Datennachnutzung und Langzeitarchivierung in den Fragebögen zum Umgang mit persönlichen Daten enthalten?	radio	text		115	145	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
351	2020-04-14 15:07:39.16+00	2020-04-14 15:07:39.16+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/Ethics/general-sensitive_data/ethics	https://fdm-bayern.org/eHumanities	ethics	Horizon2020/Ethics/general-sensitive_data/ethics		f	10	\N	\N	Discuss the corresponding ethics and legal issues. These can also be discussed in the context of the ethics review. If relevant, include references to ethics deliverables and ethics chapter in the Description of the Action (DoA).	Diskutieren sie diese ethischen bzw. rechtlichen Belange. Dies kann auch im Zusammenhang mit dem "ethics review" im H2020 Antrag diskutiert werden. Falls dem so ist, geben Sie hier bitte einen Verweis auf das Ethik-Deliverable und das\n\t\t\tentsprechende Ethik-Kapitel im DoA (Description of the Action).	textarea	text		109	146	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
352	2020-04-14 15:07:39.463+00	2020-04-14 15:07:39.463+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/Ethics/general-sensitive_data/yesno	https://fdm-bayern.org/eHumanities	yesno	Horizon2020/Ethics/general-sensitive_data/yesno		f	1	Common legal issues preventing full and/or unrestricted access: <ul> <li>Data privacy and data protection laws prevent unrestricted access (e.g. is informed consent for data sharing and long-term preservation included in\n\t\t\tthe questionnaires?) </li> <li>The data contains copyrighted works, e.g., the project uses text- and data-mining to analyse recent articles in life sciences. The text corpus cannot be made available as copyright laws allow the research,\n\t\t\tbut prohibit making the texts (publicly) available</li> <li>Contractual agreements with the data provider (e.g., a company) prevent free access to the data. </ul> Potential ethics issues: <ul> <li>Persons associated with\n\t\t\tthe personal information in the dataset died a century ago, but the information may negatively affect their descendants. This can, e.g., be relevant if the data points to inheritable genetic disorders.</li> <li>The data contain\n\t\t\tinformation that cannot be associated with an individual person, but may expose a whole group of persons to risks (e.g., the geolocation of a previously undiscovered indigenous tribe).</li> <li>unrestricted access to the data may endanger\n\t\t\tfuture research, e.g, data on archaeological sites may attract pot diggers.</li> </ul>	Rechtliche Gründe für eingeschränkten Zugang zu Daten: <ul> <li> Datenschutz und Persönlichkeitsrechte (z.B. wird die informierte Einwilligung zur Weitergabe und Langzeitarchivierung der Daten mit den Fragebögen\n\t\t\teingeholt?)</li> <li> Urheberrechte; So kann zum Zweck der Forschung ggf. ein Text-Korpus aktueller Artikel in den Lebenswissenschaften für Text- und Datenmining angelegt werden, aber dieser nicht einfach anderen zugänglich gemacht\n\t\t\twerden. </ul> Ethische Schranken können notwendig sein, wenn beispielsweise <ul> <li>Daten zu lange verstorbenen Personen negative Auswirkungen auf die Nachkommen haben können</li> <li>die Daten keine Rückschlüsse auf\n\t\t\teinzelne Personen zulassen, aber Auswirkungen auf eine Gruppe haben können (z.B. Geokoordinaten eines bislang unentdeckten Stammes von Ureinwohnern)</li> <li>uneingeschränkter Zugang weitere Forschung bzw. den Forschungsgegenstand\n\t\t\tgefährden kann (z.B. wenn die Beschreibung einer archäologischen Fundstelle Raubgrabungen auslösen könnte)</li> </ul>	Are there any ethical or legal issues that can have an impact on data sharing?	Gibt es ethische oder rechtliche Vorgaben oder Belange, die Einfluss auf das Teilen der Daten haben können?	yesno	boolean		110	146	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
353	2020-04-14 15:07:39.51+00	2020-04-14 15:07:39.51+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/FAIR_info-FAIRness/dummy	https://fdm-bayern.org/eHumanities	dummy	Horizon2020/FAIR/FAIR_info-FAIRness/dummy		f	0	\N	\N	Choose "yes" to continue:	Wählen sie "Ja" um fortzufahren:	yesno	boolean		228	147	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
354	2020-04-14 15:07:39.549+00	2020-04-14 15:07:39.549+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/Findable-accessibleMetadataProvision/dsicoverability	https://fdm-bayern.org/eHumanities	dsicoverability	Horizon2020/FAIR/Findable-accessibleMetadataProvision/dsicoverability		f	0	The Horizon 2020 data questionnaire is somewhat repetitive when it comes to metadata. You should point out if and how you will create metadata. You should also mention if the metadata are created manually, semi-automatically or\n\t\t\tautomatically (e.g. the observation tool automatically records GPS coordinates and time). Also discuss if the metadata is / will be freely available online, that is, if the metadata can be accessed and understood by machines (such as web crawlers of\n\t\t\tsearch engines). Note that even if access to your data has to be restricted (the topic of the next section), freely available and descriptive metadata are key to informing the scientific community of the existence of the dataset. Therefore, FAIR\n\t\t\tmetadata should always be freely available.	Der Horizon 2020 Datenfragebogen wiederholt sich geringfügig was Metadaten angeht. Sie sollten darauf hinweisen, ob und wie Sie Metadaten erfassen. Sie sollten auch erwähnen welche Daten automatisch (z.B. das Messgerät zeichnet bei\n\t\t\tErstellen der Datei die GPS-Koordinaten mit auf und hinterlegt sie in den Metadaten der Datei), semi-automatisch oder manuell erhoben werden. Ebenfalls sollte diskutiert werden, ob die Metadaten frei online zugänglich sind. Dies ist wichtig damit die\n\t\t\tMetadaten von (Such-)Maschinen verstanden und indexiert werden können. <br /> Selbst wenn die Daten selbst nicht frei verfügbar sein können/sollen, sind freie, beschreibende Metadaten entscheidend dafür, dass die wissenschaftliche Community von\n\t\t\tder Existenz des Datensatzes erfahren kann. FAIRe Metadaten sind daher immer frei zugänglich.	Are the data produced and / or used in the project discoverable with metadata?	Können die Daten, die in dem Projekt erhoben und / oder benutzt werden, mit Hilfe der Metadaten gefunden werden?	textarea	text		230	148	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
355	2020-04-14 15:07:39.593+00	2020-04-14 15:07:39.593+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/Findable-findable_detail/keywords	https://fdm-bayern.org/eHumanities	keywords	Horizon2020/FAIR/Findable-findable_detail/keywords		f	2	Keywords can be included in most metadata schemas. They provide information regarding the content of the dataset. Since the metadata are freely accessible in many data repositories (even if the data themselves are not), keywords\n\t\t\timprove the findability of the datasets in search engines. <br/> Furthermore it is advantageous to use a controlled vocabulary for the keywords (e.g. the GND, MeSH terms or the Wikidata Q-ID). If you need advice on recommended keyword systems,\n\t\t\tfeel free to contact the <a target="_blank" href="KONTAKTSTELLE_LINK">KONTAKTSTELLE_NAME_ENG</a>. <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc2"> <label for="acc2"> Example answer\n\t\t\t</label> <div class="acc-body"> EXAMPLE_ANSWER_KEYWORD </div> </div> </div>	Schlagwörter können in den meisten Metadatenschemata verwendet werden. Sie stellen Informationen über den Inhalt der Datensätze bereit. Da Metadaten in vielen Datenarchiven/-zentren frei zugänglich sind, sind thematisch passende Daten\n\t\t\tso einfacher mit Hilfe von Suchmaschinen zu finden. <br/> Weiter ist es von Vorteil, wenn ein kontrolliertes, standardisiertes Volabular (z.B. die GND, MeSH terms oder die Wikidata Q-ID) verwendet wird. Falls Sie mehr Informationen zu\n\t\t\tSchlagwort-Systemen benötigen, wenden Sie sich gerne an: <a target="_blank" href="KONTAKTSTELLE_LINK">KONTAKTSTELLE_NAME_DEU</a>. <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc2"> <label\n\t\t\tfor="acc2"> Beispiel-Antwort </label> <div class="acc-body"> BEISPIEL_ANTWORT_SCHLAGWORT </div> </div> </div>	Will search keywords be provided that optimize possibilities for re-use?	Werden für die Beschreibung der Datensätze Schlagwörter verwendet, um die Daten besser (zum Zwecke der Nachnutzung) finden zu können?	textarea	text		231	149	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
361	2020-04-14 15:07:40.046+00	2020-04-14 15:07:40.046+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/accessible-access_to_data/authorize	https://fdm-bayern.org/eHumanities	authorize	Horizon2020/FAIR/accessible-access_to_data/authorize		f	5	If the data is published under a specific license (see also questions on Re-Use of data later in this questionnaire), like a CC0, CC BY or MIT license, the information can be included in the metadata in a standardized way (most data\n\t\t\trepositories do this automatically). More complicated access conditions (e.g. only by request or only after evaluation via a data access commission) can be included in the metadata in free-text form.	Falls die Daten unter einer spezifischen Lizenz (siehe hierzu später auch die Fragen zur Nachnutzbarkeit) stehen, wie eine CC0, CC BY oder MIT Lizenz, kann diese Information in den Metadaten hinterlegt werden und ist damit\n\t\t\tmaschinenlesbar (bei den meisten Daten-Repositorien ist dieser Prozess automatisch). Komplexere Zugangsbedingungen (z.B. nur auf Anfrage oder nur nach Evaluation der Anfrage durch eine Kommission) können als Freitext in den Metadaten hinterlegt\n\t\t\twerden.	Are there well described conditions for access (i.e. a machine readable license)?	Gibt es klar beschriebene Bedingungen für den Zugriff (z.B. eine maschinenlesbare Lizenz)?	textarea	text		55	150	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
356	2020-04-14 15:07:39.64+00	2020-04-14 15:07:39.64+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/Findable-findable_detail/metadata_standards	https://fdm-bayern.org/eHumanities	metadata_standards	Horizon2020/FAIR/Findable-findable_detail/metadata_standards		f	4	Typical metadata that are needed to characterize a dataset may include: creators (names, affiliations, role in the creation process,...), information on (geo)location, content, methodology, creation process, technology, documentation\n\t\t\tof the software necessary to use the data, time (e.g. time span of survey, day of observation, ...), sources, agents and identifiers (DOI, grant numbers, ....). If the project will follow recommendations (e.g., by scholarly societies) which\n\t\t\tinformation should be included in the metadata, you should refer to these. Similarly, if certain metadata formats (a later question will address these in detail) are very well-established and basically the standard in your field, you can already\n\t\t\tmention this here.<br/> The Research Data Alliance provides a <a href="http://rd-alliance.github.io/metadata-directory/" target="_blank">Metadata Standards Directory</a> that can be searched for discipline-specific standards and\n\t\t\tassociated tools.<br/> A tool for creating metadata in the common DataCite XML standard is the <a href="http://dhvlab.gwi.uni-muenchen.de/datacite-generator" target="_blank" >DataCite Metadata Generator</a>.\n\t\t	Häufige Metadaten, die genutzt werden um einen Datensatz zu beschreiben sind: Autoren der Daten (Namen, Affiliation, Aufgabe bei der Datenerhebung, ...), Informationen zur (Geo-)Lokalisierung, zum Inhalt, zur Methodik der Erhebung,\n\t\t\tzur (Mess-)Technik, zur Dokumentation der Software, zu Quellenangaben sowie verwandte Identifikatoren (DOI, DOI der Vorgängerversion,...). Falls das Projekt einheitliche Vorgaben hat (z.B. durch Fachverbände, Forschungsorganisationen), welche\n\t\t\tInformationen in den Metadaten enthalten sein sollen, verlinken Sie auf diese. Falls das Metadatenformat im Fach weit verbreitet ist, kann hier schon darauf hingewiesen werden. Detailfragen zum Metadatenformat kommen später im\n\t\t\tH2020-Fragebogen.<br/> Die Research Data Alliance stellt das <a href="http://rd-alliance.github.io/metadata-directory/" target="_blank">Metadata Standards Directory</a> zur Verfügung. Es kann genutzt werden, um nach Fachstandards\n\t\t\tund passenden (Software-)Werkzeugen zu suchen. Ein Werkzeug zur Erstellung von Metadaten im verbreiteten DataCite-Standard ist der <a href="http://dhvlab.gwi.uni-muenchen.de/datacite-generator" target="_blank"\n\t\t\t>DataCite-Metadatengenerator</a>.\n\t\t	What metadata will be created? Specify standards for metadata creation (if any). If there are no standards in your discipline describe what kind of metadata will be created and how.	Welche Metadaten werden für den Datensatz erzeugt? Geben Sie die Standards für die Erzeugung der Metadaten an. Falls es in Ihrem Bereich noch keine Fachstandards gibt, beschreiben Sie welche Arten von Metadaten verwendet und wie diese erzeugt werden.	textarea	text		75	149	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
357	2020-04-14 15:07:39.707+00	2020-04-14 15:07:39.707+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/Findable-findable_detail/naming	https://fdm-bayern.org/eHumanities	naming	Horizon2020/FAIR/Findable-findable_detail/naming		f	1	You should describe what conventions are used for naming data files (and if applicable folders). A consistent naming scheme allows for a direct identification of potentially relevant files. An example for a detailed naming convention\n\t\t\tis e.g. the rules for <a target="_blank" href="https://pmm.nasa.gov/sites/default/files/document_files/FileNamingConventionForPrecipitationProductsForGPMMissionV1.4.pdf">precipitation measurement missions</a> by NASA. If you have naming\n\t\t\tconventions be sure to archive the documentation along with the dataset.	Ein konsistentes Schema für die Datei-Benennung erleichtert es einzelne Datensätze zu finden. Ein Beispiel für klare Regeln bei der Namensvergabe sind die <a target="_blank"\n\t\t\thref="https://pmm.nasa.gov/sites/default/files/document_files/FileNamingConventionForPrecipitationProductsForGPMMissionV1.4.pdf">Regeln zur Benennung von Niederschlagdaten der NASA</a>. Die Dokumentation der Konventionen sollte immer\n\t\t\tzusammen mit dem Datensatz abgelegt werden.	What naming conventions do you follow?	Welche Konventionen bei der Daten-/Dateibenennung verwenden Sie für den Datensatz?	textarea	text		133	149	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
358	2020-04-14 15:07:39.817+00	2020-04-14 15:07:39.817+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/Findable-findable_detail/pids	https://fdm-bayern.org/eHumanities	pids	Horizon2020/FAIR/Findable-findable_detail/pids		f	0	<div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc1"> <label for="acc1"> Further information on persistent identifiers (PID)</label> <div class="acc-body"> The purpose of\n\t\t\tPersistent Identifiers (PIDs) is to ensure the permanent reference of (in particular) digital objects like online publications and research data. When traditional hyperlinks are used as reference, they point directly to the storage location of the\n\t\t\tdata. However, if the storage location is changed, the link will not work anymore. A PID serves as an intermediary from which requests are directed to the current object location (this is called "resolving" of a PID). The PID stays the same, even if\n\t\t\tthe storage location changes. While a mere hyperlink in this case would lead to nowhere, via the PID the object is still accessible.<br /> You can find more information about the mode of operation, usage and different kinds of PIDs in e.g. an\n\t\t\t<a href="http://training.dasish.eu/training/3/" target="_blank">online tutorial</a> created by the DASISH project or in the <a href="http://www.ands.org.au/guides#identify" target="_blank">information material of the Australian\n\t\t\tNational Data Service (ANDS)</a> (scroll down to "Identifying data and researchers"). </div> </div> </div> The by far most common PID is the DOI, but URN, handle, ARK and PURL are also valid options. If you already plan to use\n\t\t\ta particular repository you can use <a target="_blank" href="https://www.re3data.org">re3data.org</a> to check what PID will be used. If you plan to use the INSTITUTIONAL_REPOSITORY repository for this dataset, you could for example\n\t\t\twrite: <br /> <div> <i>"TEXTforPIDS_H2020"</i></div>	<div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc1"> <label for="acc1"> Weitere Information zu persistenten Identifikatoren (PID)</label> <div class="acc-body"> Persistente\n\t\t\tIdentifikatoren (PIDs) sollen die dauerhafte Referenzierung von (insbesondere) digitalen Objekten wie Publikationen oder Forschungsdaten ermöglichen. Statt - wie i.d.R. bei der Angabe eines Hyperlinks als Referenz der Fall - direkt auf den\n\t\t\tSpeicherort des Objektes zu verweisen, fungiert die PID als eine Zwischeninstanz, von der aus zum Objekt weitergeleitet wird (dies nennt man „Auflösen“ der PID). Die PID bleibt gleich, auch wenn sich der Speicherort des Objektes ändert. Während ein\n\t\t\tbloßer Hyperlink in diesem Fall ins Nichts führen würde, ist das Objekt über die PID weiterhin erreichbar. <br /> Mehr Informationen zur Funktionsweise, Verwendung und verschiedenen Arten von PIDs gibt es z.B. in einem vom Projekt DASISH\n\t\t\terstellten <a href="http://training.dasish.eu/training/3/" target="_blank">Online-Tutorial</a> oder in den <a href="http://www.ands.org.au/guides#identify" target="_blank">Informationsmaterialien des Australian National Data Service\n\t\t\t(ANDS)</a> (nach unten scrollen zu "Identifying data and researchers"). </div> </div> </div> Der bei Weitem gebräuchlichste PID ist die DOI, aber URN, handle, ARK und PURL erfüllen den gleichen Zweck. Falls bereits geplant\n\t\t\tist, ein bestimmtes Repositorium/Datenzentrum für die Publikation der (Meta-)Daten zu nutzen, kann mittels <a target="_blank" href="https://www.re3data.org">re3data.org</a> geprüft werden welcher PID dort unterstützt wird. Falls Sie\n\t\t\tbeabsichtigen das ISTITUTIONELLES_REPOS Repositorium zu verwenden, könnten Sie beispielsweise schreiben: <br /> <div> <i>"TEXTfuerPIDS_H2020"</i></div>	Outline the identifiability of data and refer to standard identification mechanisms. Do you make use of persistent and unique identifiers, such as Digital Object Identifiers (DOI), to make sure the data can be identified and located?	Beschreiben Sie wie der Datensatz identifizierbar und lokalisierbar gemacht wird. Welches Identifikationssystem wird verwendet? Werden persistente Identifikatoren, wie die sogenannten Digital Object Identifier (DOI), verwendet?	textarea	text		90	149	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
359	2020-04-14 15:07:39.929+00	2020-04-14 15:07:39.929+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/Findable-findable_detail/versioning	https://fdm-bayern.org/eHumanities	versioning	Horizon2020/FAIR/Findable-findable_detail/versioning		f	3	Please briefly describe the project-internal regulations for the versioning of datasets (e.g.: What kind of changes require a new version? How are changes documented? What are the naming rules for different versions?) If automatic\n\t\t\tversion control tools are used, such as Git, Subversion, SCCS or Mercurial, you should briefly describe how the tool is utilized. Since the section deals with "find-able data", you could also mention if previous versions of the dataset are also\n\t\t\treferenced to in the data/metadata themselves (e.g., the DataCite metadata scheme provides fields for this information). Especially for software <a href="https://semver.org/" target="_blank" >semantic versioning</a> can be advantageous.	Beschreiben Sie die projektinternen Regelungen zur Datenversionierung. Leitfragen können sein: Welche Änderungen erfordern eine neue Version? Wie wird die Version in den Datei-Namen kenntlich gemacht? <br/> Falls automatische\n\t\t\tVersionskontrollsoftware verwendet wird, wie etwa Git, Subversion, SCCS oder Mercurial, sollten Sie kurz darauf eingehen, wie das Werkzeug genutzt wird. Da sich dieser Abschnitt mit "findbaren Daten" befasst, kann hier auch darauf eingegangen werde,\n\t\t\twie/ob ältere Versionen in den Metadaten referenziert werden (das DataCite-Schema ermöglicht dies beispielsweise). Besonders für Software kann gegebenenfalls <a href="https://semver.org/" target="_blank" >Semantic Versioning</a> sinnvoll\n\t\t\tsein.\n\t\t	Outline the approach to clear versioning. Do you provide clear version numbers?	Beschreiben Sie das Vorgehen bei der Versionierung des Datensatzes. Werden eindeutige Versionsnummern vergeben?	textarea	text		145	149	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
360	2020-04-14 15:07:39.98+00	2020-04-14 15:07:39.98+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/accessible-access_to_data/arrangements	https://fdm-bayern.org/eHumanities	arrangements	Horizon2020/FAIR/accessible-access_to_data/arrangements		f	3	Some repositories have specific requirements for metadata schema, data format (e.g. GESIS datorium) and maximal file size.<br /> By clarifying these requirements early on redundant work, e.g., changing data formats or an\n\t\t\tadditional metadata schema, can be avoided.	Einige Repositorien haben spezielle Anforderungen an Metadaten, Datenformate (z.B. GESIS datorium) oder Dateigrößen.<br /> Indem diese Anforderungen rechtzeitig abgeklärt werden, kann später unnötig Arbeit, etwa durch ein\n\t\t\tnotwendiges zweites Metadatenschema oder das Umformatieren der Daten, vermieden werden.	Have you explored appropriate arrangements with the identified repository?	Wurden bereits Vereinbarungen mit einem Repositorium getroffen?	yesno	boolean		100	150	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
362	2020-04-14 15:07:40.105+00	2020-04-14 15:07:40.105+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/accessible-access_to_data/deposit	https://fdm-bayern.org/eHumanities	deposit	Horizon2020/FAIR/accessible-access_to_data/deposit		f	2	<div><i><b>EC Guidance:</b><br /> For example by deposition in a repository. The <a href="https://www.re3data.org" target="_blank">Registry of Research Data Repositories</a> provides a listing\n\t\t\tof repositories that you can search to find a place of deposit. <br /> If you plan to deposit in a repository, it is useful to explore appropriate arrangements with the identified repository in advance. </i> </div> <div\n\t\t\tclass="akkordeon"> <div> <input type="checkbox" name="acc" id="acc1"> <label for="acc1"> Examples of Repositories and general information</label> <div class="acc-body"> <div class="akkordeon"> <div>\n\t\t\t<input type="checkbox" name="acc" id="acc10"> <label for="acc10">General Information and Repositories </label> <div class="acc-body"> Criteria for selection a repository: <ul> <li> Has access to the data be\n\t\t\trestricted? Almost all repositories offer the option to publish the datasets. However, it can be necessary to make the data available only after an embargo period (e.g. one year) or only make the metadata public and keep the data themselves hidden in\n\t\t\ta dark archive. In the latter case information on the datasets can be found during research, access is only possible after authorization by the author of the data. Not all repositories have this option.</li> <li> The repository must\n\t\t\tassign persistent identifiers to each publicly available dataset. Thus the data is citable and findable.</li> <li> The repository must have a long-term strategy for secure data storage. Otherwise technical difficulties can lead to loss of\n\t\t\tdata. Repositories that fulfil corresponding standards often have the Data Seal of Approval. </li> <li> The repository should offer several license options, e.g. the CC licenses.</li> <li> The maximal data volume and costs for\n\t\t\tstorage.</li> <li> The majority of these criteria can be checked using re3data.org.</li> </ul> In general a place where you would look for data is a good place to publish yours.<br /><br /> Several larger data\n\t\t\trepositories: <ul> <li>The UNIVERSITY_LONG provides access to <a target="_blank" href="INST_RESPOS_LINK">ISTITUTIONELLES_REPOS</a>, a multi-disciplinary repository. IST_RESPOS_FEATURE </li> <li><a\n\t\t\ttarget="_blank" href="https://zenodo.org/">Zenodo</a> a free data archive funded by the European Commission, OpernAIRE and CERN. Datasets larger than 50GB have to be cleared by Zenodo.</li> <li><a target="_blank"\n\t\t\thref="https://www.eudat.eu/services/b2safe">B2SAFE</a> and <a target="_blank" href="https://www.eudat.eu/services/b2share">B2SHARE</a> are services of the EU project <a target="_blank"\n\t\t\thref="https://www.eudat.eu/">EUDAT</a> – funded via Horizon 2020 and the EU FP7 program. </li> </ul> Note that some research funders (e.g. the SNF) insist on publications in non-commercial repository. Thus, commercial\n\t\t\trepositories can be unsuitable. </div> </div> </div> <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc11"> <label for="acc11">Philologies / Literary Studies</label> <div\n\t\t\tclass="acc-body"> A selection of repositories for philologies and literary studies: <ul> <li>Clarin-D data Centres are available for language research in the broadest sense. CLARIN-D has its own <a target="_blank"\n\t\t\thref="https://www.clarin-d.net/de/aufbereiten/clarin-zentrum-finden">online guide</a> to find a suitable centre. </li> <li><a target="_blank" href="https://textgrid.de/">TextGrid</a> runs an associated <a\n\t\t\ttarget="_blank" href="https://textgridrep.org/">data repository</a>. Text-based data should be provided in XML/TEI.</li> <li>The BMBF-funded Dariah-DE provides a <a target="_blank"\n\t\t\thref="https://de.dariah.eu/archivieren">free repository</a> (for datasets larger than 50GB please contact Dariah before submitting the data). The focus lies on data from humanities and cultural sciences. Individual datasets can be loaded\n\t\t\tinto collections, where can be prepared for data publication using a minimal metadata set.</li> <li>Some Special Information Services (Fachinformationsdienste, FID) run repositories or provide discipline-specific guides. See <a\n\t\t\ttarget="_blank" href="https://www.fid-romanistik.de/forschungsdaten/">fid-romanistik.de</a> for an example.</li> <li><a target="_blank" href="http://www.laudatio-repository.org/repository/">LAUDATIO</a> (Long-term\n\t\t\tAccess and Usage of Deeply Annotated Information) - a repository for historic corpus linguistics.</li> </ul> <a target="_blank" href="http://www.re3data.org/">re3data.org</a> can be utilized to search for repositories that\n\t\t\tcomply with specific requirements or a dedicated to a specific research area. </div> </div> </div> <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc12"> <label for="acc12">Social\n\t\t\tSciences </label> <div class="acc-body"> There are numerous data centres and repositories for social and economic sciences, for example: <ul> <li><a target="_blank"\n\t\t\thref="https://datorium.gesis.org/xmlui/">datorium</a>, the GESIS repository, one of the most prominent data centres in Germany. GESIS offers various <a target="_blank" href="https://www.gesis.org/datenservices/home/">additional\n\t\t\tservices</a> for researchers, e.g. in the areas quality control, publication or data organization. </li> <li><a target="_blank" href="http://www.qualiservice.org/">Qualiservice</a> serves as repository for the empirical\n\t\t\tsocial sciences. Qualiservice cooperates with Pangaea, a central data center for environmental and earth sciences.</li> <li>Das <a target="_blank" href="https://www.dipf.de/de/dipf-aktuell">Deutsche Institut für Internationale\n\t\t\tPädagogische Forschung (DIPF)</a> operates <a target="_blank" href="https://www.forschungsdaten-bildung.de/>forschungsdaten-bildung.de</a>, a service and publication platform. DIPF offers advanced services, e.g., data curation, that\n\t\t\tnormally are not provided by generic data repositories.</li> <li><a target="_blank" href="http://www.uni-bielefeld.de/(en)/dsz-bo/">Data Service Center for Business and Organizational Data (DSZ-BO)</a> </li>\n\t\t\t<li><a target="_blank" href="https://www.ratswd.de/forschungsdaten/fdi-ausschuss">RatSWD</a> lists several <a target="_blank" href="https://www.ratswd.de/forschungsdaten/fdz">accredited data centres</a> for social,\n\t\t\tbehavioural and economic sciences.</li> </ul> </div> </div> </div> <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc13"> <label for="acc13">Psychology / Educational\n\t\t\tSciences</label> <div class="acc-body"> <ul> <li>Das <a target="_blank" href="https://www.dipf.de/de/forschung/forschungsdaten">Deutsche Institut für Internationale Pädagogische Forschung (DIPF)</a> offers <a\n\t\t\ttarget="_blank" href="https://www.fdz-bildung.de/daten-teilen?la=de">several data services </a>, z.B. <a target="_blank" href="https://www.fdz-bildung.de/datenkuratierung">data curation</a>. </li> <li><a\n\t\t\ttarget="_blank" href="https://www.psychdata.de/">PsychData</a> a platform of the "Leibniz-Zentrum für Psychologische Information und Dokumentation (ZPID)" for archiving, documenting and exchange of research data.</li> <li>GESIS\n\t\t\truns <a target="_blank" href="https://datorium.gesis.org/xmlui/">datorium</a> - a data centre for (quantitative) social and economic sciences. GESIS <a target="_blank"\n\t\t\thref="https://www.gesis.org/datenservices/home/">supports</a> researchers by offering - among other services - quality control and publication assistance. </li> <li><a target="_blank"\n\t\t\thref="http://www.qualiservice.org/">Qualiservice</a> is a data centre for empirical research data (predominantly for social sciences). </li> <li><a target="_blank" href="https://de.dariah.eu/repository">Dariah-DE</a>\n\t\t\tprovides access to a free data repository for humanities and cultural sciences. It is recommended to contact Daria before submitting datasets larger than 50GB. </li> </ul> </div> </div> </div> <div\n\t\t\tclass="akkordeon"> <div> <input type="checkbox" name="acc" id="acc14"> <label for="acc14">History / History of Arts / Archaeology </label> <div class="acc-body"> <ul> <li><a target="_blank"\n\t\t\thref="http://www.ianus-fdz.de/">IANUS</a> - the data centre for archaeology, classical and ancient studies and history - offers support for archiving and publication of research data.</li> <li><a target="_blank"\n\t\t\thref="http://www.arthistoricum.net/">arthistoricum.net</a> is the Special information Service for history of art and operates a publication service. </li> <li><a target="_blank"\n\t\t\thref="https://www.propylaeum.de/publizieren/forschungsdaten/">Propylaeum</a> (Special Information Service for Classical and Ancient Studies) provides access to the repository of the University Heidelberg. <li><a target="_blank"\n\t\t\thref="https://de.dariah.eu/repository">Dariah-DE</a> provides a free repository. Please contact Dariah if you want to archive/publish datasets larger than 50GB.</li> <li>The various Clarin-D data centres address research "about\n\t\t\tlanguage" in the broadest sense. CLARIN-D provides an <a target="_blank" href="https:/www.clarin-d.net/de/aufbereiten/clarin-zentrum-finden"> online tool</a>, for finding a suitable data centre. <li><a target="_blank"\n\t\t\thref="https://opencontext.org/">Open Context</a> is a data publication platform for archaeology and history. Open Context is not free. However, the platform offers support for data cleaning and curation.</li> <li>Material\n\t\t\tassociated with publications of the <a target="_blank" href="https://www.dainst.org/publikationen/e-publikationen">Deutsche Archäologische Institut (DAI)</a> can be made available via DAI.</li> <li><a target="_blank"\n\t\t\thref="http://www.archaeologydataservice.ac.uk/">ads (archaeology data service)</a> - an archaeological data service </li> <li><a target="_blank" href="https://www.tdar.org/">the Digital Archaeological Record\n\t\t\t(tDAR)</a> </li> </ul> </div> </div> </div> </div> </div> </div> You can check if the repository of choice is certified (data seal of approval, etc.) via <a target="_blank"\n\t\t\thref="https://www.re3data.org">re3data.org</a>.	Beispielsweise durch Ablage der Daten in einem Repositorium. Das <a href="https://www.re3data.org" target="_blank">Registry of Research Data Repositories</a> kuratiert eine Liste mit Repositorien, die für die Recherche\n\t\t\tgenutzt werden kann. <br /> Falls Sie beabsichtigen ein bestimmtes Repositorium zu nutzen, ist es hilfreich rechtzeitig entsprechende Verabredungen mit dem Repositorium zu treffen. </i> </div> <div class="akkordeon">\n\t\t\t<div> <input type="checkbox" name="acc" id="acc1"> <label for="acc1"> Verschiedene Repositorien und Datenarchive</label> <div class="acc-body"> <div class="akkordeon"> <div> <input type="checkbox"\n\t\t\tname="acc" id="acc10"> <label for="acc10">Allgemeine Informationen und Repositorien </label> <div class="acc-body"> Wichtige Kriterien bei der Wahl eines Repositoriums: <ul> <li>Muss der Zugang zu den Daten beschränkt\n\t\t\twerden? Praktisch alle Repositorien und Datenarchive bieten die Möglichkeit, Datensätze für alle frei zu geben. Allerdings kann es geboten sein die Daten erst nach Ablauf einer Embargofrist (z.B. 1 Jahr) zugänglich zu machen oder nur die Metadaten zu\n\t\t\tpublizieren. In letztem Fall sind dann die Daten zwar beim Recherchieren zu finden, Zugriff kann aber erst nach Autorisierung durch den Autor erfolgen. Nicht alle Repositorien bieten diese Optionen.</li> <li> Das Repositorium muss für\n\t\t\tjeden Datensatz, der nach außen sichtbar ist, einen persistenten Identifikator vergeben. Der Identifikator stellt sicher, dass der Datensatz langfristig zitier- und auffindbar ist. Der bekannteste persistente Identifikator ist die DOI.</li>\n\t\t\t<li> Das Repositorium sollte eine Strategie zur langfristigen Sicherung der Daten haben, um sicherzugehen, dass die Daten nicht durch technische Störungen zerstört werden. Repositorien die entsprechende Standards erfüllen, haben oft das Data\n\t\t\tSeal of Approval. </li> <li> Das Repositorium sollte eine Auswahl an urheberrechtlichen Lizenzen anbieten; beispielsweise die CC Lizenzen.</li> <li> Das maximale Datenvolumen und ggf. die Kosten für Archivierung oder\n\t\t\tPublikation der Daten.</li> <li> Die meisten der Kriterien können mit Hilfe von re3data.org, einer Datenbank mit Datenrepositorien, geprüft werden.</li> </ul> Im Allgemeinen ist eine Plattform auf der Sie selbst nach Daten\n\t\t\tsuchen ein guter Ort, um Daten zu veröffentlichen.<br /><br /> Einige größere allgemeine Datenrepositorien: <ul> <li>Die UNIVERSITÄT_LANG ermöglicht Zugang zu dem Repositorium <a target="_blank" href="INST_RESPOS_LINK">\n\t\t\tISTITUTIONELLES_REPOS</a>. IST_RESPOS_BESCHREIBUNG </li> <li><a target="_blank" href="https://zenodo.org/">Zenodo</a> ist ein kostenfreies Datenarchiv, das von der Europäischen Kommission, OpernAIRE und CERN betrieben\n\t\t\tbzw. finanziert wird. Datensätze über 50 GB müssen aber erst von Zenodo zur Archivierung freigegeben werden.</li> <li><a target="_blank" href="https://www.eudat.eu/services/b2safe">B2SAFE</a> und <a target="_blank"\n\t\t\thref="https://www.eudat.eu/services/b2share">B2SHARE</a> sind Dienstleistungen des EU Projektes <a target="_blank" href="https://www.eudat.eu/">EUDAT</a> – finanziert via Horizont 2020 und dem EU FP7 Programm. </li>\n\t\t\t</ul> Beachten Sie, dass einige Forschungsförderer (z.B. der SNF) auf Publikationen in nicht-kommerziellen Repositorien bestehen. Daher können kommerzielle Repositorien, wie etwa <a target="_blank"\n\t\t\thref="http://www.figshare.com/">figshare</a>, ungeeignet sein. </div> </div> </div> <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc11"> <label\n\t\t\tfor="acc11">Sprach-/Literaturwissenschaften </label> <div class="acc-body"> Eine Auswahl von Repositorien der Linguistik und Sprachwissenschaft: <ul> <li>Clarin-D Datenzentren stehen für die Forschung “rund um Sprachen” zur\n\t\t\tVerfügung. CLARIN-D hat hierfür einen <a target="_blank" href="https://www.clarin-d.net/de/aufbereiten/clarin-zentrum-finden">eigenen Onlineführer</a> zum richtigen Datenrepositorium. </li <li><a target="_blank"\n\t\t\thref="https://textgrid.de/">TextGrid</a> bietet die Möglichkeit das <a target="_blank" href="https://textgridrep.org/">zugehörige Datenrepositorium</a> zu nutzen. Text-Daten sollten in XML/TEI-Form sein.</li> <li>Das\n\t\t\tBMBF-geförderte Dariah-DE stellt ein <a target="_blank" href="https://de.dariah.eu/archivieren">kostenloses Repositorium</a> (ab einem Datenvolumen über 50GB auf Antrag) mit Schwerpunkt auf den Geistes- und Kulturwissenschaften zur\n\t\t\tVerfügung. Daten können in Sammlungen geladen werden, wo sie mit einem minimalen Satz von Metadaten versehen und von den Forschern und Forscherinnen auf eine Datenpublikation vorbereitet werden können. Dies kann über einen längeren Zeitraum\n\t\t\tgeschehen. Erst wenn die Daten für die Publikation freigegeben wurden, wird eine DOI vergeben, um den Datensatz langfristig zitierbar zu machen.</li> <li>Einige Fachinformationsdienste (FID) verfügen über eigene Repositorien oder\n\t\t\tunterhalten fachspezifische Hilfeseiten. Ein Beispiel hierfür ist <a target="_blank" href="https://www.fid-romanistik.de/forschungsdaten/">fid-romanistik.de</a>.</li> <li><a target="_blank"\n\t\t\thref="http://www.laudatio-repository.org/repository/">LAUDATIO</a> (Long-term Access and Usage of Deeply Annotated Information) - ein Repositorium für die historische Korpuskinguistik.</li> </ul> Für eine Suche nach Repositorien,\n\t\t\tdie bestimmten Anforderungen entsprechen sollen, eignet sich <a target="_blank" href="http://www.re3data.org/">re3data.org</a>. </div> </div> </div> <div class="akkordeon"> <div> <input type="checkbox"\n\t\t\tname="acc" id="acc12"> <label for="acc12">Sozialwissenschaften </label> <div class="acc-body"> In den Sozial- und Wirtschaftswissenschaften gibt es eine Vielzahl von Datenzentren. Unter anderem: <ul> <li><a\n\t\t\ttarget="_blank" href="https://datorium.gesis.org/xmlui/">datorium</a>, das GESIS Datenarchiv, ist eines der bekanntesten Datenzentren in Deutschland. Zur Unterstützung der Wissenschaftler und Wissenschaftlerinnen stellt <a target="_blank"\n\t\t\thref="https://www.gesis.org/datenservices/home/">GESIS zusätzliche Dienstleistungen</a> in den Bereichen Qualitätskontrolle, Publikation und Datenorganisation zur Verfügung. </li> <li><a target="_blank"\n\t\t\thref="http://www.qualiservice.org/">Qualiservice</a> dient als Archiv für qualitative Daten der empirischen Sozialwissenschaften. Dabei kooperiert der Dienst mit Pangaea, dem zentralen Datenzentrum für Umwelt- und\n\t\t\tGeowissenschaften.</li> <li>Das <a target="_blank" href="https://www.dipf.de/de/dipf-aktuell">Deutsche Institut für Internationale Pädagogische Forschung (DIPF)</a> betreibt mit <a target="_blank"\n\t\t\thref="https://www.forschungsdaten-bildung.de/>forschungsdaten-bildung.de</a> eine Service- und Publikationsplattform. Dabei bietet DIPF Dienstleistungen, etwa Kuratieren der archivierten Forschungsdaten, die normalerweise nicht von\n\t\t\tDatenrepositorien geleistet werden. </li> <li><a target="_blank" href="http://www.uni-bielefeld.de/(en)/dsz-bo/">Data Service Center for Business and Organizational Data (DSZ-BO)</a> </li> <li><a target="_blank"\n\t\t\thref="https://www.ratswd.de/forschungsdaten/fdi-ausschuss">RatSWD</a> führt verschiedene <a target="_blank" href="https://www.ratswd.de/forschungsdaten/fdz">akkreditierte Datenzentren</a> für die\n\t\t\tSozial-/Verhaltens-/Wirtschaftswissenschaften</li> </ul> </div> </div> </div> <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc13"> <label\n\t\t\tfor="acc13">Psychologie/Erziehungswissenschaften </label> <div class="acc-body"> <ul> <li>Das <a target="_blank" href="https://www.dipf.de/de/forschung/forschungsdaten">Deutsche Institut für Internationale\n\t\t\tPädagogische Forschung (DIPF)</a> bietet einen <a target="_blank" href="https://www.fdz-bildung.de/daten-teilen?la=de">verschiedene Dienstleitungen</a> rund um Datenarchivierung und -publikation an, z.B. <a target="_blank"\n\t\t\thref="https://www.fdz-bildung.de/datenkuratierung">Datenkuratierung</a>. </li> <li><a target="_blank" href="https://www.psychdata.de/">PsychData</a> eine Plattform des Leibniz-Zentrum für Psychologische Information\n\t\t\tund Dokumentation (ZPID) zum Archivieren, Dokumentieren und Austausch von Daten.</li> <li>GESIS betreibt <a target="_blank" href="https://datorium.gesis.org/xmlui/">datorium</a>, ein Datenarchiv für (quantitative) Sozial- und\n\t\t\tWirtschaftswissenschaften. GESIS <a target="_blank" href="https://www.gesis.org/datenservices/home/">unterstützt</a> dabei Wissenschaftlerinnen und Wissenschaftlern hierbei unter anderem bei Qualitätskontrolle und Publikation der Daten.\n\t\t\t</li> <li><a target="_blank" href="http://www.qualiservice.org/">Qualiservice</a> ist ein Datenzentrum für qualitative, empirische Forschungsdaten. Qualiservice arbeitet hierbei mit Pangaea, ein bedeutendes Datenrepositorium\n\t\t\tfür Umwelt- und Geowissenschaften. </li> <li><a target="_blank" href="https://de.dariah.eu/repository">Dariah-DE</a> stellt ein kostenloses Repositorium für geistes- und kulturwissenschaftliche Forschungsdaten zur Verfügung.\n\t\t\tBei Datensätzen über 50GB bietet es sich an zunächst bei Dariah nachzufragen. </li> </ul> </div> </div> </div> <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc14"> <label\n\t\t\tfor="acc14">Geschichte/Kunstgeschichte/Archäologie </label> <div class="acc-body"> <ul> <li><a target="_blank" href="http://www.ianus-fdz.de/">IANUS</a> - das Datenzentrum für Archäologie,\n\t\t\tAltertumswissenschaften und Geschichte - unterstützt beider Archivierung und Publikation von Forschungsdaten. </li> <li><a target="_blank" href="http://www.arthistoricum.net/">arthistoricum.net</a>, der Fachinformationsdienst\n\t\t\tfür Kunstgeschichte, betreibt einen Datenpublikationsdienst. </li> <li><a target="_blank" href="https://www.propylaeum.de/publizieren/forschungsdaten/">Propylaeum</a>, der Fachinformationsdienst für Altertumswissenschaft\n\t\t\termöglicht es Daten über das Repositorium der Universität Heidelberg zu archivieren und zu publizieren. <li>Das BMBF-geförderte Dariah-DE Projekt stellt ein kostenfreies <a target="_blank"\n\t\t\thref="https://de.dariah.eu/repository">Repositorium</a> zur Verfügung. Bei Datensätzen, die mehr als 50GB benötigen, wird dies jedoch gesondert geprüft. Der Schwerpunkt des Repositoriums liegt auf den Geistes- und Kulturwissenschaften. Die\n\t\t\tDaten können dabei zunächst in sogenannte Sammlungen geladen werden. Dort können sie von den Autoren und Autorinnen bearbeitet und mit minimalen Metadaten versehen werden. Erst nachdem die Entscheidung zur Publikation gefallen ist wird eine DOI\n\t\t\tvergeben und der Datensatz für die Öffentlichkeit sichtbar.</li> <li>Clarin-D Datenzentren betreuen Forscherinnen und Forscher, die im weitesten Sinne mit „mit Sprache“ arbeiten. CLARIN-D verfügt über einen <a target="_blank"\n\t\t\thref="https:/www.clarin-d.net/de/aufbereiten/clarin-zentrum-finden">eigenen Online-Ratgeber</a>, um ein geeignetes Datenzentrum. <li><a target="_blank" href="https://opencontext.org/">Open Context</a> ist eine\n\t\t\tDatenpublikationsplattform im Bereich Archäologie und Geschichte. Die Nutzung von Open Context ist nicht kostenfrei, sondern es fallen einmalig Kosten an. Dafür bietet die Plattform auch zusätzliche Unterstützung bei Datenbereinigung und beim\n\t\t\tKuratieren der Daten.</li> <li>Datenmaterial, das zu Publikationen gehört, die das <a target="_blank" href="https://www.dainst.org/publikationen/e-publikationen">Deutsche Archäologische Institut</a> veröffentlicht, können über\n\t\t\tdas Institut zur Verfügung gestellt werden</li> <li><a target="_blank" href="http://www.archaeologydataservice.ac.uk/">ads (archaeology data service)</a> - ein archäologischer Datenservice </li> <li><a\n\t\t\ttarget="_blank" href="https://www.tdar.org/">the Digital Archaeological Record (tDAR)</a> </li> </ul> </div> </div> </div> </div> </div> </div>	Where and how will the data and associated metadata, documentation and code be deposited? Preference should be given to certified repositories which support open access where possible.	Wo und wie werden die Daten, Metadaten, Dokumentationen und Softwarecode abgelegt? Zertifizierte Repositorien, die Open Access unterstützen, sollten hier bevorzugt verwendet werden.	textarea	text		233	150	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
363	2020-04-14 15:07:40.174+00	2020-04-14 15:07:40.174+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/accessible-access_to_data/documention	https://fdm-bayern.org/eHumanities	documention	Horizon2020/FAIR/accessible-access_to_data/documention		f	1	To be able to re-use data (e.g. to replicate studies, for meta-analysis or to solve new research questions), along with the data, the software, equipment and knowledge about special methods to use the data are required. Just as with\n\t\t\tthe formats, the recommendation is: the more standardised, open and established, the better for re-use.	Um die Daten später Nachnutzen zu können (etwa für Replikationsstudien, für Metaanalysen oder um sie für neue Forschungsfragen zu nutzen), werden neben den Daten selbst auch Informationen über Software, verwendete Ausrüstung und\n\t\t\tMethodik benötigt. Genau wie im Fall von Datenformaten gilt: je offener, standardisierter und verbreiteter desto einfacher ist die Nachnutzung.	Specify what methods or software tools are needed to access the data? Is documentation about the software needed to access the data? Is it possible to include the relevant software (e.g. open source code)?	Beschreiben Sie welche Methoden oder Softwarewerkzeuge benötigt werden, um die Daten nutzen zu können. Wird für die Verwendung der Software eine Dokumentation benötigt? Ist es möglich die Software dem Datensatz hinzuzufügen?	textarea	text		144	150	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
364	2020-04-14 15:07:40.22+00	2020-04-14 15:07:40.22+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/accessible-access_to_data/restrictions	https://fdm-bayern.org/eHumanities	restrictions	Horizon2020/FAIR/accessible-access_to_data/restrictions		f	4	There are many common valid restrictions on access to certain datasets, e.g., research ethics, intellectual property rights or sensitive data. The special information service for ethnology (evifa) provides a <a target="_blank"\n\t\t\thref="http://www.evifa.de/cms/fileadmin/uploads/BibTag_2018_Vorlage_A1.pdf">graphic of different access layers</a>.	Es gibt viele berechtigte Einschränkungen für den Zugang zu den Daten; zum Beispiel Forschungsethik, Datenschutz oder Urheberrechte. Der Fachinformationsdienst Sozial- und Kulturanthropologie hat eine übersichtliche <a\n\t\t\ttarget="_blank" href="http://www.evifa.de/cms/fileadmin/uploads/BibTag_2018_Vorlage_A1.pdf">Grafik von möglichen Schranken</a> zusammengestellt.	If there are restrictions, how will access be provided? Is there a need for a data access committee? How will the identity of the person accessing the data be ascertained (if necessary)?	Falls es Einschränkungen beim Zugriff gibt, wie wird der Zugriff durch andere Forscher ermöglicht? Wird eine Datenzugangskommission benötigt? Muss - und wenn ja, wie - die Identität der Person, die auf die Daten zugreift, verifiziert werden?	textarea	text		93	150	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
365	2020-04-14 15:07:40.288+00	2020-04-14 15:07:40.288+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/accessible-dataaccess/accessibility	https://fdm-bayern.org/eHumanities	accessibility	Horizon2020/FAIR/accessible-dataaccess/accessibility		f	0	Note that the European Commission recognizes that not all data can be open:<br/> <div><i> <b>EC-Guidance:</b><br/> Participating in the ORD Pilot does not necessarily mean opening up all your\n\t\t\tresearch data. Rather, the ORD pilot follows the principle "as open as possible, as closed as necessary" and focuses on encouraging sound data management as an essential part of research best practice.<br /> The Commission recognises that there\n\t\t\tare good reasons to keep some or even all research data generated in a project closed. Where data need to be shared under restrictions, explain why, clearly separating legal and contractual reasons from voluntary restrictions.<br /> Note that\n\t\t\tin multi-beneficiary projects it is also possible for specific beneficiaries to keep their data closed if relevant provisions are made in the consortium agreement and are in line with the reasons for opting out.</i> </div> But still all\n\t\t\tdata should follow the FAIR principles. Potential reasons for not making a dataset available could be: <ul> <li> A text corpus cannot be made accessible for copyright reasons. Only storing an archival copy (cp. &sect; 60d (3)\n\t\t\tWissUrhG) via a library (e.g. the university library) is conceivable. </li> <li> The interviewees did not consent to a publication of recordings or transcripts. </li> <li> The dataset cannot be anonymized and data privacy laws\n\t\t\tprohibit a publication in the current form. </li> <li> Research ethics dictates that the data cannot be shared freely without access control. E.g. free access to the data that may indirectly cause harm to the data provider even if no\n\t\t\tindividual could ever be identified. </li> <li> Patent laws may require a delayed data publication. </li> <li>The data could be abused / deliberately be misinterpreted.</li> <li>(Premature) publication may put the\n\t\t\tresearch goals of the project at risk. </li> </ul>	Beachten Sie, dass das H2020 Programm berücksichtigt, dass nicht alle Daten offen (offen wie in Open Data) sein können:<br /> <div><i> <b>EC-Guidance:</b><br /> Participating in the ORD Pilot does\n\t\t\tnot necessarily mean opening up all your research data. Rather, the ORD pilot follows the principle "as open as possible, as closed as necessary" and focuses on encouraging sound data management as an essential part of research best practice.<br\n\t\t\t/> The Commission recognises that there are good reasons to keep some or even all research data generated in a project closed. Where data need to be shared under restrictions, explain why, clearly separating legal and contractual reasons from\n\t\t\tvoluntary restrictions.<br /> Note that in multi-beneficiary projects it is also possible for specific beneficiaries to keep their data closed if relevant provisions are made in the consortium agreement and are in line with the reasons for\n\t\t\topting out.</i> </div> Aber alle Daten sollen den FAIR Prinzipien folgen. Gründe, warum ein Datensatz nicht frei zugänglich sein kann, sind beispielsweise: <ul> <li> Ein Textkorpus kann aufgrund des Urheberrechts nicht\n\t\t\tverbreitet werden. Nur eine Archivkopie (vgl. &sect; 60d (3) WissUrhG) durch die Bibliothek der Forschungseinrichtung ist denkbar. </li> <li> Die Interviewten sind nicht mit einer Publikation der Aufzeichnungen einverstanden.\n\t\t\t</li> <li> Die Daten können nicht anonymisiert werden und das Datenschutzgesetz verhindert in diesem Fall die Verbreitung. </li> <li> Forschungsethische Bedenken verbieten eine unbeschränkten Zugang zu den Daten. Z.B. kann\n\t\t\tfreier Zugang Personen schaden, auch wenn es nicht möglich ist diese zu identifizieren. </li> <li> Patentrechtliche Vorgaben können eine Publikation verzögern. </li> <li>Die Daten können anderweitig missbraucht oder\n\t\t\tabsichtlich missinterpretiert werden.</li> <li>(Frühzeitige) Publikation der Daten kann das Forschungsziel des Projektes gefährden.</li> </ul>	Specify which data will be made openly available? If some data are kept closed, cannot be shared (or only under restrictions) provide the rational for doing so. Separate legal and contractual reasons from voluntary restrictions.	Welche Datesätze werden offen zugänglich sein. Wenn Daten unzugänglich bleiben, nicht oder nur eingeschränkt geteilt werden können, begründen Sie dies. Unterscheiden Sie hier rechtliche und vertragliche Gründe von freiwilligen Beschränkungen.	textarea	text		123	151	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
366	2020-04-14 15:07:40.346+00	2020-04-14 15:07:40.346+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/interoperable-interop/general	https://fdm-bayern.org/eHumanities	general	Horizon2020/FAIR/interoperable-interop/general		f	0	The next question will address metadata standards and ontologies / vocabularies. So we recommend to focus on data and file formats and standards. Consider: Is the file/data structure independent of the operating system? Are there open\n\t\t\tsoftware tool that can be used to utilize the data or are the data formats proprietary? Are the formats commonly used in the scientific community?	Die nächsten Fragen werden Metadatenstandards und Ontologien/Vokabulare behandeln. Deshalb empfehlen wir, sich in dieser Frage auf Daten und Dateiformate zu konzentrieren. Leitfragen: Sind die Daten/Dateistruktur unabhängig vom\n\t\t\tBetriebssystem? Gibt es offene Software, die verwendet werden kann, um die Daten zu lesen und zu bearbeiten? Sind die Formate in der Fachcommunity akzeptiert/verbreitet?	Are the data produced in the project interoperable, that is allowing data exchange and re-use between researchers, institutions, organizations, countries, etc. (i.e. adhering to standards for formats, as much as possible compliant\n\t\t\twith available (open) software applications, and in particular facilitating re-combinations with different datasets from different origins)?	Sind die Daten in dem Datensatz/Projekt dialogfähig (interoperabel)? Ist ein einfacher Datenaustausch und eine Nachnutzung zwischen Forschern, Instituten, Organisationen, usw. möglich? (D.h. die Daten halten sich an (Fach-)Standards\n\t\t\tfür Formate, erfüllen die Anforderungen verbreiteter (offener) Softwareanwendungen und erlauben es insbesondere den Datensatz mit Datensätzen aus anderen Quellen zu kombinieren.)	textarea	option		66	152	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
367	2020-04-14 15:07:40.443+00	2020-04-14 15:07:40.443+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/interoperable-interop/mappings	https://fdm-bayern.org/eHumanities	mappings	Horizon2020/FAIR/interoperable-interop/mappings		f	20	\N	\N	In case it is unavoidable that you use uncommon or generate project-specific ontologies or vocabularies, will you provide mappings to more commonly used ontologies?	Sollte es unvermeidbar sein, projektspezifische oder seltene Ontologien, Metadatenschemata oder Vokabulare zu nutzen, werden Mappings zu gängigen Ontologien etc. erstellt?	textarea	boolean		77	152	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
368	2020-04-14 15:07:40.513+00	2020-04-14 15:07:40.513+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/interoperable-interop/metadata_standard	https://fdm-bayern.org/eHumanities	metadata_standard	Horizon2020/FAIR/interoperable-interop/metadata_standard		t	10	Using established metadata standards/vocabularies/classifications is recommended. More information on standards can be found on the websites of the <a href="http://rd-alliance.github.io/metadata-directory/about/"\n\t\t\ttarget="_blank">Research Data Alliance Metadata Directory</a>. A useful resource for locating vocabularies, thesauri, ontologies and classifications is <a target="_blank" href="http://www.bartoc.org">BARTOC.org</a>. The register\n\t\t\tcan be searched for by subject, DDC or, e.g., language. <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc1"> <label for="acc1"> Some examples of discipline-specific standards</label> <div\n\t\t\tclass="acc-body"> <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc11"> <label for="acc11">Philologies/Literary Studies</label> <div class="acc-body"> <b>Common Metadata\n\t\t\tStandards</b> are: <ul> <li>the XML-based <a target="_blank" href="http://www.tei-c.org/Guidelines/P5/">TEI P5 Standard</a> is common for the semantic make-up of texts, in particular editions.</li> <li> <a\n\t\t\ttarget="_blank" href="http://www.deutschestextarchiv.de/doku/basisformat/">DTA-Basisformat</a> is a special format based on TEI P5 and created by Deutsches Textarchiv. It is recommended for text corpora by <a target="_blank"\n\t\t\thref="https://www.clarin-d.de/de/hilfe/benutzerhandbuch">Clarin</a> and <a target="_blank"\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_sprachkorpora.pdf">DFG</a>.</li> <li><a target="_blank"\n\t\t\thref="http://music-encoding.org/">MEI (Music Encoding Initiative)</a> is a standard for musicology. </li> <li><a target="_blank" href="https://www.loc.gov/standards/mets/">METS</a> / <a target="_blank"\n\t\t\thref="https://www.loc.gov/standards/mods/">MODS</a> form a common pair of metadata standards in libraries. METS/MODS is frequently used for digitized manuscripts / incunabula <li>metadata for the description of manuscripts and codices:\n\t\t\t<a target="_blank" href="http://www.manuscripta-mediaevalia.de/hs/handbuch.pdf">Manuscriptum XML (MXML)</a> </li> <li><a target="_blank" href="https://www.cei.lmu.de/">CEI (Charters Encoding Initiative)</a> – XML\n\t\t\tstandard for (medieval) charters. </li> <li><a target="_blank" href="https://mpeg.chiariglione.org/standards/mpeg-7">MPEG-7 (Multimedia Content Description Interface)</a> for multi-media files. TU Berlin provides a <a\n\t\t\ttarget="_blank" href="http://mpeg7lld.nue.tu-berlin.de/">Tool</a> for this standard. </li> <li>For collections the <a target="_blank" href="https://wiki.de.dariah.eu/pages/viewpage.action?pageId=52728662"> DCDDM (DARIAH\n\t\t\tCollection Description Data Model) </a> developed by the Dariah-DE project can be utilized. </li> </ul> <b>Various Thesauri / Vocabularies / Ontologies:</b><br /> <a target="_blank"\n\t\t\thref="http://oldenglishthesaurus.arts.gla.ac.uk/">A Thesaurus of Old English</a><br /> <a target="_blank" href="http://rbms.info/vocabularies/index.shtml">RBMS Controlled Vocabularies</a>: controlled vocabularies for\n\t\t\tmanuscripts and incunabula<br /> <a target="_blank" href="https:/wiki.bsz-bw.de/doku.php?id=v-team:recherche:ognd:start">GND (Gemeinsame Normdatei)</a> – authority data of the Deutsche Nationalbibliothek for persons, names,\n\t\t\tlocations and terms<br /> <a target="_blank" href="https://www.loc.gov/rr/print/tgm1/index.html">Thesaurus for Graphic Materials (TGM)</a><br /> <a target="_blank" href="https://www.w3.org/TR/owl-features/">OWL Web\n\t\t\tOntology Language</a><br /> Dariah-DE: <ul> <li> <a target="_blank" href="https://github.com/dhtaxonomy/TaDiRAH">TaDiRAH Taxonomie</a> </li> <li> <a target="_blank"\n\t\t\thref="http://nedimah.dcu.gr/index.php?p=navigate">NeDiMAH</a> </li> </ul> </div> </div> </div> <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc12"> <label\n\t\t\tfor="acc12">Social Sciences </label> <div class="acc-body"> The most common metadata standard in social sciences is the <a href="http://www.ddialliance.org/" target="_blank">DDI (Data Documentation Initiative)\n\t\t\tStandard</a>which exists in different versions. Version 3, also called <a href="https://www.ddialliance.org/Specification/DDI-Lifecycle/3.0/" target="_blank">DDI Lifecycle</a>, is more complex and tries to capture the whole data\n\t\t\tlifecycle. Version 2, called <a href="http://www.ddialliance.org/resources/getting-started/v2"target="_blank">DDI Codebook</a> is less complex and can be used for example for standard survey data. Other specialized metadata formats are\n\t\t\tthe <a target="_blank" href="https://sdmx.org/">Statistical Data and Metadata Exchange Standards</a> (e.g. SDMX-ML) and <a traget="_blank" href="http://www.data-archive.ac.uk/curate/standards-tools/metadata?index=2">QuDEx</a>\n\t\t\t(Qualitative Data Exchange Format) Standard for statistical and qualitative data, respectively. <br /> The handbook <a target="_blank"\n\t\t\thref="http://auffinden-zitieren-dokumentieren.de/wp-content/uploads/2015/03/Forschungsdaten_DINA4_ONLINE_VER_02_06.pdf">"Auffinden - Zitieren - Dokumentieren"</a> by GESIS, ZBW and RatSWD, in German) provides information on data\n\t\t\tdocumentation (pages 20-23). See also <a target="_blank" href="https://www.ratswd.de/download/RatSWD_WP_2009/RatSWD_WP_57.pdf">Gregory, Arofan, Pascal Heus und Jostein Ryssevik. 2009. Metadata. RatSWD Working Paper No. 57.</a> <br\n\t\t\t/> Further, <a target="_blank" href="https://www.cessda.eu/">CESSDA</a>, the Consortium of European Social Science Data Archives, provides several short guides, including a <a target="_blank"\n\t\t\thref="https://www.cessda.eu/content/download/241/2391/file/CESSDA User Guide for data management_4_Documentation and metadata.pdf">guide to data documentation</a>. <br /> <b>Some Thesauri / Vocabularies / Ontologies:</b>\n\t\t\t<br /> <a target="_blank" href="http://www.gesis.org/unser-angebot/recherchieren/tools-zur-recherche/thesaurus-sozialwissenschaften/">Thesaurus Sozialwissenschaften (TheSoz)</a> <br /> <a target="_blank"\n\t\t\thref="http://www.infodata-edepot.de/thesaurus/T_SM.HTM">INFODATA Thesaurus</a> <br /> <a target="_blank" href="http://zbw.eu/stw/version/latest/about">Standard Thesaurus Wirtschaft (STW)</a> <br /> <a\n\t\t\ttarget="_blank" href="https://www.ddialliance.org/controlled-vocabularies">DDI Controlled Vocabulary</a> <br /> <b>Some Classifications:</b> <br /> <a target="_blank"\n\t\t\thref="http://www.gesis.org/unser-angebot/recherchieren/tools-zur-recherche/klassifikation-sozialwissenschaften/">Klassifikation Sozialwissenschaften</a> <br /> <a target="_blank" href="www.aeaweb.org/jel/guide/jel.php"> Journal\n\t\t\tof Economic Literature Classification System</a>(JEL) </div> </div> </div> <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc13"> <label for="acc13">Psychology/Educational Sciences\n\t\t\t</label> <div class="acc-body"> <a href="http://www.ddialliance.org/" target="_blank">DDI (Data Documentation Initiative) Standard</a> (which was in part developed by GESIS) is commonly used. Depending on the type of data,\n\t\t\tstandards for life sciences may also be relevant (e.g. for MRI data). A collection of standards can be found at <a target="_blank" href="https://fairsharing.org/standards/">fairsharing.org</a>. <br /> forschungsdaten-bildung.de\n\t\t\tprovides <a target="_blank" href="https://www.forschungsdaten-bildung.de/datenmanagement?la=de">further information on metadata in educational science</a>. <a target="_blank" href="https://www.psychdata.de/">PsychData</a> uses\n\t\t\tits own metadata scheme with a corresponding tool, <a target="_blank" href="https://datawiz.leibniz-psychology.org/DataWiz/">DataWiz</a>. Also, the <a target="_blank" href="https://datawizkb.leibniz-psychology.org/">DataWiz\n\t\t\tKnowledge Base</a> is a good <a target="_blank" href="https://datawizkb.leibniz-psychology.org/index.php/during-data-collection/what-should-i-know-about-metadata/">resource on data documentation</a>. <br /> <b>Some\n\t\t\tThesauri/Vocabularies/Ontologies:</b> <ul> <li><a target="_blank" href="http://www.zpid.de/index.php?wahl=products&uwahl=printed&uuwahl=psyndexterms">Thesaurus Psychologie (PSYNDEX)</a></li> <li><a\n\t\t\ttarget="_blank" href="https://datawizkb.leibniz-psychology.org/index.php/during-data-collection/what-should-i-know-about-controlled-vocabularies/">Controlled Vocabularies in psychology</li> <li><a target="_blank"\n\t\t\thref="https://www.ddialliance.org/controlled-vocabularies">DDI controlled vocabulary</a></li> <li>American Psychological Association’s (APA) <a target="_blank"\n\t\t\thref="https://bioportal.bioontology.org/ontologies/APAONTO">Thesaurus for Psychological Terms</a></li> <li><a target="_blank" href="http://localhost:3000/org/admin/guidance/53/\n\t\t\thttp:/www.infodata-edepot.de/thesaurus/T_SM.HTM">INFODATA Thesaurus</a> (Informationswissenschaften)</li> </ul> <b>Some Classifications:</b> <ul> <li><a\n\t\t\thref="http://www.apa.org/pubs/databases/training/class-codes.aspx" target="_blank">PsycINFO Classification Categories and Codes</a></li> </ul> </div> </div> </div> <div class="akkordeon"> <div>\n\t\t\t<input type="checkbox" name="acc" id="acc14"> <label for="acc14">History/History of Art/Archaeology </label> <div class="acc-body"> <b>A selection of Metadata Standards:</b><br /> <em>Archaeology,\n\t\t\tClassical and Ancient Studies and cultural Heritage:</em> <ul> <li> <a target="_blank" href="http://archives.icom.museum/objectid/heritage/int.html">Core Data Standard for Archaeological Sites and Monuments</a>\n\t\t\t</li> <li> ADeX – a data export format for the description of excavation geometries </li> <li> <a href="http://www.heritage-standards.org.uk/midas-heritage/">MIDAS-Heritage</a> A cultural heritage standard for\n\t\t\trecording information on buildings, archaeological sites, other areas of interest and artifacts. </li> <li> <a target="_blank" href="https://www.loc.gov/ead/">Encoded Archival Description (EAD)</a> - a standard for encoding\n\t\t\tarchival finding aids using XML. </li> <li> The data centre <a href="https:/www.ianus-fdz.de/it-empfehlungen/metadaten-anwendung">IANUS</a> has several recommendations on metadata. </li> <li> ArchaeoML – metadata\n\t\t\tformat for <a target="_blank" href="https://www.opencontext.org/">Open Context</a> </li> <li> Additional information on metadata schemas and vocabularies can be found in the <a target="_blank"\n\t\t\thref="http://www.ariadne-infrastructure.eu/Resources/D3.1-Initial-Report-on-the-project-registry">reports by the ariadne project</a>. </li> </ul> <em>Metadata for Manuscripts:</em> <ul> <li> CEI (Charters\n\t\t\tEncoding Initiative) - a standard for (medieval) charters </li> <li> Manuscriptum XML (MXML) - standard for codicology </li> </ul> <em>General Metadata Standards:</em> <ul> <li> <a target="_blank"\n\t\t\thref="http://www.tei-c.org/index.xml">TEI</a> (Text Encoding Initiative) - a common standard for text corpora, but can be used for textual resources in general. </li> <li> <a target="_blank"\n\t\t\thref="http://www.loc.gov/standards/vracore/">VRA Core</a>- a standard for the description of works of visual culture as well as the images that document them. </li> <li> <a target="_blank"\n\t\t\thref="http://mpeg7.org/mpeg-7-standard/">MPEG-7</a> (Multimedia Content Description Interface) MPEG-7 (Multimedia Content Description Interface) - a standard for the description of multimedia objects. </li> <li> <a\n\t\t\ttarget="_blank" href="https://www.w3.org/TR/prov-overview/">PROV</a> – a metadata format for digital provenience information. </li> <li> <a target="_blank" href="http://www.loc.gov/standards/mods/">MODS (Metadata Object\n\t\t\tDescription Schema)</a>: An XML schema for descriptive metadata compatible with the MARC 21 bibliographic format. </li> </ul> <em> Geospacial Data/Metadata:</em> <ul> <li> <a target="_blank"\n\t\t\thref="https://www.fgdc.gov/metadata/geospatial-metadata-standards">The Content Standard for Digital Geospatial Metadata (CSDGM)</a> </li> <li> <a target="_blank" href="https://www.iso.org/standard/26020.html"\n\t\t\ttarget="_blank">ISO 19115:2003</a> standard for geographic metadata </li> <li> <a target="_blank" href="http://www.opengeospacial.org/standards/gml">Geography Markup Language (GML)</a> </li> </ul>\n\t\t\t<em>Metadata standards for objects:</em> <ul> <li> LIDO - XML harvesting schema for descriptive information about museum objects (works of art, architecture, cultural heritage, ...). </li> <li> EDM (Europeana Data\n\t\t\tModel) - a complex schema for generic objects that can combine other metadata schema and enables the use of entity-relationship models (similar to RDF). </li> <li> NISO - a schema/ISO standard for technical information on digital images\n\t\t\t(scans, photographs,...) </li> </ul> <b>Classifications / Vocabularies / Thesauri / Ontologies</b><br /> <ul><li> <a target="_blank" href="http://www.iconclass.nl/">ICONCLASS</a> – very common and\n\t\t\tdetailed classification system for works of art </li> <li><a target="_blank" href="https://pleiades.stoa.org/">Pleiades</a> provides a schema for ancient locations and corresponding controlled vocabulary.</li>\n\t\t\t<li><a target="_blank" href="http://www.geonames.org/">GeoNames</a> Authority file</li> <li><a target="_blank" href="http://www.getty.edu/research/tools/vocabularies/">Getty Vocabularies</a> (AAT, CONA, ULAN,\n\t\t\tTGN) for art, architecture and bibliographic materials.</li> <li><a target="_blank" href="http://swb.bsz-bw.de/">GND</a> (Gemeinsame Normdatei) – <a href="http://www.dnb.de/DE/Standardisierung/GND/gnd_node.html">\n\t\t\tauthority data of the German National Library</a> for persons, names, locations and keywords </li> <li><a target="_blank" href="https://viaf.org/">VIAF</a> (virtual international authority file) - a combination/virtual\n\t\t\tmerger of various national authority files and vocabularies </li> <li>CIDOC-CRM ontology for concepts in cultural heritage documentation</li> </ul> </div> </div> </div> </div> </div> </div>	Die Verwendung von im Fach etablierten Metadatenstandards/Vokabularen/Klassifikationen ist unbedingt zu empfehlen. Mehr Informationen zu Metadatenstandards kann in den Webseiten des <a\n\t\t\thref="http://rd-alliance.github.io/metadata-directory/about/" target="_blank">Research Data Alliance Metadata Directory</a> gefunden werden. Eine nützliche Quelle für die Suche nach verschiedenen Vokabularen, Thesauri oder Ontologien ist\n\t\t\t<a target="_blank" href="http://www.bartoc.org">BARTOC.org</a>. Das Verzeichnis kann nach fachlichen oder formalen Kriterien gefiltert werden. <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc1">\n\t\t\t<label for="acc1"> Einige Bespiele von fachspezifischen Standards</label> <div class="acc-body"> <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc11"> <label\n\t\t\tfor="acc11">Sprach-/Literaturwissenschaften </label> <div class="acc-body"> <b>Verbreitete Metadatenstandards</b> sind: <ul> <li>Der XML-basierte <a target="_blank"\n\t\t\thref="http://www.tei-c.org/Guidelines/P5/">TEI P5 Standard</a> ist ein gebräuchliches Format für die semantische Auszeichnung von Texten, besonderes bei Editionen.</li> <li> Das <a target="_blank"\n\t\t\thref="http://www.deutschestextarchiv.de/doku/basisformat/">DTA-Basisformat</a> basiert auf TEI P5 und wurde vom Deutschen Textarchiv entwickelt. Es wird von <a target="_blank"\n\t\t\thref="https://www.clarin-d.de/de/hilfe/benutzerhandbuch">Clarin</a> und <a target="_blank"\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_sprachkorpora.pdf">DFG</a> für den Einsatz bei Textkorpora udn -editionen empfohlen.</li>\n\t\t\t<li><a target="_blank" href="http://music-encoding.org/">MEI (Music Encoding Initiative)</a> ist ein dem TEI-Standard nachempfundener Standard für Dokumente aus der Musikwissenschaft (z.B. musikalische Noten). </li>\n\t\t\t<li><a target="_blank" href="https://www.loc.gov/standards/mets/">METS</a> / <a target="_blank" href="https://www.loc.gov/standards/mods/">MODS</a> sind ein vor allem bei Bibliotheken verbreiteter Standard für\n\t\t\tbibliographische Daten beispielsweise bei Digitalisaten von alten Drucken. </li> <li>Metadaten für die Beschreibung von Handschriften und Kodizes: <a target="_blank"\n\t\t\thref="http://www.manuscripta-mediaevalia.de/hs/handbuch.pdf">Manuscriptum XML (MXML)</a> </li> <li><a target="_blank" href="https://www.cei.lmu.de/">CEI (Charters Encoding Initiative)</a> – ein XML-Standard zur\n\t\t\tBeschreibung (mittelalterlicher) Urkunden. </li> <li><a target="_blank" href="https://mpeg.chiariglione.org/standards/mpeg-7">MPEG-7 (Multimedia Content Description Interface)</a> ist ein Standard für Multimedia-Dateien. Die\n\t\t\tTU Berlin bietet ein <a target="_blank" href="http://mpeg7lld.nue.tu-berlin.de/">eigenes Werkzeug</a> für diesen Standard an. </li> <li>Für (Dariah-)Sammlungen kann das <a target="_blank"\n\t\t\thref="https://wiki.de.dariah.eu/pages/viewpage.action?pageId=52728662"> DCDDM (DARIAH Collection Description Data Model)</a> verwendet werden. </li> </ul> <b>Verschiedene Thesauri / Vokabulare / Ontologien:</b><br\n\t\t\t/> <a target="_blank" href="http://oldenglishthesaurus.arts.gla.ac.uk/">A Thesaurus of Old English</a><br /> <a target="_blank" href="http://rbms.info/vocabularies/index.shtml">RBMS Controlled Vocabularies</a>:\n\t\t\tkontrolliertes Vokabular für alte Drucke und Handschriften<br /> <a target="_blank" href="https:/wiki.bsz-bw.de/doku.php?id=v-team:recherche:ognd:start">GND (Gemeinsame Normdatei)</a> – Normdatensatz der Deutschen Nationalbibliothek\n\t\t\tfür Personen, Namen, Orte und Sachbegriffe<br /> <a target="_blank" href="https://www.loc.gov/rr/print/tgm1/index.html">Thesaurus for Graphic Materials (TGM)</a><br /> <a target="_blank"\n\t\t\thref="https://www.w3.org/TR/owl-features/">OWL Web Ontology Language</a><br /> Dariah-DE: <ul> <li> <a target="_blank" href="https://github.com/dhtaxonomy/TaDiRAH">TaDiRAH Taxonomie</a> </li> <li>\n\t\t\t<a target="_blank" href="http://nedimah.dcu.gr/index.php?p=navigate">NeDiMAH</a> </li> </ul> </div> </div> </div> <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc12">\n\t\t\t<label for="acc12">Sozialwissenschaften </label> <div class="acc-body"> Das in den Sozialwissenschaften gebräuchlichste Metadatenformat ist der <a href="http://www.ddialliance.org/" target="_blank">DDI (Data Documentation\n\t\t\tInitiative) Standard</a>. Es gibt zwei Varianten des Standards: Version3 wird auch als <a href="https://www.ddialliance.org/Specification/DDI-Lifecycle/3.0/" target="_blank">DDI Lifecycle</a> bezeichnet und versucht die\n\t\t\tEntstehungsgeschichte eines Datensatzes möglichst genau zu erfassen. Version 2 oder <a href="http://www.ddialliance.org/resources/getting-started/v2"target="_blank">DDI Codebook</a> ist weniger komplex und wird z.B. bei Umfragedatensätzen\n\t\t\teingesetzt. Andere Metadatenformate für spezielle Anwendungen sind <a target="_blank" href="https://sdmx.org/">Statistical Data and Metadata Exchange Standards</a> (z.B. SDMX-ML) und der <a traget="_blank"\n\t\t\thref="http://www.data-archive.ac.uk/curate/standards-tools/metadata?index=2">QuDEx</a> (Qualitative Data Exchange Format) Standard für statistische bzw. qualitative Daten. <br /> Das Handbuch <a target="_blank"\n\t\t\thref="http://auffinden-zitieren-dokumentieren.de/wp-content/uploads/2015/03/Forschungsdaten_DINA4_ONLINE_VER_02_06.pdf">"Auffinden - Zitieren - Dokumentieren"</a> (von GESIS, ZBW und RatSWD) enthält weiterführende Informationen zu Metadaten\n\t\t\tund Dokumentation von Daten (Seiten 20-23). Siehe hierzu auch <a target="_blank" href="https://www.ratswd.de/download/RatSWD_WP_2009/RatSWD_WP_57.pdf">Gregory, Arofan, Pascal Heus und Jostein Ryssevik. 2009. Metadata. RatSWD Working Paper No.\n\t\t\t57.</a> <br /> <a target="_blank" href="https://www.cessda.eu/">CESSDA</a>, das Consortium of European Social Science Data Archives, stellt verschiedene, knappe Handreichungen zur Verfügung; darunter eine Kurzeinführung in die\n\t\t\t<a target="_blank" href="https://www.cessda.eu/content/download/241/2391/file/CESSDA User Guide for data management_4_Documentation and metadata.pdf">Datendokumentation</a>. <br /> <b>Einige Thesauri / Vokabulare /\n\t\t\tOntologien:</b> <br /> <a target="_blank" href="http://www.gesis.org/unser-angebot/recherchieren/tools-zur-recherche/thesaurus-sozialwissenschaften/">Thesaurus Sozialwissenschaften (TheSoz)</a> <br /> <a\n\t\t\ttarget="_blank" href="http://www.infodata-edepot.de/thesaurus/T_SM.HTM">INFODATA Thesaurus</a> <br /> <a target="_blank" href="http://zbw.eu/stw/version/latest/about">Standard Thesaurus Wirtschaft (STW)</a> <br />\n\t\t\t<a target="_blank" href="https://www.ddialliance.org/controlled-vocabularies">DDI Controlled Vocabulary</a> <br /> <b>Einige Klassifikationen:</b> <br /> <a target="_blank"\n\t\t\thref="http://www.gesis.org/unser-angebot/recherchieren/tools-zur-recherche/klassifikation-sozialwissenschaften/">Klassifikation Sozialwissenschaften</a> <br /> <a target="_blank" href="www.aeaweb.org/jel/guide/jel.php"> Journal\n\t\t\tof Economic Literature Classification System</a>(JEL) </div> </div> </div> <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc13"> <label\n\t\t\tfor="acc13">Psychologie/Erziehungswissenschaften </label> <div class="acc-body"> Der in den Sozialwissenschaften dominante <a href="http://www.ddialliance.org/" target="_blank">DDI (Data Documentation Initiative)\n\t\t\tStandard</a> findet auch in Psychologie und Erziehungswissenschaften Einsatz. Allerdings können gerade in der Psychologie auch Datenstandards auch den Lebenswissenschaften (etwa für MRT-Daten in der Neurologie) von Bedeutung sein. Ein\n\t\t\tZusammenstellung verschiedener solcher Standards findet sich auf <a target="_blank" href="https://fairsharing.org/standards/">fairsharing.org</a>. <br /> Auf forschungsdaten-bildung.de gibt es weiterführende <a target="_blank"\n\t\t\thref="https://www.forschungsdaten-bildung.de/datenmanagement?la=de">Informationen zu Metadaten in Pädagogik und Erziehungswissenschaft</a>. <a target="_blank" href="https://www.psychdata.de/">PsychData</a> verwendet ein eigenes\n\t\t\tMetadatenschema und stellt ein Assistenztool, <a target="_blank" href="https://datawiz.leibniz-psychology.org/DataWiz/">DataWiz</a>, zur Verfügung. Die <a target="_blank" href="https://datawizkb.leibniz-psychology.org/">DataWiz\n\t\t\tKnowledge Base</a> liefert darüber hinaus <a target="_blank" href="https://datawizkb.leibniz-psychology.org/index.php/during-data-collection/what-should-i-know-about-metadata/">Informationen und Empfehlungen zu Dokumentation und\n\t\t\tMetadaten</a>. <br /> <b>Einige Thesauri / Vokabulare / Ontologien:</b> <ul> <li><a target="_blank" href="http://www.zpid.de/index.php?wahl=products&uwahl=printed&uuwahl=psyndexterms">Thesaurus\n\t\t\tPsychologie (PSYNDEX)</a></li> <li><a target="_blank" href="https://datawizkb.leibniz-psychology.org/index.php/during-data-collection/what-should-i-know-about-controlled-vocabularies/">Controlled Vocabularies in\n\t\t\tpsychology</li> <li><a target="_blank" href="https://www.ddialliance.org/controlled-vocabularies">DDI controlled vocabulary</a></li> <li>American Psychological Association’s (APA) <a target="_blank"\n\t\t\thref="https://bioportal.bioontology.org/ontologies/APAONTO">Thesaurus for Psychological Terms</a></li> <li><a target="_blank" href="http://localhost:3000/org/admin/guidance/53/\n\t\t\thttp:/www.infodata-edepot.de/thesaurus/T_SM.HTM">INFODATA Thesaurus</a> (Informationswissenschaften)</li> </ul> <b>Klassifikationen:</b> <ul> <li><a\n\t\t\thref="http://www.apa.org/pubs/databases/training/class-codes.aspx" target="_blank">PsycINFO Classification Categories and Codes</a></li> </ul> </div> </div> </div> <div class="akkordeon"> <div>\n\t\t\t<input type="checkbox" name="acc" id="acc14"> <label for="acc14">Geschichte/Kunstgeschichte/Archäologie </label> <div class="acc-body"> <b>Eine Auswahl von Metadatenstandards:</b><br /> <em>Archäologie,\n\t\t\tAltertumswissenschaften und Kulturelles Erbe:</em> <ul> <li> <a target="_blank" href="http://archives.icom.museum/objectid/heritage/int.html">Core Data Standard for Archaeological Sites and Monuments</a> </li>\n\t\t\t<li> ADeX – Exportdatenformat zur Beschreibung der Geometrie von Ausgrabungen </li> <li> <a target="_blank" href="http://www.heritage-standards.org.uk/midas-heritage/">MIDAS-Heritage</a> – ein Standard zur Beschreibung\n\t\t\tvon Objekten des kulturellen Erbes (Gebäude, Artefakte, …). </li> <li> <a target="_blank" href="https://www.loc.gov/ead/">Encoded Archival Description (EAD)</a> – für Archivalien / Findbücher </li> <li>\n\t\t\tEmpfehlungen von <a target="_blank" href="https:/www.ianus-fdz.de/it-empfehlungen/metadaten-anwendung">IANUS</a> zu Metadaten. </li> <li> ArchaeoML – Metadatenformat vom <a href="https://www.opencontext.org/">Open\n\t\t\tContext</a> </li> <li> Weiterführende Informationen zu Metadaten und Vokabularen finden Sie auch in den <a target="_blank"\n\t\t\thref="http://www.ariadne-infrastructure.eu/Resources/D3.1-Initial-Report-on-the-project-registry">Berichten des ariadne-Projekts</a> </li> </ul> <em>Metadaten für Manuskripte:</em> <ul> <li> CEI (Charters\n\t\t\tEncoding Initiative) - (mittelalterliche) Urkunden </li> <li> Manuscriptum XML (MXML) - Kodikologie </li> </ul> <em>Allgemeine Metadaten Standards</em> <ul> <li> <a target="_blank"\n\t\t\thref="http://www.tei-c.org/index.xml">TEI</a> (Text Encoding Initiative) – verbreiteter Standard bei Textkorpora, der aber für viele textuelle Ressourcen eingesetzt werden kann. </li> <li> <a target="_blank"\n\t\t\thref="http://www.loc.gov/standards/vracore/">VRA Core</a> – Beschreibung von visuellen Kulturgütern (Bilder, Kunstobjekte) </li> <li> <a target="_blank" href="http://mpeg7.org/mpeg-7-standard/">MPEG-7</a> (Multimedia\n\t\t\tContent Description Interface) – Metadatenstandard für die Beschreibung von Multimediadaten/Objekten </li> <li> <a target="_blank" href="https://www.w3.org/TR/prov-overview/">PROV</a> – digitale Provenienz-Information\n\t\t\t</li> <li> <a target="_blank" href="http://www.loc.gov/standards/mods/">MODS (Metadata Object Description Schema)</a>: XML Schema für bibliographische Daten. Vom Bibliotheken oft zur Beschreibung von Digitalisaten eingesetzt.\n\t\t\t</li> </ul> <em> Daten/Metadaten im Bereich Geolokalisierung:</em> <ul> <li> <a target="_blank" href="https://www.fgdc.gov/metadata/geospatial-metadata-standards">The Content Standard for Digital Geospatial\n\t\t\tMetadata (CSDGM)</a> </li> <li> ISO 19115:2003 Standard für geographische Metadaten </li> <li> <a target="_blank" href="http://www.opengeospacial.org/standards/gml">Geography Markup Language (GML)</a>\n\t\t\t</li> </ul> <em>Metadaten für Objekte / musealer Bereich:</em> <ul> <li> LIDO – XML-Schema für deskriptive Informationen zu Objekten in Museen Kunstwerke, Architektur, ...) </li> <li> EDM (Europeana\n\t\t\tData Model) – detailliertes Metadatenschema für Objekte des kulturellen Erbes. Kann mit anderen Metadatenschemata kombiniert werden und unterstützt ein Entity-Relationship Modell. </li> <li> NISO – technische Metadaten für digitale Bilder\n\t\t\t</li> </ul> <b>Einige Klassifikationen/Vokabulare / Ontologien / Thesauri</b><br /> <a target="_blank" href="http://www.iconclass.nl/">ICONCLASS</a> – weit verbreitetes und feingranulares\n\t\t\tKlassifikationssystem für Kunstwerke <ul> <li><a target="_blank" href="https://pleiades.stoa.org/">Pleiades</a> stellt ein Schema für Orte des Altertums und entsprechendes kontrolliertes Vokabular zur Verfügung</li>\n\t\t\t<li><a target="_blank" href="http://www.geonames.org/">GeoNames</a> Authority file</li> <li><a target="_blank" href="http://www.getty.edu/research/tools/vocabularies/">Getty Vocabularies</a> (AAT, CONA, ULAN,\n\t\t\tTGN) für Kunst, Architektur und bibliographisches Material</li> <li><a target="_blank" href="http://swb.bsz-bw.de/">GND</a> (Gemeinsame Normdatei) – der <a\n\t\t\thref="http://www.dnb.de/DE/Standardisierung/GND/gnd_node.html">Normdatensatz der Deutschen Nationalbibliothek</a> für Personen, Namen, Orte und Sachbegriffe.</li> <li><a target="_blank"\n\t\t\thref="https://viaf.org/">VIAF</a> (virtual international authority file) kombiniert bzw. Verknüpft die Normdatensätze verschiedener Nationalbibliotheken </li> <li>CIDOC-CRM Ontologie für Konzepte im Bereich des kulturellen\n\t\t\tErbes</li> </ul> </div> </div> </div> </div> </div> </div>	What data and metadata vocabularies, standards or methodologies will you follow to make your data interoperable? Will you be using standard vocabularies for all data types present in your dataset, to allow inter-disciplinary interoperability?	Welche Daten- und Metadaten-Vokabulare, -Standards und Methodologien werden verwendet, um die Daten interoperabel zu machen? Werden Standardvokabulare für alle Datentypen in dem Datensatz verwendet, um interdisziplinäre\n\t\t\tInteroperabilität zu ermöglichen?	text	text		83	152	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
369	2020-04-14 15:07:40.787+00	2020-04-14 15:07:40.787+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/re_useable-re_use/embargo	https://fdm-bayern.org/eHumanities	embargo	Horizon2020/FAIR/re_useable-re_use/embargo		f	2	\N	\N	If an embargo is sought to give time to publish or seek patents, specify why and how long this will apply, bearing in mind that research data should be made available as soon as possible.	Falls eine Embargo-Periode nötig ist, um beispielsweise Patente zu beantragen, geben sie an warum und wie lange dies nötig ist. Bedenken Sie, dass Forschungsdaten möglichst zeitnah verfügbar sein sollten.	textarea	text		97	153	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
372	2020-04-14 15:07:40.947+00	2020-04-14 15:07:40.947+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/re_useable-re_use/qa	https://fdm-bayern.org/eHumanities	qa	Horizon2020/FAIR/re_useable-re_use/qa		f	5	This includes measures that ensure the integrity of the datasets, e.g., checksums or appointing a data steward, who controls and monitors access to the primary datasets; But also measures that have been put in place to check data\n\t\t\tcollection, such as <ul> <li> standardized protocols for calibration of the experimental setup </li> <li>repeat measurements / control samples / confirmatory measurements</li> </ul> Also keep in mind that the data\n\t\t\tsubjects expect that their data are recorded properly. If a data archive / repository will be used: Some data centres, like GESIS datorium (social and behavioural sciences & economy) or Dryad (life, environmental, biological and social sciences\n\t\t\tas well as humanities), curate the archived / published data and provide an additional quality control process.	Dies umfasst zum einen Maßnahmen, die die Integrität der Daten selbst sicherstellen (Checksummen oder Benennen eines Datenstewards, der die Daten und den Zugang zu diesen überwacht). Zum anderen aber auch Maßnahmen, die bereits\n\t\t\twährend der Datenentstehung durchgeführt wurden. Beispielsweise: <ul> <li>Standardisierte Protokolle zur Kalibrierung des Experimentes</li> <li>unabhängige Wiederholung aller Messungen / Kontrollgruppen / ...</li>\n\t\t\t</ul> Dabei ist zu bedenken, dass Datengeber (etwa Patienten oder Interviewpartner) ein Recht darauf haben, dass ihre Daten korrekt aufgezeichnet und ggf. wiedergegeben werden. Falls ein Datenrepositorium für die Archivierung/Publikation der\n\t\t\tDaten verwendet werden soll:<br /> Einige Datenzentren wie das GESIS datorium oder Dryad haben eigene Schritte zur Qualitätskontrolle und kuratieren die dort abgelegten Daten aktiv.	Describe the data quality assurance process.	Beschreiben Sie den Prozess der Qualitätssischerung bei diesem Datensatz.	textarea	text		103	153	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
373	2020-04-14 15:07:41.093+00	2020-04-14 15:07:41.093+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/re_useable-re_use/re_usethrid_party	https://fdm-bayern.org/eHumanities	re_usethrid_party	Horizon2020/FAIR/re_useable-re_use/re_usethrid_party		f	3	Re-use restrictions can arise via intellectual property rights, data privacy concerns or contractual obligations (agreements with industry partners, consent of subjects of the study, ...) .	Einschränkung an die Nachnutzbarkeit können aufgrund von fehlenden Rechten am geistigen Eigentum, Datenschutzrichtlinien oder sonstigen vertraglichen / ethischen Vorgaben bestehen.	Are the data produced and / or used in the project useable by third parties, in particular after the end of the project? If the re-use of some data is restricted, explain why.	Kann der Datensatz von Dritten nach Ende des Projektes verwendet werden? Falls es Einschränkungen gibt, erklären Sie warum.	textarea	text		125	153	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
374	2020-04-14 15:07:41.135+00	2020-04-14 15:07:41.135+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/re_useable-re_use/reuse_duration	https://fdm-bayern.org/eHumanities	reuse_duration	Horizon2020/FAIR/re_useable-re_use/reuse_duration		f	4	Note that re-usability does not only depend on availability of the stored data. E.g. some data repositories, like RADAR, guarantee availability of published data for as long as the service exists but at least for 25 years. However, in\n\t\t\t25 years the data may be obsolete or cannot be accessed as the data format is no longer recognized. Open formats and discipline standards can mitigate this.	Beachten Sie das Nachnutzbarkeit nicht nur an der Verfügbarkeit der Daten hängt. Etliche Repositorien garantieren, dass publizierte Daten mindestens 25 Jahren lang sicher aufbewahrt werden. Jedoch kann es sein, dass in 25 Jahren das\n\t\t\tverwendete Datenformat nicht mehr von neuen Betriebssystemen oder neuer Software gelesen werden kann. Offene Formate und in der Fachdisziplin verbreitete Standards reduzieren dieses Risiko.	How long is it intended that the data remains re-usable?	Wie lange wird der Datensatz nachnutzbar bleiben?	textarea	text		101	153	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
375	2020-04-14 15:07:41.182+00	2020-04-14 15:07:41.182+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/costs/data-costs/cover_how	https://fdm-bayern.org/eHumanities	cover_how	Horizon2020/costs/data-costs/cover_how		f	20	Costs are eligible for reimbursement during the duration of the project under the conditions defined in the H2020 Grant Agreement, in particular <a\n\t\t\thref="http://ec.europa.eu/research/participants/data/ref/h2020/grants_manual/amga/h2020-amga_en.pdf#page=36" target="_blank">Article 6</a> and <a\n\t\t\thref="http://ec.europa.eu/research/participants/data/ref/h2020/grants_manual/amga/h2020-amga_en.pdf#page=83" target="_blank">Article 6.2.D.3</a>, but also other articles relevant for the cost category chosen.	Kosten sind während der Projektlaufzeit förderfähig unter den Bedingungen des H2020 Grant Agreement, insbesondere <a href="http://ec.europa.eu/research/participants/data/ref/h2020/grants_manual/amga/h2020-amga_en.pdf#page=36"\n\t\t\ttarget="_blank">Artikel 6</a> und <a href="http://ec.europa.eu/research/participants/data/ref/h2020/grants_manual/amga/h2020-amga_en.pdf#page=83" target="_blank">Artikel 6.2.D.3</a>, aber auch anderen Artikeln, die für die\n\t\t\tKostenkategorie relevant sind.	How will these be covered? Note that costs related to open access to research data are eligible as part of the Horizon 2020 grant (if compliant with the Grant Agreement conditions).	Wie werden diese Kosten bestritten werden? Beachten Sie, dass Kosten für offenen Zugang (open access) zu Forschungsdaten als Teil des Horizon 2020 Grants gefördert werden können (sofern dies mit den Bedingungen des Programms konform ist).	textarea	text		21	154	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
376	2020-04-14 15:07:41.222+00	2020-04-14 15:07:41.222+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/costs/data-costs/other	https://fdm-bayern.org/eHumanities	other	Horizon2020/costs/data-costs/other		f	10	Give the costs in **Euro**.	Geben Sie die Kosten in **Euro** an.	Estimate the non-personnel costs for making your data FAIR.	Schätzen Sie die Kosten, die nötig sind um die Daten FAIR zu machen.	text	float	Euro	15	154	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
377	2020-04-14 15:07:41.266+00	2020-04-14 15:07:41.266+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/costs/data-costs/personal	https://fdm-bayern.org/eHumanities	personal	Horizon2020/costs/data-costs/personal		f	0	\N	\N	Estimate the costs of needed personnel for making your data FAIR. Give the number of person months.	Schätzen Sie die Personalkosten, die nötig sind um die Daten FAIR zu machen. Geben Sie die Personenmonate an.	range	float	PM	16	154	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
378	2020-04-14 15:07:41.305+00	2020-04-14 15:07:41.305+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/costs/data-datavalue/longterm_decide	https://fdm-bayern.org/eHumanities	longterm_decide	Horizon2020/costs/data-datavalue/longterm_decide		t	1	\N	\N	Who selects the data to be long-term archived?	Wer entscheidet welche Daten langfristig gesichert werden?	textarea	text		88	155	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
379	2020-04-14 15:07:41.351+00	2020-04-14 15:07:41.351+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/costs/data-datavalue/longterm_value	https://fdm-bayern.org/eHumanities	longterm_value	Horizon2020/costs/data-datavalue/longterm_value		f	2	Since long-term preservation comes with a non-trivial monetary and administrative cost, one should carefully consider if the dataset has to be long-term preserved.<br /> Some data is basically unique as it cannot be reproduced\n\t\t\t(weather data on a given day in a given region, certain surveys ...) or reproducing the data requires extreme efforts (expensive experimental setups, multiple years of observations ...). Such data will generally have long-term value and should be\n\t\t\tpreserved - provided no other issues (research ethics, privacy protection, patents, contracts, ...) have to be taken into account. Other data are relatively easy to reproduce and a detailed description, e.g. of the experiment or the computer code\n\t\t\tthat generated the data is more useful to scientists as they can reproduce the data easily themselves. Some data may also become obsolete after some time, as new technologies may provide much more refined data. (The original data may still have been\n\t\t\tvaluable to verify the feasibility of the new method.)	Da Langzeitarchivierung mit finanziellen Kosten und administrativem Aufwand einhergeht, sollte geprüft werden, ob ein Datensatz langfristig aufbewahrt werden muss. <br /> Manche Daten sind einzigartig und können nicht\n\t\t\treproduziert werden (Wetterdaten zu einem bestimmten Tag in einer bestimmten Region, Umfragen vor einschneidenden Ereignissen,...) oder nur unter unverhältnismäßigem Aufwand (erforderlich ist der Bau eines Satelliten, die Beobachtungen erstrecken\n\t\t\tsich über eine Periode von mehreren Jahren,...). Daten dieser Art haben in der Regel langfristigen Wert und sollten bewahrt werden, sofern keine anderen Gründe (Datenschutz, vertragliche Absprachen,...) dagegen sprechen. Andere Daten lassen sich\n\t\t\tverhältnismäßig einfach reproduzieren. In diesen Fällen ist eine detaillierte Dokumentation des Experimentes oder des Computer-Codes unter Umständen wichtiger als die Daten selbst. Weiter können Daten durch neue bessere Methoden langfristig obsolet\n\t\t\twerden. (Die Daten sind natürlich wichtig, um die Validität der neuen Methodik zu verifizieren.)	Why should this dataset be long term preserved? What is its future value?	Warum sollte dieser Datensatz langfristig bewahrt werden? Welchen Wert hat er für die Zukunft?	textarea	text		232	155	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
381	2020-04-14 15:07:41.45+00	2020-04-14 15:07:41.45+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/costs/data-longtermcost/longterm_cost_person	https://fdm-bayern.org/eHumanities	longterm_cost_person	Horizon2020/costs/data-longtermcost/longterm_cost_person		f	0	\N	\N	Estimate the personnel costs for long-term preservation for the whole project. Give the number of person months.	Schätzen Sie die Personalkosten für die Langzeitsicherung für das gesamte Projekt. Geben Sie die Personenmonate an.	range	float	PM	23	156	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
382	2020-04-14 15:07:41.522+00	2020-04-14 15:07:41.522+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/costs/data-responsible/responsible	https://fdm-bayern.org/eHumanities	responsible	Horizon2020/costs/data-responsible/responsible		t	0	\N	\N	Who will be responsible for data management in your project?	Wer ist in Ihrem Projekt für das Datenmanagement zuständig?	text	text		180	157	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
383	2020-04-14 15:07:41.566+00	2020-04-14 15:07:41.566+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_security/transfer_storage-datasecurity/repos	https://fdm-bayern.org/eHumanities	repos	Horizon2020/data_security/transfer_storage-datasecurity/repos		f	2	Certificates include: Data Seal of Approval, the nestor Seal or certification via ISO 16363. For many repositories you can check this using <a target="_blank" href="https://www.re3data.org/">re3data.org</a>.	Häufige Zertifikate sind das Data Seal of Approval, das Nestor Gütesiegel oder eine Zertifizierung nach ISO 16363. Zu vielen Repositorien finden diese Informationen über <a target="_blank" href="https://www.re3data.org/">re3data.org</a>.	Is the dataset safely stored in certified repositories for long term preservation and curation?	Ist der Datensatz sicher in einem zertifizierten Repositorium zur Langzeitsicherung und Kuratierung gespeichert?	textarea	boolean		94	158	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
384	2020-04-14 15:07:41.61+00	2020-04-14 15:07:41.61+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_security/transfer_storage-datasecurity/security	https://fdm-bayern.org/eHumanities	security	Horizon2020/data_security/transfer_storage-datasecurity/security		f	1	You can consider the questions: <ul> <li>Where and how will you store the master copy of your raw research data? </li> <li>Where and how will you and your collaborators store the data during the analysis phase?\n\t\t\t</li> <li>If the project involved non-digital data or non-digital versions of the data, how will these be stored? </li> <li>How often will the data be backed up? What tools are used for this? </li> <li>Will there\n\t\t\tbe multiple redundant copies of the datasets? </li> <li>If the data can be accessed via the internet: What authentication procedures are in place? Is the data transfer encrypted (e.g., in case of https via SSL/TLS)? </ul>\n\t\t\tEspecially, if you are working with sensitive data, you may want to consider especially strict security measures, e.g., by physical security measures (e.g. locked rooms, safes), removal of personal information that may allow identification (e.g.\n\t\t\tanonymisation), encrypting the data storage or authentication procedures for access to the data.	Folgende Fragen können hier hilfreich sein: <ul> <li>Wo und wie wird die Hauptkopie der Rohdaten gesichert?</li> <li>Wo und wie werden die Projektmitglieder die Daten während der Auswertung\n\t\t\tspeichern?</li> <li>Falls neben digitalen auch nicht-digitale Daten anfallen: Wie werden diese gelagert?</li> <li>Wie oft werden Backups durchgeführt? Welche Software-Tools werden für automatische Backups verwendet?</li>\n\t\t\t<li>Gibt es dezentral gelagerte redundante Kopien der Daten?</li> </ul> Besonders wenn es sich um sensible Daten handelt, können strenge Sicherheitsmaßnahmen notwendig sein. Beispielsweise verschlossene Räume oder Tresore, das\n\t\t\tEntfernen persönlicher Informationen (z.B. Anonymisierung), Verschlüsseln des Datenspeichers oder strenge Authentifizierungsprozeduren, um Zugriff auf die Daten zu erhalten.	What provisions are in place for data security (including data recovery as well as secure storage and transfer of sensitive data)?	Welche Maßnahmen zur Datensicherheit werden eingesetzt? Dies umfasst Daten-Rückgewinnung (data recovery), sichere Speicherung und sichere Übertragung sensibler Daten.	textarea	text		60	158	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
385	2020-04-14 15:07:41.677+00	2020-04-14 15:07:41.677+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_summary/datasets-Dataset_intro/Fortfahren	https://fdm-bayern.org/eHumanities	Fortfahren	Horizon2020/data_summary/datasets-Dataset_intro/Fortfahren		f	0	\N	\N	Choose "yes" and continue:	Wählen Sie "Ja" und fahren Sie fort:	yesno	boolean		209	159	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
386	2020-04-14 15:07:41.726+00	2020-04-14 15:07:41.726+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_summary/datasets-data_reuse/origin	https://fdm-bayern.org/eHumanities	origin	Horizon2020/data_summary/datasets-data_reuse/origin		f	1	This is relevant if you reuse data. Questions that could be considered:<br/> Who created the dataset in the first place and as part of which project? Are the data publicly available or were they obtained upon request? If the set\n\t\t\tis published you should give the link to the data archive or its DOI. If the dataset is provided as part of a collaboration with an industry partner, some comment on a legal agreement could be added. Details will be asked later.	Wer hat den Datensatz erstellt und als Teil welchen Projektes? Ist der Datensatz frei verfügbar oder wurde er auf Anfrage herausgegeben? Falls die Daten publiziert sind, sollte der Link oder die DOI unter der der Datensatz verfügbar\n\t\t\tist angegeben werden. Falls die Daten im Rahmen einer Industriekooperation genutzt werden, kann hier schon ein Satz zu den rechtlichen Rahmenbedingungen stehen. Fragen zu den Details kommen später.	What is the origin of the data?	Beschreiben Sie den Ursprung der (nachgenutzen) Daten.	textarea	text		85	160	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
387	2020-04-14 15:07:41.791+00	2020-04-14 15:07:41.791+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_summary/datasets-data_reuse/re_use	https://fdm-bayern.org/eHumanities	re_use	Horizon2020/data_summary/datasets-data_reuse/re_use		f	0	You can also discuss why the datasets were chosen and how they fit into the project. For example: the dataset is considered to be the best / only option for your purpose and it is not feasible / efficient to recreate the dataset from scratch.	Beschreiben Sie auch warum diese Datensätze verwendet werden und wie Sie zur Beantwortung der Forschungsfrage beitragen. Zum Beispiel: der Datensatz gilt als der beste / einzige für die Fragestellung des Projektes. Es ist nicht\n\t\t\tmöglich oder sinnvoll einen eigenen Datensatz in gleicher Güte mit vertretbarem Aufwand zu erzeugen.	Will you be re-using any existing dataset and how?	Werden bereits existierende Datensätze verwendet und wie werden diese nachgenutzt?	textarea	text		44	160	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
388	2020-04-14 15:07:41.89+00	2020-04-14 15:07:41.89+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_summary/datasets-datasets/data_type	https://fdm-bayern.org/eHumanities	data_type	Horizon2020/data_summary/datasets-datasets/data_type		f	1	Common data types are: <ul> <li>textual data (transcriptions, translations, personal names,...)</li> <li>images (scans of manuscripts, microscope images, objects, ...)</li> <li>survey\n\t\t\tdata</li> <li>3D model / digital reconstruction (e.g. of a stone age settlement)</li> <li>experimental measurements</li> <li>software developed within the project</li> <li> audio or video recordings\n\t\t\t(e.g. a qualitative interview) </ul> When choosing a data format, one should consider the consequences for collaborative use, long-term preservation as well as re-use. Outline why these data formats are used, especially if you use formats that\n\t\t\tare not standardised, open, non-proprietary or established in the scholarly community. More criteria and detailed explanations can be found e.g. in the <a href="https://escience.aip.de/wissgrid/publikationen/Leitfaden_Data-Management-WissGrid.pdf"\n\t\t\ttarget=_blank">WissGrid-Leitfaden, pp. 22 f.</a> <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc1"> <label for="acc1">Further information on data formats for archival purposes</label>\n\t\t\t<div class="acc-body"> The choice of the data format may determine how easy other researchers can reuse your data if the usability is tied to a proprietary software. This might also affect you directly, if you change research institutes and the\n\t\t\tsoftware is temporarily unavailable.<br /> <br />Some recommended data formats for long term storage and publication:<br /><br /> <b>SQL / Tables:</b><br /> Simple comma separated values (.csv) is a standard\n\t\t\tformat for storing and exchanging data in tabular form. Note, that csv can only transport the basic content of the elements of a table, but not color, font size and other advanced format options that are available in dedicated programs such as Excel\n\t\t\tor Open Office Calc.<br /> Databases (DB) should ideally not be saved directly, but if possible as SQL dumps. The dumps are normal text files with commands in the DB language. The file is in principle human-readable. A special long-term format\n\t\t\tfor DBs is <a target="_blank" href="https://www.bar.admin.ch/bar/de/home/archivierung/tools---hilfsmittel/siard-suite.html">SIARD</a>.<br /><br /> <b>Audio and video data:</b><br /> Uncompressed .wav, .avi,\n\t\t\tmotion JPEG 2000 (.mj2) and .mov are expected to be reusable for an extended period of time. Further, .flac, .mp4 and mp3 file formats are considered to be acceptable, see <a target="_blank"\n\t\t\thref="https://www.ukdataservice.ac.uk/manage-data/format/recommended-formats">UK data archive</a>.<br /> Music notations can be stored in <a target="_blank" href="https://www.musicxml.com/">Music XML</a>- an open, XML-based\n\t\t\tstandard.<br /><br /> <b>Text files:</b><br /> Unless there is a dedicated XML standard (like TEI P5) simple textual information (e.g. transcriptions of interviews) can be save as standard .txt files using a common\n\t\t\tcharacter encoding (ASCII or Unicode in UTF8).<br /><br /> <b>Statistical Data: </b><br /> SPSS: When using the standard .sav-files used to be problematic in older program versions as there were problems to interpret the\n\t\t\tfiles without the software. The portable .por format can be used to avoid this.<br /> R: .R files can be opened in a regular editor.<br /><br /> <b>Further information on data formats</b> can be found here:<br />\n\t\t\t<ul> <li><a target="_blank" href="https://www.forschungsdaten.info/themen/bewahren-und-nachnutzen/formate-erhalten/">forschungsdaten.info</a> </li> <li><a target="_blank"\n\t\t\thref="https://datawizkb.leibniz-psychology.org/index.php/during-data-collection/what-should-i-know-about-file-formats/">DataWiz knowledge base</a> by ZPID (psychology)</li> <li>Recommended formats for transfer and archiving in\n\t\t\teducational sciences: <a target="_blank" href="https://www.forschungsdaten-bildung.de/formate">forschungsdaten-bildung.de</a>. <li><a target="_blank"\n\t\t\thref="https://wiki.de.dariah.eu/pages/viewpage.action?pageId=38080370#Empfehlungenf%C3%BCrForschungsdaten,ToolsundMetadateninderDARIAH-DEInfrastruktur-EmpfohleneDateiformate">Dariah-DE (humanities)</a> </li> <li><a\n\t\t\ttarget="_blank" href="https://www.cessda.eu/Research-Infrastructure/Training/Online-Materials">CESSDA (social sciences)</a></li> <li><a target="_blank"\n\t\t\thref="https://www.ianus-fdz.de/it-empfehlungen/?q=node/44">IANUS</a> provides a list of recommended formats for historical sciences. </li> </ul> </div> </div> </div>	Häufige Datenarten sind: <ul> <li>Textuelle Daten (Transkripte, Übersetzungen, Textkorpora, Personennamen, ...)</li> <li>Bilder (Scans von Handschriften, Mikroskop-Aufnahmen, Objekte, ...)</li>\n\t\t\t<li>3D-Modelle / digitale Nachbildungen (z.B. von Gebäuden, von Grabungsstätten, von Kunstobjekten, ...)</li> <li>Messwerte aus verschiedenen Experimenten</li> <li>Software</li> <li>Audio- und\n\t\t\tVideoaufzeichnungen</li> </ul> Bei der Wahl des Dateiformates sollten auch die Konsequenzen für die kollaborative Nutzung, die Langzeitarchivierung sowie die Nachnutzung beachtet werden. Begründen Sie die Wahl der Datenformate bzw.\n\t\t\tDateiformate, insbesondere wenn keine standardisierten, nicht-proprietären bzw. in der Community verbreiteten Formate verwendet werden. Weitere Kriterien sowie detaillierte Erläuterungen sind z.B. im <a\n\t\t\thref="https://escience.aip.de/wissgrid/publikationen/Leitfaden_Data-Management-WissGrid.pdf" target=_blank">WissGrid-Leitfaden, S. 22 f.,</a> zu finden. <div class="akkordeon"> <div> <input type="checkbox" name="acc"\n\t\t\tid="acc1"> <label for="acc1">Weitere Informationen zu Datenformaten zur Archivierung</label> <div class="acc-body"> Wie leicht andere Forschende Datensätze nachnutzen können, hängt stark von den verwendeten Daten- bzw.\n\t\t\tDateiformaten ab. Besonders Dateiformate, die nur von proprietärer Software gelesen werden können, schränken den potentiellen Nutzerkreis stark ein. Diese Problematik kann auch die Autoren selbst betreffen, wenn nach einem Wechsel des\n\t\t\tForschungsinstitutes oder der Universität kurzfristig keine Lizenzen für die benötigte Software zur Verfügung stehen.<br /> <br />Eine knappe Übersicht über Daten-Formate, die als geeignet für die nachhaltige Sicherung eingestuft\n\t\t\twerden:<br /><br /> <b>SQL / Tabellen:</b><br /> Einfache Comma Separated Values Dateien (.csv) sind gut für den Austausch und die langfristige Sicherung von Daten in tabellarischer Form geeignet. CSV kann dabei nur den\n\t\t\telementaren Inhalt der einzelnen Einträge der Tabelle abbilden. Formatierungen (Schriftart, Farben, …) oder andere erweiterte Funktionen wie sie Programme wie Excel oder OpenOffice Calc anbieten können nicht abgebildet werden.<br /> Der Inhalt\n\t\t\teiner Datenbank sollte idealerweise über einen SQL-Dump exportiert werden. Dabei entstehen im Wesentlichen normale Textdateien mit Befehlen in der Datenbanksprache. Die Dateien sind im Prinzip von Menschen „lesbar“. Ein spezielles Format für die\n\t\t\tLangzeitarchivierung von Datenbanken ist <a target="_blank" href="https://www.bar.admin.ch/bar/de/home/archivierung/tools---hilfsmittel/siard-suite.html">SIARD</a>.<br /><br /> <b>Audio- und Videodaten:</b><br\n\t\t\t/> Unkomprimierte .wav, .avi, motion JPEG 2000 (.mj2) und .mov Dateien versprechen momentan eine langfristig gute Nachnutzbarkeit. Weiter werden z.B. vom <a target="_blank"\n\t\t\thref="https://www.ukdataservice.ac.uk/manage-data/format/recommended-formats">UK data archive</a> die Formate .flac, .mp4 und .mp3 als geeignet eingestuft.<br /> Musiknotationen können in <a target="_blank"\n\t\t\thref="https://www.musicxml.com/">Music XML</a>, ein offenes XML-Format, abgelegt werden.<br /><br /> <b>Textdateien:</b><br /> Sofern es keinen passenden XML-Standard (wie TEI P5) gibt, können einfache textuelle\n\t\t\tInformationen (z.B. Abschriften von Interviews) als Textdateien (txt) mit dokumentierter freier Zeichenkodierung (wie ASCII oder Unicode in UTF-8) verwendet werden.<br /><br /> <b>Statistische Daten: </b><br /> SPSS: Bei\n\t\t\tälteren Software-Versionen kann es vorkommen, dass die normalen .sav-Dateien nicht ohne die Software interpretiert werden können. Dies kann durch ein Speichern der Daten im .por-Format umgangen werden.<br /> R: .R-Dateien können in einfachen\n\t\t\tTexteditoren geöffnet werden.<br /><br /> <b>Weitere Informationen zu passenden / gebräuchlichen Datenformaten</b> finden Sie unter anderem hier:<br /> <ul> <li><a target="_blank"\n\t\t\thref="https://www.forschungsdaten.info/themen/bewahren-und-nachnutzen/formate-erhalten/">forschungsdaten.info</a> </li> <li><a target="_blank"\n\t\t\thref="https://datawizkb.leibniz-psychology.org/index.php/during-data-collection/what-should-i-know-about-file-formats/">DataWiz knowledge base</a> des ZPID (Psychologie)</li> <li>Empfohlene Datenformate für Datentransfer und\n\t\t\tArchivierung in den Erziehungswissenschaften: <a target="_blank" href="https://www.forschungsdaten-bildung.de/formate">forschungsdaten-bildung.de</a>. <li><a target="_blank"\n\t\t\thref="https://wiki.de.dariah.eu/pages/viewpage.action?pageId=38080370#Empfehlungenf%C3%BCrForschungsdaten,ToolsundMetadateninderDARIAH-DEInfrastruktur-EmpfohleneDateiformate">Dariah-DE (Geisteswissenschaften)</a> </li> <li><a\n\t\t\ttarget="_blank" href="https://www.cessda.eu/Research-Infrastructure/Training/Online-Materials">CESSDA (Sozialwissenschaften)</a></li> <li><a target="_blank"\n\t\t\thref="https://www.ianus-fdz.de/it-empfehlungen/?q=node/44">IANUS</a> stellt eine Liste für die Geschichts- und Altertumswissenschaften empfohlenen Datenformaten zur Verfügung. </li> </ul> </div> </div> </div>	What types and formats of data will be generated in the project?	Welche Arten von Daten werden in dem Projekt erstellt / gesammelt und welche Datenformate werden verwendet?	textarea	text		62	161	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
389	2020-04-14 15:07:41.956+00	2020-04-14 15:07:41.956+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_summary/datasets-datasets/description	https://fdm-bayern.org/eHumanities	description	Horizon2020/data_summary/datasets-datasets/description		f	0	\N	\N	What is the purpose of the data collection / generation and its relation to the objectives of the project?	Was ist das Ziel der Datenerzeugung und in welcher Beziehung steht diese zu den Zielen des Projektes?	textarea	text		140	161	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
488	2020-04-29 09:54:34.264+00	2020-11-08 14:54:48.454+00	http://example.com/terms/questions/GFBio test/general/category/categoryType	http://example.com/terms	categoryType	GFBio test/general/category/categoryType	In GFBio a research field is a category	f	0	\N		Please select a category:	Bitte wählen Sie eine Kategorie:	select	option		242	206	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
534	2020-10-28 14:09:45.289+00	2020-10-28 14:09:45.289+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/costs-dataset/storage_personnel	https://rdmorganiser.github.io/terms	storage_personnel	biodiversity_dfg/data-usage/costs-dataset/storage_personnel		f	5	Please estimate the effort in person months.	Bitte schätzen sie den Aufwand in Personenmonaten.	What are the personnel costs associated with data storage and data security in the project?	Welcher Personalaufwand entsteht im Zusammenhang mit der Speicherung der Daten und Maßnahmen zur Datensicherheit während des Projektes?	range	float	PM	33	242	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
390	2020-04-14 15:07:42.008+00	2020-04-14 15:07:42.008+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_summary/datasets-size_and_use/size	https://fdm-bayern.org/eHumanities	size	Horizon2020/data_summary/datasets-size_and_use/size		f	0	Try to give an estimate how much data will be generated over the course of the project and with how much data you will be working with. Note the total expected data volume in MB/GB/TB/PB or give the expected number of individual data\n\t\t\tfiles and their average size. For example you might expect about 1000 high-resolution images each with a file size of roughly 220 MB. Here it is also useful to note the sample size you are aiming for, for example: <ul> <li>Transcriptions\n\t\t\tand scans of 500 documents on the Hanseatic League </li> <li>50 interviews with patients </li> <li>a survey among 2000 teachers </li> <li>200 hours of night sky observations </li> </ul> If you combine\n\t\t\tnew and existing data give the information separately for each dataset. This is also recommended if you are creating very different datasets, e.g. interviews as well as MRI scans.	Versuchen Sie abzuschätzen, wie viel Daten im Projekt erzeugt und mit wie vielen Daten Sie insgesamt arbeiten werden. Das Datenvolumen kann hierbei einfach durch die Anzahl von MB/GB/TP/PB beziffert werden oder durch Angabe der\n\t\t\terwarteten Dateianzahl und ihrer mittleren Größe. Beispielweise: Es werden 1000 hochauflösende Bilder mit einer typischen Dateigröße von 220MB angestrebt. Hierbei ist es sinnvoll auch den beabsichtigten Probenumfang zu beschreiben. Etwa: <ul>\n\t\t\t<li>Abschriften von 500 Dokumenten über die Hanse.</li> <li>50 Interviews mit Patienten.</li> <li>Eine Umfrage unter 2000 Lehrern.</li> <li>200 Stunden Aufnahmen des Nachthimmels.</li> </ul> Falls\n\t\t\tin dem Projekt bereits existierende Datensätze mit neuen kombiniert werden, sollte jeder Datensatz einzeln betrachtet werden. Ebenso falls die unterschiedlich Datensätze in dem Projekt entstehen werden, zum Beispiel Interviews und MRT-Scans.	What is the expected size of the data(set)?	Geben Sie das erwartete Volumen des Datensatzes an (soweit bekannt).	textarea	float		130	162	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
391	2020-04-14 15:07:42.125+00	2020-04-14 15:07:42.125+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_summary/datasets-size_and_use/use	https://fdm-bayern.org/eHumanities	use	Horizon2020/data_summary/datasets-size_and_use/use		f	1	Consider both uses inside and outside your own field of research. <br /> For example: if you collect extensive data on temporal and geographic evolution of dialects in a certain language, the data may have uses to researchers\n\t\t\twho study migration patterns due to e.g. a change in regional climate or plague.	Versuchen Sie möglichen Nutzen in Ihrem Forschungsbebiet und auch in fachfremden Gebieten abzuschätzen.<br /> Zum Beispiel: Falls Sie extensiv Daten zur räumlichen und zeitlichen Entwicklung von Dialekten in einer Region\n\t\t\tsammeln, könnten die Daten auch Forschenden nutzen, die Migrationsmuster in Folge regionaler klimatischer Veränderungen oder sich ausbreitender Seuchen untersuchen.	Outline the data utility; to whom will the data(set) be useful?	Wer könnte diese Daten noch nutzen?	textarea	text		106	162	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
392	2020-04-14 15:07:42.179+00	2020-04-14 15:07:42.179+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/other/funder-other/other	https://fdm-bayern.org/eHumanities	other	Horizon2020/other/funder-other/other		f	0	Here you should describe the policies that apply to the project. But be sure to contact the project partners for information on their policies. Furthermore there are various guidelines, policies and recommendations by scientific and\n\t\t\tresearch societies or institutes, which may relate/apply to your research subjects. Here are some examples of the policies and recommendations that may apply: <div class="akkordeon"> <div> <input type="checkbox"\n\t\t\tname="acc" id="acc1"> <label for="acc1">Philologies/Literary Studies</label> <div class="acc-body"> <ul> <li><a target="_blank"\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/foerderkriterien_editionen_literaturwissenschaft.pdf"><span>Funding criteria for scientific editions (DFG) </span></a></li>\n\t\t\t<li>Recommendations / Requirements for language corpora / linguistics (DFG): <ul> <li><a target="_blank" href="\n\t\t\thttps://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/guidelines_review_board_linguistics_corpora.pdf">Guidelines by the DFG Review Board on Linguistics</a></li> <li><a target="_blank"\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_recht.pdf"><span>legal aspects of handling language corpora\n\t\t\t</span></a></li> <li><a target="_blank"\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_sprachkorpora.pdf"><span>data technology and tools </span></a></li>\n\t\t\t</ul> </li> </ul> Furthermore, some scholarly societies have their own memorandums or recommendations, e.g., the DRV (Deutscher Romanisten Verband) released the position paper <a target="_blank"\n\t\t\thref="http://deutscher-romanistenverband.de/wp-content/uploads/sites/14/Open-Access-und-Forschungsdaten_Mrz-2017.pdf"><span> "Open Access and Research Data in Romance Studies"</span></a> (in German).\n\t\t\t</div> </div> <div> <input type="checkbox" name="acc" id="acc2"> <label for="acc2">Social / Economic Sciences</label> <div class="acc-body"> Some BMBF\n\t\t\tprograms do include additional requirements, but the specifics depend on the funding program. DFG lists several guidelines / requirements for social / economic sciences on their webpage: <ul> <li><a target="_blank"\n\t\t\tref="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/dgs_stellungnahme_forschungsdaten.pdf">Bereitstellung und Nachnutzung von Forschungsdaten in der Soziologie: Stellungnahme des Vorstands und Konzils der\n\t\t\tDGS</a> (in German)</li> <li>requirements in the <a target="_blank" href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/basisinformationen_forschungsdatenmanagement.pdf"\n\t\t\ttarget="_blank" >Basic Information on Research Data Management</a> (German) of the Council for Social and Economic Data (RatSWD)</li> <li>requirements of the <a target="_blank"\n\t\t\thref="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/fachkollegium112_forschungsdatenmanagement_1811.pdf" target="_blank" >DFG Review Board 112 "Economics"</a> (German)</li>\n\t\t\t</ul> Furthermore, there are various other recommendation: <ul> <li><a target="_blank" href="http://www.ratswd.de/dl/RatSWD_Output3_Forschungsdatenmanagement.pdf">Guidelines of RatSWD for data management in\n\t\t\tsocial, behavioural and economic sciences </a></li> <li>The <a target="_blank" href="https://www.gesis.org/en/gesis-survey-guidelines/operations/online-surveys/" target="_blank" >GESIS survey\n\t\t\tguidelines </a> encompass various best practices for setting up and planning social surveys </li> <li>The German Sociological Association (GSE) and the Berufsverband Deutscher Soziologen (BDS) provide an <a\n\t\t\thref="https://www.soziologie.de/fileadmin/user_upload/DGS_Redaktion_BE_FM/DGSallgemein/Ethik-Kodex_2017-06-10.pdf" target="_blank">Ethics Code</a> that also applies to the handling of research data. </li>\n\t\t\t<li>The <a href="https://www.dvpw.de/fileadmin/docs/2017-06-15_Ethik-Kodex__DVPW.pdf" target="_blank">Ethics Code</a> of the German Political Science Association (GPSA). </li> <li>The UNESCO <a\n\t\t\thref="http://www.unesco.org/new/fileadmin/MULTIMEDIA/HQ/SHS/pdf/Soc_Sci_Code.pdf" target="_blank">Code of conduct social science research </a>. </li> </ul> </div> </div> <div> <input\n\t\t\ttype="checkbox" name="acc" id="acc3"> <label for="acc3">Psychology/Education</label> <div class="acc-body"> Both for psychology and for educational research there are DFG\n\t\t\trecommendations: <ul> <li><a target="_blank" href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf"><span>memorandum of DFG review\n\t\t\tboard "Educational Research" </span></a></li> <li><a target="_blank"\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/empfehlungen_forschungsdaten_psychologie.pdf"><span>Recommendations for handling research data in psychology </span></a> (DGP Executive\n\t\t\tBoard) and <a target="_blank" href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/empfehlungen_forschungsdaten_psychologie_kommentar.pdf"> Comment of the DFG Review Board "Psychology"\n\t\t\t</a>.</li> <li><a target="_blank"\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/foerderkriterien_replikationsstudien_psychologie.pdf">DFG guidelines for replications studies in psychology\n\t\t\t(in German)</a></li> </ul> Note that specific funding programs can have additional requirements that supersede those in the general data policies. This is often the case for BMBF funding programs, for example the program <a\n\t\t\ttarget="_blank" href="https:/www.bmbf.de/foerderungen/bekanntmachung-1003.html"><span>"Bildung durch Sprache und Schrift (BiSS)"</span></a>. <br /> The German Psychological Society (DGP) has\n\t\t\t<a target="_blank" href="https://www.dgps.de/index.php?id=85#c2001837"> general guidelines regarding ethics and privacy</a>, which also mention research practices and thus apply to research data and handling of\n\t\t\tresearch data. The American Psychological Association follows a similar <a target="_blank" href="https://www.apa.org/ethics/code/" target="_blank">ethics code</a>. <br /> The Deutsche Gesellschaft für\n\t\t\tErziehungswissenschaft (DGfE) also provides an <a href="https://www.dgfe.de/fileadmin/OrdnerRedakteure/Satzung_etc/Ethikkodex_2010.pdf" target="_blank">ethics code</a>. </div> </div> <div> <input\n\t\t\ttype="checkbox" name="acc" id="acc4"> <label for="acc4">History/History of Art/Archaeology</label> <div class="acc-body"> There is currently (21.12.2019) no specific DFG policy\n\t\t\tfor history, history of art, archaeology or ancient studies. Some BMBF project lines do include additional requirements, but the specifics depend on the funding program.<br /> The data centre IANUS has some very general <a\n\t\t\ttarget="_blank" href="https://www.ianus-fdz.de/it-empfehlungen/">IT recommendations</a> for handling data in archaeology, history as well as classical and ancient studies. Note that the DFG Review Board for Social and\n\t\t\tCultural anthropology, non-European cultures, Judaic studies and religious studies does have <a target="_blank"\n\t\t\thref="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/handreichung_fachkollegium_106_forschungsdaten.pdf">specific guidelines</a>. </div> </div>	Beschreiben Sie alle Richtlinien nach denen sich das Projekt richtet. Das ist zumindest die FAU Datenpolicy. Die DFG-Empfehlungen und die Empfehlungen der Allianz der Wissenschaftsorganisationen sind, wenn auch nicht verpflichtend,\n\t\t\tmeist von Bedeutung. Fragen Sie hierzu auch bei ihren Projektpartnern nach, ob es von dort Vorgaben gibt. Viele Fachgesellschaften, Forschungsförderer, Datenzentren und Dachorganisationen haben eigene Empfehlungen und Policies zum Datenmanagement.\n\t\t\t<br /> Einige Beispiele für fachspezifische Empfehlungen und Richtlinien sind die nachfolgenden Regelungen: <div class="akkordeon"> <div> <input type="checkbox" name="acc" id="acc1">\n\t\t\t<label for="acc1">Sprachen & Literaturwiss.</label> <div class="acc-body"> <ul> <li><a\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/foerderkriterien_editionen_literaturwissenschaft.pdf"><span>Förderkriterien für Editionen in den Literaturwissenschaften\n\t\t\t(DFG)</span></a></li> <li>Richtlinien / Empfehlungen für Sprachkorpora / Linguistik: <ul> <li><a target="_blank" href="\n\t\t\thttps://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/guidelines_review_board_linguistics_corpora.pdf">Guidelines by the DFG Review Board on Linguistics</a></li> <li><a target="_blank"\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_recht.pdf"><span>rechtliche Aspekte im Umgang mit\n\t\t\tSprachkorpora</span></a></li> <li><a target="_blank"\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_sprachkorpora.pdf"><span>datentechnische Standards und Tools\n\t\t\tbei</span></a><span> der Erhebung von Sprachkorpora</span></li> </ul> </li> </ul> Einige Fachgesellschaften haben eigene Empfehlungen zum Umgang mit Forschungsdaten. So hat der DRV (Deutscher Romanisten\n\t\t\tVerband) das Positionspapier <a target="_blank" href="http://deutscher-romanistenverband.de/wp-content/uploads/sites/14/Open-Access-und-Forschungsdaten_Mrz-2017.pdf"><span>"Open Access und Forschungsdaten in der\n\t\t\tRomanistik"</span></a> herausgegeben. </div> </div> <div> <input type="checkbox" name="acc" id="acc2"> <label for="acc2">Sozial- /\n\t\t\tWirtschaftswissenschaften</label> <div class="acc-body"> Einige-BMBF Programme haben Anforderungen an das Datenmanagement, aber diese sind immer spezifisch für einzelne Förderprogramme. Die DFG verweist explizit auf einige\n\t\t\tRichtlinien / Anforderungen: <ul> <li><a target="_blank" ref="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/dgs_stellungnahme_forschungsdaten.pdf">Bereitstellung und Nachnutzung von\n\t\t\tForschungsdaten in der Soziologie: Stellungnahme des Vorstands und Konzils der DGS</a> (in German)</li> <li> <a target="_blank"\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/basisinformationen_forschungsdatenmanagement.pdf" target="_blank" >Basisinformationen zum Forschungsdatenmanagement</a> des RatSWD</li>\n\t\t\t<li>Anforderungen des <a target="_blank" href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/fachkollegium112_forschungsdatenmanagement_1811.pdf" target="_blank" >DFG Fachkollegium\n\t\t\t112 „Wirtschaftswissenschaften“</a> der DFG</li> </ul> Es gibt jedoch eine Vielzahl weitere Empfehlungen: <ul> <li><a target="_blank"\n\t\t\thref="http://www.ratswd.de/dl/RatSWD_Output3_Forschungsdatenmanagement.pdf">Richtlinien das RatSWD zum Datenmanagement in Sozial-, Verhaltens- und Wirtschaftswissenschaften </a></li> <li>Die <a\n\t\t\ttarget="_blank" href="https://www.gesis.org/en/gesis-survey-guidelines/operations/online-surveys/">GESIS Richtlinien</a> <u>für Umfragen</u> beinhalten verschiedene Best-Practice-Hilfen für Planung und\n\t\t\tDurchführung von Umfragen</li> <li>Der <a href="https://www.soziologie.de/fileadmin/user_upload/DGS_Redaktion_BE_FM/DGSallgemein/Ethik-Kodex_2017-06-10.pdf" target="_blank">Ethik-Kodex</a> der Deutschen\n\t\t\tGesellschaft für Soziologie (DGS) und des Berufsverbandes Deutscher Soziologinnen und Soziologen (BDS). </li> <li>Der <a href="https://www.dvpw.de/fileadmin/docs/2017-06-15_Ethik-Kodex__DVPW.pdf"\n\t\t\ttarget="_blank">Ethik-Kodex</a> der Deutschen Vereinigung für Politikwissenschaft (DVPW). </li> <li>Der UNESCO <a href="http://www.unesco.org/new/fileadmin/MULTIMEDIA/HQ/SHS/pdf/Soc_Sci_Code.pdf"\n\t\t\ttarget="_blank">Code of conduct social science research</a>. </ul> </div> </div> <div> <input type="checkbox" name="acc" id="acc3"> <label\n\t\t\tfor="acc3">Psychologie/Erziehungswiss.</label> <div class="acc-body"> Sowohl für die Psychologie als auch für die Erziehungswissenschaften hat die DFG gesonderte, zusätzlich Förderbedingungen bzw. Empfehlungen:\n\t\t\t<ul> <li><a target="_blank" href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_bildungsforschung.pdf"><span>Memorandum des Fachkollegiums\n\t\t\t„Erziehungswissenschaft“ der DFG</span></a></li> <li><a target="_blank"\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/empfehlungen_forschungsdaten_psychologie.pdf"><span>Empfehlungen zu Umgang mit Forschungsdaten in der Psychologie</span></a> (DGP Vorstand)\n\t\t\tund der <a target="_blank" href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/empfehlungen_forschungsdaten_psychologie_kommentar.pdf"><span>Kommentar des DFG Fachkollegs\n\t\t\t"Psychologie"</span></a> zu diesen Empfehlungen</li> <li><a target="_blank"\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/foerderkriterien_replikationsstudien_psychologie.pdf"><span>DFG Richtlinien für Replikationsstudien in\n\t\t\tder Psychologie</span></a></li> </ul> Einzelne Förderlinien haben manchmal eigene, strengere Auflagen, die die allgemeinen Anforderungen der Policies konkretisieren oder erweitern. Dies ist häufig der Fall bei BMBF-Programmen,\n\t\t\twie beispielsweise dem Programm <a href="https:/www.bmbf.de/foerderungen/bekanntmachung-1003.html"><span>"Bildung durch Sprache und Schrift (BiSS)"</span></a>. <br /> Der Berufsverband Deutscher\n\t\t\tPsychologinnen und Psychologen und die Deutsche Gesellschaft für Psychologie haben darüber hinaus <a target="_blank" href="https://www.dgps.de/index.php?id=85#c2001837"><span>Richtlinien zur (Berufs-)Ethik und zu\n\t\t\tPersönlichkeitsrechten</span></a>. Die American Psychological Association verfügt über einen ähnlichen <a href="https://www.apa.org/ethics/code/" target="_blank">Ethikkodex</a>. <br /> Die Deutsche\n\t\t\tGesellschaft für Erziehungswissenschaft (DGfE) verfügt ebenfalls über einen <a href="https://www.dgfe.de/fileadmin/OrdnerRedakteure/Satzung_etc/Ethikkodex_2010.pdf" target="_blank">Ethik-Kodex</a>. </div>\n\t\t\t</div> <div> <input type="checkbox" name="acc" id="acc4"> <label for="acc4">Geschichte/Kunstgeschichte/Archäologie</label> <div class="acc-body"> Das Datenzentrum\n\t\t\tIANUS hat mehrere <a target="_blank" href="https://www.ianus-fdz.de/it-empfehlungen/"><span>IT-Empfehlungen</span></a> zum Umgang mit Daten in der Archäologie, der Geschichte, den Altertumswissenschaften\n\t\t\tsowie der Archäologie herausgegeben, die Projekte als interne Richtlinien übernehmen können. Beachten Sie bitte sofern zutreffend auch die Anforderungen in der <a target="_blank"\n\t\t\thref="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/handreichung_fachkollegium_106_forschungsdaten.pdf">Handreichung des DFG Fachkollegiums 106</a> Sozial- und Kulturanthropologie, Außereuropäische\n\t\t\tKulturen, Judaistik und Religionswissenschaft. </div> </div> </div>	If there are other procedures, which ones?	Falls es weitere Vorgaben gibt, welche sind das?	textarea	text		3	163	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
393	2020-04-14 15:07:42.248+00	2020-04-14 15:07:42.248+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/other/funder-yesno/yesno	https://fdm-bayern.org/eHumanities	yesno	Horizon2020/other/funder-yesno/yesno		f	0	INST_POLICY_INFO_ENG Partner institutions may have of policies of their own and you should check with them. An incomplete overview of policies of German organizations can be found on <a\n\t\t\thref="http://www.forschungsdaten.org/index.php/Data_Policies#Institutionelle_Policies" target=_blank">forschungsdaten.org</a>.	INST_POLICY_INFO_DEU Beachten Sie auch, dass die verschiedenen Projektpartner eigene Policies haben können. Informieren Sie sich dort rechtzeitig. Eine unvollständige Liste der Richtlinien und Policies deutscher Einrichtungen finden\n\t\t\tsie auf <a href="http://www.forschungsdaten.org/index.php/Data_Policies#Institutionelle_Policies" target=_blank">forschungsdaten.org</a>.	Do you make use of other national/funder/sectorial/departmental procedures for data management?	Folgen Sie anderen Vorgaben bezüglich des Datenmanagements von institutioneller, nationaler, fachlicher Seite bzw. von anderen Förderorganisationen?	radio	boolean		4	164	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
394	2020-04-14 15:07:42.356+00	2020-04-14 15:07:42.356+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/project_details/project_info-PI/affiliation	https://fdm-bayern.org/eHumanities	affiliation	Horizon2020/project_details/project_info-PI/affiliation		f	3	If the PI has more than one affiliation, use a new line for each affiliation.\n\t\t	Falls die hauptverantwortliche Wissenschaftlerin oder der hauptverantwortliche Wissenschaftler Mitglied mehrerer Forschungsorganisationen ist, kann für jede Angabe eine eigene Zeile verwendet werden.\n\t\t	Affiliation:	Affiliation:	textarea	text		221	165	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
395	2020-04-14 15:07:42.409+00	2020-04-14 15:07:42.409+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/project_details/project_info-PI/data_contact	https://fdm-bayern.org/eHumanities	data_contact	Horizon2020/project_details/project_info-PI/data_contact		f	6	\N	\N	Is this PI contact person for questions regarding data and data management?	Kontaktperson für daten-bezogene Fragen?	yesno	boolean		222	165	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
396	2020-04-14 15:07:42.459+00	2020-04-14 15:07:42.459+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/project_details/project_info-PI/given_name	https://fdm-bayern.org/eHumanities	given_name	Horizon2020/project_details/project_info-PI/given_name		f	2	I case of more than one given name do not use separators, like commas, e.g., just "Amalie Emmy"	Geben Sie die Vornamen am besten ohne Trennzeichen an, beispielsweise: "Amalie Emmy".	Given name(s) of the Principal Investigator:	Vorname(n) des PI:	text	text		224	165	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
397	2020-04-14 15:07:42.509+00	2020-04-14 15:07:42.509+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/project_details/project_info-PI/mail	https://fdm-bayern.org/eHumanities	mail	Horizon2020/project_details/project_info-PI/mail		f	4	\N	\N	e-mail address:	E-Mail-Adresse:	text	text		223	165	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
398	2020-04-14 15:07:42.559+00	2020-04-14 15:07:42.559+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/project_details/project_info-PI/name	https://fdm-bayern.org/eHumanities	name	Horizon2020/project_details/project_info-PI/name		f	1	For example: "Noether".	Beispielsweise: "Noether".	Name of the Principal Investigator (PI):	Name der Projektleiterin / des Projektleiters (PI)	text	text		226	165	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
399	2020-04-14 15:07:42.607+00	2020-04-14 15:07:42.607+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/project_details/project_info-PI/orcid	https://fdm-bayern.org/eHumanities	orcid	Horizon2020/project_details/project_info-PI/orcid		f	5	The <a target="_blank" href="https://orcid.org/">ORCID</a> (Open Researcher and Contributer ID) is a unique identifier for researchers that tries to alleviate the problem of identifying scholars with common names.	Die <a target="_blank" href="https://orcid.org/">ORCID</a> (Open Researcher and Contributer ID) ist eine eindeutige Identifikationsnummer für Forschende. Mit einer ORCID lassen sich beispielsweise Aufsätze einfach der\n\t\t\trichtigen Wissenschaftlerin oder dem richtigen Wissenschaftler zuordnen.	ORCID:	ORCID:	text	text		227	165	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
400	2020-04-14 15:07:42.671+00	2020-04-14 15:07:42.671+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/project_details/project_info-project/grant_number	https://fdm-bayern.org/eHumanities	grant_number	Horizon2020/project_details/project_info-project/grant_number		f	0	\N	\N	If already available, what is the EC H2020 grant number?	Wie lautet - falls bereits verfügbar - das EC Horiont 2020 Förderkennzeichen?	text	text		155	166	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
487	2020-04-29 09:34:35.29+00	2020-11-08 14:54:49.383+00	http://example.com/terms/questions/GFBio test/general/projectName/project_name	http://example.com/terms	project_name	GFBio test/general/projectName/project_name		f	0	\N	\N	What is the official name of your research project?	Wie lautet der offizielle Name Ihres Forschungsprojekts?	textarea	text		241	205	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
489	2020-04-29 10:32:12.906+00	2020-11-08 14:54:49.567+00	http://example.com/terms/questions/GFBio test/general/reproducible/is_data_reproducible	http://example.com/terms	is_data_reproducible	GFBio test/general/reproducible/is_data_reproducible	define as a checkbox by the GFBio-DMP. I'd rather radio buttons	f	0	Imagine your data gets lost. Would you (or someone else) be able to reproduce your data? What effort or resources would be necessary?	Stellen Sie sich vor, Ihre Daten gehen verloren. Wären Sie (oder jemand anderes) in der Lage, Ihre Daten zu reproduzieren? Welcher Aufwand oder welche Ressourcen wären dafür nötig?	Is your research data reproducible?	Sind Ihre Forschungsdaten reproduzierbar?	checkbox	option		243	207	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
490	2020-04-29 10:39:18.616+00	2020-11-08 14:58:03.777+00	http://example.com/terms/questions/GFBio test/general/reproducible/additional_information	http://example.com/terms	additional_information	GFBio test/general/reproducible/additional_information		f	1	\N	\N	Add additional information (e.g. data reproduction might cause high costs or a lot of effort)	Zusätzliche Informationen hinzufügen (z.B. kann die Datenreproduktion hohe Kosten oder viel Aufwand verursachen)	textarea	text		244	207	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
491	2020-04-29 10:44:45.655+00	2020-11-08 14:59:24.712+00	http://example.com/terms/questions/GFBio test/general/projectTypes/Options	http://example.com/terms	Options	GFBio test/general/projectTypes/Options		f	0	You can combine several types	Sie können mehrere Typen kombinieren	Please specify your project type	Bitte geben Sie Ihren Projekttyp an	checkbox	option		245	208	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
492	2020-04-29 10:49:39.02+00	2020-11-08 14:59:42.533+00	http://example.com/terms/questions/GFBio test/general/projectAbstract/Description	http://example.com/terms	Description	GFBio test/general/projectAbstract/Description		f	1	\N	\N	Provide your project abstract or describe your work and the data involved.	Geben Sie eine Zusammenfassung Ihres Projekts oder beschreiben Sie Ihre Arbeit und die damit verbundenen Daten.	textarea	text		246	209	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
493	2020-04-29 10:55:10.07+00	2020-11-08 15:00:10.929+00	http://example.com/terms/questions/GFBio test/general/point_of_contact/PersonName	http://example.com/terms	PersonName	GFBio test/general/point_of_contact/PersonName		f	0	\N	\N	Who is the point of contact for the project data?	Wer ist die Anlaufstelle für die Projektdaten?	text	text		248	210	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
494	2020-04-29 11:06:24.093+00	2020-11-08 15:00:18.016+00	http://example.com/terms/questions/GFBio test/general/point_of_contact/phone_number	http://example.com/terms	phone_number	GFBio test/general/point_of_contact/phone_number		f	1	\N	\N	Who is the point of contact for the project data? (Phone number)	Wer ist die Anlaufstelle für die Projektdaten? (Telefonnummer)	text	integer		249	210	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
495	2020-04-29 11:13:14.391+00	2020-11-08 15:00:24.231+00	http://example.com/terms/questions/GFBio test/general/point_of_contact/email	http://example.com/terms	email	GFBio test/general/point_of_contact/email		f	2	\N	\N	Who is the point of contact for the project data? (E-Mail adress)	Wer ist die Anlaufstelle für die Projektdaten? (E-Mail Adresse)	text	text		250	210	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
496	2020-04-29 13:06:50.317+00	2020-11-08 14:54:48.989+00	http://example.com/terms/questions/GFBio test/general/investigators/principal_investigators	http://example.com/terms	principal_investigators	GFBio test/general/investigators/principal_investigators	how to include this field if we want it to be exact as the one in the DMPT?	f	0	\N	\N	Who are the principal investigators?	Wer sind die Hauptforscher?	radio	option		252	211	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
497	2020-04-29 13:51:29.337+00	2020-11-08 14:54:48.35+00	http://example.com/terms/questions/GFBio test/general/Funding/funder_or_programme_title	http://example.com/terms	funder_or_programme_title	GFBio test/general/Funding/funder_or_programme_title		f	0	Funding agencies or even funding programmes demand certain data management standards. We support you in meeting their requirements.	Finanzierungsagenturen oder sogar Finanzierungsprogramme verlangen bestimmte Datenverwaltungsstandards. Wir unterstützen Sie dabei, deren Anforderungen zu erfüllen.	For which funding are you applying?	Für welche Finanzierung bewerben Sie sich?	radio	option		253	212	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
498	2020-04-29 15:19:16.321+00	2020-11-08 15:01:19.39+00	http://example.com/terms/questions/GFBio test/general/coordinated_programme/Details	http://example.com/terms	Details	GFBio test/general/coordinated_programme/Details	Doubts about the attribute	f	0	\N	\N	If you are part of a coordinated programme (Koordinierte Programme, Verbundprojekte), is there any specific coordination, guideline or policy for data management?	Falls Sie Teil eines koordinierten Programms (Koordinierte Programme, Verbundprojekte) sind, gibt es eine spezifische Koordination, Richtlinie oder Politik für das Datenmanagement?	textarea	text		255	213	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
499	2020-04-30 09:54:24.815+00	2020-11-08 15:01:26.454+00	http://example.com/terms/questions/GFBio test/general/researchUnit/name	http://example.com/terms	name	GFBio test/general/researchUnit/name	external link to: https://www.dfg.de/en/research_funding/programmes/coordinated_programmes/research_units/index.html	f	0	https://www.dfg.de/en/research_funding/programmes/coordinated_programmes/research_units/index.html	https://www.dfg.de/en/research_funding/programmes/coordinated_programmes/research_units/index.html	Are you a member of a research unit (Forschungsgruppe)?	Sind Sie Mitglied einer Forschungseinheit (Forschungsgruppe)?	checkbox	option		257	214	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
500	2020-04-30 09:59:21.534+00	2020-11-08 14:54:48.297+00	http://example.com/terms/questions/GFBio test/general/Budget/total_budget	http://example.com/terms	total_budget	GFBio test/general/Budget/total_budget	The help text was added here / Der Hilfetext wurde hier hinzugefügt	f	0	Please provide your budget in Euros (€)	Bitte geben Sie Ihr Budget in Euro (€) an.	What is the total budget of your research proposal?	Wie hoch ist das Gesamtbudget Ihres Forschungsvorhabens?	text	float		258	215	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
501	2020-04-30 10:07:14.22+00	2020-11-08 15:01:47.734+00	http://example.com/terms/questions/GFBio test/general/policies or guidelines/for_RDM	http://example.com/terms	for_RDM	GFBio test/general/policies or guidelines/for_RDM	I'd rather use a selection 'button' for each option instead of a radio button, like in the DMPT	f	0	\N	\N	Which policies or guidelines for research data management will you follow?	Welche Richtlinien oder Vorgaben für die Verwaltung von Forschungsdaten werden Sie befolgen?	radio	option		260	219	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
508	2020-05-18 15:20:09.39+00	2020-11-08 14:54:46.086+00	http://example.com/terms/questions/GFBio test/Data_Collection/Data objects_1/dead or alive	http://example.com/terms	dead or alive	GFBio test/Data_Collection/Data objects_1/dead or alive		f	1	\N	\N	Is your object dead or alive?	Ist Ihr Objekt tot oder lebendig?	radio	boolean		287	237	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
509	2020-05-18 15:22:28.842+00	2020-11-08 14:54:46.224+00	http://example.com/terms/questions/GFBio test/Data_Collection/Data objects_2/taxon	http://example.com/terms	taxon	GFBio test/Data_Collection/Data objects_2/taxon		f	1	\N	\N	Is your object taxon-based?	Beruht Ihr Objekttaxon auf einem Taxon?	radio	boolean		239	238	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
510	2020-05-18 15:36:21.964+00	2020-11-08 14:54:46.361+00	http://example.com/terms/questions/GFBio test/Data_Collection/data objects_0/physical_object	http://example.com/terms	physical_object	GFBio test/Data_Collection/data objects_0/physical_object		f	0	\N	\N	Do you want to submit physical objects along with your data?	Möchten Sie physische Objekte zusammen mit Ihren Daten einreichen?	radio	boolean		238	220	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
511	2020-05-22 10:01:42.788+00	2020-05-22 10:05:10.554+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/Alternative GFBio/General/gfbio_other-requirements-yesno/gfbio_yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	gfbio_yesno	Alternative GFBio/General/gfbio_other-requirements-yesno/gfbio_yesno	copied from the DFG Catalog	f	0	Examples of discipline-specific requirements are: \n\n- <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/guidelines_biodiversity_research.pdf" target=_blank">Guidelines on the Handling of Research\n                                Data in Biodiversity Research</a> \n\n- <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/foerderkriterien_editionen_literaturwissenschaft.pdf" target=_blank">Elegibility criteria for funding for\n                                scholarly editions in the literary studies (German)</a> \n\n- Recommendations on <a href="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_sprachkorpora.pdf"\n                                target=_blank">data standards and tools</a> as well as <a href="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_recht.pdf" target=_blank">legal\n                                aspects</a> associated with language corpora (German)	Beispiele für fachspezifische Empfehlungen und Richtlinien sind: \n\n- <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_biodiversitaetsforschung.pdf" target=_blank">Richtlinien zum Umgang mit Forschungsdaten in der Biodiversitätsforschung</a>\n\n- <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/foerderkriterien_editionen_literaturwissenschaft.pdf" target=_blank">Förderkriterien für wissenschaftliche Editionen in der Literaturwissenschaft</a> \n\n- Empfehlungen zu <a href="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_sprachkorpora.pdf" target=_blank">datentechnischen Standards und Tools</a>\n                                sowie zu <a href="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_recht.pdf" target=_blank">rechtlichen Fragen</a> bei der Erhebung von Sprachkorpora	Are there requirements regarding the data management from your scholarly/scientific community?	Gibt es von Seiten Ihrer Fachcommunity Anforderungen an das Datenmanagement, die beachtet werden müssen?	radio	boolean		4	224	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
512	2020-07-06 13:35:30.224+00	2020-11-08 14:54:46.55+00	http://example.com/terms/questions/GFBio test/Data_Collection/data type/sequence data	http://example.com/terms	sequence data	GFBio test/Data_Collection/data type/sequence data		f	0	\N	\N	Do you have mainly sequence data?	Haben Sie hauptsächlich Sequenzdaten?	yesno	boolean		263	225	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
513	2020-07-06 13:40:09.48+00	2020-11-08 14:54:46.685+00	http://example.com/terms/questions/GFBio test/Data_Collection/data type/type of data	http://example.com/terms	type of data	GFBio test/Data_Collection/data type/type of data		f	1	You can combine several options	Sie können mehrere Optionen kombinieren	What type of data will you create?	Welche Art von Daten werden Sie erstellen?	checkbox	option		264	225	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
514	2020-07-06 13:59:58.491+00	2020-11-08 14:54:46.503+00	http://example.com/terms/questions/GFBio test/Data_Collection/data type/data_type_file_formats	http://example.com/terms	data_type_file_formats	GFBio test/Data_Collection/data type/data_type_file_formats		f	2	Please name all considered data formats. According on the DFG Guidelines on the Handling of Research Data in Biodiversity Research, we recommend the use of "open or opnely documented formats".\n\nList all data formats you are planning to produce and give additional information if necessary (such as "only legible with software xy"). there are loads of data formats and some disciplines even their own ones.	Bitte nennen Sie alle in Frage kommenden Datenformate. Gemäß den Richtlinien der DFG zum Umgang mit Forschungsdaten in der Biodiversitätsforschung empfehlen wir die Verwendung von "offenen oder offen dokumentierten Formaten".\n\nFühren Sie alle Datenformate auf, die Sie zu produzieren beabsichtigen, und geben Sie gegebenenfalls zusätzliche Informationen an (z.B. "nur mit Software xy lesbar"). Es gibt eine Vielzahl von Datenformaten und einige Disziplinen haben sogar ihre eigenen.	What file formats will you create?	Welche Dateiformate werden Sie erstellen?	textarea	text		265	225	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
515	2020-07-06 14:31:47.875+00	2020-11-08 15:02:47.049+00	http://example.com/terms/questions/GFBio test/Data_Collection/data volume/estimated	http://example.com/terms	estimated	GFBio test/Data_Collection/data volume/estimated		f	0	Please estimate roughly your expected data volume. Think about the data you plan to collect. Will there be any areal photos of video files? Multimedia files produce much more volume than e.g. spreadsheets do.	Bitte schätzen Sie Ihr erwartetes Datenvolumen grob ein. Denken Sie über die Daten nach, die Sie sammeln wollen. Wird es Flächenfotos von Videodateien geben? Multimediadateien erzeugen viel mehr Volumen als z.B. Tabellenkalkulationen.	Please estimate the data volume you will create.	Bitte schätzen Sie das Datenvolumen, das Sie erstellen werden.	radio	option		267	226	10	1	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
516	2020-07-06 14:50:16.178+00	2020-11-08 14:54:46.969+00	http://example.com/terms/questions/GFBio test/Data_Collection/data volume/estimate_number_data_sets	http://example.com/terms	estimate_number_data_sets	GFBio test/Data_Collection/data volume/estimate_number_data_sets		f	1	Do you plan to create a lot of single data sets or will there be only few? The amount of data sets you will create is closely linked to your style of working and managing data. For example, you could use a single spreadsheet for each planned vegetation mapping or you could as well put hundreds of vegetation mappings in a single spreadsheet. Just give a brief impression of how many data sets might result from your work.	Haben Sie vor, viele einzelne Datensätze zu erstellen, oder wird es nur wenige geben? Die Menge der Datensätze, die Sie erstellen werden, hängt eng mit Ihrer Art der Arbeit und der Datenverwaltung zusammen. Sie könnten zum Beispiel für jede geplante Vegetationskartierung ein einziges Arbeitsblatt verwenden oder auch hunderte von Vegetationskartierungen in einem einzigen Arbeitsblatt zusammenfassen. Geben Sie einfach einen kurzen Eindruck davon, wie viele Datensätze sich aus Ihrer Arbeit ergeben könnten.	Please estimate the number of data sets (files) you will create.	Bitte schätzen Sie die Anzahl der Datensätze (Dateien), die Sie erstellen werden.	radio	option		268	226	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
517	2020-07-06 15:09:47.662+00	2020-11-08 14:54:47.113+00	http://example.com/terms/questions/GFBio test/Data_Collection/standards_metodologies_or_tools/data_collection_detailed_standards	http://example.com/terms	data_collection_detailed_standards	GFBio test/Data_Collection/standards_metodologies_or_tools/data_collection_detailed_standards	external link to:\n https://gfbio.biowikifarm.net/wiki/Technical_Documentations	f	0	Try to document as detailed as possible and describe your workflows of data handling. Do you plan to use specific tools like Diversity Workbench or BExIS? Name common standards for data collection or methodologies you refer to. By clicking the link above you can find more information about tools and management systems in our wiki.	Versuchen Sie, so detailliert wie möglich zu dokumentieren und Ihre Arbeitsabläufe der Datenverarbeitung zu beschreiben. Planen Sie den Einsatz spezifischer Werkzeuge wie Diversity Workbench oder BExIS? Nennen Sie allgemeine Standards für die Datenerfassung oder Methoden, auf die Sie sich beziehen. Wenn Sie auf den obigen Link klicken, finden Sie weitere Informationen über Werkzeuge und Managementsysteme in unserem Wiki.\n\nÜbersetzt mit www.DeepL.com/Translator (kostenlose Version)	What standards, methodologies or tools will you use to collect, manage and process your data?	Welche Standards, Methoden oder Werkzeuge werden Sie zur Erfassung, Verwaltung und Verarbeitung Ihrer Daten verwenden?	textarea	text		270	227	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
576	2020-10-28 14:09:49.615+00	2020-10-28 14:09:49.615+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/yesno	https://rdmorganiser.github.io/terms	yesno	biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/yesno		f	1	\N	\N	Does this dataset have to preserved for the long-term?	Muss dieser Datensatz langfristig aufbewahrt werden?	yesno	boolean		102	262	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
518	2020-07-07 10:19:23.926+00	2020-11-08 15:03:17.147+00	http://example.com/terms/questions/GFBio test/Documentation_and_metadata/documentation_and_metadata01/schema_type	http://example.com/terms	schema_type	GFBio test/Documentation_and_metadata/documentation_and_metadata01/schema_type		f	0	In order to be able to read and interpret as well as archive and find your data in the future, metadata are needed. If you don't know which metadata standard to choose, please select 'other' and describe your type of documentation which will accompany the data.	Um Ihre Daten in Zukunft lesen und interpretieren sowie archivieren und finden zu können, werden Metadaten benötigt. Wenn Sie nicht wissen, welchen Metadatenstandard Sie wählen sollen, wählen Sie bitte "andere" und beschreiben Sie Ihre Art der Dokumentation, die die Daten begleiten soll.	Which metadata schema does your data support (if any)?	Welches Metadatenschema unterstützen Ihre Daten (falls vorhanden)?	checkbox	option		272	228	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
519	2020-07-07 10:41:57.807+00	2020-11-08 14:54:47.523+00	http://example.com/terms/questions/GFBio test/Ethics_and_legal_compliance/ethical_issues_and_legal_requirements/legal_requirements	http://example.com/terms	legal_requirements	GFBio test/Ethics_and_legal_compliance/ethical_issues_and_legal_requirements/legal_requirements		f	0	Will your data meet any ethical issues or legal requirements such as personally identifiable information? Data dealing with abundance of Red List Species needs to be handled according to the legal requirements and may not be easily published. In terms of handling genetic resources, the Nagoya Protocol has to be considered. If you feel uncertain about legal requirements, choose 'uncertain' and we support you in identifying your legal requiements.	Erfüllen Ihre Daten alle ethischen Fragen oder rechtlichen Anforderungen, wie z.B. persönlich identifizierbare Informationen? Daten, die sich mit der Fülle der Arten der Roten Liste befassen, müssen entsprechend den gesetzlichen Bestimmungen behandelt werden und sind möglicherweise nicht ohne weiteres zu veröffentlichen. Hinsichtlich des Umgangs mit genetischen Ressourcen ist das Nagoya-Protokoll zu beachten. Wenn Sie sich bezüglich der rechtlichen Anforderungen unsicher fühlen, wählen Sie "unsicher" und wir unterstützen Sie bei der Ermittlung Ihrer rechtlichen Anforderungen.	Which legal requirements will your research data meet?	Welche rechtlichen Anforderungen werden Ihre Forschungsdaten erfüllen?	checkbox	option		274	229	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
520	2020-07-07 14:11:56.736+00	2020-11-08 15:03:34.664+00	http://example.com/terms/questions/GFBio test/Ethics_and_legal_compliance/copyright_and_licensing/reuse	http://example.com/terms	reuse	GFBio test/Ethics_and_legal_compliance/copyright_and_licensing/reuse	by selecting an option a link should appear beneath	f	0	The overall goal of GFBio is to provide a sustainable, service oriented, national data infrastructure facilitating data sharing. Thus, we support the idea of open access to data. Attaching a corresponding license to your data is an important part of data management. Open access does not mean everyone can use your data at his leisure. Data can be cited as well as publications can be. Licenses define citation demands as well as further terms of use, e.g. if data my be remixed or transformed.	Das übergeordnete Ziel von GFBio ist die Bereitstellung einer nachhaltigen, serviceorientierten, nationalen Dateninfrastruktur, die den Datenaustausch erleichtert. Daher unterstützen wir die Idee des offenen Zugangs zu Daten. Das Anbringen einer entsprechenden Lizenz an Ihre Daten ist ein wichtiger Teil des Datenmanagements. Open Access bedeutet nicht, dass jeder Ihre Daten nach Belieben nutzen kann. Daten können ebenso zitiert werden wie Publikationen. Lizenzen definieren Zitationsforderungen sowie weitere Nutzungsbedingungen, z.B. wenn Daten remixed oder transformiert werden können.	How will your data be licensed for reuse	Wie werden Ihre Daten zur Wiederverwendung lizenziert?	select	option		275	230	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
521	2020-07-08 09:48:49.381+00	2020-11-08 14:54:47.665+00	http://example.com/terms/questions/GFBio test/Ethics_and_legal_compliance/reuse_restrictions/access_restriction_to_data	http://example.com/terms	access_restriction_to_data	GFBio test/Ethics_and_legal_compliance/reuse_restrictions/access_restriction_to_data	The condition (equals=yes) makes the next  2 questions visible in the interview	f	0	\N	\N	Do you need access restriction for your data?	Brauchen Sie eine Zugangsbeschränkung für Ihre Daten?	radio	boolean		276	231	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
522	2020-07-08 09:57:36.628+00	2020-11-08 14:54:47.431+00	http://example.com/terms/questions/GFBio test/Ethics_and_legal_compliance/data_sharing_restrictions/lenght_exclusive_use_data	http://example.com/terms	lenght_exclusive_use_data	GFBio test/Ethics_and_legal_compliance/data_sharing_restrictions/lenght_exclusive_use_data	if the answer in the previous question is YES	f	0	\N	\N	For how long do you need exclusive use of the data?	Für wie lange benötigen Sie eine exklusive Nutzung der Daten?	textarea	text		282	232	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
523	2020-07-08 09:58:45.402+00	2020-11-08 14:54:47.48+00	http://example.com/terms/questions/GFBio test/Ethics_and_legal_compliance/data_sharing_restrictions/reason_exclusive_use_data	http://example.com/terms	reason_exclusive_use_data	GFBio test/Ethics_and_legal_compliance/data_sharing_restrictions/reason_exclusive_use_data		f	1	\N	\N	Why do you need exclusive use of the data?	Warum brauchen Sie eine exklusive Nutzung der Daten?	textarea	text		283	232	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
524	2020-07-08 10:12:40.363+00	2020-11-08 14:54:48.083+00	http://example.com/terms/questions/GFBio test/Preservation_and_Sharing/retain_share_preserve/time_data_submission_to_GFBio	http://example.com/terms	time_data_submission_to_GFBio	GFBio test/Preservation_and_Sharing/retain_share_preserve/time_data_submission_to_GFBio		f	0	Submit the final and quality-assured version of your datasets. Metadata will be curated by our data centers and will subsequently be published via the GFBio portal. Research data will be published within the klimit of their respective embargo and license.	Reichen Sie die endgültige und qualitätsgesicherte Version Ihrer Datensätze ein. Die Metadaten werden von unseren Datenzentren kuratiert und anschliessend über das GFBio-Portal veröffentlicht. Forschungsdaten werden im Rahmen der jeweiligen Embargo- und Lizenzgrenzen veröffentlicht.	When will your data be submitted to GFBio?	Wann werden Ihre Daten an GFBio übermittelt?	checkbox	option		278	233	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
525	2020-07-08 10:42:12.239+00	2020-11-08 14:54:48.226+00	http://example.com/terms/questions/GFBio test/Preservation_and_Sharing/storage_and_backup/data_backup	http://example.com/terms	data_backup	GFBio test/Preservation_and_Sharing/storage_and_backup/data_backup		f	0	With which technologies and in which locations are your data stored? Are there regular backups and at what intervals? Who is responsible for data backup and which service providers (e.g. local IT support) are involved?	Mit welchen Technologien und an welchen Orten werden Ihre Daten gespeichert? Gibt es regelmässige Backups und in welchen Abständen? Wer ist für die Datensicherung verantwortlich und welche Dienstleister (z.B. lokaler IT-Support) sind involviert?	How is your data backed up during project runtime? Who is responsible for data backup?	Wie werden Ihre Daten während der Projektlaufzeit gesichert? Wer ist für die Datensicherung verantwortlich?	textarea	text		279	234	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
526	2020-07-08 14:28:02.675+00	2020-11-08 14:54:47.944+00	http://example.com/terms/questions/GFBio test/Preservation_and_Sharing/long_term_preservation_data/place_data_long_term_archiving	http://example.com/terms	place_data_long_term_archiving	GFBio test/Preservation_and_Sharing/long_term_preservation_data/place_data_long_term_archiving		f	0	If you are not sure which data center fits best for your data, choose "GFBio Data Center" and our curation experts will find the best solution for storing your data within GFBio.	Wenn Sie nicht sicher sind, welches Rechenzentrum am besten zu Ihren Daten passt, wählen Sie "GFBio Data Center" und unsere Kurationsexperten werden die beste Lösung für die Speicherung Ihrer Daten innerhalb von GFBio finden.	Where will your data be long-term archived?	Wo werden Ihre Daten langfristig archiviert?	checkbox	option		280	235	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
527	2020-07-08 14:38:52.307+00	2020-11-08 14:54:47.802+00	http://example.com/terms/questions/GFBio test/Preservation_and_Sharing/Data_citation/requirement_persistent_identifier	http://example.com/terms	requirement_persistent_identifier	GFBio test/Preservation_and_Sharing/Data_citation/requirement_persistent_identifier		f	0	With a persistent identifier (PID) - like DOI- you make your data citable and linkable to publications which is increasingly required by journals. GFBio recommends to add a PID to your data.	Mit einem Persistent Identifier (PID) - wie DOI - machen Sie Ihre Daten zitierfähig und verknüpfbar mit Publikationen, was von Zeitschriften zunehmend gefordert wird. GFBio empfiehlt, Ihre Daten mit einem PID zu versehen.	Do you need a persistent identifier (e.g. ePIC PID / DOI) for your data?	Benötigen Sie einen persistenten Identifikator (z.B. ePIC PID / DOI) für Ihre Daten?	radio	option		281	236	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
528	2020-10-28 14:09:44.872+00	2020-10-28 14:09:44.872+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/content-classification/data-dataset/description	https://rdmorganiser.github.io/terms	description	biodiversity_dfg/content-classification/data-dataset/description		f	1	In the <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/guidelines_biodiversity_research.pdf" target=_blank>Guidelines on the Handling of Research Data in Biodiversity Research</a>, "kind (individual, tissue, etc.) and type of data (picture, audio, text, source code, numbers)" are recommended.	In den <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_biodiversitaetsforschung.pdf" target=_blank>Richtlinien zum Umgang mit Forschungsdaten in der Biodiversitätsforschung</a> werden Angaben "zu Art  (Individuum, Gewebe,… ) und Typ der Daten (Bild, Audio, Text, Sourcecode, Zahlen)" empfohlen.	What kind of dataset is it?	Um was für einen Datensatz handelt es sich?	textarea	text		61	239	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
529	2020-10-28 14:09:44.924+00	2020-10-28 14:09:44.924+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/content-classification/data-reproducibility/reproducibility	https://rdmorganiser.github.io/terms	reproducibility	biodiversity_dfg/content-classification/data-reproducibility/reproducibility		f	2	Some data can, technically, be created anew at any time, as is the case with scientific experiments or digitised versions of analog objects (as long as the originals are still there and in good shape). However, this can consume a\n                                        considerable amount of time and cost. With respect to long-term preservation, the effort of re-creation has to be weighed up against the effort of long-term preservation. Other data cannot be collected or created anew. Examples are all kinds of "time\n                                        stamped" observations, be they from social science, astrophysics or any other discipline. Observations represent a certain phenomenon at a certain time and / or place and are therefore not repeatable. Their value for re-use as well as the loss in\n                                        case of failed preservation is much higher than that of reproducible data.	Manche Daten können im Prinzip jederzeit neu erstellt werden. Beispiele hierfür sind etwa naturwissenschaftliche Experimentdaten oder auch Digitalisate analoger Objekte (solange die Originale nicht verlorengehen). Der Aufwand und die\n                                        Kosten hierfür können natürlich durchaus beträchtlich sein. Im Hinblick auf die Frage der Notwendigkeit einer späteren Langzeitarchivierung sollte in diesen Fällen der Aufwand einer erneuten Erstellung gegen den Aufwand der Langzeitarchivierung\n                                        abgewogen werden. Andere Daten wiederum lassen sich per se nicht erneut erheben. Dies ist etwa bei jeglicher Art von episodischer Beobachtungen, sei es sozialwissenschaftlicher oder naturwissenschaftlicher Art, der Fall, da diese ein bestimmtes\n                                        Phänomen an einem bestimmten Zeitpunkt und/oder Ort abbilden und somit i.d.R. nicht wiederholbar sind. Ihr Wert für die Nachnutzung durch andere wie auch der Verlust bei einer nicht erfolgten oder misslungenen Langzeitarchivierung ist ungleich höher\n                                        als bei reproduzierbaren Daten.	Is the dataset reproducible in the sense that it could be created / collected anew in case it got lost?	Ist der Datensatz reproduzierbar, d. h. ließe sich er sich, wenn er verloren ginge, erneut erstellen oder erheben?	radio	text		105	240	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
530	2020-10-28 14:09:45.032+00	2020-10-28 14:09:45.032+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/content-classification/data-reuse/scenario	https://rdmorganiser.github.io/terms	scenario	biodiversity_dfg/content-classification/data-reuse/scenario		f	1	It is important to set the fundamental course as to whether or not the data will be permitted for reuse. Of course, the potential for subsequent use can not be the sole decision criterion, but legal impediments, such as privacy, copyright and business secrets must be taken into account. Otherwise, consider the re-use potential against the disadvantages, e.g. a decrease in the readiness to participate and the expected extra effort of a data publication.	Wichtig ist die grundsätzliche Weichenstellung, ob die Daten zur Nachnutzung zugelassen werden oder nicht. Selbstverständlich kann das Nachnutzungspotential dabei nicht alleiniges Entscheidungskriterium sein, sondern rechtliche Hinderungsgründe, wie z.B. Datenschutz, Urheberrecht und die Wahrung von Geschäftsgeheimnissen, müssen berücksichtigt werden. Wägen Sie ansonsten das Nachnutzungspotential gegen die Nachteile ab, beispielsweise gegen ein Absinken der Teilnahmebereitschaft und den zu erwartenden Mehraufwand einer Datenveröffentlichung.	Which individuals, groups or institutions could be interested in re-using this dataset? What are possible scenarios? What consequences does the re-use potential have for the provision of the data later?	Für welche Personen, Gruppen oder Institutionen könnte dieser Datensatz (für die Nachnutzung) von Interesse sein? Für welche Szenarien ist dies denkbar? Welche Konsequenzen hat das Nachnutzungspotential später für die Bereitstellung der Daten?	textarea	text		106	241	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
531	2020-10-28 14:09:45.099+00	2020-10-28 14:09:45.099+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/costs-dataset/creation_non_personnel	https://rdmorganiser.github.io/terms	creation_non_personnel	biodiversity_dfg/data-usage/costs-dataset/creation_non_personnel		f	2	Please estimate the effort in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel-costs for data management associated with the creation or acquisiton of data in the project?	Welche Sachkosten für das Datenmanagement entstehen im Rahmen der Erhebung, Erstellung oder Akquise der Daten im Projekt?	text	float	Euro	9	242	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
532	2020-10-28 14:09:45.186+00	2020-10-28 14:09:45.186+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/costs-dataset/creation_personnel	https://rdmorganiser.github.io/terms	creation_personnel	biodiversity_dfg/data-usage/costs-dataset/creation_personnel		f	1	Please estimate the effort in person months.	Bitte schätzen sie den Aufwand in Personenmonaten.	What are the personnel costs for data management associated with the creation or acquisition of data in the project?	Welcher Personalaufwand für das Datenmanagement entsteht im Rahmen der Erhebung, Erstellung oder Akquise der Daten im Projekt?	range	float	PM	10	242	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
533	2020-10-28 14:09:45.241+00	2020-10-28 14:09:45.241+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/costs-dataset/storage_non_personnel	https://rdmorganiser.github.io/terms	storage_non_personnel	biodiversity_dfg/data-usage/costs-dataset/storage_non_personnel		f	6	Please estimate the costs in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel costs associated with the storage of the data sets during the project?	Welche Sachkosten entstehen im Zusammenhang mit der Speicherung der Datensätze während des Projektes?	text	float	Euro	32	242	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
535	2020-10-28 14:09:45.352+00	2020-10-28 14:09:45.352+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/costs-dataset/usage_non_personnel	https://rdmorganiser.github.io/terms	usage_non_personnel	biodiversity_dfg/data-usage/costs-dataset/usage_non_personnel		f	4	Please estimate the costs in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel-costs for data management associated with the usage of data in the project?	Welche Sachkosten für das Datenmanagement entstehen im Zusammenhang mit der Nutzung der Daten im Projekt?	text	float	Euro	35	242	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
536	2020-10-28 14:09:45.404+00	2020-10-28 14:09:45.404+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/costs-dataset/usage_personnel	https://rdmorganiser.github.io/terms	usage_personnel	biodiversity_dfg/data-usage/costs-dataset/usage_personnel		f	3	Please estimate the effort in person months.	Bitte schätzen sie den Aufwand in Personenmonaten.	What are the personnel costs for data management associated with the the usage of data in the project?	Welcher Personalaufwand für das Datenmanagement entsteht im Zusammenhang mit der Nutzung der Daten im Projekt?	range	float	PM	36	242	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
537	2020-10-28 14:09:45.454+00	2020-10-28 14:09:45.454+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-sharing-and-re-use-publication/conditions	https://rdmorganiser.github.io/terms	conditions	biodiversity_dfg/data-usage/data-sharing-and-re-use-publication/conditions		t	3	The options refer to the licenses of the <a href="https://creativecommons.org/share-your-work/licensing-types-examples/" target=_blank">Creative Commons family</a>. From the <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/guidelines_biodiversity_research.pdf" target=_blank>Guidelines on the Handling of Research Data in Biodiversity Research</a>: Expected is information "on which conditions re-use will be rendered possible and, if applicable, who will decide this in the long term".	Die Auswahlmöglichkeiten orientieren sich hier an Lizenzen der <a href="http://de.creativecommons.org/" target=_blank">Creative-Commons-Familie</a>. In den <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_biodiversitaetsforschung.pdf" target=_blank>Richtlinien zum Umgang mit Forschungsdaten in der Biodiversitätsforschung</a> werden Angaben empfohlen, "unter welchen Bedingungen eine Nachnutzung ermöglicht wird und ggfls. wer hierüber langfristig entscheidet".	If yes, under which terms of use or license will the dataset be published or shared?	Wenn ja, unter welchen Nutzungsbedingungen oder welcher Lizenz sollen die Daten veröffentlicht bzw. geteilt werden?	checkbox	text		122	243	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
538	2020-10-28 14:09:45.553+00	2020-10-28 14:09:45.553+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-sharing-and-re-use-publication/data_publication_date	https://rdmorganiser.github.io/terms	data_publication_date	biodiversity_dfg/data-usage/data-sharing-and-re-use-publication/data_publication_date		f	6	\N	\N	When will the data be published (if they are)?	Wann werden die Daten veröffentlicht?	date	datetime		53	243	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
539	2020-10-28 14:09:45.643+00	2020-10-28 14:09:45.643+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-sharing-and-re-use-publication/explanation	https://rdmorganiser.github.io/terms	explanation	biodiversity_dfg/data-usage/data-sharing-and-re-use-publication/explanation		f	2	\N	\N	If no, please explain why not. Please differentiate between legal and contractual reasons and voluntary restrictions.	Wenn nicht, begründen Sie dies bitte und unterscheiden Sie dabei zwischen rechtlichen und/oder vertraglichen Gründen und freiwilligen Einschränkungen.	textarea	text		123	243	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
540	2020-10-28 14:09:45.707+00	2020-10-28 14:09:45.707+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-sharing-and-re-use-publication/restrictions_explanation	https://rdmorganiser.github.io/terms	restrictions_explanation	biodiversity_dfg/data-usage/data-sharing-and-re-use-publication/restrictions_explanation		f	4	\N	\N	If there are any restrictions on the re-use of this dataset, please explain why.	Sollte die Nachnutzung dieses Datensatzes Einschränkungen unterliegen, erläutern Sie bitte die Gründe.	textarea	text		125	243	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
541	2020-10-28 14:09:45.759+00	2020-10-28 14:09:45.759+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-sharing-and-re-use-publication/yesno	https://rdmorganiser.github.io/terms	yesno	biodiversity_dfg/data-usage/data-sharing-and-re-use-publication/yesno		f	1	From the <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/guidelines_biodiversity_research.pdf" target=_blank>Guidelines on the Handling of Research Data in Biodiversity Research</a>:\n\nEnabling free public access to data deriving from DFG-funded research should be the norm. Restrictions due to legal, copyright or ethical aspects will be approved after corresponding justification.	Aus den <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_biodiversitaetsforschung.pdf" target=_blank>Richtlinien zum Umgang mit Forschungsdaten in der Biodiversitätsforschung</a>:\n\nDie Ermöglichung des öffentlichen, kostenlosen Zugangs zu Daten, die aus DFG finanzierter Forschung stammen, sollte die Regel sein. Eine Einschränkung aufgrund rechtlicher, urheberrechtlicher oder ethischer  Aspekte wird nach entsprechender Begründung anerkannt.	Will this dataset be published or shared?	Soll dieser Datensatz veröffentlicht oder geteilt werden?	radio	boolean		127	243	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
542	2020-10-28 14:09:45.858+00	2020-10-28 14:09:45.858+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-storage-and-security-data_security/access_permissions	https://rdmorganiser.github.io/terms	access_permissions	biodiversity_dfg/data-usage/data-storage-and-security-data_security/access_permissions		f	1	\N	\N	Who is allowed to access the dataset?	Wer darf auf den Datensatz zugreifen?	textarea	text		55	244	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
543	2020-10-28 14:09:45.912+00	2020-10-28 14:09:45.912+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-storage-and-security-data_security/backups	https://rdmorganiser.github.io/terms	backups	biodiversity_dfg/data-usage/data-storage-and-security-data_security/backups		f	2	This question refers to backups while the data is being worked with. Questions of long-term preservation will be adressed in the respective section.	Die Frage bezieht sich auf Backups während der Zeit, in denen mit den Daten gearbeitet wird. Fragen der Langzeitarchivierung werden gesondert im entsprechenden Abschnitt behandelt.	How and how often will backups of the data be created?	Wie und wie oft werden Backups der Daten erstellt?	textarea	text		58	244	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
544	2020-10-28 14:09:45.959+00	2020-10-28 14:09:45.959+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-storage-and-security-data_security/security_measures	https://rdmorganiser.github.io/terms	security_measures	biodiversity_dfg/data-usage/data-storage-and-security-data_security/security_measures		f	4	\N	\N	Which measures or provisions are in place to ensure data security (e.g. protection against unauthorized access, data recovery, transfer of sensitive data)?	Welche Maßnahmen zur Gewährleistung der Datensicherheit werden getroffen (z. B. Schutz vor unbefugtem Zugriff, Datenwiederherstellung, Übertragung sensibler Daten)?	textarea	text		60	244	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
545	2020-10-28 14:09:46.024+00	2020-10-28 14:09:46.024+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-storage-and-security-storage/naming_policy	https://rdmorganiser.github.io/terms	naming_policy	biodiversity_dfg/data-usage/data-storage-and-security-storage/naming_policy		f	4	\N	\N	Is there a internal project guideline for naming the data? If so, please briefly outline the naming conventions and, if necessary, link to the documentation.	Gibt es eine projektinterne Richtlinie zur Benennung der Daten? Wenn ja, bitte skizzieren Sie sie kurz und verlinken Sie ggf. zu einer ausführlicheren Dokumentation.	radio	text		133	245	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
546	2020-10-28 14:09:46.125+00	2020-10-28 14:09:46.125+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-storage-and-security-storage/organisation_policy	https://rdmorganiser.github.io/terms	organisation_policy	biodiversity_dfg/data-usage/data-storage-and-security-storage/organisation_policy		f	3	\N	\N	Are there internal project guidelines for a consistent organisation of the data? If so, where they are documented?	Gibt es projektinterne Richtlinien zur einheitlichen Organisation der Daten? Wenn ja, wo sind diese festgehalten?	radio	text		134	245	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
547	2020-10-28 14:09:46.225+00	2020-10-28 14:09:46.225+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-storage-and-security-storage/type	https://rdmorganiser.github.io/terms	type	biodiversity_dfg/data-usage/data-storage-and-security-storage/type		f	1	If parts of the documentation or related software (custom development) are not stored with the data, also indicate where they are stored. This applies to the documentation of the software too.	Falls Teile der Dokumentation oder zugehöriger, selbst entwickelter Software nicht mit dem Datensatz zusammen gespeichert sind, sollten Sie auch angeben, wo diese gespeichert sind. Das gilt auch für die Dokumentation der Software.	Where is the dataset stored during the project?	Wo wird der Datensatz während des Projektes gespeichert?	textarea	text		135	245	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
548	2020-10-28 14:09:46.274+00	2020-10-28 14:09:46.274+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-tools/creation_methods	https://rdmorganiser.github.io/terms	creation_methods	biodiversity_dfg/data-usage/data-tools/creation_methods		f	1	This information is necessary to be able to reconstruct the process by which the data was generated. It is also a prerequisite to judge the objectivity, reliability and validity of the dataset. For reproducible data, it is also\n                                        required to re-generate the data if need be.	Diese Informationen sind für alle Arten von Daten relevant, um ihre Genese nachvollziehen zu können. Bei reproduzierbaren Daten kommt ein weiterer Aspekt hinzu. Diese müssen nicht notwendigerweise aufbewahrt werden - allerdings müssen\n                                        alle Geräte, Software und auch Informationen über die Vorgehensweise erhalten bleiben, die notwendig sind, um die Daten erneut erstellen zu können.	Which tools, software, technologies or processes are used to generate or collect the data?	Welche Instrumente, Software, Technologien oder Verfahren werden zur Erzeugung oder Erfassung der Daten genutzt?	textarea	text		44	246	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
549	2020-10-28 14:09:46.336+00	2020-10-28 14:09:46.337+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-tools/documentation	https://rdmorganiser.github.io/terms	documentation	biodiversity_dfg/data-usage/data-tools/documentation		f	3	\N	\N	Is documentation about relevant software needed to use the data?	Wird die Dokumentation von ggf. zur Nutzung notwendiger Software benötigt, um die Daten zu nutzen?	yesno	boolean		131	246	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
550	2020-10-28 14:09:46.4+00	2020-10-28 14:09:46.4+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-tools/usage_technology	https://rdmorganiser.github.io/terms	usage_technology	biodiversity_dfg/data-usage/data-tools/usage_technology		f	2	To be able to re-use data (e.g. to replicate studies, for meta analysis or to solve new research questions), along with the data the software, equipment and knowledge about special methods to use the data are required. Just as with\n                                        the formats, the recommendation is: the more standardised, open and established, the better for re-use.	Um Daten nachnutzen zu können, bspw. für die Replikation von Studien, Metaanalysen oder die Beantwortung neuer Forschungsfragen, werden neben den Daten selbst auch die Software, Geräte etc. und das Wissen über spezielle Verfahren zur\n                                        Nutzung benötigt. Ebenso wie bei den Formaten gilt hier: je standardisierter, offener und etablierter diese sind, desto einfacher ist i.d.R. eine Nachnutzung möglich.	Which software, processes or technologies are necessary to use the data?	Welche Software, Verfahren oder Technologien sind notwendig, um die Daten zu nutzen?	textarea	text		144	246	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
551	2020-10-28 14:09:46.438+00	2020-10-28 14:09:46.438+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/quality-assurance-dataset/measures	https://rdmorganiser.github.io/terms	measures	biodiversity_dfg/data-usage/quality-assurance-dataset/measures		f	7	\N	\N	Which measures of quality assurance are taken for this dataset?	Welche Maßnahmen zur Qualitätssicherung werden für diesen Datensatz ergriffen?	textarea	text		103	247	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
552	2020-10-28 14:09:46.487+00	2020-10-28 14:09:46.487+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/doc/metadata-costs/non_personnel	https://rdmorganiser.github.io/terms	non_personnel	biodiversity_dfg/doc/metadata-costs/non_personnel		f	2	Please estimate the costs in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel-costs associated with the documention and the creation of metadata and context information in the project?	Welche Sachkosten entstehen im Zusammenhang mit der Dokumentation und der Erstellung von Metadaten und Kontextinformation im Projekt?	text	float	Euro	15	248	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
553	2020-10-28 14:09:47.859+00	2020-10-28 14:09:47.859+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/doc/metadata-costs/personnel	https://rdmorganiser.github.io/terms	personnel	biodiversity_dfg/doc/metadata-costs/personnel		f	1	Please estimate the effort in person months.	Bitte schätzen sie den Aufwand in Personenmonaten.	What are the personnel costs associated with the data documentation and the creation of metadata in the project?	Welcher Personalaufwand entsteht im Zusammenhang mit der Datendokumentation und der Erstellung der Metadaten im Projekt?	range	float	PM	16	248	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
554	2020-10-28 14:09:47.899+00	2020-10-28 14:09:47.899+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/doc/metadata-dataset/documentation	https://rdmorganiser.github.io/terms	documentation	biodiversity_dfg/doc/metadata-dataset/documentation		f	4	Context of the investigations, methods used, etc.	Kontext der Untersuchungen, eingesetzte Methoden,…	Which components of the data documentation are available together with the dataset?	Welche Komponenten der Datendokumentation stehen zusammen mit dem Datensatz zur Verfügung?	textarea	text		\N	249	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
555	2020-10-28 14:09:47.941+00	2020-10-28 14:09:47.941+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/doc/metadata-dataset/standards	https://rdmorganiser.github.io/terms	standards	biodiversity_dfg/doc/metadata-dataset/standards		t	1	Also specify the metadata standard if it is already clear which one to use, e.g. because the repository specifies one.	Geben Sie auch den Metadatenstandard an, wenn bereits klar ist, welcher verwendet werden soll, z.B. weil das Repositorium einen vorgibt.	Which standards, ontologies, classifications etc. are used to describe the data?	Welche Standards, Ontologien, Klassifikationen etc. werden zur Beschreibung der Daten genutzt?	checkbox	text		83	249	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
556	2020-10-28 14:09:48.005+00	2020-10-28 14:09:48.005+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/general/other-requirements-requirements/requirements	https://rdmorganiser.github.io/terms	requirements	biodiversity_dfg/general/other-requirements-requirements/requirements		f	0	Please briefly outline them and refer to more detailed sources of information if necessary. Please also indicate, if the rules / guidelines are mandatory or optional.	Bitte skizzieren Sie sie kurz und verweisen Sie ggf. auf weiterführende Informationen. Geben Sie bitte auch an, welchen Grad an Verbindlichkeit sie haben.	Which are these additional requirements regarding data management?	Welche Anforderungen an das Datenmanagement sind dies?	textarea	text		3	250	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
557	2020-10-28 14:09:48.049+00	2020-10-28 14:09:48.049+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/general/other-requirements-yesno/yesno	https://rdmorganiser.github.io/terms	yesno	biodiversity_dfg/general/other-requirements-yesno/yesno		f	0	\N	\N	Are there requirements regarding the data management from your scholarly/scientific community?	Gibt es von Seiten Ihrer Fachcommunity Anforderungen an das Datenmanagement, die beachtet werden müssen?	radio	boolean		4	251	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
558	2020-10-28 14:09:48.128+00	2020-10-28 14:09:48.128+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/general/support/datamanagement	https://rdmorganiser.github.io/terms	datamanagement	biodiversity_dfg/general/support/datamanagement		f	1	\N	\N	Who provides support for research data management issues for the project?	Wer leistet Unterstützung in Fragen des Forschungsdatenmanagements für das Projekt?	textarea	text		207	252	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
559	2020-10-28 14:09:48.194+00	2020-10-28 14:09:48.194+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/legal-and-ethics/intellectual-property-rights-costs/non_personnel	https://rdmorganiser.github.io/terms	non_personnel	biodiversity_dfg/legal-and-ethics/intellectual-property-rights-costs/non_personnel		f	3	Please estimate the costs in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel-costs regarding intellectual property rights in the project?	Welche Sachkosten entstehen im Zusammenhang mit Urheber- und verwandten Schutzrechten im Projekt?	text	float	Euro	12	253	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
560	2020-10-28 14:09:48.247+00	2020-10-28 14:09:48.247+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/legal-and-ethics/intellectual-property-rights-costs/personnel	https://rdmorganiser.github.io/terms	personnel	biodiversity_dfg/legal-and-ethics/intellectual-property-rights-costs/personnel		f	1	Please estimate the effort in person months.	Bitte schätzen sie den Aufwand in Personenmonaten.	What are the personnel costs associated with intellectual property rights in the project?	Welcher Personalaufwand entsteht im Zusammenhang mit Urheber- oder verwandten Schutzrechten im Projekt?	range	float	PM	13	253	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
561	2020-10-28 14:09:48.295+00	2020-10-28 14:09:48.295+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/legal-and-ethics/intellectual-property-rights-dataset/copyrights	https://rdmorganiser.github.io/terms	copyrights	biodiversity_dfg/legal-and-ethics/intellectual-property-rights-dataset/copyrights		t	0	\N	\N	Does copyright law apply to this dataset?	Be- oder entstehen an diesem Datensatz Urheberrechte?	checkbox	text		68	254	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
562	2020-10-28 14:09:48.41+00	2020-10-28 14:09:48.41+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/legal-and-ethics/intellectual-property-rights-dataset/other_rights	https://rdmorganiser.github.io/terms	other_rights	biodiversity_dfg/legal-and-ethics/intellectual-property-rights-dataset/other_rights		t	2	\N	\N	Do other intellectual property rights apply to this dataset?	Be- oder entstehen an diesem Datensatz andere Schutzrechte?	checkbox	text		69	254	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
563	2020-10-28 14:09:48.508+00	2020-10-28 14:09:48.508+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/legal-and-ethics/intellectual-property-rights-yesno/yesno	https://rdmorganiser.github.io/terms	yesno	biodiversity_dfg/legal-and-ethics/intellectual-property-rights-yesno/yesno		f	0	Data or software can be subject to intellectual or industrial property rights. Applicable laws differ broadly even within EU. According to the German copyright law (UrhG) works of literature, scholarship and the arts that can be regarded as a “personal intellectual creation” are protected by copyright. Copyright protection expires 70 years after the death of the copyright holder. Mere data, e.g. measured data or survey data, and metadata (except in some cases descriptive metadata) are not protected by copyright. § 2 of the UrhG lists the following kinds of protected works (list is not concluded): \n\n* linguistic works such as written works, speeches and computer programs \n\n* works of music \n\n* pantomimic works including works of the art of dance \n\n* works or the fine arts including works of architecture and the applied arts as well as sketches of such works \n\n* works of photography and cinematography \n\n* descriptions and illustrations of scholarly or technical nature such as drawings, plans, maps, sketches, tables and three-dimensional represenations \n\nAccording to § 3, copyright is also applicable to translations and other modifications or adaptions of a work if they are individual intellectual creations of the editor. Finally, according to § 4 copyright also extents to collected editions and database works. Collected editions are “collections of work, data or other independent elements that are individual intellectual creations based on the selection and arrangement of the elements”. Database works are defined as “collected editions, the elements of which are arranged in a systematic or methodical way and can be accessed individually by electronic means or in other ways”. Other relevant property rights can be trademarks, patents, utility models, plant variety rights protection, integrated circuit layout design protection, geographical indications or registered designs.	Daten oder Software können Urheber- oder anderen Schutzrechten unterliegen. Die Rechtslage kann selbst in der EU von Land zu Land erheblich abweichen. In Deutschland sind nach dem Urheberrechtsgesetz (UrhG) Werke der Literatur, Wissenschaft und Kunst, die eine „persönliche geistige Schöpfung“ darstellen, urheberrechtlich geschützt. Der urheberrechtliche Schutz erlischt 70 Jahre nach dem Tod der bzw. des Urheberin/s. Reine Daten, z.B. Messdaten oder Surveydaten, aber auch Metadaten (bis auf ggf. „beschreibende“ Metadaten) sind hingegen nicht schutzfähig. In § 2 nennt das UrhG folgende geschützte Werkarten, wobei die Aufzählung nicht abschließend ist: \n\n* Sprachwerke, wie Schriftwerke, Reden und Computerprogramme \n\n* Werke der Musik \n\n* pantomimische Werke einschließlich Werke der Tanzkunst \n\n* Werke der bildenden Künste einschließlich der Werke der Baukunst und der angewandten Kunst und Entwürfe solcher Werke \n\n* Lichtbildwerke einschließlich der Werke, die ähnlich wie Lichtbildwerke geschaffen werden \n\n* Darstellungen wissenschaftlicher oder technischer Art wie Zeichnungen, Pläne, Karten, Skizzen, Tabellen und plastische Darstellungen. \n\nNach § 3 sind auch „Übersetzungen und andere Bearbeitungen“ von Werken geschützt, die persönliche geistige Schöpfungen des Bearbeiters sind“. Schließlich sind nach § 4 auch Sammelwerke und Datenbankwerke geschützt, was im Bereich Forschungsdaten durchaus relevant sein kann. Sammelbankwerke werden dabei definiert als „Sammlungen von Werken, Daten oder anderen unabhängigen Elementen, die aufgrund der Auswahl oder Anordnung der Elemente eine persönliche geistige Schöpfung sind“. Bei einem „Datenbankwerk im Sinne des Gesetzes“ handelt es sich um ein „Sammelwerk, dessen Elemente systematisch oder methodisch angeordnet und einzeln mit Hilfe elektronischer Mittel oder auf andere Weise zugänglich sind“. Weitere relevante Schutzrechte können gewerbliche Schutzrechte wie Patente, Gebrauchsmuster, Sortenschutz [bei Pflanzenzüchtungen], Halbleiterschutz, Marken, geographische Herkunftsangaben, eingetragene Designs oder geschäftliche Bezeichnungen sein.	Does the project use and/or produce data that is protected by intellectual or industrial property rights?	Werden Daten genutzt und/oder erstellt, die durch Urheber- oder verwandte Schutzrechte geschützt sind?	yesno	boolean		162	255	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
564	2020-10-28 14:09:48.567+00	2020-10-28 14:09:48.567+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/legal-and-ethics/sensitive-data-personal_data/anonymization	https://rdmorganiser.github.io/terms	anonymization	biodiversity_dfg/legal-and-ethics/sensitive-data-personal_data/anonymization		f	2	\N	\N	Will the data be anonymised or pseudonymised?	Werden die Daten anonymisiert oder pseudonymisiert?	radio	text		112	256	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
575	2020-10-28 14:09:49.518+00	2020-10-28 14:09:49.518+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/repository	https://rdmorganiser.github.io/terms	repository	biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/repository		t	5	\N	\N	Where will the data (including metadata, documentation and, if applicable, relevant code) be stored or archived after the end of the project?	Wo werden die Daten (einschließlich Metadaten, Dokumentation und ggf. relevantem Code bzw. relevanter Software) nach Projektende gespeichert bzw. archiviert?	checkbox	text		99	262	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
565	2020-10-28 14:09:48.665+00	2020-10-28 14:09:48.665+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/legal-and-ethics/sensitive-data-personal_data_yesno/yesno	https://rdmorganiser.github.io/terms	yesno	biodiversity_dfg/legal-and-ethics/sensitive-data-personal_data_yesno/yesno		f	1	The EU General Data Protection Regulation (GDPR) defines in Art. 4 personal data as "any information relating to an identified or identifiable natural person". An identifiable natural person is "one who can be identified, directly or indirectly, in particular by reference to an identifier such as a name, an identification number, location data, an online identifier or to one or more factors specific to the physical, physiological, genetic, mental, economic, cultural or social identity of that natural person".	Die EU Datenschutz-Grundverordnung (DSGVO) definiert in Art. 4 personenbezogene Daten als "alle Informationen, die sich auf eine identifizierte oder identifizierbare natürliche Person beziehen". Als identifizierbar wird "eine natürliche Person angesehen, die direkt oder indirekt, insbesondere mittels Zuordnung zu einer Kennung wie einem Namen, zu einer Kennnummer, zu Standortdaten, zu einer Online-Kennung oder zu einem oder mehreren besonderen Merkmalen identifiziert werden kann, die Ausdruck der physischen, physiologischen, genetischen, psychischen, wirtschaftlichen, kulturellen oder sozialen Identität dieser natürlichen Person sind".	Does this dataset contain personal data?	Enthält dieser Datensatz personenbezogene Daten?	yesno	boolean		120	257	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
566	2020-10-28 14:09:48.73+00	2020-10-28 14:09:48.73+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/referencing/structure-granularity-and-referencing-costs/non_personnel	https://rdmorganiser.github.io/terms	non_personnel	biodiversity_dfg/referencing/structure-granularity-and-referencing-costs/non_personnel		f	3	Please estimate the costs in Euro.	Bitte schätzen sie die Kosten in Euro.	What is the amount of non-personnel-costs associated with persistent identifiers in the project?	Welche Sachkosten entstehen im Zusammenhang mit persistenten Identifikatoren im Projekt?	text	float	Euro	18	258	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
567	2020-10-28 14:09:48.783+00	2020-10-28 14:09:48.783+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/referencing/structure-granularity-and-referencing-costs/personnel	https://rdmorganiser.github.io/terms	personnel	biodiversity_dfg/referencing/structure-granularity-and-referencing-costs/personnel		f	1	Please estimate the effort in person months.	Bitte schätzen sie den Aufwand in Personenmonaten.	What are the personnel costs associated with of persistent identifiers in the project?	Welcher Personalaufwand entsteht im Zusammenhang mit der Vergabe von persistenten Identifikatoren im Projekt?	range	float	PM	19	258	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
568	2020-10-28 14:09:48.829+00	2020-10-28 14:09:48.829+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/referencing/structure-granularity-and-referencing-pids/yesno	https://rdmorganiser.github.io/terms	yesno	biodiversity_dfg/referencing/structure-granularity-and-referencing-pids/yesno		f	0	\N	\N	Will persistent identifiers (PIDs) be used for this data set?	Sollen für diesen Datensatz persistente Identifikatoren (PIDs) genutzt werden?	yesno	boolean		91	259	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
569	2020-10-28 14:09:48.88+00	2020-10-28 14:09:48.88+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/referencing/structure-granularity-and-referencing-structure/structure	https://rdmorganiser.github.io/terms	structure	biodiversity_dfg/referencing/structure-granularity-and-referencing-structure/structure		f	0	According to the <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/guidelines_biodiversity_research.pdf" target=_blank>Guidelines on the Handling of Research Data in Biodiversity Research</a> information concerning "the connection to research objects (e.g. voucher specimen or soil samples) and other referenced data" is expected.	Nach den <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_biodiversitaetsforschung.pdf" target=_blank>Richtlinien zum Umgang mit Forschungsdaten in der Biodiversitätsforschung</a> werden Angaben "zu dem Bezug auf Forschungsobjekte (etwa Belegexemplare oder Bodenproben) und andere referenzierte Daten" erwartet.	What is the structure of the data? How are the individual components of the dataset related to each other? How is the dataset related to other datasets and to physical objects used in the project?	Wie sind die Daten strukturiert? In welchem Verhältnis stehen die einzelnen Komponenten zueinander? In welchem Verhältnis steht der Datensatz zu anderen im Projekt erhobenen oder genutzten Datensätzen und zu physischen Objekten?	textarea	text		137	260	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
570	2020-10-28 14:09:49.202+00	2020-10-28 14:09:49.202+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-costs/cover_how	https://rdmorganiser.github.io/terms	cover_how	biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-costs/cover_how		f	10	\N	\N	How will the datamanagement costs of the project be covered?	Wie werden die Kosten für das Datenmanagement im Projekt aufgebracht?	textarea	text		21	261	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
571	2020-10-28 14:09:49.256+00	2020-10-28 14:09:49.256+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-costs/non_personnel	https://rdmorganiser.github.io/terms	non_personnel	biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-costs/non_personnel		f	2	Please estimate the costs in **Euro**.	Bitte schätzen sie die Kosten in **Euro**.	What is the amount of non-personnel-costs regarding long-term preservation for the project?	Welche Sachkosten entstehen im Zusammenhang mit Langzeitarchivierung für dieses Projekt?	text	float	Euro	22	261	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
572	2020-10-28 14:09:49.304+00	2020-10-28 14:09:49.304+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-costs/personnel	https://rdmorganiser.github.io/terms	personnel	biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-costs/personnel		f	1	Please estimate the effort in person months.	Bitte schätzen sie den Aufwand in Personenmonaten.	What are the personnel costs associated with long-term preservation for the project?	Welcher Personalaufwand entsteht im Zusammenhang mit Langzeitarchivierung für dieses Projekt?	range	float	PM	23	261	12	0	0.1					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
573	2020-10-28 14:09:49.355+00	2020-10-28 14:09:49.355+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/duration	https://rdmorganiser.github.io/terms	duration	biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/duration		f	3	\N	\N	How long will the data be stored?	Wie lange müssen die Daten aufbewahrt werden?	text	text		96	262	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
574	2020-10-28 14:09:49.407+00	2020-10-28 14:09:49.407+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/purpose	https://rdmorganiser.github.io/terms	purpose	biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-datasets/purpose		t	2	\N	\N	What are the reasons this dataset has to be preserved for the long-term?	Aus welchen Gründen müssen die Daten langfristig aufbewahrt werden?	checkbox	text		98	262	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
577	2020-10-28 14:09:49.665+00	2020-10-28 14:09:49.665+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/technical-classification/data-formats/format	https://rdmorganiser.github.io/terms	format	biodiversity_dfg/technical-classification/data-formats/format		f	4	When choosing a data format, one should consider the consequences for collaborative use, long-term preservation as well as re-use. It is advisable to prefer formats that are standardised, open, non-proprietary and well-established in the respective scholarly community. A table with recommended file formats can be found in Kristin Briney, <i>Data Management for Researchers</i>, Pelargic, 2015, pages 133-134.	Bei der Wahl des Dateiformates sollten auch die Konsequenzen für die kollaborative Nutzung, die Langzeitarchivierung sowie die Nachnutzung beachtet werden. Es empfiehlt sich, möglichst standardisierte, nicht-proprietäre und allgemein bzw. in der spezifischen Community verbreitete Formate zu nutzen. Weitere Kriterien sowie detaillierte Erläuterungen sind z.B. im <a href="http://nestor.sub.uni-goettingen.de/handbuch/"  target=_blank">nestor Handbuch</a> zu finden.	Which file formats are used?	In welchen Formaten liegen die Daten vor?	textarea	text		62	263	\N	\N	\N					\N	\N	\N	\N	\N	\N							f	f	\N	\N	\N	\N	\N	\N	
\.


--
-- Data for Name: questions_question_conditions; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.questions_question_conditions (id, question_id, condition_id) FROM stdin;
1	150	1
2	158	2
3	206	7
4	267	2
5	291	2
6	351	7
7	371	2
8	531	1
9	538	2
\.


--
-- Data for Name: questions_question_optionsets; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.questions_question_optionsets (id, question_id, optionset_id) FROM stdin;
1	1	10
2	143	9
3	145	11
4	149	4
5	156	6
6	157	8
7	161	12
8	166	34
9	167	34
10	174	18
11	175	35
12	180	22
13	187	26
14	193	5
15	194	10
16	195	35
17	203	15
18	205	16
19	209	3
20	212	17
21	216	2
22	223	20
23	225	19
24	226	21
25	231	23
26	242	24
27	243	25
28	260	33
29	263	13
30	266	8
31	269	12
32	273	22
33	274	5
34	275	10
35	277	3
36	280	24
37	281	25
38	287	9
39	290	8
40	293	12
41	298	19
42	300	22
43	301	5
44	302	10
45	304	3
46	308	24
47	309	25
48	350	17
49	357	34
50	358	23
51	366	6
52	368	21
53	387	9
54	390	13
55	393	22
56	488	54
57	489	42
58	491	39
59	496	55
60	497	40
61	499	43
62	501	41
63	508	60
64	509	59
65	510	58
66	511	22
67	512	34
68	513	46
69	515	47
70	516	48
71	518	49
72	519	50
73	520	51
74	521	57
75	524	52
76	526	53
77	527	56
78	529	11
79	537	8
80	541	12
81	545	34
82	546	34
83	555	21
84	557	22
85	561	5
86	562	10
87	564	3
88	574	24
89	575	25
\.


--
-- Data for Name: questions_questionset; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.questions_questionset (id, created, updated, uri, uri_prefix, key, path, comment, is_collection, "order", help_lang1, help_lang2, attribute_id, verbose_name_lang2, verbose_name_lang1, verbose_name_plural_lang2, verbose_name_plural_lang1, section_id, title_lang2, title_lang1, help_lang3, help_lang4, help_lang5, title_lang3, title_lang4, title_lang5, verbose_name_lang3, verbose_name_lang4, verbose_name_lang5, verbose_name_plural_lang3, verbose_name_plural_lang4, verbose_name_plural_lang5, locked) FROM stdin;
4	2021-07-13 19:40:11.412997+00	2021-07-13 19:40:11.413009+00	http://0.0.0.0:8000/questions/Cat1/sec1/set1	http://0.0.0.0:8000/	set1	Cat1/sec1/set1		f	0			\N					3		set1													f
58	2020-04-14 14:47:19.923+00	2020-04-14 14:47:19.923+00	https://rdmorganiser.github.io/terms/questions/rdmo/content-classification/data-dataset	https://rdmorganiser.github.io/terms	data-dataset	rdmo/content-classification/data-dataset		t	1	The following questions collect information on the data that is produced or used in the project. They also help to estimate the value of the data in terms of potential re-use and long-term preservation. Before data is newly created,\n\t\t\tis advisable to check if there is existing data that could be re-used. This way, redundant collection or creation of research data is prevented. This saves efforts and costs. Furthermore, in the case of personal data, the principles of the General\n\t\t\tData Protection Regulation (<a href="https://gdpr-info.eu/" target=_blank">GDPR</a>) like data minimisation (<a href="https://gdpr-info.eu/art-5-gdpr/" target=_blank">Art.5 Section 1</a>) and in\n\t\t\tGermany the Bundesdatenschutzgesetz (<a ="https://dsgvo-gesetz.de/bdsg/" target=_blank"> BDSG</a>) apply. The information regarding the data collected, produced or used in the project is gathered along datasets. The of\n\t\t\tthese datasets is an important conceptional decision that has to be made individually and carefully for each project.	Die nächsten Fragen dienen zur Beschreibung der Datensätze, die im Projekt erzeugt und/oder verwendet werden. Sie helfen zudem, den Wert der Daten hinsichtlich der potentiellen Nachnutzung und einer späteren Archivierung einschätzen\n\t\t\tkönnen. Vor der Erzeugung von Daten empfiehlt es sich zu prüfen, ob bereits vorhandene Daten nachgenutzt werden können. Die Vermeidung doppelter Erhebungen spart Aufwand und Kosten. Handelt es sich um personenbezogene Daten, gelten die Grundsätze der\n\t\t\tEU-Datenschutzgrundverordnung (<a href="https://dsgvo-gesetz.de/" target=_blank">DSGVO</a>) wie z.B. Datenminimierung (<a href="https://dsgvo-gesetz.de/art-5-dsgvo/" target=_blank">Art.5\n\t\t\tAbs.1</a>) und das Bundesdatenschutzgesetz (<a ="https://dsgvo-gesetz.de/bdsg/" target=_blank">BDSG</a>). Die Angaben zu den im Projekt erzeugten oder verwendeten Daten sind nach „Datensätzen“ strukturiert. Die\n\t\t\tDefinition dessen, was jeweils ein ist, ist eine wichtige konzeptionelle Entscheidung, die für jedes Vorhaben bzw. Projekt individuell getroffen und sorgfältig abgewogen werden muss.	39	Datensatz	dataset	Datensätze	datasets	14	Datensätze	Datasets													f
59	2020-04-14 14:47:19.972+00	2020-04-14 14:47:19.972+00	https://rdmorganiser.github.io/terms/questions/rdmo/content-classification/data-existing_data	https://rdmorganiser.github.io/terms	data-existing_data	rdmo/content-classification/data-existing_data		t	2			39	Datensatz	dataset	Datensätze	datasets	14	Datenursprung	Data origin													f
60	2020-04-14 14:47:20.013+00	2020-04-14 14:47:20.013+00	https://rdmorganiser.github.io/terms/questions/rdmo/content-classification/data-reproducibility	https://rdmorganiser.github.io/terms	data-reproducibility	rdmo/content-classification/data-reproducibility		t	4			39	Datensatz	dataset	Datensätze	datasets	14	Reproduzierbarkeit	Reproducibility													f
61	2020-04-14 14:47:20.055+00	2020-04-14 14:47:20.055+00	https://rdmorganiser.github.io/terms/questions/rdmo/content-classification/data-reuse	https://rdmorganiser.github.io/terms	data-reuse	rdmo/content-classification/data-reuse		t	3			39	Datensatz	dataset	Datensätze	datasets	14	Nachnutzung	Reuse													f
62	2020-04-14 14:47:20.094+00	2020-04-14 14:47:20.094+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/collaborative-work-collaboration	https://rdmorganiser.github.io/terms	collaborative-work-collaboration	rdmo/data-usage/collaborative-work-collaboration		t	53			39	Datensatz	dataset	Datensätze	datasets	15	Kollaboratives Arbeiten	Collaborative work													f
63	2020-04-14 14:47:20.13+00	2020-04-14 14:47:20.13+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/costs-dataset	https://rdmorganiser.github.io/terms	costs-dataset	rdmo/data-usage/costs-dataset		f	70			\N					15	Kosten	Costs													f
64	2020-04-14 14:47:20.182+00	2020-04-14 14:47:20.182+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-sharing-and-re-use-interoperability	https://rdmorganiser.github.io/terms	data-sharing-and-re-use-interoperability	rdmo/data-usage/data-sharing-and-re-use-interoperability		t	51			39	Datensatz	dataset	Datensätze	datasets	15	Interoperabilität	Interoperability													f
65	2020-04-14 14:47:20.231+00	2020-04-14 14:47:20.231+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-sharing-and-re-use-publication	https://rdmorganiser.github.io/terms	data-sharing-and-re-use-publication	rdmo/data-usage/data-sharing-and-re-use-publication		t	52			39	Datensatz	dataset	Datensätze	datasets	15	Weitergabe und Veröffentlichung	Data sharing and re-use													f
66	2020-04-14 14:47:20.278+00	2020-04-14 14:47:20.278+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-storage-and-security-data_security	https://rdmorganiser.github.io/terms	data-storage-and-security-data_security	rdmo/data-usage/data-storage-and-security-data_security		t	12			39	Datensatz	dataset	Datensätze	datasets	15	Datenspeicherung und -sicherheit	Data storage and security													f
67	2020-04-14 14:47:20.329+00	2020-04-14 14:47:20.329+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/data-storage-and-security-storage	https://rdmorganiser.github.io/terms	data-storage-and-security-storage	rdmo/data-usage/data-storage-and-security-storage		t	11			39	Datensatz	dataset	Datensätze	datasets	15	Datenorganisation	Data organisation													f
68	2020-04-14 14:47:20.38+00	2020-04-14 14:47:20.38+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/quality-assurance-dataset	https://rdmorganiser.github.io/terms	quality-assurance-dataset	rdmo/data-usage/quality-assurance-dataset		t	61			39	Datensatz	dataset	Datensätze	datasets	15	Qualitätssicherung	Quality assurance													f
69	2020-04-14 14:47:20.427+00	2020-04-14 14:47:20.427+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/quality-assurance-integration	https://rdmorganiser.github.io/terms	quality-assurance-integration	rdmo/data-usage/quality-assurance-integration	the stipulation that re-used and created data are of the same type (= and thus capable to be integrated) is problematic, since this implies properties of the data that are not a given. May be this shoud be reformulated to : Is the between\n\t\t\tre-used and created data ensures (which goes into the provenance realm)	f	63			\N					15	Datenintegration	Data integration													f
70	2020-04-14 14:47:20.48+00	2020-04-14 14:47:20.48+00	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage/scenarios-usage	https://rdmorganiser.github.io/terms	scenarios-usage	rdmo/data-usage/scenarios-usage		t	0	The following questions will help to estimate, which ressources are necessary to enable the envisioned data usage scenarios during the project. These can be technical / IT resources as well as expertise brought in by e.g. data or IT experts.	Die folgenden Fragen dienen dazu einzuschätzen, welche Ressourcen für die geplante Nutzung der Daten während der Projektlaufzeit nötig sind. Dabei kann es sich um technische bzw. IT-Ressourcen handeln, aber auch um Expertise, die z.B.\n\t\t\tDatenmanagement- oder IT-ExpertInnen eingebracht wird.	39	Datensatz	dataset	Datensätze	datasets	15	Nutzungsszenarien	Usage scenarios													f
71	2020-04-14 14:47:20.528+00	2020-05-14 10:58:56.921+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/funding-funder	https://rdmorganiser.github.io/terms	funding-funder	rdmo/general/funding-funder		t	40			151	Förderer	funder	Förderer	funders	16	Förderung	Funding													f
72	2020-04-14 14:47:20.576+00	2020-05-14 10:58:57.19+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/other-requirements-requirements	https://rdmorganiser.github.io/terms	other-requirements-requirements	rdmo/general/other-requirements-requirements		f	51			\N					16	Weitere Anforderungen II	Other requirements II													f
73	2020-04-14 14:47:20.671+00	2020-05-14 10:58:57.102+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/other-requirements-yesno	https://rdmorganiser.github.io/terms	other-requirements-yesno	rdmo/general/other-requirements-yesno		f	50			\N					16	Weitere Anforderungen I	Other requirements I													f
74	2020-04-14 14:47:20.727+00	2020-05-14 10:58:56.647+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/project-partners-name	https://rdmorganiser.github.io/terms	project-partners-name	rdmo/general/project-partners-name		f	20			\N					16	Projektkoordination	Project coordination													f
75	2020-04-14 14:47:20.778+00	2020-05-14 10:58:56.736+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/project-partners-partner	https://rdmorganiser.github.io/terms	project-partners-partner	rdmo/general/project-partners-partner		t	21			177	Projektpartner	project partner	Projektpartner	project partners	16	Projektpartner	Project partners													f
76	2020-04-14 14:47:20.829+00	2020-05-14 10:58:56.515+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/project-schedule-schedule	https://rdmorganiser.github.io/terms	project-schedule-schedule	rdmo/general/project-schedule-schedule		f	10			\N					16	Projektablauf	Project schedule													f
77	2020-04-14 14:47:20.878+00	2020-05-14 10:58:56.463+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/topic-research_field	https://rdmorganiser.github.io/terms	topic-research_field	rdmo/general/topic-research_field	for Germany, the classification works, but we might consider also DDC as an option	f	1			\N					16	Disziplin	Research field													f
78	2020-04-14 14:47:20.928+00	2020-05-14 10:58:56.368+00	https://rdmorganiser.github.io/terms/questions/rdmo/general/topic-research_question	https://rdmorganiser.github.io/terms	topic-research_question	rdmo/general/topic-research_question		f	0			\N					16	Thema	Topic													f
79	2020-04-14 14:47:20.978+00	2020-04-14 14:47:20.978+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/general-legal-issues-international_yesno	https://rdmorganiser.github.io/terms	general-legal-issues-international_yesno	rdmo/legal-and-ethics/general-legal-issues-international_yesno		f	10			\N					17	Recht allgemein	General legal issues													f
80	2020-04-14 14:47:21.028+00	2020-04-14 14:47:21.028+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/intellectual-property-rights-costs	https://rdmorganiser.github.io/terms	intellectual-property-rights-costs	rdmo/legal-and-ethics/intellectual-property-rights-costs		f	34			\N					17	Urheber- oder verwandte Schutzrechte Kosten	Intellectual property rights costs													f
81	2020-04-14 14:47:21.111+00	2020-04-14 14:47:21.111+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/intellectual-property-rights-dataset	https://rdmorganiser.github.io/terms	intellectual-property-rights-dataset	rdmo/legal-and-ethics/intellectual-property-rights-dataset		t	31			39	Datensatz	dataset	Datensätze	datasets	17	Urheber- oder verwandte Schutzrechte II	Intellectual property rights II													f
82	2020-04-14 14:47:21.203+00	2020-04-14 14:47:21.203+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/intellectual-property-rights-yesno	https://rdmorganiser.github.io/terms	intellectual-property-rights-yesno	rdmo/legal-and-ethics/intellectual-property-rights-yesno		f	30			\N					17	Urheber- oder verwandte Schutzrechte I	Intellectual property rights I													f
83	2020-04-14 14:47:21.256+00	2020-04-14 14:47:21.256+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-costs	https://rdmorganiser.github.io/terms	sensitive-data-costs	rdmo/legal-and-ethics/sensitive-data-costs		f	27			\N					17	Sensible Daten Kosten	Sensitive data costs													f
84	2020-04-14 14:47:21.391+00	2020-04-14 14:47:21.391+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-official_approval	https://rdmorganiser.github.io/terms	sensitive-data-official_approval	rdmo/legal-and-ethics/sensitive-data-official_approval		f	28			\N					17	Offizielle Genehmigung	Official approval													f
85	2020-04-14 14:47:21.451+00	2020-04-14 14:47:21.451+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-other	https://rdmorganiser.github.io/terms	sensitive-data-other	rdmo/legal-and-ethics/sensitive-data-other		t	26			39	Datensatz	dataset	Datensätze	datasets	17	Weitere sensible Daten	Other sensitive data													f
86	2020-04-14 14:47:21.517+00	2020-04-14 14:47:21.517+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-personal_data	https://rdmorganiser.github.io/terms	sensitive-data-personal_data	rdmo/legal-and-ethics/sensitive-data-personal_data		t	24			39	Datensatz	dataset	Datensätze	datasets	17	Sensible Daten	Sensitive data													f
87	2020-04-14 14:47:21.594+00	2020-04-14 14:47:21.594+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-personal_data_yesno	https://rdmorganiser.github.io/terms	sensitive-data-personal_data_yesno	rdmo/legal-and-ethics/sensitive-data-personal_data_yesno		t	21			39	Datensatz	dataset	Datensätze	datasets	17	Personenbezogene Daten	Personal data													f
88	2020-04-14 14:47:21.65+00	2020-04-14 14:47:21.65+00	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics/sensitive-data-privacy_law	https://rdmorganiser.github.io/terms	sensitive-data-privacy_law	rdmo/legal-and-ethics/sensitive-data-privacy_law		f	22			\N					17	Datenschutz	Data protection													f
89	2020-04-14 14:47:21.733+00	2020-04-14 14:47:21.733+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/metadata-costs	https://rdmorganiser.github.io/terms	metadata-costs	rdmo/metadata-and-referencing/metadata-costs		f	12			\N					18	Metadatenkosten	Metadata costs													f
90	2020-04-14 14:47:21.791+00	2020-04-14 14:47:21.791+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/metadata-dataset	https://rdmorganiser.github.io/terms	metadata-dataset	rdmo/metadata-and-referencing/metadata-dataset		t	10			39	Datensatz	dataset	Datensätze	datasets	18	Metadaten	Metadata													f
91	2020-04-14 14:47:21.838+00	2020-04-14 14:47:21.838+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/structure-granularity-and-referencing-costs	https://rdmorganiser.github.io/terms	structure-granularity-and-referencing-costs	rdmo/metadata-and-referencing/structure-granularity-and-referencing-costs		f	23			\N					18	PIDs Kosten	PIDs costs													f
92	2020-04-14 14:47:21.892+00	2020-04-14 14:47:21.892+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/structure-granularity-and-referencing-pids	https://rdmorganiser.github.io/terms	structure-granularity-and-referencing-pids	rdmo/metadata-and-referencing/structure-granularity-and-referencing-pids		t	21	The purpose of Persistent Identifiers (PIDs) is to ensure the permanent reference of (in particular) digital objects like online publications and research data. When traditional hyperlinks are used as reference, they point directly to\n\t\t\tstorage location of the data. The problem is, that if the storage location is changed, the link will not work anymore. A PID serves as an intermediate from which requests are directed to the current object location (this is called\n\t\t\t"resolving" of PID). The PID stays the same, even if the storage location changes. While a mere hyperlink in this case would lead to nowhere, via the PID the object is still accessible. You can find more information about the mode of\n\t\t\toperation, usage and kinds of PIDs in e.g. an <a href="http://training.dasish.eu/training/3/" target=_blank">online tutorial</a> created by the DASISH project or in the <a\n\t\t\thref="http://www.ands.org.au/guides#identify" target=_blank">information material of the Australian National Data Service (ANDS)</a> (scroll down to "Identifying data and researchers").	Persistente Identifikatoren (PIDs) sollen die dauerhafte Referenzierung von (insbesondere) digitalen Objekten wie Publikationen oder Forschungsdaten ermöglichen. Statt, wie i.d.R. bei der Angabe eines Hyperlinks als Referenz der Fall,\n\t\t\tauf den Speicherort des Objektes zu verweisen, fungiert die PID als eine Zwischeninstanz, von der aus zum Objekt weitergeleitet wird (dies nennt man „Auflösen“ der PID). Die PID bleibt gleich, auch wenn der Speicherort des Objektes sich. Während ein\n\t\t\tHyperlink in diesem Fall ins Nichts führen würde, ist das Objekt über die PID weiterhin erreichbar. Mehr Informationen zur Funktionsweise, Verwendung und verschiedenen Arten von PIDs gibt es z.B. in einem vom Projekt DASISH <a\n\t\t\thref="http://training.dasish.eu/training/3/" target=_blank">Online-Tutorial</a> oder in den <a href="http://www.ands.org.au/guides#identify" target=_blank">Informationsmaterialien des Australian National\n\t\t\tData Service ANDS)</a> (nach unten scrollen zu "Identifying data and researchers").	39	Datensatz	dataset	Datensätze	datasets	18	Persistente Identifikatoren (PIDs)	Persistent Identifiers (PIDs)													f
93	2020-04-14 14:47:21.947+00	2020-04-14 14:47:21.947+00	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing/structure-granularity-and-referencing-structure	https://rdmorganiser.github.io/terms	structure-granularity-and-referencing-structure	rdmo/metadata-and-referencing/structure-granularity-and-referencing-structure		t	20			39	Datensatz	dataset	Datensätze	datasets	18	Objektstruktur, Granularität und Referenzierung	Structure, granularity, and referencing													f
94	2020-04-14 14:47:21.996+00	2020-04-14 14:47:21.996+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-costs	https://rdmorganiser.github.io/terms	long-term-preservation-costs	rdmo/storage-and-long-term-preservation/long-term-preservation-costs		f	13			\N					19	Langzeitarchivierungskosten	Long-term preservation costs													f
95	2020-04-14 14:47:22.048+00	2020-04-14 14:47:22.048+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/long-term-preservation-datasets	https://rdmorganiser.github.io/terms	long-term-preservation-datasets	rdmo/storage-and-long-term-preservation/long-term-preservation-datasets		t	11			39	Datensatz	dataset	Datensätze	datasets	19	Langzeitarchivierung	Long-term preservation													f
96	2020-04-14 14:47:22.097+00	2020-04-14 14:47:22.097+00	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation/selection-criteria	https://rdmorganiser.github.io/terms	selection-criteria	rdmo/storage-and-long-term-preservation/selection-criteria		f	0			\N					19	Auswahl	Selection													f
97	2020-04-14 14:47:22.159+00	2020-04-14 14:47:22.159+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-dates	https://rdmorganiser.github.io/terms	data-dates	rdmo/technical-classification/data-dates		t	1	Give time specifications to such a degree as (already) known.	Geben Sie Zeitangaben an insofern (bereits) bekannt.	39	Datensatz	dataset	Datensätze	datasets	20	Datenerhebung	Date collection													f
98	2020-04-14 14:47:22.212+00	2020-04-14 14:47:22.212+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-formats	https://rdmorganiser.github.io/terms	data-formats	rdmo/technical-classification/data-formats		t	3			39	Datensatz	dataset	Datensätze	datasets	20	Formate	Formats													f
99	2020-04-14 14:47:22.263+00	2020-04-14 14:47:22.263+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-tools	https://rdmorganiser.github.io/terms	data-tools	rdmo/technical-classification/data-tools		t	4			39	Datensatz	dataset	Datensätze	datasets	20	Werkzeuge	Tools													f
100	2020-04-14 14:47:22.308+00	2020-04-14 14:47:22.308+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-versioning	https://rdmorganiser.github.io/terms	data-versioning	rdmo/technical-classification/data-versioning		t	5			39	Datensatz	dataset	Datensätze	datasets	20	Versionierung	Versioning													f
101	2020-04-14 14:47:22.357+00	2020-04-14 14:47:22.357+00	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification/data-volume	https://rdmorganiser.github.io/terms	data-volume	rdmo/technical-classification/data-volume		t	2			39	Datensatz	dataset	Datensätze	datasets	20	Datengröße	Data size													f
102	2020-04-14 14:58:23.288+00	2020-05-12 08:10:41.355+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/content-classification/data-dataset	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	data-dataset	dfg/content-classification/data-dataset		t	1	The following questions collect information on the data that is produced or used in the project. They also help to estimate the value of the data in terms of potential re-use and long-term preservation. Before data is newly created, it is advisable to check if there is existing data that could be re-used. This way, redundant collection or creation of research data is prevented. This saves efforts and costs. Furthermore, in the case of personal data, the principle of data minimization (Art. 5 EU General Data Protection Regulation) allows the collection of personal data only when there are no other reasonable means to clarify the research question (re-use of existing data would be such a reasonable means). Also, there shall be collected no more information than necessary. The information regarding the data collected, produced or used in the project is gathered along datasets. The definition of these datasets is an important conceptional decision that has to be made individually and carefully for each project.	Die nächsten Fragen dienen zur Beschreibung der Datensätze, die im Projekt erzeugt und/oder verwendet werden. Sie helfen zudem, den Wert der Daten hinsichtlich der potentiellen Nachnutzung und einer späteren Archivierung einschätzen zu können. Vor der Erzeugung von Daten empfiehlt es sich zu prüfen, ob bereits vorhandene Daten nachgenutzt werden können. Die Vermeidung doppelter Erhebungen spart Aufwand und Kosten. Handelt es sich um personenbezogene Daten, ist dies zudem durch den Grundsatz der Datenminimierung (Art. 5 EU Datenschutz-Grundverordnung) geboten. Die Angaben zu den im Projekt erzeugten oder verwendeten Daten sind nach „Datensätzen“ strukturiert. Die Definition dessen, was jeweils ein Datensatz ist, ist eine wichtige konzeptionelle Entscheidung, die für jedes Vorhaben bzw. Projekt individuell getroffen und sorgfältig abgewogen werden muss.	39	Datensatz	dataset	Datensätze	datasets	21	Datensätze	Datasets													f
103	2020-04-14 14:58:23.338+00	2020-05-12 08:10:41.446+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/content-classification/data-reuse	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	data-reuse	dfg/content-classification/data-reuse		t	3			39	Datensatz	dataset	Datensätze	datasets	21	Nachnutzung	Reuse													f
157	2020-04-14 15:07:38.477+00	2020-04-14 15:07:38.477+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/costs/data-responsible	https://fdm-bayern.org/eHumanities	data-responsible	Horizon2020/costs/data-responsible		f	20			\N					41	Verantwortlichkeiten	Responsibilities													f
104	2020-04-14 14:58:23.402+00	2020-05-12 08:10:41.533+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/data-usage/data-sharing-and-re-use-publication	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	data-sharing-and-re-use-publication	dfg/data-usage/data-sharing-and-re-use-publication		t	52			39	Datensatz	dataset	Datensätze	datasets	22	Weitergabe und Veröffentlichung	Data sharing and re-use													f
105	2020-04-14 14:58:23.443+00	2020-05-12 08:10:41.768+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/data-usage/data-storage-and-security-storage	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	data-storage-and-security-storage	dfg/data-usage/data-storage-and-security-storage		t	11			39	Datensatz	dataset	Datensätze	datasets	22	Datenorganisation	Data organisation													f
106	2020-04-14 14:58:23.48+00	2020-05-12 08:10:41.859+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/data-usage/quality-assurance-dataset	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	quality-assurance-dataset	dfg/data-usage/quality-assurance-dataset		t	61			39	Datensatz	dataset	Datensätze	datasets	22	Qualitätssicherung	Quality assurance													f
107	2020-04-14 14:58:23.522+00	2020-05-12 08:10:41.946+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/general/other-requirements-requirements	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	other-requirements-requirements	dfg/general/other-requirements-requirements		f	51			\N					23	Weitere Anforderungen II	Other requirements II													f
108	2020-04-14 14:58:23.593+00	2020-05-12 08:10:42.113+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/general/other-requirements-yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	other-requirements-yesno	dfg/general/other-requirements-yesno		f	50			\N					23	Weitere Anforderungen I	Other requirements I													f
109	2020-04-14 14:58:23.652+00	2020-05-12 08:10:42.205+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/legal-and-ethics/intellectual-property-rights-dataset	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	intellectual-property-rights-dataset	dfg/legal-and-ethics/intellectual-property-rights-dataset		t	31			39	Datensatz	dataset	Datensätze	datasets	24	Urheber- oder verwandte Schutzrechte II	Intellectual property rights II													f
110	2020-04-14 14:58:23.735+00	2020-05-12 08:10:42.412+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/legal-and-ethics/intellectual-property-rights-yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	intellectual-property-rights-yesno	dfg/legal-and-ethics/intellectual-property-rights-yesno		f	30			\N					24	Urheber- oder verwandte Schutzrechte I	Intellectual property rights I													f
111	2020-04-14 14:58:23.792+00	2020-05-12 08:10:42.516+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/legal-and-ethics/sensitive-data-personal_data	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	sensitive-data-personal_data	dfg/legal-and-ethics/sensitive-data-personal_data		t	24			39	Datensatz	dataset	Datensätze	datasets	24	Sensible Daten	Sensitive data													f
112	2020-04-14 14:58:23.876+00	2020-05-12 08:10:42.677+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/legal-and-ethics/sensitive-data-personal_data_yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	sensitive-data-personal_data_yesno	dfg/legal-and-ethics/sensitive-data-personal_data_yesno		t	21			39	Datensatz	dataset	Datensätze	datasets	24	Personenbezogene Daten	Personal data													f
113	2020-04-14 14:58:23.933+00	2020-05-12 08:10:42.769+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/storage-and-long-term-preservation/long-term-preservation-datasets	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	long-term-preservation-datasets	dfg/storage-and-long-term-preservation/long-term-preservation-datasets		t	11	The DFG expects primary data that is the basis of a publication to be stored in the researcher's own institution or an appropriate nationwide infrastructure long-term (for at least 10 years).	Die DFG erwartet, dass Primärdaten, die Grundlage einer Publikation sind, langfristig (für mindestens 10 Jahre) in der eigenen Einrichtung  oder in einer fachlich einschlägigen, überregionalen Infrastruktur gespeichert werden.	39	Datensatz	dataset	Datensätze	datasets	25	Langzeitarchivierung	Long-term preservation													f
114	2020-04-14 14:58:23.982+00	2020-05-12 08:10:42.995+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/technical-classification/data-formats	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	data-formats	dfg/technical-classification/data-formats		t	3			39	Datensatz	dataset	Datensätze	datasets	26	Formate	Formats													f
115	2020-04-14 14:59:59.3+00	2020-04-14 14:59:59.3+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/content-classification/data-dataset	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	data-dataset	edu_dfg/content-classification/data-dataset		t	1	The following questions collect information on the data that is produced or used in the project. They also help to estimate the value of the data in terms of potential re-use and long-term preservation. Before data is newly created, it is advisable to check if there is existing data that could be re-used. This way, redundant collection or creation of research data is prevented. This saves efforts and costs. Furthermore, in the case of personal data, the principle of data minimization (Art. 5 EU General Data Protection Regulation) allows the collection of personal data only when there are no other reasonable means to clarify the research question (re-use of existing data would be such a reasonable means). Also, there shall be collected no more information than necessary. The information regarding the data collected, produced or used in the project is gathered along datasets. The definition of these datasets is an important conceptional decision that has to be made individually and carefully for each project.	Die nächsten Fragen dienen zur Beschreibung der Datensätze, die im Projekt erzeugt und/oder verwendet werden. Sie helfen zudem, den Wert der Daten hinsichtlich der potentiellen Nachnutzung und einer späteren Archivierung einschätzen zu können. Vor der Erzeugung von Daten empfiehlt es sich zu prüfen, ob bereits vorhandene Daten nachgenutzt werden können. Die Vermeidung doppelter Erhebungen spart Aufwand und Kosten. Handelt es sich um personenbezogene Daten, ist dies zudem durch den Grundsatz der Datenminimierung (Art. 5 EU Datenschutz-Grundverordnung) geboten. Die Angaben zu den im Projekt erzeugten oder verwendeten Daten sind nach „Datensätzen“ strukturiert. Die Definition dessen, was jeweils ein Datensatz ist, ist eine wichtige konzeptionelle Entscheidung, die für jedes Vorhaben bzw. Projekt individuell getroffen und sorgfältig abgewogen werden muss.	39	Datensatz	dataset	Datensätze	datasets	27	Datensätze	Datasets													f
116	2020-04-14 14:59:59.356+00	2020-04-14 14:59:59.356+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/content-classification/data-existing_data	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	data-existing_data	edu_dfg/content-classification/data-existing_data		t	2			39	Datensatz	dataset	Datensätze	datasets	27	Datenursprung	Data origin													f
117	2020-04-14 14:59:59.398+00	2020-04-14 14:59:59.398+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/content-classification/data-reuse	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	data-reuse	edu_dfg/content-classification/data-reuse		t	3			39	Datensatz	dataset	Datensätze	datasets	27	Nachnutzung	Reuse													f
213	2020-04-29 14:15:06.913+00	2020-11-08 14:54:45.187+00	http://example.com/terms/questions/GFBio test/general/coordinated_programme	http://example.com/terms	coordinated_programme	GFBio test/general/coordinated_programme		f	8			\N					60	koordiniertes Programm	Coordinated programme													f
118	2020-04-14 14:59:59.444+00	2020-04-14 14:59:59.444+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/data-usage/data-sharing-and-re-use-publication	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	data-sharing-and-re-use-publication	edu_dfg/data-usage/data-sharing-and-re-use-publication		t	52			39	Datensatz	dataset	Datensätze	datasets	28	Weitergabe und Veröffentlichung	Data sharing and re-use													f
119	2020-04-14 14:59:59.482+00	2020-04-14 14:59:59.482+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/data-usage/data-storage-and-security-storage	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	data-storage-and-security-storage	edu_dfg/data-usage/data-storage-and-security-storage		t	11			39	Datensatz	dataset	Datensätze	datasets	28	Datenorganisation	Data organisation													f
120	2020-04-14 14:59:59.522+00	2020-04-14 14:59:59.522+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/data-usage/quality-assurance-dataset	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	quality-assurance-dataset	edu_dfg/data-usage/quality-assurance-dataset		t	61			39	Datensatz	dataset	Datensätze	datasets	28	Qualitätssicherung	Quality assurance													f
121	2020-04-14 14:59:59.587+00	2020-04-14 14:59:59.587+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/doc/general	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	general	edu_dfg/doc/general		t	10			39	Datensatz	dataset	Datensätze	datasets	29	Notwendigkeit und Verfügbarkeit	Necessity and availability													f
122	2020-04-14 14:59:59.634+00	2020-04-14 14:59:59.634+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/general/other-requirements-requirements	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	other-requirements-requirements	edu_dfg/general/other-requirements-requirements		f	51			\N					30	Weitere Anforderungen II	Other requirements II													f
123	2020-04-14 14:59:59.716+00	2020-04-14 14:59:59.716+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/general/other-requirements-yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	other-requirements-yesno	edu_dfg/general/other-requirements-yesno		f	50			\N					30	Weitere Anforderungen I	Other requirements I													f
124	2020-04-14 14:59:59.775+00	2020-04-14 14:59:59.775+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/legal-and-ethics/intellectual-property-rights-dataset	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	intellectual-property-rights-dataset	edu_dfg/legal-and-ethics/intellectual-property-rights-dataset		t	31			39	Datensatz	dataset	Datensätze	datasets	31	Urheber- oder verwandte Schutzrechte II	Intellectual property rights II													f
125	2020-04-14 14:59:59.856+00	2020-04-14 14:59:59.856+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/legal-and-ethics/intellectual-property-rights-yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	intellectual-property-rights-yesno	edu_dfg/legal-and-ethics/intellectual-property-rights-yesno		f	30			\N					31	Urheber- oder verwandte Schutzrechte I	Intellectual property rights I													f
126	2020-04-14 14:59:59.915+00	2020-04-14 14:59:59.915+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/legal-and-ethics/sensitive-data-personal_data	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	sensitive-data-personal_data	edu_dfg/legal-and-ethics/sensitive-data-personal_data		t	24			39	Datensatz	dataset	Datensätze	datasets	31	Sensible Daten	Sensitive data													f
127	2020-04-14 14:59:59.999+00	2020-04-14 14:59:59.999+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/legal-and-ethics/sensitive-data-personal_data_yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	sensitive-data-personal_data_yesno	edu_dfg/legal-and-ethics/sensitive-data-personal_data_yesno		t	21			39	Datensatz	dataset	Datensätze	datasets	31	Personenbezogene Daten	Personal data													f
128	2020-04-14 15:00:00.059+00	2020-04-14 15:00:00.059+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/storage-and-long-term-preservation/long-term-preservation-datasets	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	long-term-preservation-datasets	edu_dfg/storage-and-long-term-preservation/long-term-preservation-datasets		t	11	The DFG expects primary data that is the basis of a publication to be stored in the researcher's own institution or an appropriate nationwide infrastructure long-term (for at least 10 years).	Die DFG erwartet, dass Primärdaten, die Grundlage einer Publikation sind, langfristig (für mindestens 10 Jahre) in der eigenen Einrichtung oder in einer fachlich einschlägigen, überregionalen Infrastruktur gespeichert werden.	39	Datensatz	dataset	Datensätze	datasets	32	Langzeitarchivierung	Long-term preservation													f
129	2020-04-14 15:00:00.123+00	2020-04-14 15:00:00.123+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/technical-classification/data-formats	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	data-formats	edu_dfg/technical-classification/data-formats		t	3			39	Datensatz	dataset	Datensätze	datasets	33	Formate	Formats													f
145	2020-04-14 15:07:37.875+00	2020-04-14 15:07:37.875+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/Ethics/general-informed_consent	https://fdm-bayern.org/eHumanities	general-informed_consent	Horizon2020/Ethics/general-informed_consent		t	12	The German Federal Data Protection Act (<a target="_blank" href="https://www.gesetze-im-internet.de/bdsg_2018/index.html">BDSG</a>) and the new General Data Protection Regulation (GDPR) have similar defintions what\n\t\t\tconstitutes personal data. Personal data is any form of "information relating to an identified or identifiable individual ('data subject')" (<a target="_blank"\n\t\t\thref="https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=CELEX:32016R0679&from=EN">GDPR Art. 4, page 33 in document</a>). This includes, e.g., names, (geo)location, genetic, economic and physical information and online identity\n\t\t\t(screen name). A person is "identified" if it is obvious to whom the data refers or belongs. A person is "identifiable" if one can deduce to which person the data refers given additional information. See page 7 in working paper by Häder. The handling\n\t\t\tof personal information is regulated by law. More information (in German only) can be found in the following publications: * <a href="http://www.ratswd.de/download/RatSWD_WP_2009/RatSWD_WP_90.pdf" target=_blank">Michael Häder (2009): Der\n\t\t\tDatenschutz in den Sozialwissenschaften. RatSWD Working Paper No. 90.</a> * <a href="http://www.gesis.org/fileadmin/upload/forschung/publikationen/gesis_reihen/gesis_methodenberichte/2012/TechnicalReport_2012-07.pdf" target=_blank">Uwe\n\t\t\tJensen (2012): Leitlinien zum Management von Forschungsdaten. Sozialwissenschaftliche Umfragedaten. GESIS Technical Report 2012|07.</a> (esp. pp. 13 ff) * <a\n\t\t\thref="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_recht.pdf" target=_blank">Handreichung: Informationen zu rechtlichen Aspekten bei der Handhabung von\n\t\t\tSprachkorpora.</a> (esp. part 1.1 and part 2.2)	Das Bundesdatenschutzgesetz (<a target="_blank" href="https://www.gesetze-im-internet.de/bdsg_2018/index.html">BDSG</a>) und auch die neue Datenschutzgrundverordnung der EU (DS-GVO) haben ähnliche Definitionen was unter\n\t\t\tden Begriff „persönliche Daten“ fällt. Persönliche Daten sind jeder Arte von "information relating to an identified or identifiable individual ('data subject')" (<a target="_blank"\n\t\t\thref="https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=CELEX:32016R0679&from=EN">DSGVO Art. 4, Seite 33 im Dokument</a>). Dies umfasst zum Beispiel Namen, Geolokalisation, genetische, wirtschaftliche oder physische Informationen\n\t\t\tund sogenannte Online-Identitäten. Eine Person gilt als „identifiziert“ oder „bestimmt“, wenn offensichtlich ist zum wem die Daten gehören. Eine Person ist „identifizierbar / bestimmbar“, wenn man mit zusätzlichen Informationen und weiterer Recherche\n\t\t\tdie Daten einem Individuum zuordenbar werden. Siehe hierzu auch Seite 7 im Aufsatz von Häder. Der Umgang mit solchen Daten ist gesetzlich geregelt. Mehr Informationen (zwar auf bestimmte Disziplinen / Datentypen fokussiert, aber übertragbar) zum\n\t\t\tThema bieten bspw.: * <a href="http://www.ratswd.de/download/RatSWD_WP_2009/RatSWD_WP_90.pdf" target=_blank">Michael Häder (2009): Der Datenschutz in den Sozialwissenschaften. RatSWD Working Paper No. 90.</a> * <a\n\t\t\thref="http://www.gesis.org/fileadmin/upload/forschung/publikationen/gesis_reihen/gesis_methodenberichte/2012/TechnicalReport_2012-07.pdf" target=_blank">Uwe Jensen (2012): Leitlinien zum Management von Forschungsdaten. Sozialwissenschaftliche\n\t\t\tUmfragedaten. GESIS Technical Report 2012|07.</a> (v.a. S. 13ff.) * <a href="http://www.dfg.de/download/pdf/foerderung/grundlagen_dfg_foerderung/informationen_fachwissenschaften/geisteswissenschaften/standards_recht.pdf"\n\t\t\ttarget=_blank">Handreichung: Informationen zu rechtlichen Aspekten bei der Handhabung von Sprachkorpora.</a> (v.a. Teil 1.1 und Teil 2.2)	39	Datensatz	datset	Datensätze	datasets	39	Allgemeines	general information													f
146	2020-04-14 15:07:37.936+00	2020-04-14 15:07:37.936+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/Ethics/general-sensitive_data	https://fdm-bayern.org/eHumanities	general-sensitive_data	Horizon2020/Ethics/general-sensitive_data		t	11			39	Datensatz	datset	Datensätze	datasets	39	Allgemeines	general													f
158	2020-04-14 15:07:38.543+00	2020-04-14 15:07:38.543+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_security/transfer_storage-datasecurity	https://fdm-bayern.org/eHumanities	transfer_storage-datasecurity	Horizon2020/data_security/transfer_storage-datasecurity		t	0			39	Datensatz	datset	Datensätze	datasets	42	Transfer und Speicherung	transfer and storage													f
147	2020-04-14 15:07:37.985+00	2020-04-14 15:07:37.985+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/FAIR_info-FAIRness	https://fdm-bayern.org/eHumanities	FAIR_info-FAIRness	Horizon2020/FAIR/FAIR_info-FAIRness		f	10	One of the central themes of the H2020 Data management questionnaire is the <a target="_blank" href="https://doi.org/10.1038/sdata.2016.18">FAIR data principle</a>, see also the corresponding <a target="_blank"\n\t\t\thref="https://www.force11.org/group/fairgroup/fairprinciples">force11 website</a>. Here you can find some additional information. If you are already familiar with the FAIR criteria, you can just continue to the next H2020 question, otherwise\n\t\t\tit is recommended to read this short introduction and have a look at the website. <br /> The acronym FAIR stands for <b>Findable</b>, <b>Accessible</b>, <b>Interoperable</b> and <b>Re-Usable</b>.\n\t\t\t<br /><br /> Basically to be <b>Findable</b> a dataset needs a persistent identifier (PID), such as a DOI, and metadata that includes information about the data themselves. The first piece, the PID, ensures that the location\n\t\t\tof the data (e.g. on a server) can be found, the second piece is needed to be able to find out if the data is potentially interesting. Both pieces have to be presented in such way that machines and search engines can understand this information.\n\t\t\t<br /> <b>Accessible</b> refers to digital access protocols which should be an international standard to allow for easy, automated retrieval. In addition it requires the metadata to be accessible. <b>Note that FAIR data are\n\t\t\tnot necessarily open and not all freely accessible data are FAIR!</b> The FAIR principles accept that some data need access restrictions, but the metadata (which ensure that one can at least find out that the data exists) should be available.\n\t\t\t<br /> <b>Interoperable</b> means that data and metadata can be used and combined with other (meta)data without the need for extensive restructuring. This usually means following metadata standards and using established vocabularies\n\t\t\tand ontologies. <br /> <b>Re-Usablily</b> refers to both detailed metadata (and documentation) to ensure that others can understand how to re-use the data but also to a clear legal license that specifies what needs to be done to be\n\t\t\tallowed to use the data. Both pieces of information should be able to be extracted in an automated way. <br /> More information on FAIR principles can be found in Wilkinson et al., "The FAIR Guiding Principles for scientific data management and\n\t\t\tstewardship", Scientific Data Vol. 3, 160018 (2016).	Eines der Kernthemen des H2020 Datenmanagements sind <a target="_blank" href="https://doi.org/10.1038/sdata.2016.18">FAIRe Daten</a>, siehe auch die <a target="_blank"\n\t\t\thref="https://www.force11.org/group/fairgroup/fairprinciples">Force11-Webseite</a>. Hier finden Sie einige Erläuterungen zur FAIRen Daten. Falls Sie mit dem Begriff bereits vertraut sind, können Sie einfach mit der nächsten H2020-Fragen\n\t\t\tfortfahren. Sonst ist es sinnvoll einen Blick auf die genannte Webseite zu werfen. <br /> Das Akronym FAIR seht für Findable, Accessible, Interoperable und Re-Usable und wurde in Wilkinson et al., "The FAIR Guiding Principles for scientific\n\t\t\tdata management and stewardship", Scientific Data Vol. 3, 160018 (2016) eingeführt.	\N					40	Was versteht man unter FAIRen Daten?	What are FAIR data?													f
148	2020-04-14 15:07:38.038+00	2020-04-14 15:07:38.038+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/Findable-accessibleMetadataProvision	https://fdm-bayern.org/eHumanities	Findable-accessibleMetadataProvision	Horizon2020/FAIR/Findable-accessibleMetadataProvision		t	20	Metadata are a formalized way to describe a datasets. They usually follow discipline or data type specific standards. A documentation is a more than an in-depth description of a dataset. The documentation should also include a\n\t\t\tdetailed record of how the data was generated, how it can be re-used with standard tools and ideally an example how this can be done. Documentations do not necessary follow a standard. Metadata standards are necessary to ensure that other researchers\n\t\t\tbut more importantly machines can <ul> <li>locate the dataset </li> <li>cite the dataset </li> <li>determine content and context </li> <li>check conditions for re-use and access </li>\n\t\t\t<li>disseminate the metadata and make sure that the dataset can be found in various search engine and databases.</li> </ul>	Metadaten stellen eine formalisierte Art dar, einen Datensatz zu beschreiben. Es sind „Daten über Daten“. In aller Regel folgen Metadaten disziplin- oder datentyp-spezifischen Standards. Eine Dokumentation ist eine sehr viel tiefere\n\t\t\tBeschreibung des Datensatzes. Sie umfasst nicht nur den genauen Aufbau des Datensatzes sondern beschreibt auch deren Genese und Informationen wie und mit welchen Werkzeugen die Daten am besten genutzt werden können. Eine Dokumentation folgt nicht\n\t\t\tnotwendigerweise einem Standard. Metadatenstandards sind notwendig, um sicherzustellen, dass Forschende vor allem aber Maschinen <ul> <li>den Datensatz auffinden können</li> <li>die Daten zitieren können</li>\n\t\t\t<li>sich ein Bild von Inhalt und Kontext der Daten machen können</li> <li>die Bedingungen für die Nachnutzung der Daten erschießen können</li> <li>die Metadaten verbreiten und somit sicherstellen können, dass einer\n\t\t\tVielzahl von Suchmaschinen, Datenbanken und Repositorien Informationen über diesen Datensatz zur Verfügung stehen.</li> </ul>	39	Datensatz	datset	Datensätze	datasets	40	Daten auffindbar machen und Regelungen für Metadaten I	Making data findable, including provisions fo metadata I													f
149	2020-04-14 15:07:38.091+00	2020-04-14 15:07:38.091+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/Findable-findable_detail	https://fdm-bayern.org/eHumanities	Findable-findable_detail	Horizon2020/FAIR/Findable-findable_detail		t	20			39	Datensatz	datset	Datensätze	datasets	40	Daten auffindbar machen und Regelungen für Metadaten II	Making data findable, including provisions for metadata II													f
150	2020-04-14 15:07:38.133+00	2020-04-14 15:07:38.133+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/accessible-access_to_data	https://fdm-bayern.org/eHumanities	accessible-access_to_data	Horizon2020/FAIR/accessible-access_to_data		t	30			39	Datensatz	datset	Datensätze	datasets	40	Offener Zugang zu den Daten II	Making data openly accessible II													f
151	2020-04-14 15:07:38.181+00	2020-04-14 15:07:38.181+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/accessible-dataaccess	https://fdm-bayern.org/eHumanities	accessible-dataaccess	Horizon2020/FAIR/accessible-dataaccess		t	30	Horizon 2020 follows the accessibility criteria of the <a target="_blank" href="http://www.force11.org/group/fairgroup/fairprinciples">FAIR data project</a>. The project stresses that (meta-)data should be accessible via\n\t\t\topen, standardized communication protocols or software. The metadata should always be freely accessible even if the data are not.	Horizon 2020 folgt weitestgehend der Definition von Zugänglichkeit des <a target="_blank" href="http://www.force11.org/group/fairgroup/fairprinciples">FAIR Data Projekts</a>. Diese betont, dass auf die (Meta-)Daten mit\n\t\t\tHilfe offener, standardisierter Kommunikationsprotokolle und Software zugegriffen werden können muss. Die Metadaten sollen grundsätzlich frei zugänglich sein, selbst wenn die Daten dies nicht sind.	39	Datensatz	datset	Datensätze	datasets	40	Offener Zugang zu den Daten I	Making data openly accessible II													f
152	2020-04-14 15:07:38.24+00	2020-04-14 15:07:38.24+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/interoperable-interop	https://fdm-bayern.org/eHumanities	interoperable-interop	Horizon2020/FAIR/interoperable-interop		t	40			39	Datensatz	datset	Datensätze	datasets	40	Daten dialogfähig machen	Making data interoperable													f
153	2020-04-14 15:07:38.282+00	2020-04-14 15:07:38.282+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR/re_useable-re_use	https://fdm-bayern.org/eHumanities	re_useable-re_use	Horizon2020/FAIR/re_useable-re_use		t	50			39	Datensatz	datset	Datensätze	datasets	40	Erhöhen der Nachnutzbarkeit (durch klare Lizenzbedingungen)	Increase data re-use (through clarifying licences)													f
154	2020-04-14 15:07:38.326+00	2020-04-14 15:07:38.326+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/costs/data-costs	https://fdm-bayern.org/eHumanities	data-costs	Horizon2020/costs/data-costs		f	0			\N					41	Kosten, um Daten FAIR zu gestalten	Costs for making data FAIR													f
155	2020-04-14 15:07:38.378+00	2020-04-14 15:07:38.378+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/costs/data-datavalue	https://fdm-bayern.org/eHumanities	data-datavalue	Horizon2020/costs/data-datavalue		t	30			39	Datensatz	datset	Datensätze	datasets	41	Kosten - Langzeitarchivierung	Costs - long term archiving													f
156	2020-04-14 15:07:38.426+00	2020-04-14 15:07:38.426+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/costs/data-longtermcost	https://fdm-bayern.org/eHumanities	data-longtermcost	Horizon2020/costs/data-longtermcost		f	10	Long term preservation usually means that the dataset is stored securely for a time-span that exceeds the standard storage time. The time span is, however, not clearly defined. Often it is taken to mean 'at least for 25 years', but\n\t\t\tmuseums, libraries and other memory institutions tend to think in terms of centuries. Published data should generally be stored long-term, in order to ensure that references to the dataset can be checked.	Langzeitarchivierung (LZA) bedeutet das Aufbewahren des Datensatzes über die übliche Haltefrist hinaus. Die Aufbewahrungsdauer ist allerdings nicht klar festgelegt. So gelten oft Zeiten von mindestens 25 Jahren als\n\t\t\tLangzeitarchivierung. Museen, Bibliotheken und andere Gedächtnisinstitutionen neigen aber dazu, bei LZA in Jahrhunderten zu denken. Publizierte Daten sollten im Allgemeinen langfristig gesichert werden, um sicherzugehen, dass entsprechende\n\t\t\tLiteraturangaben und Referenzen geprüft werden können.	\N					41	Kosten - Langzeitverfügbarkeit	Costs - long term preservation													f
212	2020-04-29 13:44:43.931+00	2020-11-08 14:54:44.931+00	http://example.com/terms/questions/GFBio test/general/Funding	http://example.com/terms	Funding	GFBio test/general/Funding		f	7			\N					60	Förderung	Funding													f
159	2020-04-14 15:07:38.588+00	2020-04-14 15:07:38.588+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_summary/datasets-Dataset_intro	https://fdm-bayern.org/eHumanities	datasets-Dataset_intro	Horizon2020/data_summary/datasets-Dataset_intro		f	11	In this section information on the data themselves will be collected. This H2020 plan allows you to consider various datasets separately. This can be advantageous, as different datasets may be very different in regard to data size,\n\t\t\tintellectual property rights or data types. If the project has vastly different data types that are analysed and created by different project partners, you can also provide a distinct data management plan for different parts of the project. <br\n\t\t\t/> E.g. consider a project that tries to map the information flow of various scholars in the early 20th century. One data file may contain information on the network of letters (who corresponded with whom, when, on which topic ...) another dataset\n\t\t\tmight be the transcriptions and digital scans of the letters. Compiling and sharing the latter may be affected by privacy protection laws, copyright laws or research ethics guidelines; the network data will be far less constrained. <br />\n\t\t\tHowever, it is also recommended to group data that face similar external constraints and have similar properties in one larger dataset and consider the different files / data types as subsets of the larger dataset. This simplifies writing this DMP as\n\t\t\tthere will be less (repetitive) answers to give.	In diesem Anschnitt werden allgemeine Informationen zu den Daten gesammelt. Es ist möglich verschiedene Datensätze getrennt voneinander zu behandeln. Dies ist von Vorteil, wenn die einzelnen Datensätze sehr unterschiedliche\n\t\t\tEigenschaften haben und unterschiedliche Auflagen bzw. Bedingungen erfüllt werden müssen. <br /> Ein Beispiel: Das Projekt umfasst eine Untersuchung zum Informationsfluss zwischen Forschern im frühen 20. Jahrhundert. Ein Datensatz ist das\n\t\t\tNetzwerk der Briefe zwischen Forschern (Wer, mit wem, wann, zu welchem Thema, ...), ein anderer Datensatz sind die Transkriptionen und Scans der Briefe selbst. In letzterem Fall werden nicht nur andere Standards und Formate verwendet werden, sondern\n\t\t\tauch strengere Auflagen bezüglich der Weiterverbreitung und Nachnutzung aus Datenschutzrecht, Urheberrecht und Forschungsethik bestehen. <br /> Ein sinnvolles Zusammenfassen von Daten zu einem übergreifenden Datensatz kann vorteilhaft sein,\n\t\t\twenn die Daten ähnliche Eigenschaften aufweisen. Dies reduziert die Zahl der (sich wiederholenden) Fragen, die in diesem DMP beantwortet werden müssen.	\N					43	Datensätze	Datasets													f
160	2020-04-14 15:07:38.642+00	2020-04-14 15:07:38.642+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_summary/datasets-data_reuse	https://fdm-bayern.org/eHumanities	datasets-data_reuse	Horizon2020/data_summary/datasets-data_reuse		t	13			39	Datensatz	dataset	Datensätze	datasets	43	Datensätze - Nachnutzung	Datasets - re-use													f
161	2020-04-14 15:07:38.691+00	2020-04-14 15:07:38.691+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_summary/datasets-datasets	https://fdm-bayern.org/eHumanities	datasets-datasets	Horizon2020/data_summary/datasets-datasets		t	12	Please create at least one new dataset to continue!	Bitte legen Sie mindestens einen Eintrag für einen Datensatz an, bevor Sie fortfahren!	39	Datensatz	datset	Datensätze	datasets	43	Datensätze - Beschreibung und Formate	Datasets - description and formats													f
162	2020-04-14 15:07:38.758+00	2020-04-14 15:07:38.758+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_summary/datasets-size_and_use	https://fdm-bayern.org/eHumanities	datasets-size_and_use	Horizon2020/data_summary/datasets-size_and_use		t	14			39	Datensatz	datset	Datensätze	datasets	43	Datensätze - Volumen und Potential	Datasets - size and utility													f
163	2020-04-14 15:07:38.811+00	2020-04-14 15:07:38.811+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/other/funder-other	https://fdm-bayern.org/eHumanities	funder-other	Horizon2020/other/funder-other		f	12			\N					44	Datenmanagementanforderungen	data management requirements													f
164	2020-04-14 15:07:38.887+00	2020-04-14 15:07:38.887+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/other/funder-yesno	https://fdm-bayern.org/eHumanities	funder-yesno	Horizon2020/other/funder-yesno		f	11			\N					44	Datenmanagementanforderungen	data management requirements													f
165	2020-04-14 15:07:38.945+00	2020-04-14 15:07:38.945+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/project_details/project_info-PI	https://fdm-bayern.org/eHumanities	project_info-PI	Horizon2020/project_details/project_info-PI		t	2	Please first add a new PI using the green button.	Bitte fügen Sie zunächst einen hauptverantwortlichen Wissenschaftler oder eine hauptverantwortliche Wissenschaftlerin (PI) über den grünen Knopf hinzu.	220	PI	principal investigator	PI	principal investigators	45	Allgemeine Informationen II	General information II													f
166	2020-04-14 15:07:38.995+00	2020-04-14 15:07:38.995+00	https://fdm-bayern.org/eHumanities/questions/Horizon2020/project_details/project_info-project	https://fdm-bayern.org/eHumanities	project_info-project	Horizon2020/project_details/project_info-project		f	1	\n\t\t\tBefore you start working on this H2020 datamanagement plan, it can be useful to have a look at H2020 DMPs that have been published to get a feel for the level of detail of other DMPs. Here are some examples: <ul> <li> <a\n\t\t\ttarget="_blank" href="https://www.magenta-h2020.eu/wp-content/uploads/2018/01/D8.2-Data-Management-Plan.pdf">MAGnetic nanoparticle based liquid ENergy materials for Thermoelectric device Applications</a> follows the official H2020\n\t\t\tquestionnaire template closely. </li> <li> <a target="_blank" href="https://seafoodtomorrow.eu/wp-content/uploads/2018/06/SEAFOODtomorrow_Data-Management-Plan_D6.1_FINAL.pdf">SEAFOOD TOMORROW</a> uses a different structure for\n\t\t\tthe DMP but the sections still roughly follow the standard template. </li> <li> <a target="_blank" href="http://www.freme-project.eu/resources/FREME_Deliverable_D7-4.pdf">FERME</a> is an older project and the H2020 DMP\n\t\t\ttemplate was published after the project started. </li> <li> <a target="_blank" href="https://zenodo.org/record/48171#.XhhSDiMxmUm">HNSciCloud</a> also published the DMP before the template was made available. </li>\n\t\t\t</ul>\n\t\t	Da der Horizon 2020 Datenmanagementplan wahrscheinlich in Englisch geschrieben werden soll, ist es sinnvoll die Sprache auf Englisch umzustellen. Die Fragen entsprechen dann der offiziellen EU Vorgabe. Die deutschsprachige Übersetzung\n\t\t\tdient nur der Vollständigkeit.\n\t\t\t	\N					45	Allgemeine Informationen I	General information I													f
205	2020-04-29 09:21:39.657+00	2020-11-08 14:54:45.674+00	http://example.com/terms/questions/GFBio test/general/projectName	http://example.com/terms	projectName	GFBio test/general/projectName		f	0			201					60	Name	Name													f
206	2020-04-29 09:49:40.125+00	2020-11-08 14:54:45.116+00	http://example.com/terms/questions/GFBio test/general/category	http://example.com/terms	category	GFBio test/general/category		f	1			1					60	Kategorie	Category													f
207	2020-04-29 10:26:45.403+00	2020-11-08 14:54:45.854+00	http://example.com/terms/questions/GFBio test/general/reproducible	http://example.com/terms	reproducible	GFBio test/general/reproducible		f	2			1					60	Reproduzierbar	Reproducible													f
208	2020-04-29 10:42:36.892+00	2020-11-08 14:54:45.769+00	http://example.com/terms/questions/GFBio test/general/projectTypes	http://example.com/terms	projectTypes	GFBio test/general/projectTypes		f	3			1					60	Projekttyp	Project Type													f
209	2020-04-29 10:48:24.356+00	2020-11-08 14:54:45.595+00	http://example.com/terms/questions/GFBio test/general/projectAbstract	http://example.com/terms	projectAbstract	GFBio test/general/projectAbstract		f	4			\N					60	Zusammenfassung des Projekts	Project abstract													f
210	2020-04-29 10:53:01.722+00	2020-11-08 14:54:45.364+00	http://example.com/terms/questions/GFBio test/general/point_of_contact	http://example.com/terms	point_of_contact	GFBio test/general/point_of_contact		f	5	Who should be contacted in case of any question concerning data management? This might be technical issues as well as questions concerning data policies, legal requirements or data volumes and formats. Most commonly this is: you - the one preparing the DMP.	Wer sollte bei Fragen zur Datenverwaltung kontaktiert werden? Dabei kann es sich sowohl um technische Fragen als auch um Fragen zur Datenpolitik, zu rechtlichen Anforderungen oder zu Datenmengen und -formaten handeln. Am häufigsten ist dies: Sie - derjenige, der das DMP vorbereitet.	247					60	Anlaufstelle	Point of contact													f
211	2020-04-29 12:46:55.231+00	2020-11-08 14:54:45.283+00	http://example.com/terms/questions/GFBio test/general/investigators	http://example.com/terms	investigators	GFBio test/general/investigators		f	6			\N					60	Forscher	Investigators													f
214	2020-04-30 09:51:18.048+00	2020-11-08 14:54:45.99+00	http://example.com/terms/questions/GFBio test/general/researchUnit	http://example.com/terms	researchUnit	GFBio test/general/researchUnit		f	9			\N					60	Forschungsgruppe	Research unit													f
215	2020-04-30 09:57:14.063+00	2020-11-08 14:54:44.842+00	http://example.com/terms/questions/GFBio test/general/Budget	http://example.com/terms	Budget	GFBio test/general/Budget		f	10			7					60	Budget	Budget													f
219	2020-04-30 10:04:57.728+00	2020-11-08 14:54:45.501+00	http://example.com/terms/questions/GFBio test/general/policies or guidelines	http://example.com/terms	policies or guidelines	GFBio test/general/policies or guidelines		f	10			37					60	Grundsätze oder Richtlinien	Policies or guidelines													f
220	2020-04-30 10:11:03.97+00	2020-11-08 14:54:43.416+00	http://example.com/terms/questions/GFBio test/Data_Collection/data objects_0	http://example.com/terms	data objects_0	GFBio test/Data_Collection/data objects_0	Re-define conditions for this complete question set	f	0			261					61	Datenobjekte	Data objects													f
224	2020-05-22 10:01:28.485+00	2020-05-22 10:04:56.181+00	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/Alternative GFBio/General/gfbio_other-requirements-yesno	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	gfbio_other-requirements-yesno	Alternative GFBio/General/gfbio_other-requirements-yesno	copied from the DFG Catalog	f	50			\N					62	Weitere Anforderungen I	Other requirements I													f
225	2020-07-06 13:32:07.086+00	2020-11-08 14:54:43.505+00	http://example.com/terms/questions/GFBio test/Data_Collection/data type	http://example.com/terms	data type	GFBio test/Data_Collection/data type		f	3			39					61	Datentyp	Data Type													f
226	2020-07-06 14:28:04.097+00	2020-11-08 14:54:43.69+00	http://example.com/terms/questions/GFBio test/Data_Collection/data volume	http://example.com/terms	data volume	GFBio test/Data_Collection/data volume		f	3			130					61	Datenmenge	Data volume													f
227	2020-07-06 15:05:38.551+00	2020-11-08 14:54:43.821+00	http://example.com/terms/questions/GFBio test/Data_Collection/standards_metodologies_or_tools	http://example.com/terms	standards_metodologies_or_tools	GFBio test/Data_Collection/standards_metodologies_or_tools		f	3			237					61	Standards, Methoden oder Werkzeuge	Standards, methodologies or tools													f
228	2020-07-07 10:17:32.738+00	2020-11-08 14:54:43.909+00	http://example.com/terms/questions/GFBio test/Documentation_and_metadata/documentation_and_metadata01	http://example.com/terms	documentation_and_metadata01	GFBio test/Documentation_and_metadata/documentation_and_metadata01		f	0			\N					63	Metadatenschema benutzt	Metadata schema used													f
229	2020-07-07 10:35:57.718+00	2020-11-08 14:54:44.297+00	http://example.com/terms/questions/GFBio test/Ethics_and_legal_compliance/ethical_issues_and_legal_requirements	http://example.com/terms	ethical_issues_and_legal_requirements	GFBio test/Ethics_and_legal_compliance/ethical_issues_and_legal_requirements		f	1			\N					64	Ethische Fragen und rechtliche Anforderungen	Ethical issues and legal requirements													f
230	2020-07-07 14:10:27.978+00	2020-11-08 14:54:44.001+00	http://example.com/terms/questions/GFBio test/Ethics_and_legal_compliance/copyright_and_licensing	http://example.com/terms	copyright_and_licensing	GFBio test/Ethics_and_legal_compliance/copyright_and_licensing		f	2			\N					64	Urheberrecht und Lizenzierung	Copyright and licensing													f
231	2020-07-08 09:45:27.045+00	2020-11-08 14:54:44.394+00	http://example.com/terms/questions/GFBio test/Ethics_and_legal_compliance/reuse_restrictions	http://example.com/terms	reuse_restrictions	GFBio test/Ethics_and_legal_compliance/reuse_restrictions		f	3			\N					64	Einschränkungen bei der Wiederverwendung	Reuse restrictions													f
232	2020-07-08 10:02:32.11+00	2020-11-08 14:54:44.097+00	http://example.com/terms/questions/GFBio test/Ethics_and_legal_compliance/data_sharing_restrictions	http://example.com/terms	data_sharing_restrictions	GFBio test/Ethics_and_legal_compliance/data_sharing_restrictions	To GFBio team: \nwhy is 'Data Sharing restrictions' not included in the last section: 'Preservation and Sharing'?	f	4			\N					64	Einschränkungen bei der gemeinsamen Nutzung von Daten	Data Sharing Restrictions													f
233	2020-07-08 10:09:17.167+00	2020-11-08 14:54:44.66+00	http://example.com/terms/questions/GFBio test/Preservation_and_Sharing/retain_share_preserve	http://example.com/terms	retain_share_preserve	GFBio test/Preservation_and_Sharing/retain_share_preserve		f	0			\N					65	Behalten, Teilen, Bewahren	Retain, Share, Preserve													f
234	2020-07-08 10:28:32.07+00	2020-11-08 14:54:44.755+00	http://example.com/terms/questions/GFBio test/Preservation_and_Sharing/storage_and_backup	http://example.com/terms	storage_and_backup	GFBio test/Preservation_and_Sharing/storage_and_backup		f	1			\N					65	Speicherung und Sicherung	Storage and Backup													f
235	2020-07-08 14:24:39.049+00	2020-11-08 14:54:44.571+00	http://example.com/terms/questions/GFBio test/Preservation_and_Sharing/long_term_preservation_data	http://example.com/terms	long_term_preservation_data	GFBio test/Preservation_and_Sharing/long_term_preservation_data		f	2			\N					65	Daten für die Langzeitarchivierung	Long-term preservation data													f
236	2020-07-08 14:35:18.615+00	2020-11-08 14:54:44.483+00	http://example.com/terms/questions/GFBio test/Preservation_and_Sharing/Data_citation	http://example.com/terms	Data_citation	GFBio test/Preservation_and_Sharing/Data_citation		f	3			\N					65	Zitieren von Daten	Data citation													f
237	2020-10-21 15:09:46.277+00	2020-11-08 14:54:43.093+00	http://example.com/terms/questions/GFBio test/Data_Collection/Data objects_1	http://example.com/terms	Data objects_1	GFBio test/Data_Collection/Data objects_1	If the previous question was answered with a 'yes', if 'no' then it should be skipped	f	1			285					61	Status der Datenobjekte	Data objects status													f
238	2020-10-21 15:20:28.307+00	2020-11-08 14:54:43.249+00	http://example.com/terms/questions/GFBio test/Data_Collection/Data objects_2	http://example.com/terms	Data objects_2	GFBio test/Data_Collection/Data objects_2		f	2			286					61	Datenobjekt Taxonomie	Data object Taxonomy													f
252	2020-10-28 14:09:44.125+00	2020-10-28 14:09:44.125+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/general/support	https://rdmorganiser.github.io/terms	support	biodiversity_dfg/general/support		f	61	Please enter here who supports you and how, e.g. gives advice, if possible divided into subject areas such as privacy protection, copyright and license law, storage, general data management advice,...	Bitte tragen Sie hier ein, wer Sie wie unterstützt, z.B. berät, möglichst eingeteilt in Themenfelder wie Datenschutz, Urheber- und Lizenzrecht, Speicherung, allgemeine Datenmanagementberatung,...	\N					69	Unterstützung	Support													f
253	2020-10-28 14:09:44.176+00	2020-10-28 14:09:44.176+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/legal-and-ethics/intellectual-property-rights-costs	https://rdmorganiser.github.io/terms	intellectual-property-rights-costs	biodiversity_dfg/legal-and-ethics/intellectual-property-rights-costs		f	65			\N					70	Urheber- oder verwandte Schutzrechte Kosten	Intellectual property rights costs													f
254	2020-10-28 14:09:44.262+00	2020-10-28 14:09:44.262+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/legal-and-ethics/intellectual-property-rights-dataset	https://rdmorganiser.github.io/terms	intellectual-property-rights-dataset	biodiversity_dfg/legal-and-ethics/intellectual-property-rights-dataset		t	31			39	Datensatz	dataset	Datensätze	datasets	70	Urheber- oder verwandte Schutzrechte II	Intellectual property rights II													f
239	2020-10-28 14:09:43.415+00	2020-10-28 14:09:43.415+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/content-classification/data-dataset	https://rdmorganiser.github.io/terms	data-dataset	biodiversity_dfg/content-classification/data-dataset		t	1	The following questions collect information on the data that is produced or used in the project. They also help to estimate the value of the data in terms of potential re-use and long-term preservation. Before data is newly created, it is advisable to check if there is existing data that could be re-used. This way, redundant collection or creation of research data is prevented. This saves efforts and costs. Furthermore, in the case of personal data, the principle of data minimization (Art. 5 EU General Data Protection Regulation) allows the collection of personal data only when there are no other reasonable means to clarify the research question (re-use of existing data would be such a reasonable means). Also, there shall be collected no more information than necessary. The information regarding the data collected, produced or used in the project is gathered along datasets. The definition of these datasets is an important conceptional decision that has to be made individually and carefully for each project.	Die nächsten Fragen dienen zur Beschreibung der Datensätze, die im Projekt erzeugt und/oder verwendet werden. Sie helfen zudem, den Wert der Daten hinsichtlich der potentiellen Nachnutzung und einer späteren Archivierung einschätzen zu können. Vor der Erzeugung von Daten empfiehlt es sich zu prüfen, ob bereits vorhandene Daten nachgenutzt werden können. Die Vermeidung doppelter Erhebungen spart Aufwand und Kosten. Handelt es sich um personenbezogene Daten, ist dies zudem durch den Grundsatz der Datenminimierung (Art. 5 EU Datenschutz-Grundverordnung) geboten. Die Angaben zu den im Projekt erzeugten oder verwendeten Daten sind nach „Datensätzen“ strukturiert. Die Definition dessen, was jeweils ein Datensatz ist, ist eine wichtige konzeptionelle Entscheidung, die für jedes Vorhaben bzw. Projekt individuell getroffen und sorgfältig abgewogen werden muss.	39	Datensatz	dataset	Datensätze	datasets	66	Datensätze	Datasets													f
240	2020-10-28 14:09:43.46+00	2020-10-28 14:09:43.46+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/content-classification/data-reproducibility	https://rdmorganiser.github.io/terms	data-reproducibility	biodiversity_dfg/content-classification/data-reproducibility		t	4			39	Datensatz	dataset	Datensätze	datasets	66	Reproduzierbarkeit	Reproducibility													f
241	2020-10-28 14:09:43.501+00	2020-10-28 14:09:43.501+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/content-classification/data-reuse	https://rdmorganiser.github.io/terms	data-reuse	biodiversity_dfg/content-classification/data-reuse		t	3			39	Datensatz	dataset	Datensätze	datasets	66	Nachnutzung	Reuse													f
242	2020-10-28 14:09:43.542+00	2020-10-28 14:09:43.542+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/costs-dataset	https://rdmorganiser.github.io/terms	costs-dataset	biodiversity_dfg/data-usage/costs-dataset		f	70			\N					67	Kosten	Costs													f
243	2020-10-28 14:09:43.703+00	2020-10-28 14:09:43.703+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-sharing-and-re-use-publication	https://rdmorganiser.github.io/terms	data-sharing-and-re-use-publication	biodiversity_dfg/data-usage/data-sharing-and-re-use-publication		t	52			39	Datensatz	dataset	Datensätze	datasets	67	Weitergabe und Veröffentlichung	Data sharing and re-use													f
244	2020-10-28 14:09:43.74+00	2020-10-28 14:09:43.74+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-storage-and-security-data_security	https://rdmorganiser.github.io/terms	data-storage-and-security-data_security	biodiversity_dfg/data-usage/data-storage-and-security-data_security		t	12			39	Datensatz	dataset	Datensätze	datasets	67	Datenspeicherung und -sicherheit	Data storage and security													f
245	2020-10-28 14:09:43.776+00	2020-10-28 14:09:43.776+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-storage-and-security-storage	https://rdmorganiser.github.io/terms	data-storage-and-security-storage	biodiversity_dfg/data-usage/data-storage-and-security-storage		t	11			39	Datensatz	dataset	Datensätze	datasets	67	Datenorganisation	Data organisation													f
246	2020-10-28 14:09:43.814+00	2020-10-28 14:09:43.814+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/data-tools	https://rdmorganiser.github.io/terms	data-tools	biodiversity_dfg/data-usage/data-tools		t	4			39	Datensatz	dataset	Datensätze	datasets	67	Werkzeuge	Tools													f
247	2020-10-28 14:09:43.856+00	2020-10-28 14:09:43.856+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage/quality-assurance-dataset	https://rdmorganiser.github.io/terms	quality-assurance-dataset	biodiversity_dfg/data-usage/quality-assurance-dataset		t	61			39	Datensatz	dataset	Datensätze	datasets	67	Qualitätssicherung	Quality assurance													f
248	2020-10-28 14:09:43.894+00	2020-10-28 14:09:43.894+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/doc/metadata-costs	https://rdmorganiser.github.io/terms	metadata-costs	biodiversity_dfg/doc/metadata-costs		f	12			\N					68	Dokumentationskosten	Documentation costs													f
249	2020-10-28 14:09:43.931+00	2020-10-28 14:09:43.931+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/doc/metadata-dataset	https://rdmorganiser.github.io/terms	metadata-dataset	biodiversity_dfg/doc/metadata-dataset		t	10			39	Datensatz	dataset	Datensätze	datasets	68	Metadaten und Datendokumentation	Metadata and data documentation													f
250	2020-10-28 14:09:43.971+00	2020-10-28 14:09:43.971+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/general/other-requirements-requirements	https://rdmorganiser.github.io/terms	other-requirements-requirements	biodiversity_dfg/general/other-requirements-requirements		f	51			\N					69	Anforderungen II	Requirements II													f
251	2020-10-28 14:09:44.054+00	2020-10-28 14:09:44.054+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/general/other-requirements-yesno	https://rdmorganiser.github.io/terms	other-requirements-yesno	biodiversity_dfg/general/other-requirements-yesno		f	50	At least the <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/guidelines_biodiversity_research.pdf" target=_blank>Guidelines on the Handling of Research Data in Biodiversity Research</a> should be considered. The recommendations mentioned there and those in the interdisplinary <a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/guidelines_research_data.pdf" target=_blank>DFG Guidelines on the Handling of Research Data</a> are covered by this questionnaire.	Mindestens die <a href="http://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten_biodiversitaetsforschung.pdf" target=_blank>Richtlinien zum Umgang mit Forschungsdaten in der Biodiversitätsforschung</a> sollten Beachtung finden. Die dort genannten Empfehlungen und die in den die fachübergreifenden DFG-<a href="https://www.dfg.de/download/pdf/foerderung/antragstellung/forschungsdaten/richtlinien_forschungsdaten.pdf" target=_blank>Leitlinien zum Umgang mit Forschungsdaten</a> sind durch diesen Fragenkatalog abgedeckt.	\N					69	Anforderungen I	Requirements I													f
255	2020-10-28 14:09:44.36+00	2020-10-28 14:09:44.36+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/legal-and-ethics/intellectual-property-rights-yesno	https://rdmorganiser.github.io/terms	intellectual-property-rights-yesno	biodiversity_dfg/legal-and-ethics/intellectual-property-rights-yesno		f	30			\N					70	Urheber- oder verwandte Schutzrechte I	Intellectual property rights I													f
256	2020-10-28 14:09:44.416+00	2020-10-28 14:09:44.416+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/legal-and-ethics/sensitive-data-personal_data	https://rdmorganiser.github.io/terms	sensitive-data-personal_data	biodiversity_dfg/legal-and-ethics/sensitive-data-personal_data		t	24			39	Datensatz	dataset	Datensätze	datasets	70	Sensible Daten	Sensitive data													f
257	2020-10-28 14:09:44.502+00	2020-10-28 14:09:44.502+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/legal-and-ethics/sensitive-data-personal_data_yesno	https://rdmorganiser.github.io/terms	sensitive-data-personal_data_yesno	biodiversity_dfg/legal-and-ethics/sensitive-data-personal_data_yesno		t	21			39	Datensatz	dataset	Datensätze	datasets	70	Personenbezogene Daten	Personal data													f
258	2020-10-28 14:09:44.565+00	2020-10-28 14:09:44.565+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/referencing/structure-granularity-and-referencing-costs	https://rdmorganiser.github.io/terms	structure-granularity-and-referencing-costs	biodiversity_dfg/referencing/structure-granularity-and-referencing-costs		f	23			\N					71	PIDs Kosten	PIDs costs													f
259	2020-10-28 14:09:44.611+00	2020-10-28 14:09:44.611+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/referencing/structure-granularity-and-referencing-pids	https://rdmorganiser.github.io/terms	structure-granularity-and-referencing-pids	biodiversity_dfg/referencing/structure-granularity-and-referencing-pids		t	21	The purpose of Persistent Identifiers (PIDs) is to ensure the permanent reference of (in particular) digital objects like online publications and research data. When traditional hyperlinks are used as reference, they point directly to the storage location of the data. The problem is, that if the storage location is changed, the link will not work anymore. A PID serves as an intermediate from which requests are directed to the current object location (this is called "resolving" of a PID). The PID stays the same, even if the storage location changes. While a mere hyperlink in this case would lead to nowhere, via the PID the object is still accessible. You can find more information about the mode of operation, usage and different kinds of PIDs in e.g. the <a href="http://www.ands.org.au/guides#identify" target=_blank>information material of the Australian National Data Service (ANDS)</a> (scroll down to "Identifying data and researchers").	Persistente Identifikatoren (PIDs) sollen die dauerhafte Referenzierung von (insbesondere) digitalen Objekten wie Publikationen oder Forschungsdaten ermöglichen. Statt, wie i.d.R. bei der Angabe eines Hyperlink als Referenz der Fall, direkt auf den Speicherort des Objektes zu verweisen, fungiert die PID als eine Zwischeninstanz, von der aus zum Objekt weitergeleitet wird (dies nennt man „Auflösen“ der PID). Die PID bleibt gleich, auch wenn der Speicherort des Objektes sich ändert. Während ein Hyperlink in diesem Fall ins Nichts führen würde, ist das Objekt über die PID weiterhin erreichbar. Mehr Informationen zur Funktionsweise, Verwendung und verschiedenen Arten von PIDs gibt es z.B. in den Informationsmaterialien von <a href="https://www.forschungsdaten.info/themen/veroeffentlichen-und-archivieren/persistente-identifikatoren/" target=_blank>forschungsdaten.info</a> oder des <a href="http://www.ands.org.au/guides#identify" target=_blank> Australian National Data Service (ANDS)</a> (nach unten scrollen zu "Identifying data and researchers").	39	Datensatz	dataset	Datensätze	datasets	71	Persistente Identifikatoren (PIDs)	Persistent Identifiers (PIDs)													f
260	2020-10-28 14:09:44.662+00	2020-10-28 14:09:44.662+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/referencing/structure-granularity-and-referencing-structure	https://rdmorganiser.github.io/terms	structure-granularity-and-referencing-structure	biodiversity_dfg/referencing/structure-granularity-and-referencing-structure		t	20			39	Datensatz	dataset	Datensätze	datasets	71	Objektstruktur, Granularität und Referenzierung	Structure, granularity, and referencing													f
261	2020-10-28 14:09:44.705+00	2020-10-28 14:09:44.705+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-costs	https://rdmorganiser.github.io/terms	long-term-preservation-costs	biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-costs		f	13			\N					72	Langzeitarchivierungskosten	Long-term preservation costs													f
262	2020-10-28 14:09:44.771+00	2020-10-28 14:09:44.771+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-datasets	https://rdmorganiser.github.io/terms	long-term-preservation-datasets	biodiversity_dfg/storage-and-long-term-preservation/long-term-preservation-datasets		t	11	The DFG expects primary data that is the basis of a publication to be stored in the researcher's own institution or an appropriate nationwide infrastructure long-term (for at least 10 years).	Die DFG erwartet, dass Primärdaten, die Grundlage einer Publikation sind, langfristig (für mindestens 10 Jahre) in der eigenen Einrichtung  oder in einer fachlich einschlägigen, überregionalen Infrastruktur gespeichert werden.	39	Datensatz	dataset	Datensätze	datasets	72	Langzeitarchivierung	Long-term preservation													f
263	2020-10-28 14:09:44.821+00	2020-10-28 14:09:44.821+00	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/technical-classification/data-formats	https://rdmorganiser.github.io/terms	data-formats	biodiversity_dfg/technical-classification/data-formats		t	3			39	Datensatz	dataset	Datensätze	datasets	73	Formate	Formats													f
\.


--
-- Data for Name: questions_questionset_conditions; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.questions_questionset_conditions (id, questionset_id, condition_id) FROM stdin;
1	72	1
2	80	4
3	81	4
4	83	8
5	83	7
6	86	8
7	88	8
8	107	1
9	109	4
10	111	8
11	122	1
12	124	4
13	126	8
14	163	1
15	232	17
16	237	18
17	238	19
18	250	1
19	253	4
20	254	4
21	256	8
\.


--
-- Data for Name: questions_section; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.questions_section (id, created, updated, "order", title_lang1, title_lang2, catalog_id, comment, key, uri, uri_prefix, path, title_lang3, title_lang4, title_lang5, locked) FROM stdin;
3	2021-07-13 19:37:54.559653+00	2021-07-13 19:37:54.559661+00	0			3		sec1	http://0.0.0.0:8000/questions/Cat1/sec1	http://0.0.0.0:8000/	Cat1/sec1				f
14	2020-04-14 14:47:19.661+00	2020-04-14 14:47:19.662+00	1	Content classification	Inhaltliche Einordnung	8		content-classification	https://rdmorganiser.github.io/terms/questions/rdmo/content-classification	https://rdmorganiser.github.io/terms	rdmo/content-classification				f
15	2020-04-14 14:47:19.696+00	2020-04-14 14:47:19.696+00	3	Data usage	Datennutzung	8		data-usage	https://rdmorganiser.github.io/terms/questions/rdmo/data-usage	https://rdmorganiser.github.io/terms	rdmo/data-usage				f
16	2020-04-14 14:47:19.733+00	2020-05-14 10:58:56.336+00	0	General	Allgemein	8		general	https://rdmorganiser.github.io/terms/questions/rdmo/general	https://rdmorganiser.github.io/terms	rdmo/general				f
17	2020-04-14 14:47:19.767+00	2020-04-14 14:47:19.767+00	5	Legal and ethics	Rechtliche und ethische Fragen	8		legal-and-ethics	https://rdmorganiser.github.io/terms/questions/rdmo/legal-and-ethics	https://rdmorganiser.github.io/terms	rdmo/legal-and-ethics				f
18	2020-04-14 14:47:19.801+00	2020-04-14 14:47:19.801+00	4	Metadata and referencing	Metadaten und Referenzierung	8		metadata-and-referencing	https://rdmorganiser.github.io/terms/questions/rdmo/metadata-and-referencing	https://rdmorganiser.github.io/terms	rdmo/metadata-and-referencing				f
19	2020-04-14 14:47:19.843+00	2020-04-14 14:47:19.843+00	10	Storage and long-term preservation	Speicherung und Langzeitarchivierung	8		storage-and-long-term-preservation	https://rdmorganiser.github.io/terms/questions/rdmo/storage-and-long-term-preservation	https://rdmorganiser.github.io/terms	rdmo/storage-and-long-term-preservation				f
20	2020-04-14 14:47:19.876+00	2020-04-14 14:47:19.876+00	2	Technical classification	Technische Einordnung	8		technical-classification	https://rdmorganiser.github.io/terms/questions/rdmo/technical-classification	https://rdmorganiser.github.io/terms	rdmo/technical-classification				f
21	2020-04-14 14:58:23.072+00	2020-05-12 08:10:39.644+00	1	Content classification	Inhaltliche Einordnung	9		content-classification	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/content-classification	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	dfg/content-classification				f
22	2020-04-14 14:58:23.105+00	2020-05-12 08:10:39.856+00	3	Data usage	Datennutzung	9		data-usage	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/data-usage	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	dfg/data-usage				f
23	2020-04-14 14:58:23.136+00	2020-05-12 08:10:40.298+00	0	General	Allgemein	9		general	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/general	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	dfg/general				f
24	2020-04-14 14:58:23.171+00	2020-05-12 08:10:40.513+00	5	Legal and ethics	Rechtliche und ethische Fragen	9		legal-and-ethics	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/legal-and-ethics	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	dfg/legal-and-ethics				f
25	2020-04-14 14:58:23.208+00	2020-05-12 08:10:40.961+00	10	Storage and long-term preservation	Speicherung und Langzeitarchivierung	9		storage-and-long-term-preservation	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/storage-and-long-term-preservation	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	dfg/storage-and-long-term-preservation				f
26	2020-04-14 14:58:23.247+00	2020-05-12 08:10:41.223+00	2	Technical classification	Technische Einordnung	9		technical-classification	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/dfg/technical-classification	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	dfg/technical-classification				f
27	2020-04-14 14:59:59.041+00	2020-04-14 14:59:59.041+00	1	Content classification	Inhaltliche Einordnung	10		content-classification	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/content-classification	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	edu_dfg/content-classification				f
28	2020-04-14 14:59:59.077+00	2020-04-14 14:59:59.077+00	3	Data usage	Datennutzung	10		data-usage	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/data-usage	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	edu_dfg/data-usage				f
29	2020-04-14 14:59:59.115+00	2020-04-14 14:59:59.115+00	4	Metadata and data documentation	Metadaten und Datendokumentation	10	hervorgegangen aus dem Abschnitt "Metadaten und Referenzierung" des Katalogs "RDMO"	doc	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/doc	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	edu_dfg/doc				f
30	2020-04-14 14:59:59.149+00	2020-04-14 14:59:59.149+00	0	General	Allgemein	10		general	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/general	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	edu_dfg/general				f
31	2020-04-14 14:59:59.19+00	2020-04-14 14:59:59.19+00	5	Legal and ethics	Rechtliche und ethische Fragen	10		legal-and-ethics	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/legal-and-ethics	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	edu_dfg/legal-and-ethics				f
32	2020-04-14 14:59:59.225+00	2020-04-14 14:59:59.225+00	10	Storage and long-term preservation	Speicherung und Langzeitarchivierung	10		storage-and-long-term-preservation	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/storage-and-long-term-preservation	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	edu_dfg/storage-and-long-term-preservation				f
33	2020-04-14 14:59:59.257+00	2020-04-14 14:59:59.257+00	2	Technical classification	Technische Einordnung	10		technical-classification	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo/questions/edu_dfg/technical-classification	https://ed45a26fb17322518ab44517596c99f815c6df14.rdmo	edu_dfg/technical-classification				f
39	2020-04-14 15:07:37.601+00	2020-04-14 15:07:37.601+00	6	Ethical Aspects	Ethische Aspekte	12		Ethics	https://fdm-bayern.org/eHumanities/questions/Horizon2020/Ethics	https://fdm-bayern.org/eHumanities	Horizon2020/Ethics				f
40	2020-04-14 15:07:37.636+00	2020-04-14 15:07:37.636+00	3	FAIR data principles	FAIR-Prinzipien	12		FAIR	https://fdm-bayern.org/eHumanities/questions/Horizon2020/FAIR	https://fdm-bayern.org/eHumanities	Horizon2020/FAIR				f
41	2020-04-14 15:07:37.672+00	2020-04-14 15:07:37.672+00	4	Allocation of resources	Benötigte Ressourcen	12		costs	https://fdm-bayern.org/eHumanities/questions/Horizon2020/costs	https://fdm-bayern.org/eHumanities	Horizon2020/costs				f
42	2020-04-14 15:07:37.706+00	2020-04-14 15:07:37.707+00	5	Data security	Datensicherheit	12		data_security	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_security	https://fdm-bayern.org/eHumanities	Horizon2020/data_security				f
43	2020-04-14 15:07:37.762+00	2020-04-14 15:07:37.762+00	2	Data summary	Zusammenfassung der Daten	12		data_summary	https://fdm-bayern.org/eHumanities/questions/Horizon2020/data_summary	https://fdm-bayern.org/eHumanities	Horizon2020/data_summary				f
44	2020-04-14 15:07:37.797+00	2020-04-14 15:07:37.797+00	7	Other	Sonstiges	12		other	https://fdm-bayern.org/eHumanities/questions/Horizon2020/other	https://fdm-bayern.org/eHumanities	Horizon2020/other				f
45	2020-04-14 15:07:37.831+00	2020-04-14 15:07:37.831+00	1	Project	Projekt	12		project_details	https://fdm-bayern.org/eHumanities/questions/Horizon2020/project_details	https://fdm-bayern.org/eHumanities	Horizon2020/project_details				f
60	2020-04-29 09:19:35.094+00	2020-11-08 14:54:41.504+00	0	General Project Information	Allgemeine Projektinformationen	18		general	http://example.com/terms/questions/GFBio test/general	http://example.com/terms	GFBio test/general				f
61	2020-04-30 10:09:07.109+00	2020-11-08 14:54:39.639+00	1	Data Collection	Datenerfassung	18		Data_Collection	http://example.com/terms/questions/GFBio test/Data_Collection	http://example.com/terms	GFBio test/Data_Collection				f
62	2020-05-12 10:34:05.124+00	2020-05-12 10:43:45.971+00	0	General	Allgemein	19		General	http://example.com/terms/questions/Alternative GFBio/General	http://example.com/terms	Alternative GFBio/General				f
63	2020-07-06 15:16:15.531+00	2020-11-08 14:54:40.543+00	2	Documentation and metadata	Dokumentation und Metadaten	18		Documentation_and_metadata	http://example.com/terms/questions/GFBio test/Documentation_and_metadata	http://example.com/terms	GFBio test/Documentation_and_metadata				f
64	2020-07-07 10:32:03.771+00	2020-11-08 14:54:40.669+00	3	Ethics and legal compliance	Ethik und Einhaltung von Gesetzen	18		Ethics_and_legal_compliance	http://example.com/terms/questions/GFBio test/Ethics_and_legal_compliance	http://example.com/terms	GFBio test/Ethics_and_legal_compliance				f
65	2020-07-08 09:59:49.716+00	2020-11-08 14:54:41.108+00	4	Preservation and Sharing	Bewahrung und gemeinsame Nutzung	18		Preservation_and_Sharing	http://example.com/terms/questions/GFBio test/Preservation_and_Sharing	http://example.com/terms	GFBio test/Preservation_and_Sharing				f
66	2020-10-28 14:09:43.118+00	2020-10-28 14:09:43.118+00	1	Content classification	Inhaltliche Einordnung	21		content-classification	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/content-classification	https://rdmorganiser.github.io/terms	biodiversity_dfg/content-classification				f
67	2020-10-28 14:09:43.181+00	2020-10-28 14:09:43.181+00	3	Data usage	Datennutzung	21		data-usage	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/data-usage	https://rdmorganiser.github.io/terms	biodiversity_dfg/data-usage				f
68	2020-10-28 14:09:43.211+00	2020-10-28 14:09:43.211+00	4	Documentation	Dokumentation	21		doc	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/doc	https://rdmorganiser.github.io/terms	biodiversity_dfg/doc				f
69	2020-10-28 14:09:43.241+00	2020-10-28 14:09:43.241+00	0	General	Allgemein	21		general	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/general	https://rdmorganiser.github.io/terms	biodiversity_dfg/general				f
70	2020-10-28 14:09:43.279+00	2020-10-28 14:09:43.279+00	6	Legal and ethics	Rechtliche und ethische Fragen	21		legal-and-ethics	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/legal-and-ethics	https://rdmorganiser.github.io/terms	biodiversity_dfg/legal-and-ethics				f
71	2020-10-28 14:09:43.31+00	2020-10-28 14:09:43.31+00	5	Referencing	Referenzierung	21		referencing	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/referencing	https://rdmorganiser.github.io/terms	biodiversity_dfg/referencing				f
72	2020-10-28 14:09:43.34+00	2020-10-28 14:09:43.34+00	10	Storage and long-term preservation	Speicherung und Langzeitarchivierung	21		storage-and-long-term-preservation	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/storage-and-long-term-preservation	https://rdmorganiser.github.io/terms	biodiversity_dfg/storage-and-long-term-preservation				f
73	2020-10-28 14:09:43.371+00	2020-10-28 14:09:43.371+00	2	Technical classification	Technische Einordnung	21		technical-classification	https://rdmorganiser.github.io/terms/questions/biodiversity_dfg/technical-classification	https://rdmorganiser.github.io/terms	biodiversity_dfg/technical-classification				f
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: tasks_task; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.tasks_task (id, title_lang1, title_lang2, text_lang1, text_lang2, comment, key, uri, uri_prefix, days_after, days_before, end_attribute_id, start_attribute_id, text_lang3, text_lang4, text_lang5, title_lang3, title_lang4, title_lang5, available, locked) FROM stdin;
1	Contact IT or data management expert	IT- oder Datenmanagementexpertin/en kontaktieren	Please contact an IT or data managament expert to get support in terms of data usage.	Bitte kontaktieren Sie Personen mit IT- oder Datenmanagementexpertise, um die notwendige Unterstützung für geplante Datennutzungsszenarien zu erhalten.		contact_IT_or_data_management_expert	http://example.com/terms/tasks/contact_IT_or_data_management_expert	http://example.com/terms	\N	\N	\N	\N							t	f
2	Clarify consequences of different international jurisdictions	Konsequenzen verschiedener relevanter Gesetzgebungen klären	Please get in touch with the legal department or a respective contact person at your institution to clarify if this has consequences for the project and its data management and if yes, what consequences these are.	Setzen Sie sich bitte mit der Rechtsabteilung bzw. einem/r entsprechenden Ansprechpartner/in an Ihrer Institution in Verbindung, um zu klären, ob sich daraus Konsequenzen für Ihr Projekt ergeben und wenn ja, welche dies sind.		clarify_consequences_international_law	https://rdmorganiser.github.io/terms/tasks/clarify_consequences_international_law	https://rdmorganiser.github.io/terms	\N	\N	\N	\N							t	f
3	Contact IT department to acquire infrastructure resources	IT-Abteilung kontaktieren, um Infrastrukturressourcen zu organisieren	Please get in touch with your IT department to arrange that the required infrastructure resources are provided.	Bitte nehmen Sie Kontakt mit der IT-Abteilung auf, um die Bereitstellung der benötigten Infrastrukturressourcen zu organisieren.		contact_IT_department	https://rdmorganiser.github.io/terms/tasks/contact_IT_department	https://rdmorganiser.github.io/terms	\N	\N	\N	\N							t	f
6	Create data organisation policy	Richtlinien zur Datenorganisation erstellen	Create a policy for a consistent data organisation in the project.	Erstellen Sie eine Richtlinie zur einheitlichen Organisation der Daten im Projekt.		create_data_organisation_policy	https://rdmorganiser.github.io/terms/tasks/create_data_organisation_policy	https://rdmorganiser.github.io/terms	\N	\N	\N	\N							t	f
4	Contact data security officer about special requirements	Datenschutzbeauftragten bzgl. spezieller Anforderungen kontaktieren.	At least one of the datasets contains particularly sensitive personal information according ot BDSG § 3, 9. \n\nPlease get in touch with the data protection officer of your institution to check which additional protection measures are necessary.	Mindestens einer der Datensätze enthält besonders sensible personenbezogene Daten\n nach BDSG §3, Abs. 9. \n\nInfomieren Sie sich bitte bei der/dem Datenschutzbeauftragten Ihrer Institution, welche zusätzlichen Schutzmaßnahmen notwendig sind.		contact_data_security_officer	https://rdmorganiser.github.io/terms/tasks/contact_data_security_officer	https://rdmorganiser.github.io/terms	\N	\N	\N	\N							t	f
5	Contact rights owner	Rechteinhaber/in kontaktieren	Clarify, if and how this restricts the possibility of long-term preservation and re-use and if the rights onwer ist willing to grant the necessary rights.	Prüfen Sie, welche Einschränkungen damit bezüglich der Langzeitarchivierung und Nachnutzung bestehen und ob der/die Rechteinhaberin bereit ist, ggf. die notwendigen Rechte einzuräumen.		contact_rights_owner	https://rdmorganiser.github.io/terms/tasks/contact_rights_owner	https://rdmorganiser.github.io/terms	\N	\N	\N	\N							t	f
7	Create data naming policy	Richtlinie zur Benennung der Daten erstellen	Create a guideline for a consistent naming of the data within the project.	Erstellen Sie eine Richtlinie zur einheitlichen Benennung der Daten innerhalb des Projekts.		create_naming_policy	https://rdmorganiser.github.io/terms/tasks/create_naming_policy	https://rdmorganiser.github.io/terms	\N	\N	\N	\N							t	f
8	Determine Versioning Tool	Versionierungstool bestimmen	Determine, which versioning tool will be used for the versioning.	Legen Sie fest, welches Versionierungstool genutzt werden soll.		determine_versioning_tool	https://rdmorganiser.github.io/terms/tasks/determine_versioning_tool	https://rdmorganiser.github.io/terms	\N	\N	\N	\N							t	f
9	Finish first DMP	Ersten DMP abschließen	The first DMP should be finished about 3 months after the project has started.	Der erste DMP sollte 3 Monate nach Projektbeginn abgeschlossen sein.		finish-first-dmp	https://rdmorganiser.github.io/terms/tasks/finish-first-dmp	https://rdmorganiser.github.io/terms	90	\N	\N	206							t	f
10	Identify rights owner	Rechteinhaber/in recherchieren	Identify the rights owner and contact him / her to see if the rights necessary for long-term preservation and re-use will be granted.	Identifizeren Sie den/die Rechteinhaber/in und prüfen Sie, ob diese/r bereit ist, die ggf. die für die Langzeitarchivierung und Nachnutzung notwendigen Rechte einzuräumen.		identify_rights_owner	https://rdmorganiser.github.io/terms/tasks/identify_rights_owner	https://rdmorganiser.github.io/terms	\N	\N	\N	\N							t	f
11	Inform data security officer	Datenschutzbeauftragte/n informieren	At least one dataset contains personal data. Please contact the data security officer in charge.	Mindestens ein Datensatz enthält personenbezogene Daten. Bitte infomieren Sie den oder die zuständige/n Datenschutzbeauftragte/n Ihrer Institution.		inform_data_security_officer	https://rdmorganiser.github.io/terms/tasks/inform_data_security_officer	https://rdmorganiser.github.io/terms	\N	\N	\N	\N							t	f
12	Please provide the official name for your project	Bitte geben Sie den offiziellen Namen für Ihr Projekt an	An official name for your project is mandatory	Ein offizieller Name für Ihr Projekt ist obligatorisch	Please provide the official name for your project.	gfbio_provide_official_name_project	http://example.com/terms/tasks/gfbio_provide_official_name_project	http://example.com/terms	\N	\N	\N	\N							t	f
13	Please provide the point of contact of your data	Bitte geben Sie die Kontaktstelle Ihrer Daten an	Please provide the point of contact of your data: name and e-mail	Bitte geben Sie den Kontaktpunkt Ihrer Daten an: Name und E-Mail		gfbio_point_of_contact_mandatory	http://example.com/terms/tasks/gfbio_point_of_contact_mandatory	http://example.com/terms	\N	\N	\N	\N							t	f
\.


--
-- Data for Name: tasks_task_catalogs; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.tasks_task_catalogs (id, task_id, catalog_id) FROM stdin;
\.


--
-- Data for Name: tasks_task_conditions; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.tasks_task_conditions (id, task_id, condition_id) FROM stdin;
1	2	6
2	3	3
3	5	10
4	8	13
\.


--
-- Data for Name: tasks_task_groups; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.tasks_task_groups (id, task_id, group_id) FROM stdin;
\.


--
-- Data for Name: tasks_task_sites; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.tasks_task_sites (id, task_id, site_id) FROM stdin;
1	1	1
2	2	1
3	3	1
4	4	1
5	5	1
6	6	1
7	7	1
8	8	1
9	9	1
10	10	1
11	11	1
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.users_user (id, password, last_login, is_superuser, username, email, is_staff, is_active, date_joined, name, first_name, last_name) FROM stdin;
1	argon2$argon2i$v=19$m=512,t=2,p=2$SjAyakwzWXFVaUVt$Kj6VXafijopvW593dIVJMA	2021-07-16 10:48:53.709515+00	t	maweber	maweber@mpi-bremen.de	t	t	2021-06-23 12:40:52+00			
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
1	1	1
2	1	2
3	1	3
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
1	1	1
2	1	2
3	1	3
4	1	4
5	1	5
6	1	6
7	1	7
8	1	8
9	1	9
10	1	10
11	1	11
12	1	12
13	1	13
14	1	14
15	1	15
16	1	16
17	1	17
18	1	18
19	1	19
20	1	20
21	1	21
22	1	22
23	1	23
24	1	24
25	1	25
26	1	26
27	1	27
28	1	28
29	1	29
30	1	30
31	1	31
32	1	32
33	1	33
34	1	34
35	1	35
36	1	36
37	1	37
38	1	38
39	1	39
40	1	40
41	1	41
42	1	42
43	1	43
44	1	44
45	1	45
46	1	46
47	1	47
48	1	48
49	1	49
50	1	50
51	1	51
52	1	52
53	1	53
54	1	54
55	1	55
56	1	56
57	1	57
58	1	58
59	1	59
60	1	60
61	1	61
62	1	62
63	1	63
64	1	64
65	1	65
66	1	66
67	1	67
68	1	68
69	1	69
70	1	70
71	1	71
72	1	72
73	1	73
74	1	74
75	1	75
76	1	76
77	1	77
78	1	78
79	1	79
80	1	80
81	1	81
82	1	82
83	1	83
84	1	84
85	1	85
86	1	86
87	1	87
88	1	88
89	1	89
90	1	90
91	1	91
92	1	92
93	1	93
94	1	94
95	1	95
96	1	96
97	1	97
98	1	98
99	1	99
100	1	100
101	1	101
102	1	102
103	1	103
104	1	104
105	1	105
106	1	106
107	1	107
108	1	108
109	1	109
110	1	110
111	1	111
112	1	112
113	1	113
114	1	114
115	1	115
116	1	116
117	1	117
118	1	118
119	1	119
120	1	120
121	1	121
122	1	122
123	1	123
124	1	124
125	1	125
126	1	126
127	1	127
128	1	128
129	1	129
130	1	130
131	1	131
132	1	132
133	1	133
134	1	134
135	1	135
136	1	136
137	1	137
138	1	138
139	1	139
140	1	140
141	1	141
142	1	142
143	1	143
144	1	144
145	1	145
146	1	146
147	1	147
148	1	148
149	1	149
150	1	150
151	1	151
152	1	152
153	1	153
154	1	154
155	1	155
156	1	156
157	1	157
158	1	158
159	1	159
160	1	160
161	1	161
162	1	162
163	1	163
164	1	164
165	1	165
166	1	166
167	1	167
168	1	168
169	1	169
170	1	170
171	1	171
172	1	172
173	1	173
174	1	174
175	1	175
176	1	176
177	1	177
178	1	178
179	1	179
180	1	180
\.


--
-- Data for Name: views_view; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.views_view (id, key, comment, template, uri, uri_prefix, help_lang2, help_lang1, title_lang2, title_lang1, help_lang3, help_lang4, help_lang5, title_lang3, title_lang4, title_lang5, available, locked) FROM stdin;
1	citec		{% load view_tags %}\n\n{% get_set 'project/partner' as partners %}\n{% get_set 'project/dataset' as datasets %}\n\n<h1>CITEC Data management plan</h1>\n\n<p>Name of the project:</p>\n\n<p>\n    <b>Project start:</b> {% render_value 'project/schedule/project_start' %}\n</p>\n<p>\n    <b>Project end:</b> {% render_value 'project/schedule/project_end' %}\n</p>\n<p>\n    <b>Project coordinator:</b> {% render_value_inline_list 'project/coordination/name' %}\n</p>\n<p>\n    <b>Project members:</b>\n</p>\n\n<p>\n    <b>Data manager:</b>\n</p>\n{% for dataset in datasets %}\n    <p>\n        <i>Dataset {% render_set_value dataset 'project/dataset/id' %}</i>\n    </p>\n    <p>\n    \tResponsible person for the backups:\n        {% render_set_value dataset 'project/dataset/storage/responsible_person/name' %}\n    </p>\n    <p>\n    \tResponsible person for documenting the metadata and context information:\n        {% render_set_value dataset 'project/dataset/metadata/responsible_person/name' %}\n    </p>\n    <p>\n    \tResponsible person for the maintenance of the PIDs and the object maintenance:\n    \t{% render_set_value dataset 'project/dataset/pids/responsible_person/name' %}\n    </p>\n{% endfor %}\n\n<p>\n    <i>All datasets</i>\n</p>\n<p>\n\tResponsible person for chosing which data to be archived:\n\t{% render_value_inline_list 'project/preservation/responsible_person/name' %}\n</p>\n\n<p>\n    <b>What are the goals / research questions of the project?</b>\n</p>\n<p>\n    {% render_value 'project/research_question/title' %}\n</p>\n\n<p>\n    <b>What data will be acquired?</b>\n</p>\n{% for dataset in datasets %}\n    <p>\n    \t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n        {% render_set_value dataset 'project/dataset/description' %}\n    </p>\n{% endfor %}\n\n<p>\n\t<b>How will the data be acquired??</b>\n</p>\n\n<p>\n\t<b>Which formats will be used for the data?</b>\n</p>\n\n{% for dataset in datasets %}\n    <p>\n        <i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n        {% render_set_value dataset 'project/dataset/format' %}\n    </p>\n{% endfor %}\n\n<p>\n\t<b>What amount of data is expected?</b>\n</p>\n\n{% for dataset in datasets %}\n    <p>\n        <i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n        {% render_set_value dataset 'project/dataset/size/volume' %}\n    </p>\n{% endfor %}\n\n<p>\n    <b>How will the data be stored during the project?</b>\n</p>\n\n{% for dataset in datasets %}\n    <p>\n    \t<i>Dataset Dataset {% render_set_value dataset 'project/dataset/id' %}</i>\n        {% render_set_value dataset 'project/dataset/storage/type' %}\n    </p>\n{% endfor %}\n\n<p>\n    <b>Does the project create non digital material that needs to be archived?</b>\n</p>\n\n<p>\n    <b>How will the data be archived after the end of the project?</b>\n</p>\n\n{% for dataset in datasets %}\n    <p>\n        <i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n        {% render_set_value dataset 'project/dataset/preservation/repository' %}\n        for the duration of {% render_set_value dataset 'project/dataset/preservation/duration' %}\n    </p>\n{% endfor %}\n\n<p>\n    <b>Does the project involve co-operations outside of Bielefeld University?</b>\n</p>\n<ul>\n{% for partner in partners %}\n<li>\n    {% render_set_value partner 'project/partner/name' %}\n</li>\n{% endfor %}\n</ul>\n\n<p>\n    <b>Are there requirements by others concerning data publication?</b>\n</p>\n<ul>\n{% for partner in partners %}\n<li>\n    {% render_set_value partner 'project/partner/name' %}:\n    {% render_set_value partner 'project/partner/rdm_policy' %}\n</li>\n{% endfor %}\n</ul>\n\n<p>\n    <b>Will the data be published?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% get_set_value dataset 'project/dataset/sharing/yesno' as val %}\n\t{% if val.is_true %}\n\t{% render_set_value dataset 'project/dataset/sharing/conditions' %}\n\tLicense: {% render_set_value dataset 'project/dataset/sharing/sharing_license' %}\n\t{% endif %}\n</p>\n{% endfor %}	http://example.com/terms/views/citec		DMP Vorlage der Universität Bielefeld für CITEC geförderte Projekte.	DMP template from the University of Bielefeld for CITEC funded research projects.	CITEC DMP	CITEC DMP							t	f
2	bielefeld		{% load view_tags %}\n\n{% get_set 'project/partner' as partners %}\n{% get_set 'project/dataset' as datasets %}\n\n<h1>DMP der Universität Bielefeld</h1>\n\n<h2>1. Allgemeine Angaben zum Forschungsvorhaben</h2>\n\n<p>\n    <b>1.1 Titel des Projektvorhabens</b>\n</p>\n<p>\n    {% render_value 'project/research_question/title' %}\n</p>\n\n<p>\n    <b>1.2 Ziele des Projekts</b>\n</p>\n\n<p>\n    <b>1.3 Externe Projektpartner</b>\n</p>\n<p>\n    {% render_value 'project/partner/name' %}\n</p>\n\n<p>\n    <b>1.4 Projektleiter / Verantwortliche</b>\n</p>\n<p>\n    {% render_value_inline_list 'project/coordination/name' %}\n</p>\n\n<p>\n    <b>1.5 Mitarbeiter und Funktionen</b>\n</p>\n\n<p>\n    <b>1.6 Genehmigte / angestrebte Laufzeit</b>\n</p>\n<p>\n    Projektbeginn: {% render_value 'project/schedule/project_start' %}\n    Projektende: {% render_value 'project/schedule/project_end' %}\n</p>\n\n<p>\n    <b>1.7 Welche Anforderungen gibt es seitens der Projektförderer bezüglich der Erstellung\n    eines DMPs und seiner Durchführung?</b>\n</p>\n<p>\n    {% render_value 'project/funder/requirements' %}\n</p>\n\n<p>\n    <b>1.8 Gibt es für Ihr Projektvorhaben institutionelle oder fakultätsinterne Policies,\n    die in dem DMP berücksicht werden müssen?</b>\n</p>\n<p>\n    {% render_value 'project/additional_requirements/yesno' %}\n    {% render_value 'project/additional_requirements/requirements' %}\n</p>\n\n<p>\n    <b>1.9 Gibt es Abhängigkeiten zu weiteren Policies?</b>\n</p>\n\n<h2>2/ Existierende Daten</h2>\n\n<p>\n    <b>2.1 Baut die Forschungsarbeit auf Daten Dritter oder auf generierte Daten aus anderen\n    abgeschlossenen Projekten (oder auch teilweise) auf?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    Datensatzherkunft: {% render_set_value dataset 'project/dataset/origin' %}/\n    Datensatzerzeuger: {% render_set_value dataset 'project/dataset/creator/name' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>2.1.1 Wenn ja, welche Bedeutung haben die vorhandenen Daten für das Vorhabensziel?\n    Warum sind die Daten wichtig?</b>\n</p>\n\n<p>\n    <b>2.2 Gibt es Möglichkeiten der Nachnutzung existierender Datensätze? Wurde nach diesen\n    innerhalb der eigenen Institution und von anderen diversen Datendrittanbietern recherchiert?</b>\n</p>\n\n<p>\n    <b>2.3 Wie wird die Integration zwischen den bereits existierenden Daten und den neu zu\n    generierenden Daten bewerkstelligt? Wie wird die Nutzung der existierenden\n    Daten dokumentiert?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/technical_integration' %}\n</p>\n{% endfor %}\n\n<h2>3. Im Projekt generierten Daten</h2>\n\n<p>\n    <b>3.1 Beschreiben Sie die Daten, die im Rahmen Ihres Forschungsvorhabens anfallen</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/description' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>3.2 Wie werden Daten erfasst oder erstellt?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/creation_methods' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>3.3 In welchen Dateiformaten werden die Daten vorliegen? Und benötigt man für die Nachnutzung\n    oder Nachvollziehbarkeit der Daten besondere Softwarelösungen\n    (sowohl frei als auch kommerziell)?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/format' %}\n</p>\n{% endfor %}\n\n<h2>4. Datenorganisation</h2>\n\n<p>\n    <b>4.1 Gibt es projektinterne Richtlinie zur Benennung der entstehenden Daten?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/storage/naming' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>4.2 Gibt es auch Richtlinien zur einheitlichen Organisation der Daten?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/storage/organisation' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>4.3 Wie werden Daten von einem Ort zum anderen transferiert (z.B. von lokaler Festplatte\n    auf ein Netzlaufwerk oder Server). Werden Synchronisationsmethoden angewandt?</b>\n</p>\n\n<p>\n    <b>4.4 Wie ist das kollaborative Arbeiten an den selben Dateien geregelt?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/collaboration_organisation' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>4.5 Wie sieht die Versionierungsstrategie für die entstehenden Daten oder Dokumente aus?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/versioning_strategy' %}\n</p>\n{% endfor %}\n\n<h2>5. Administrative und rechtliche Aspekte</h2>\n\n<p>\n    <b>5.1 Existieren für Ihr Projekt Vorgaben seitens der Forschungsförderer bezüglich bestimmter\n    Aspekte des Forschungsdatenmanagements?</b>\n</p>\n<p>\n    {% render_value 'project/funder/requirements' %}\n</p>\n\n<p>\n    <b>5.2 Gibt es bereits Überlegungen, was mit den Daten geschieht, wenn die Vorgaben oder andere\n    Erhaltungsmaßnahmen nicht mehr greifen?</b>\n</p>\n\n<p>\n    <b>5.3 Werden fremde Forschungsdaten oder Software verwendet, welche dem Urheberrecht, dem\n    Patenrecht oder anderen geistigen Eigentumsrechten unterliegen?\n    Wenn ja, wer besitzt die Rechte?</b>\n</p>\n<p>\n    {% render_value 'project/legal_aspects/ipr/yesno' %}\n</p>\n\n<p>\n    <b>5.4 Unterliegen die eigenen Forschungsdaten oder andere Forschungsartefakte (z.B. Software,\n    Hardware) dem Urheberrecht, dem Patentrecht oder anderen geistigen Eigentumsrechten? Wenn ja,\n    gibt es bereits Überlegungen zur Lizenzierung oder Vergabe von Nutzungsrrechten?</b>\n</p>\n\n<p>\n    <b>5.5 Existieren Schutzfristen für die eigenen Forschungsdaten, welche während des\n    Aufbewahrungszeitraumes enden?</b>\n</p>\n\n<p>\n    <b>5.6 Sind die im Projekt erzeugten Daten von einem öffentlichen Interesse?</b>\n</p>\n\n<p>\n    <b>5.7 Sind die Nutzungsziele (und die Nutzerzielgruppe) und die Anforderungen an die\n    Nutzung der Daten dokumentiert?</b>\n</p>\n\n<p>\n    <b>5.8 Wie werden die Nutzungsbeschränkungen organisatorisch gehandhabt? Sind hierfür die\n    Verantwortlichen klar definiert?</b>\n</p>\n\n<p>\n    <b>5.9 Unterliegen die erzeugten Daten dem Datenschutz?</b>\n</p>\n<p>\n    {% render_value_inline_list 'project/legal_aspects/sensitive_data/personal_data/privacy_laws' %}\n</p>\n\n<p>\n    <b>5.10 Welche Anstrengungen werden unternommen, um den Anforderungen des Datenschutzes\n    zu genügen?</b>\n</p>\n<p>\n    {% render_value 'project/legal_aspects/sensitive_data/personal_data/anonymization' %}\n</p>\n<p>\n    <b>5.11 Gibt es ethisch, kommerziell oder in anderer Hinsicht sensible Daten? Wenn ja, welche\n    Maßnahmen werden zum Schutz dieser Daten getroffen?</b>\n</p>\n<p>\n    {% render_value 'project/legal_aspects/sensitive_data/other_sensitive_data/yesno' %}\n</p>\n\n<p>\n    <b>5.12 Wer ist während des Projekts und nach dem Projekt verantwortlich für die Speicherung der\n    Daten?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/storage/responsible_person/name' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>5.13 Werden regelmäßig Sicherheitskopien der aktuellen Arbeitsdateien erzeugt? Mit\n    welchenTechnologien erfolgt dies und an welchem Ort?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/storage/backup_frequency' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>5.14 Wie sehen die technischen Lösungen für die Backupstrategie aus? (auch für\n    mobile Geräte, wie Laptops?)</b>\n</p>\n\n<h2>6. Archivierung, Datenaustausch und Datenpublikation</h2>\n\n<p>\n    <b>6.1 Wieso und für wie lange müssen Daten archiviert werden? Welche Daten sind\n    das genau, und durch wen und womit erfolgt die Auswahl der zu archivierenden Daten?</b>\n</p>\n<p>\n    {% render_value 'project/dataset/preservation/yesno' %}\n    {% render_value 'project/dataset/preservation/motivation' %}\n    {% render_value 'project/dataset/preservation/duration' %}\n    {% render_value 'project/preservation/criteria' %}\n    {% render_value_inline_list 'project/preservation/responsible_person/name' %}\n</p>\n\n<p>\n    <b>6.2 Was geschieht mit den Daten nach Ablauf der Aufbewahrungsdauer?</b>\n</p>\n\n<p>\n    <b>6.3 Ist es geplant, dass die Daten innerhalb oder außerhalb des Projekts von Anderen\n    genutzt werden? Wenn nein, bitte Gründe nennen.</b>\n</p>\n\n<p>\n    <b>6.4 Gibt es eine Verpflichtung, die Daten freizugeben?</b>\n</p>\n\n<p>\n    <b>6.5 Wie werden Veröffentlichung (Datenpublikation), Suchbarkeit und der Zugriff auf die Daten\n    realisiert? Werden hierfür institutionelle Dienste der Universität Bielefeld in Anspruch\n    genommen (z.B. DOI Registrierung)? Oder externe fachspezifische Datenservices?</b>\n</p>\n\n<p>\n    <b>6.6 Gibt es definierte Workflows für die Identifikation von Datenobjekten?</b>\n</p>\n\n<p>\n    <b>6.7 Werden Metadaten für die (maschinen-lesbare) Beschreibung von Objekten oder im Rahmen\n    der Dokumentation des Forschungsprozesses verwendet? Welchem Zweck dient das Metadatensystem?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/metadata/description' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>6.8 Welche Informationen (des Forschungsprozesses) sollen durch Metadaten\n    beschriebenwerden?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/metadata/information' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>6.9 Gibt es Metadaten, die automatisch erhoben werden können?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/creation_automatic' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>6.10 Welche Voraussetzungen muss Hardware und Software erfüllen, um die Metadatenverarbeiten\n    zu können? Und welche Vorkenntnisse/Fachkenntnisse sind zum Verständnis bzw/Verarbeitung dieser\n    Metadaten notwendig?</b>\n</p>\n\n<p>\n    <b>6.11 Werden bestimmte Restriktionen für die Nutzung von den publizierten Daten erhoben?</b>\n</p>\n\n<p>\n    <b>6.12 Spielt bei dem Datentausch die Interoperabilität zwischen der eigenenen Infrastruktur\n    und den anderen beteiligten Infrastrukturen eine Rolle?</b>\n</p>\n\n<h2>7. Verantwortlichkeiten und Pflichten</h2>\n\n<p>\n    <b>7.1 Wer ist innerhalb des Projekts verantwortlich für das Datenmanagement?</b>\n</p>\n\n<p>\n    <b>7.2 Gibt es eine Regelung zur Überprüfung der Einhaltung des Datenmanagement Plans?</b>\n</p>\n\n<p>\n    <b>7.3 Wie, wann und von wem wird der DMP bei Bedarf aktualisiert?</b>\n</p>\n\n<p>\n    <b>7.4 Sind andere Institutionen oder universitäre Dienste am Datenmanagement für das\n    Projektbeteiligt?</b>\n</p>\n\n<p><b>Begründung:</b></p>\n\n<h2>8. Kosten und Ressourcen</h2>\n\n<p>\n    <b>8.1 Sind die Kosten und der Personalaufwand für das Datenmanagement von Forschungsdaten\n    abgeschätzt worden?</b>\n</p>\n\n<p>\n    <b>8.2 Welche Kosten entstehen während und nach der Projektlaufzeit? Und wie hoch ist das im\n    Projekt veranschlagte Budget für Datenmanagement?</b>\n</p>\n<p>\n    Personalaufwand für das Datenmanagement im Rahmen der Erhebung, Erstellung oder Akquise der\n    Daten: {% render_value 'project/costs/creation/personnel' %}\n</p>\n<p>\n    Sachkosten für das Datenmanagement im Rahmen der Erhebung, Erstellung oder Akquise der Daten:\n    {% render_value 'project/costs/creation/expenses' %}\n</p>\n<p>\n    Personalaufwand für das Datenmanagement im Zusammenhang mit der Nutzung der Daten:\n    {% render_value 'project/costs/usage/personnel' %}\n</p>\n<p>\n    Sachkosten für das Datenmanagement im Zusammenhang mit der Nutzung der Daten:\n    {% render_value 'project/costs/usage/expenses' %}\n</p>\n<p>\n    Personalaufwand im Zusammenhang mit der Speicherung der Daten:\n    {% render_value 'project/costs/storage/personnel' %}\n</p>\n<p>\n    Sachkosten im Zusammenhang mit der Speicherung der Datensätze:\n    {% render_value 'project/costs/storage/expenses' %}\n</p>\n\n<p>\n    <b>8.3 Wurden innerhalb des Projektes die Gründe für das Management von Forschungsdaten\n    kommuniziert und sind diese allen beteiligten Mitarbeitern klar?</b>\n</p>\n\n<p>\n    <b>8.4 Stehen alle Verantwortlichen und Beteiligten hinter den Plänen zum Datenmanagement? Wenn\n    nein, ist es notwendig, den individuellen und allgemeinen Nutzen herauszuarbeiten oder\n    Anreizsysteme einzuführen?</b>\n</p>	https://rdmorganiser.github.io/terms/views/bielefeld	https://rdmorganiser.github.io/terms	DMP Vorlage der Universität Bielefeld.	DMP template from the University of Bielefeld.	Bielefeld	Bielefeld							t	f
3	dmponline	Source: https://dmponline.dcc.ac.uk/	{% load view_tags %}\n\n{% get_set 'project/partner' as partners %}\n{% get_set 'project/dataset' as datasets %}\n\n<h1>DMPonline Template</h1>\n\n<h2>Data Collection</h2>\n<p>\n  <b>What data will you collect or create?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/description' %},\n\tdata format: {% render_set_value dataset 'project/dataset/format' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>How will the data be collected or created?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/creation_methods' %}\n</p>\n{% endfor %}\n\n<h2>Documentation and Metadata</h2>\n<p>\n    <b>What documentation and metadata will accompany the data?</b>\n</p>\n\n<p>\n    <i>Metadata</i>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/interoperability' %}\n</p>\n{% endfor %}\n\n<p>\n    <i>Documentation</i>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/id/standards' %}\n</p>\n{% endfor %}\n\n<h2>Ethics and Legal Compliance</h2>\n\n<p>\n    <b>How will you manage any ethical issues?</b>\n</p>\n<p>\n    {% render_value 'project/legal_aspects/sensitive_data/other_sensitive_data/yesno' %}\n    {% render_value 'project/legal_aspects/sensitive_data/other_sensitive_data/description' %}\n</p>\n\n<p>\n    <b>How will you manage copyright and Intellectual Property Rights (IPR) issues?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n</p>\n<p>\n\tApplicable copyrights:\n    {% render_set_value dataset 'project/dataset/ipr/copyrights' %}\n</p>\n<p>\n\tOther applicable intellectual property rights:\n    {% render_set_value dataset 'project/dataset/ipr/other_rights' %}\n</p>\n<p>\n\tRightsholder: {% render_set_value dataset 'project/dataset/ipr/owner/name' %}\n</p>\n{% endfor %}\n\n<h2>Storage and Backup</h2>\n<p>\n    <b>How will the data be stored and backed up during the research?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/storage/type' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>How will you manage access and security?</b>\n</p>\n<p>{% render_value 'project/data_security' %}\n\n<h2>Selection and Preservation</h2>\n\n<p>\n    <b>Which data are of long-term value and should be retained, shared, and/or preserved?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/preservation/yesno' %}.\n\t{% render_set_value_inline_list dataset 'project/dataset/preservation/purpose' %}.\n</p>\n{% endfor %}\n\n<p>\n    <b>What is the long-term preservation plan for the dataset?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/preservation/duration' %}.\n\tIn: {% render_set_value dataset 'project/dataset/preservation/repository' %}\n</p>\n{% endfor %}\n\n<h2>Data Sharing</h2>\n\n<p>\n    <b>How will you share the data?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/metadata/standards' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>Are any restrictions on data sharing required?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/sharing/conditions' %}\n</p>\n{% endfor %}\n\n<h2>Responsibilities and Resources</h2>\n\n<p>\n    <b>Who will be responsible for data management?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n</p>\n<p>\n\tResponsible person for the backups:\n\t{% render_set_value dataset 'project/dataset/backup_responsible/name' %}\n</p>\n<p>\n\tResponsible person for documenting the metadata and context information:\n\t{% render_set_value dataset 'project/dataset/metadata/responsible_person/name' %}\n</p>\n\tResponsible person for the maintenance of the PIDs and the object maintenance:\n\t{% render_set_value dataset 'project/dataset/pids/responsible_person/name' %}\n</p>\n{% endfor %}\n\n<p>\n\tPerson(s) who choose(s) the data to be archived:\n    {% render_value_inline_list 'project/preservation/responsible_person/name' %}\n</p>\n\n<p>\n    <b>What resources will you require to deliver your plan?</b>\n</p>\n\n<p>\n    <i>Metadata costs</i>\n</p>\n\n<p>\n    Personnel: {% render_value 'project/costs/metadata/personnel' %}\n</p>\n\n<p>\n    Other: {% render_value 'project/costs/metadata/non_personnel' %}\n</p>\n\n<p>\n    <i>Preservation costs</i>\n</p>\n\n<p>\n    Personnel: {% render_value 'project/costs/preservation/personnel' %}\n</p>\n\n<p>\n    Other: {% render_value 'project/costs/preservation/non_personnel' %}\n</p>\n\n<p>\n    <i>Data sizes</i>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/id/volume' %}\n</p>\n{% endfor %}	https://rdmorganiser.github.io/terms/views/dmponline	https://rdmorganiser.github.io/terms	Vorlage von DMPonline, Online: https://dmponline.dcc.ac.uk	Template from DMPonline, online https://dmponline.dcc.ac.uk	DMPonline template	DMPonline template							t	f
4	dmptool	Source: https://dmptool.org/ and based on the template "NSF-GEN: Generic"	{% load view_tags %}\n\n{% get_set 'project/partner' as partners %}{% get_set 'project/dataset' as datasets %}\n\n<h1>DMPTool</h1>\n\n<h2>Types of data produced</h2>\n\n<p>\n\t<b>What data will be generated in the research?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/description' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>What data types will you be creating or capturing?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/format' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>How will you capture or create the data?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/creation_methods' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>If you will be using existing data, state this and include how you will obtain it.</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/origin' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>What is the relationship between the data you are collecting and any existing data?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/structure' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>How will the data be processed?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/usage_description' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>What quality assurance &amp; quality control measures will you employ?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/quality_assurance' %}\n</p>\n{% endfor %}\n\n<h2>Data and metadata standards</h2>\n\n<p>\n\t<b>Which file formats will you use for your data, and why?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/format' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>What form will the metadata describing/documenting your data take?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/metadata/mappings/yesno' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>How will you create or capture these details?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n</p>\n<p>\n\tautomatic: {% render_set_value dataset 'project/dataset/metadata/creation_automatic' %}\n</p>\n<p>\n\tsemi-automatic: {% render_set_value dataset 'project/dataset/metadata/creation_semi_automatic' %}\n</p>\n<p>\n\tmanual: {% render_set_value dataset 'project/dataset/metadata/creation_manual' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>Which metadata standards will you use and why have you chosen them? (e.g. accepted domain-local standards, widespread usage)</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/metadata/standards' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>What contextual details (metadata) are needed to make the data you capture or collect\n    meaningful?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/metadata/scope' %}\n</p>\n{% endfor %}\n\n<h2>Policies for access and sharing</h2>\n\n<p>\n\t<b>How will you make the data available? (Include resources needed to make the data available: equipment, systems, expertise, etc.)</b>\n</p>\n\n<p>\n\t<i>Sharing</i>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/sharing/yesno' %}\n</p>\n{% endfor %}\n\n<p>\n\t<i>Data sizes</i>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/size/volume' %}\n</p>\n{% endfor %}\n<p>\n\t<i>Metadata costs</i>\n</p>\n<p>\n\tPersonnel: {% render_value 'project/costs/metadata/personnel' %} PM\n</p>\n<p>\n\tOther: {% render_value 'project/costs/metadata/non_personnel' %} Euro\n</p>\n\n<p>\n\t<b>When will you make the data available?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/data_publication_date' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>What is the process for gaining access to the data?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t{% render_value 'project/preservation/access_authentication' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>Will access be chargeable?</b>\n</p>\n\n<p>\n\t<b>How long will the original data collector/creator/principal investigator retain the right to use the data before making them available for wider distribution?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/datasetpreservation/embargo_period' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>Are there any embargo periods for political/commercial/patent reasons? If so, give details.</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:\n\t</i> {% render_set_value dataset 'project/dataset/preservation/accessibility' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>Are there ethical and privacy issues? If so, how will these be resolved?</b>\n</p>\n<p>\n\tPersonal data is being used:\n\t{% render_value 'project/legal_aspects' %}\n\t{% get_value 'values/project/legal_aspects/sensitive_data/personal_data' as val %}\n</p>\n{% if val.is_true %}\n<p>\n\tApplicable law(s):\n\t{% render_value_inline_list 'project/legal_aspects/sensitive_data/personal_data/privacy_law' %}\n</p>\n<p>\n\tData will be anonymised or pseudonymised:\n\t{% render_value 'project/legal_aspects/sensitive_data/personal_data/anonymization' %}\n</p>\n<p>\n\t"Informed consent" will be obtained from the person(s) concerned:\n\t{% render_value 'project/legal_aspects/sensitive_data/personal_data/consent/extent' %}\n</p>\n{% endif %}\n\n<p>\n\t<b>What have you done to comply with your obligations in your IRB Protocol?</b>\n</p>\n\n<p>\n\t{% render_value 'project/legal_aspects/official_approval/data_access_committee/yesno' %}\n</p>\n\n<p>\n\t<b>Who will hold the intellectual property rights to the data and how might this affect data access?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/ipr/owner/name' %}\n</p>\n{% get_set_value dataset 'project/dataset/ipr/copyrights' %}\n{% if val.is_true %}\n<p>\n\t{% render_set_value_inline_list dataset 'project/dataset/ipr/copyrights' %}\n</p>\n{% endif %}\n{% get_set_value dataset 'project/dataset/ipr/other_rights' %}\n{% if val.is_true %}\n<p>\n\t{% render_set_value_inline_list dataset 'project/dataset/ipr/other_rights' %}\n</p>\n{% endif %}\n{% endfor %}\n\n<h2>Policies for re-use, redistribution</h2>\n\n<p>\n\t<b>Will any permission restrictions need to be placed on the data?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/sharing/conditions' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>Who is likely to be interested in the data?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/reuse_scenario' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>What and who are the intended or foreseeable uses of the data?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/reuse_scenario' %}\n</p>\n{% endfor %}\n\n<h2>Plans for archiving and preservation</h2>\n\n<p>\n\t<b>What is the long-term strategy for maintaining, curating and archiving the data?</b>\n</p>\n\n{% get_value 'values/project/values/project/preservation'}\n{% if val.is_true %}\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/preservation/purpose' %}\n</p>\n<p>\n\t{% render_set_value dataset 'project/dataset/preservation/duration' %}\n</p>\n<p>\n\t{% render_set_value dataset 'project/dataset/costs/preserved/cover_how' %}\n</p>\n{% endfor %}\n{% endif %}\n\n<p>\n\t<b>Which archive/repository/database have you identified as a place to deposit data?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/preservation/repository' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>What procedures does your intended long-term data storage facility have in place for preservation and backup?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n</p>\n<p>\n\tResponsible person for the backups:\n    {% render_set_value dataset 'project/dataset/backup_responsible/name' %}</p>\n<p>\n\tResponsible person for documenting the metadata and context information:\n    {% render_set_value dataset 'project/dataset/metadata/responsible_person/name' %}</p>\n<p>\n\tResponsible person for the maintenance of the PIDs and the object maintenance:\n    {% render_set_value dataset 'project/dataset/pids/responsible_person/name' %}</p>\n{% endfor %}\n\n<p>\n\t<b>How long will/should data be kept beyond the life of the project?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/preservation/duration' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>What data will be preserved for the long-term?</b>\n</p>\n\n<p>\n\t{% render_value 'project/preservation/selection_criteria' %}\n</b>\n\n<p>\n\t<b>What transformations will be necessary to prepare data for preservation / data sharing?</b>\n</p>\n\n<p>\n\t<b>What metadata / documentation will be submitted alongside the data\n    or created on deposit / transformation in order to make the data reusable?</b>\n</p>\n\n<p>\n\t<b>What related information will be deposited?</b>\n</p>	https://rdmorganiser.github.io/terms/views/dmptool	https://rdmorganiser.github.io/terms	Vorlage von DMPtool, basiert auf on "NSF-GEN: Generic", Online: https://dmptool.org	Template from DMPtool, based on "NSF-GEN: Generic", online: https://dmptool.org	DMPTool template	DMPTool template							t	f
5	horizon2020	Source: http://ec.europa.eu/research/participants/data/ref/h2020/grants_manual/hi/oa_pilot/h2020-hi-oa-data-mgt_en.pdf	{% load view_tags %}\n\n<h1>Horizon 2020</h1>\n\n<h2>1. Data Summary</h2>\n\n{% get_set 'project/dataset' as datasets %}\n{% get_set 'project/partner' as partners %}\n\n<p>\n\t\t<b>What is the purpose of the data collection/generation and its relation to the objectives\n\t\tof the project?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/usage_description' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>What types and formats of data will the project generate/collect?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/format' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>Will you re-use any existing data and how?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/origin' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>What is the origin of the data?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/creator/name' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>What is the expected size of the data?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/size/volume' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>To whom might it be useful ('data utility')?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/reuse_scenario' %}\n</p>\n{% endfor %}\n\n<h2>2. FAIR data</h2>\n\n<h3>2.1 Making data findable, including provisions for metadata</h3>\n\n<p>\n\t\t<b>Are the data produced and/or used in the project discoverable with metadata, identifiable\n\t\tand locatable by means of a standard identification mechanism (e.g. persistent and unique\n\t\tidentifiers such as Digital Object Identifiers)?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% get_set_value dataset 'project/dataset/pids/yesno' as pids %}\n\t\t{{ pids.value }}\n\t\t{% if pids.is_true %}\n\t\t{% render_set_value dataset 'project/dataset/pids/system' %}\n\t\t{% endif %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>What naming conventions do you follow?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/storage/naming_policy' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>Will search keywords be provided that optimize possibilities for re-use?</b>\n</p>\n<ul>\n\t\t{% render_value_list 'project/research_question/keywords' %}\n</ul>\n\n<p>\n\t\t<b>Do you provide clear version numbers?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/versioning_strategy' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>What metadata will be created? In case metadata standards do not exist in your discipline,\n\t\tplease outline what type of metadata will be created and how.</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n</p>\n<ul>\n\t\t<li>\n\t\t\t\tautomatic:\n\t\t\t\t{% render_set_value dataset 'project/dataset/metadata/creation_automatic' %}\n\t\t</li>\n\t\t\t <li>\n\t\t\t\tsemi-automatic:\n\t\t\t\t{% render_set_value dataset 'project/dataset/metadata/creation_automatic' %}\n\t\t</li>\n\t\t<li>\n\t\t\t\tmanual:\n\t\t\t\t{% render_set_value dataset 'project/dataset/metadata/creation_automatic' %}\n\t\t</li>\n</ul>\n{% endfor %}\n\n<h3>2.2. Making data openly accessible</h3>\n\n<p>\n\t\t<b>Which data produced and/or used in the project will be made openly available as the default?\n\t\tIf certain data sets cannot be shared (or need to be shared under restrictions), explain why,\n\t\tclearly separating legal and contractual reasons from voluntary restrictions.</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/sharing/yesno' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>How will the data be made accessible (e.g. by deposition in a repository)?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/preservation/repository' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>What methods or software tools are needed to access the data?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/usage_technology' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>Is documentation about the software needed to access the data included?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/software_documentation/yesno' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>Is it possible to include the relevant software (e.g. in open source code)?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/sharing/yesno' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>Where will the data and associated metadata, documentation and code be deposited?\n\t\tPreference should be given to certified repositories which support open access\n\t\twhere possible.</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/preservation/repository' %}\n\n\t\t{% get_set_values dataset 'project/dataset/preservation/certification' as certification %}\n\t\t{% if certification.is_true %}\n\t\t(certified)\n\t\t{% else %}\n\t\t(not certified)\n\t\t{% endif %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>Have you explored appropriate arrangements with the identified repository?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/preservation/repository_arrangements' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>Is there a need for a data access committee?</b>\n</p>\n<p>\n\t\t{% render_value 'project/legal_aspects/official_approval/data_access_committee' %}\n</p>\n\n<p>\n\t\t<b>Are there well described conditions for access (i.e. a machine-readable license)?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/data_security/access_permissions' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>How will the identity of the person accessing the data be ascertained?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/data_security/security_measures' %}\n</p>\n{% endfor %}\n\n<h3>2.3. Making data interoperable</h3>\n\n<p>\n\t\t<b>Are the data produced in the project interoperable, that is allowing data exchange and\n\t\tre-use between researchers, institutions, organisations, countries, etc. (i.e. adhering to\n\t\tstandards for formats, as much as possible compliant with available (open) software\n\t\tapplications, and in particular facilitating re-combinations with different datasets\n\t\tfrom different origins)?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n</p>\n<ul>\n\t\t{% render_set_value_list dataset 'project/dataset/interoperability' %}\n</ul>\n{% endfor %}\n\n<p>\n\t\t<b>What data and metadata vocabularies, standards or methodologies will you follow to make\n\t\tyour data interoperable?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n</p>\n<ul>\n\t\t{% render_set_value_list dataset 'project/dataset/metadata/standards' %}\n</ul>\n{% endfor %}\n\n<p>\n\t\t<b>Will you be using standard vocabularies for all data types present in your data set,\n\t\tto allow inter-disciplinary interoperability?</b>\n</p>\n\n<p>\n\t\t<b>In case it is unavoidable that you use uncommon or generate project specific\n\t\tontologies or vocabularies, will you provide mappings to more commonly used ontologies?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/metadata/mappings' %}\n</p>\n{% endfor %}\n\n<h3>2.4. Increase data re-use (through clarifying licences)</h3>\n\n<p>\n\t\t<b>How will the data be licensed to permit the widest re-use possible?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value_inline_list dataset 'project/dataset/sharing/conditions' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>When will the data be made available for re-use? If an embargo is sought to give time\n\t\tto publish or seek patents, specify why and how long this will apply, bearing in mind\n\t\tthat research data should be made available as soon as possible.</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/data_publication_date' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>Are the data produced and/or used in the project useable by third parties, in particular\n\t\tafter the end of the project? If the re-use of some data is restricted, explain why.</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/reuse_scenario' %}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>How long is it intended that the data remains re-usable?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/preservation/duration' %}\n</p>\n{% endfor %}\n\n<h2>3. Allocation of resources</h2>\n\n<p>\n\t\t<b>What are the costs for making data FAIR in your project?</b>\n</p>\n<p>\n\t\tPersonnel:\n\t\t{% render_value 'project/costs/metadata/personnel' %}\n</p>\n<p>\n\t\tOther:\n\t\t{% render_value 'project/costs/metadata/non_personnel' %}\n</p>\n\n<p>\n\t\t<b>How will these be covered? Note that costs related to open access to research data are\n\t\teligible as part of the Horizon 2020 grant (if compliant with the Grant Agreement\n\t\tconditions).</b>\n</p>\n<p>\n\t\t{% render_value 'project/costs/preservation/cover_how' %}\n</p>\n\n<p\n\t\t<b>Who will be responsible for data management in your project?</b>\n</p>\n{% for partner in partners %}\n<p>\n\t\t<i>Partner {{ partner.value }}:</i>\n</p>\n<ul>\n\t\t{% render_set_value_list partner 'project/partner/contact_person/name' %}\n</ul>\n{% endfor %}\n\n<p>\n\t\t<b>Are the resources for long term preservation discussed (costs and potential value,\n\t\twho decides and how what data will be kept and for how long)?</b>\n</p>\n<p>\n\t\t<i>Preservation decisions</i>\n</p>\n<ul>\n\t\t{% render_value_list 'project/preservation/responsible_person/name' %}\n</ul>\n<p>\n\t\t<i>Costs</i>\n</p>\n<p>\n\t\tPersonnel:\n\t\t{% render_value 'project/costs/preservation/personnel' %}\n</p>\n<p>\n\t\tOther:\n\t\t{% render_value 'project/costs/preservation/non_personnel' %}\n</p>\n\n<h2>4. Data security</h2>\n\n<p>\n\t\t<b>What provisions are in place for data security (including data recovery as well\n\t\tas secure storage and transfer of sensitive data)?</b>\n</p>\n<p>\n\t\t{% render_value 'project/legal_aspects/security_measures' %}\n</p>\n\n<p>\n\t\t<b>Is the data safely stored in certified repositories for long term preservation\n\t\tand curation?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value_inline_list dataset 'project/dataset/preservation/repository' %}\n\t\t{% get_set_value dataset  'project/dataset/preservation/certification' as certification %}\n\t\t{% if certification.is_true %}\n\t\t(certified)\n\t\t{% else %}\n\t\t(not certified)\n\t\t{% endif %}\n</p>\n{% endfor %}\n\n<h2>5. Ethical aspects</h2>\n\n<p>\n\t\t<b>Are there any ethical or legal issues that can have an impact on data sharing? These can\n\t\talso be discussed in the context of the ethics review. If relevant, include references to\n\t\tethics deliverables and ethics chapter in the Description of the Action (DoA).</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n\t\t{% render_set_value dataset 'project/dataset/sensitive_data/other/yesno' %}\n\t\t{% render_set_value dataset 'project/dataset/sensitive_data/other/description'%}\n</p>\n{% endfor %}\n\n<p>\n\t\t<b>Is informed consent for data sharing and long term preservation included in questionnaires\n\t\tdealing with personal data?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t\t<i>Dataset {{ dataset.value }}:</i>\n</p>\n<ul>\n\t\t<li>\n\t\tPersonal data:\n\t\t{% render_set_value dataset 'project/dataset/sensitive_data/personal_data_yesno/yesno' %}\n\t\t</li>\n\t\t<li>\n\t\tInformed consent:\n\t\t{% render_set_value dataset 'project/dataset/sensitive_data/personal_data/consent/extent' %}\n\t\t</li>\n</ul>\n{% endfor %}\n\n<h2>6. Other issues</h2>\n\n<p>\n\t\t<b>Do you make use of other national/funder/sectorial/departmental procedures for data\n\t\tmanagement? If yes, which ones?</b>\n</p>\n<p>\n\t\t{% get_value 'project/additional_rdm_policy/yesno' as additional_rdm_policy %}\n\t\t{{ additional_rdm_policy.value }}\n</p>\n<p>\n\t\t{% render_value 'project/additional_rdm_policy/requirements' %}\n</p>	https://rdmorganiser.github.io/terms/views/horizon2020	https://rdmorganiser.github.io/terms	Vorlage für Horizon 2020, aus "Guidelines on\nFAIR Data Management in Horizon 2020", Online: http://ec.europa.eu/research/participants/data/ref/h2020/grants_manual/hi/oa_pilot/h2020-hi-oa-data-mgt_en.pdf	Template for Horizon 2020, from "Guidelines on\nFAIR Data Management in Horizon 2020", online: http://ec.europa.eu/research/participants/data/ref/h2020/grants_manual/hi/oa_pilot/h2020-hi-oa-data-mgt_en.pdf	Horizon 2020 FAIR Data Management Plan template	Horizon 2020 FAIR Data Management Plan template							t	f
6	snf	Source: http://www.snf.ch/SiteCollectionDocuments/DMP_content_mySNF-form_de.pdf	{% load view_tags %}\n\n{% get_set 'project/partner' as partners %}\n{% get_set 'project/dataset' as datasets %}\n\n<h1>Data Management Plan - SNF Formular</h1>\n\n<h2>Allgemein</h2>\n\n<p>\n    <b>Welche Personen oder Institutionen sind verantwortlich für die Projektkoordination?</b>\n</p>\n<p>{% render_value_inline_list 'project/coordination' %}</p>\n\n<p>\n    <b>Gibt es an Ihrer Einrichtung Regeln oder Richtlinien zum Umgang mit den im\n    Projekt erhobenen Forschungsdaten? Wenn ja, skizzieren Sie diese kurz und verweisen\n    Sie ggf. auf weiterführende Informationen. Geben Sie bitte auch an, welchen Grad an\n    Verbindlichkeit sie haben.</b>\n</p>\n<p>\n\t{% render_value 'project/additional_requirements/yesno' %}\n\t{% render_value 'project/additional_requirements/requirements' %}\n</p>\n\n<p>\n\t<b>Wer ist bei diesem Partner der/die Ansprechpartner/in für das Datenmanagement?</b>\n</p>\n{% for partner in partners %}\n<p>\n    <i>{% render_set_value partner 'project/partner/name' %}:</i>\n    Richtlinien: {% render_set_value partner 'project/partner/rdm_policy' %},\n    Ansprechpartner: {% render_set_value_inline_list partner 'project/partner/contact_person/name' %}\n</p>\n{% endfor %}\n\n<h2>1. Datenerhebung und -dokumentation</h2>\n<h3>1.1. Welche Daten werden Sie erheben, beobachten, generieren oder wiederverwerten?</h3>\n\n<p>\n    <b>1.1.1. Welche Art, welches Format und welches Volumen von Daten werden Sie\n    erheben, beobachten, generieren oder weiterverwenden?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        {% render_set_value dataset 'project/dataset/description' %};\n        Format: {% render_set_value dataset 'project/dataset/format' %},\n        Volumen: {% render_set_value dataset 'project/dataset/size/volume' %},\n        Rate: {% render_set_value dataset 'project/dataset/rate' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>1.1.2. Welche bestehenden (eigene oder externe) Daten werden Sie weiterverarbeiten?</p>\n</b>\n{% for dataset in datasets %}\n<p>\n\t<em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    Datensatzerzeuger: {% render_set_value dataset 'project/dataset/creator/name' %},\n    Verfügbar unter: {% render_set_value dataset 'project/dataset/uri' %}\n</p>\n{% endfor %}\n\n<h3>1.2 Wie werden die Daten erhoben, beobachtet oder generiert?</h3>\n<p>\n    <b>1.2.1. Welche Standards, Methoden oder Qualitätssicherungsverfahren werden Sie verwenden?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        Methoden:\n        {% render_set_value dataset 'project/dataset/creation_methods' %}\n        Technologien:\n        {% render_set_value dataset 'project/dataset/usage_technology' %}\n        Qualitätssicherungsverfahren:\n        {% render_set_value dataset 'project/dataset/control_tools' %}\n        Korrektheit &amp; Vollständigkeit:\n        {% render_set_value dataset 'project/dataset/quality_assurance' %}\n        Datenintegration: {% render_set_value dataset 'project/dataset/integration' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>1.2.2. Wie werden Sie ihre Daten verwalten, wie gestalten Sie Versionierungen?</p>\n</b>\n{% for dataset in datasets %}\n<p>\n\t<em> Datensatz {% render_set_value dataset 'project/dataset/id' %}: </em>\n    Datenstruktur: {% render_set_value dataset 'project/dataset/structure' %}, {% render_set_value dataset 'project/storage/organisation_policy' %}\n    Dateibenennung: {% render_set_value dataset 'project/dataset/storage/naming_policy' %}\n    Versionierung: {% render_set_value dataset 'project/dataset/versioning_yesno' %}, {% render_set_value dataset 'project/dataset/versioning_strategy' %},\n    Tool: {% render_set_value dataset 'project/dataset/versioning_tool' %}\n</p>\n{% endfor %}\n\n<h3>1.3. Welche Dokumentationen, Metadaten  und Standards für Metadaten sehen Sie im Zusammenhang mit den Daten vor?</h3>\n<p>\n    <b>1.3.1. Welche Informationen benötigen Benutzer (Computer oder Menschen), um die Daten in Zukunft zu lesen und zu interpretieren?</p>\n</b>\n\n{% for dataset in datasets %}\n<p>\n    <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n    {% render_set_value dataset 'project/dataset/metadata/scope' %}\n    Software-Dokumentation: {% render_set_value dataset 'project/dataset/software_documentation' %}\n    Veröffentlichung: {% render_set_value dataset 'project/dataset/metadata/public' %}\n</p>\n {% endfor %}\n\n<p>\n    <b>1.3.2. Wie werden diese Informationen erstellt?</p>\n</b>\n\n{% for dataset in datasets %}\n    <p>\n        <em> Datensatz {% render_set_value dataset 'project/dataset/id' %}: </em>\n        Standards:\n        {% render_set_value dataset 'project/dataset/metadata/standards' %}\n        Automatisch:\n        {% render_set_value dataset 'project/dataset/metadata/creation_automatic' %}\n        Semi-automatisch:\n        {% render_set_value dataset 'project/dataset/metadata/creation_semi_automatic' %}\n        Manuell:\n        {% render_set_value dataset 'project/dataset/metadata/creation_manual' %}\n        Mappings:\n        {% render_set_value dataset 'project/dataset/metadata/mappings' %}\n    </p>\n    <p>\n        Verantwortlicher für Richtigkeit:\n        {% render_set_value_inline_list dataset 'project/dataset/metadata/responsible_person/name' %}\n    </p>\n{% endfor %}\n\n<h2>2. Ethische, rechtliche und Sicherheitsfragen</h2>\n<h3>2.1. Wie gestalten sich der Umfang mit und die Behandlung von ethischen Fragen?</h3>\n<p>\n    <b>2.1.1. Welche Sicherheitsstandards sind für ihre Daten relevant? Sind Sie an eine Vertraulichkeitsvereinbarung gebunden?</p>\n</b>\n\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        Sicherheitsstandards:\n        Vertrauchlichkeitsvereinbarung:\n    </p>\n{% endfor %}\n\n<p>\n    Rechtliche Situation verschiedener Länder: {% render_value 'project/legal_aspects/international_yesno' %}\n</p>\n\n<p>\n    <b>2.1.2. Verfügen Sie über die notwendigen Genehmigungen, um die Daten einzuholen, zu verarbeiten, zu speichern und weiterzuverarbeiten?</p>\n</b>\n\n{% for dataset in datasets %}\n    <p>\n        <em> Datensatz {% render_set_value dataset 'project/dataset/id' %}: </em>\n    </p>\n    Rechtinhaber recherchiert: {% render_set_value dataset 'project/dataset/ipr/owner/name' %}\n    {% get_set_value dataset 'project/dataset/ipr/copyrights' as val %}\n    {% if val.is_true %}\n        <p>Copyrights: {% render_set_value_inline_list dataset 'project/dataset/ipr/copyrights' %}</p>\n    {% endif %}\n    {% get_set_value dataset 'project/dataset/ipr/other_rights' as val %}\n    {% if val.is_true %}\n        <p>Andere Rechte: {% render_set_value_inline_list dataset 'project/dataset/ipr/copyrights' %}</p>\n    {% endif %}\n{% endfor %}\n\n<p>\n    <b>2.1.3. Wurden die Personen, deren Daten verwendet werden, informiert oder haben sie ihre Zustimmung gegeben?</p>\n</b>\n\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        {% render_set_value dataset 'project/dataset/sensitive_data/personal_data/consent/extent' %},\n        abegelegt: {% render_set_value dataset 'project/dataset/sensitive_data/personal_data/consent/record' %}\n        Begründung, falls keine Zustimmung eingeholt: {% render_set_value dataset 'project/dataset/sensitive_data/personal_data/consent/statement' %}\n    </p>\n{% endfor %}\n\n<p>\n    <b>2.1.4. Mit welchen Methoden und Vorkehrungen planen Sie Personendaten und andere sensbile Daten zu schützen?</b>\n</p>\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        {% render_set_value dataset 'project/dataset/sensitive_data/personal_data/anonymization' %}\n        Gelöscht bis {% render_set_value dataset 'project/dataset/sensitive_data/personal_data/deletion' %}\n    </p>\n{% endfor %}\n\n<h3>2.2. Wie werden der Zugriff auf Daten und die Datensicherung verwaltet?</h3>\n<p>\n    <b>2.2.1. Welche sind die wesentlichen Bedenken bei der Datensicherheit, wie groß sind die Risiken und welche Maßnahmen zum Umgang mit Sicherheitsrisiken stehen zur Verfügung?</p>\n</b>\n\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        Maßnahmen: {% render_set_value dataset 'project/dataset/data_security/security_measures' %}\n    </p>\n{% endfor %}\n\n<p>\n    <b>2.2.2. Wie werden Sie Zugriffsrechte auf Daten/Genehmigungen zur Sicherstellung der Datensicherheit behandeln?</b>\n</p>\n\n<p>\n    <b>2.2.3. Wir wird im Umgang mit Personendaten oder mit anderen sensiblen Daten die sichere Datenspeicherung und -übertragung gewährleistet?</b>\n</p>\n\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        {% render_set_value dataset 'project/dataset/collaboration_organisation' %}\n    </p>\n{% endfor %}\n\n<h3>2.3. Wie lösen Sie Urheberrechtsfragen und Fragen des geistigen Eigentums?</h3>\n<p>\n    <b>2.3.1. Wer ist der Eigner der Daten?</p>\n</b>\n\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        {% render_set_value dataset 'project/dataset/ipr/owner/name' %}\n    </p>\n{% endfor %}\n\n<p>\n    <b>2.3.2. Welche Lizenzen gelten für die Daten?</p>\n</b>\n\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        {% render_set_value_inline_list dataset 'project/dataset/sharing/conditions' %}\n    </p>\n{% endfor %}\n\n<p>\n    <b>2.3.3. Welche Einschränkungen gelten für die Weiterverwendung von externen Daten?</b>\n</p>\n\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        {% render_set_value dataset 'project/dataset/sharing/restrictions_explanation' %}\n    </p>\n{% endfor %}\n\n<h2> 3. Datenspeicherung und Datenerhalt</h2>\n<h3>3.1. Wie werden Ihre Daten während der Forschungsarbeit gespeichert und gesichert?</h3>\n<p>\n    <b>3.1.1. Über welche Speicherkapazitäten verfügen Sie und wo werden die Daten gespeichert?</b>\n</p>\n\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em> Ort: {% render_set_value dataset 'project/dataset/storage/type' %}\n    </p>\n{% endfor %}\n\n<p>\n    <b>3.1.2. Welche Verfahren dienen zur Datensicherung?</b>\n</p>\n\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        Zugangerlaubnis: {% render_set_value dataset 'project/dataset/data_security/access_permissions' %}\n        Backups: {% render_set_value dataset 'project/dataset/data_security/backups' %}\n        Verantwortlichkeit: {% render_set_value dataset 'project/dataset/data_security/backup_responsible/name' %}\n        Maßnahmen: {% render_set_value dataset 'project/dataset/data_security/security_measures' %}\n        Zugangsauthentification: {% render_set_value dataset 'project/dataset/preservation/access_authentication' %}\n        Benötigte Infrastrukturressourcen: {% render_set_value dataset 'project/dataset/usage_infrastructure' %}\n        Unterstützung notwendig: {% render_set_value dataset 'project/dataset/usage_support' %}\n    </p>\n{% endfor %}\n\n<h3>3.2. Wie gestaltet sich ihre Planung für den Datenerhalt?</h3>\n<p>\n    <b>3.2.1. Mittels welchen Verfahren werden die zu erhaltenden Daten ausgewählt?</p>\n</b>\n<p> {% render_value 'project/preservation/selection_criteria' %}</p>\n<p>Zuständigkeit: {% render_value_inline_list 'project/dataset/preservation/responsible_person/name' %}</p>\n<p>\n    <b>3.2.2. Welche Dateiformate werden zum Datenerhalt eingesetzt?</b>\n</p>\n\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        Muss aufbewahrt werden: {% render_set_value dataset 'project/dataset/preservation/yesno' %}\n        Begründung: {% render_set_value dataset 'project/dataset/preservation/purpose' %}\n        Dauer: {% render_set_value dataset 'project/dataset/preservation/duration' %}\n        Nachnutzung: {% render_set_value dataset 'project/dataset/preservation/reuse_duration' %}\n        Interoperabilität: {% render_set_value_inline_list dataset 'project/dataset/interoperability' %}\n        Ort: {% render_set_value dataset 'project/dataset/preservation/repository' %}\n        Zertifizierung: {% render_set_value dataset 'project/dataset/preservation/certification' %}\n    </p>\n{% endfor %}\n\n<h2> 4. Datenaustausch und Weiterverwendung von Daten</h2>\n<h3> 4.1. Wie und wo werden die Daten zugänglich gemacht? </h3>\n<p>\n    <b> 4.1.1. In welchem Datenarchiv wollen Sie Ihre Daten zur Verfügung stellen?</b>\n</p>\n\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        Repository: {% render_set_value dataset 'project/dataset/preservation/repository' %}\n        Zertifiziert?: {% render_set_value dataset 'project/dataset/preservation/certification' %}\n        Archivierungslösungen: {% render_set_value dataset 'project/dataset/preservation/repository_arrangements' %}\n        wann archiviert: {% render_set_value dataset 'project/dataset/preservation/data_archiving_date' %}\n        veröffentlicht: {% render_set_value dataset 'project/dataset/data_publication_date/data_publication_date' %}\n    </p>\n{% endfor %}\n\n<p>\n    <b>4.1.2. Wie erfahren potentielle Benutzer von Ihren Daten?</b>\n</p>\n\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        Persistente Identifikatoren: {% render_set_value dataset 'project/dataset/pids' %}\n        System: {% render_set_value dataset 'project/dataset/pids/system' %}\n        Subentitäten: {% render_set_value dataset 'project/dataset/pids/subentities' %}\n    </p>\n{% endfor %}\n\n<h3>4.2. Sind bestimmte Einschränkungen erforderlich, um sensible Daten zu schützen?</h3>\n<p>\n    <b>4.2.1. Unter welchen Bedingungen werden die Daten zur Verfügung gestellt (Zeitpunkt der Datenfreigabe, Gründe für allfällige Verzögerungen)?</b>\n</p>\n\n<p>\n    Datenzugangskommitee: {% render_value 'project/legal_aspects/official_approval/data_access_committee' %},\n    {% render_value 'project/legal_aspects/official_approval/statutatory_approval/title' %}\n</p>\n\n{% for dataset in datasets %}\n    <p>\n        <em>Datensatz {% render_set_value dataset 'project/dataset/id' %}:</em>\n        Embargo-Zeit: {% render_set_value dataset 'project/dataset/preservation/embargo_period' %}\n    </p>\n{% endfor %}\n\n<p>Zeitpunkt der Datenfreigabe:</p>\n<p>Gründe für allfällige Verzögerungen:</p>\n\n<h3> 4.3. Ich werde digitale Archive nutzen, die den FAIR Data Principiles entsprechen </h3>\n<p>\n    {% render_value 'project/preservation/archive/yesno' %}\n   {% render_value 'project/preservation/archive/fair_archive' %}\n</p>\n\n<h3> 4.4.  Ich werde digitale Archive wählen, die von einer gemeinnützigen Organisation verwaltet werden.</h3>\n<p>\n    {% render_value 'project/nonprofit/yesno' %}\n    {% render_value 'project/preservation/archive/nonprofit/explanation' %}\n</p>	https://rdmorganiser.github.io/terms/views/snf	https://rdmorganiser.github.io/terms	DMP für die SNF (Schweiz)	DMP of the SNF (Switzerland)	SNF Vorlage	SNF Template							t	f
7	Test_GFBio_2	For internal test only!\nSmall DMP template adapted from the  GFBio DMPT	{% load view_tags %}\n\n{% get_set 'project/partner' as partners %}\n{% get_set 'project/dataset' as datasets %}\n\n<h1>DMP adapted test template for GFBio</h1>\n\n<h2>1. General Project Information</h2>\n<p>\n  <b>What is the official name of your research project?*</b>\n</p>\n<p>\n{% render_value 'project/research_question/title' %}\n</p>\n<p>\n<b>What are the principal investigators?</b>\n</p>\n<p>\n{% render_value_inline_list 'project/coordination/name' %}\n</p>\n<p>\n<b>Who will be responsible for data management in your project?</b>\n</p>\n{% for partner in partners %}\n<p>\n{% render_set_value_list partner 'project/partner/contact_person/name' %}\n</p>\n{% endfor %}\n<p>\n\n<h2>2. Data Collection</h2>\n<p>\n  <b>What data will you collect or create?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/description' %},\n\tdata format: {% render_set_value dataset 'project/dataset/format' %}\n</p>\n{% endfor %}\n<p>\n    <b>How will the data be collected or created?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/creation_methods' %}\n</p>\n{% endfor %}\n<p>\n\n<h2>3. Documentation and Metadata</h2>\n<p>\n    <b>What documentation and metadata will accompany the data?</b>\n</p>\n\n<p>\n    <i>Metadata</i>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/interoperability' %}\n</p>\n{% endfor %}\n\n<p>\n    <i>Documentation</i>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/id/standards' %}\n</p>\n{% endfor %}\n\n<h2>4. Ethics and Legal Compliance</h2>\n\n<p>\n    <b>How will you manage any ethical issues?</b>\n</p>\n<p>\n    {% render_value 'project/legal_aspects/sensitive_data/other_sensitive_data/yesno' %}\n    {% render_value 'project/legal_aspects/sensitive_data/other_sensitive_data/description' %}\n</p>\n\n<p>\n    <b>How will you manage copyright and Intellectual Property Rights (IPR) issues?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n</p>\n<p>\n\tApplicable copyrights:\n    {% render_set_value dataset 'project/dataset/ipr/copyrights' %}\n</p>\n<p>\n\tOther applicable intellectual property rights:\n    {% render_set_value dataset 'project/dataset/ipr/other_rights' %}\n</p>\n<p>\n\tRightsholder: {% render_set_value dataset 'project/dataset/ipr/owner/name' %}\n</p>\n{% endfor %}\n\n<p>\n\n<h2>5. Storage and Backup</h2>\n<p>\n    <b>How will the data be stored and backed up during the research?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/storage/type' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>How will you manage access and security?</b>\n</p>\n<p>{% render_value 'project/data_security' %}\n\n<h2>6. Preservation and Sharing</h2>\n\n<p>\n    <b>Which data are of long-term value and should be retained, shared, and/or preserved?</b>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/preservation/yesno' %}.\n\t{% render_set_value_inline_list dataset 'project/dataset/preservation/purpose' %}.\n</p>\n{% endfor %}\n\n<p>\n    <b>What is the long-term preservation plan for the dataset?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/preservation/duration' %}.\n\tIn: {% render_set_value dataset 'project/dataset/preservation/repository' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>How will you share the data?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/metadata/standards' %}\n</p>\n{% endfor %}\n\n<p>\n    <b>Are any restrictions on data sharing required?</b>\n</p>\n\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/sharing/conditions' %}\n</p>\n{% endfor %}\n\n\n<p>\n    <i>Data sizes</i>\n</p>\n{% for dataset in datasets %}\n<p>\n\t<i>Dataset {% render_set_value dataset 'project/dataset/id' %}:</i>\n\t{% render_set_value dataset 'project/dataset/id/volume' %}\n</p>\n{% endfor %}	https://rdmorganiser.github.io/terms/views/Test_GFBio_2	https://rdmorganiser.github.io/terms	Klein und algemeine DMP-Vorlage für GFBio	A small and general  DMP template	GFBio_Test_Vorlage Basis-DMP	GFBio_test_template basic DMP							t	f
8	Test_GFBio_1	based on the GFBio DMPT available online	{% load view_tags %}\n\n{% get_set 'gfbio/general/research_category_type' as categories %}\n{% get_set 'gfbio/general/research_data_reproducible' as reproducibles %}\n{% get_set 'gfbio/general/funder_or_programm_title' as fundings %}\n{% get_set 'gfbio/general/policies_or_guidelines/type' as policies %}\n{% get_set 'gfbio/data_collection/data_type/will_be_created' as datatypes %}\n{% get_set 'gfbio/ethics_and_legal_compliance/legal_requirement_type' as legalrequirements %}\n{% get_set 'gfbio/ethics_and_legal_compliance/license_type' as licenses %}\n{% get_set 'gfbio/preservation_and_sharing/data_submission_to_GFBio' as datasubmissions %}\n{% get_set 'gfbio/preservation_and_sharing/place_long_term_archiving' as archiving %}\n{% get_set 'gfbio/preservation_and_sharing/persistent_identifier_for_data' as dataidentifiers %}\n\n<h1>Test GFBio Template DMPT</h1>\n\n<h2>1. General</h2>\n\n<p>\n\t<b>1.1 What is the official name of your research project?</b>\n</p>\n<p>\n {% render_value 'gfbio/general/project_name' %}\n</p>\n\n<p>\n\t<b>1.2 Please select a category:</b>\n</p>\n\n<p>\n{% render_value 'gfbio/general/research_category_type' %}\n</p>\n\n<p>\n\t<b>1.3 Is your research data reproducible?</b>\n</p>\n{% for reproducible in reproducibles %}\n<p>\n    {% render_set_value reproducible 'gfbio/general/research_data_reproducible' %}\n</p>\n{% endfor %}\n\n<p> \n\t<b>1.4 Please specify your project type<b>\n</p>\n<p>\n{% render_value 'gfbio/general/project_type' %}\n</p>\n\n<p> \n\t<b>1.5 Provide your project abstract or describe your work and the data involved.<b>\n</p>\n<p>\n{% render_value 'gfbio/general/project_abstract' %}\n</p>\n\n<p> \n\t<b>1.6 Who is the point of contact for the project data?</b>\n</p>\n<p>\n <em>{% render_value 'gfbio/general/point_of_contact/contact_person_name' %}</em> /\n <em>Phone number:</em> {% render_value 'gfbio/general/point_of_contact/phone_number' %} /\n <em>E-mail:</em> {% render_value 'gfbio/general/point_of_contact/email' %}\n</p>\n\n<p> \n\t<b>1.7 For which funding are you applying?<b>\n {% for funding in funding %}\n</p>\n    {% render_set_value funding 'gfbio/general/funder_or_programm_title' %}\n</p>\n{% endfor %}\n\n <p>\n \t<b>1.8 Which policies or guidelines for research data management will you follow?</b>\n</p>\n{% for policy in policies %}\n<p>\n    {% render_set_value category 'gfbio/general/policies_or_guidelines/type' %}\n</p>\n{% endfor %}\n\n</p>\n\n<h2>2. Data Collection</h2>\n\n<p> \n\t<b>2.1 Do you want to submit physical objects along with your data?<b>\n</p>\n<p>\n{% render_value 'gfbio/data_collection/object/physical_object_yesno' %}\n</p>\n\n<p>\n\t<b>2.2 Is your object dead or alive?</b>\n    \n{% render_value 'gfbio/data_collection/object_1/object_dead_or_alive' %}\n</p>\n\n<p>\n\t<b>2.3 Is your object taxon-based?</b>\n</p>\n<p>\n{% render_value 'gfbio/data_collection/object_2/taxon_yesno' %}\n</p>\n\n<p>\n\t<b>2.4 Do you have mainly sequence data?</b>\n    </p>\n<p>\n{% render_value 'gfbio/data_collection/data_type/sequence_data' %}\n</p>\n\n<p> \n\t<b>2.5 What type of data will you create?<b>\n</p>\n{% for datatype in datatypes %}\n<p>\n    {% render_set_value datatype 'gfbio/data_collection/data_type/will_be_created' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>2.6 What file formats will you create?</b>\n</p>\n<p>\n{% render_value 'gfbio/data_collection/data_type/file_formats' %}\n</p>\n\n<p> \n\t<b>2.7 Please estimate the data volume you will create</b>\n</p>\n<p>\n{% render_value 'gfbio/data_collection/data_volume/estimated' %}\n</p>\n\n<h2>3. Documentation and Metadata</h2>\n\n<p>\n\t<b>3.1 Which metadata schema does your data support (if any)?<b>\n </p>\n<p>\n{% render_value 'gfbio/documentation_and_metadata/metadata_schema_type' %}\n</p>\n\n<h2>4. Ethics and legal compliance</h2>\n\n<p> \n\t<b>4.1 Which legal requirements will your research data meet?<b>\n</p>\n{% for legalrequirement in legalrequirements %}\n<p>\n    {% render_set_value legalrequirement 'gfbio/ethics_and_legal_compliance/legal_requirement_type' %}\n</p>\n{% endfor %}\n\n<p> \n\t<b>4.2 How will your data be licensed for reuse?<b>\n\n{% for license in licenses %}\n<p>\n    {% render_set_value license 'gfbio/ethics_and_legal_compliance/license_type' %}\n</p>\n{% endfor %}\n\n<p> \n\t<b>4.3  Do you need access restriction for your data?<b>\n</p>\n<p>\n{% render_value 'gfbio/ethics_and_legal_compliance/acces_restriction_to_data' %}\n</p>\n\n<p> \n\t<b>4.4  For how long do you need exclusive use of the data?<b>\n</p>\n<p>\n{% render_value 'gfbio/ethics_and_legal_compliance/acces_restriction_to_data/lenght_of_access_restriction' %}\n</p>\n\n<h2>5. Preservation and Sharing</h2>\n\n<p> \n\t<b>5.1 When will your data be submitted to GFBio?<b>\n</p>\n{% for datasubmission in datasubmissions %}\n<p>\n    {% render_set_value datasubmission 'gfbio/preservation_and_sharing/data_submission_to_GFBio' %}\n</p>\n{% endfor %}\n\n<p> \n\t<b>5.2 Where will your data be long-term archived?<b>\n</p>\n{% for archive in archiving %}\n<p>\n    {% render_set_value archive 'gfbio/preservation_and_sharing/place_long_term_archiving' %}\n</p>\n{% endfor %}\n\n<p> \n\t<b>5.3 Do you need a persistent identifier (e.g. ePIC PID / DOI) for your data?<b>\n</p>\n{% for dataidentifier in dataidentifiers %}\n<p>\n    {% render_set_value dataidentifier 'gfbio/preservation_and_sharing/persistent_identifier_for_data' %}\n</p>\n{% endfor %}\n\n</p>	http://example.com/terms/views/Test_GFBio_1	http://example.com/terms		based on the GFBio DMPT available online	GFBio_Vorlage_DMPT	GFBio_Template_DMPT							t	f
9	Jimena_test		{% load view_tags %}\n\n{% get_set 'gfbio/general/research_category_type' as categories %}\n{% get_set 'gfbio/general/research_data_reproducible' as reproducibles %}\n{% get_set 'gfbio/general/funder_or_programm_title' as fundings %}\n{% get_set 'gfbio/general/policies_or_guidelines/type' as policies %}\n{% get_set 'gfbio/data_collection/data_type/will_be_created' as datatypes %}\n{% get_set 'gfbio/ethics_and_legal_compliance/legal_requirement_type' as legalrequirements %}\n{% get_set 'gfbio/ethics_and_legal_compliance/license_type' as licenses %}\n{% get_set 'gfbio/preservation_and_sharing/data_submission_to_GFBio' as datasubmissions %}\n{% get_set 'gfbio/preservation_and_sharing/place_long_term_archiving' as archiving %}\n{% get_set 'gfbio/preservation_and_sharing/persistent_identifier_for_data' as dataidentifiers %}\n\n<h1>Test GFBio Template DMPT</h1>\n\n<h2>1. General</h2>\n\n<p>\n\t<b>1.1 What is the official name of your research project?</b>\n</p>\n<p>\n {% render_value 'gfbio/general/project_name' %}\n</p>\n\n<p>\n\t<b>1.2 Please select a category:</b>\n</p>\n\n<p>\n{% render_value 'gfbio/general/research_category_type' %}\n</p>\n\n\n<p>\n\t<b>1.3 Is your research data reproducible?</b>\n</p>\n{% for reproducible in reproducibles %}\n<p>\n    {% render_set_value reproducible 'gfbio/general/research_data_reproducible' %}\n</p>\n{% endfor %}\n\n<p> \n\t<b>1.4 Please specify your project type<b>\n</p>\n<p>\n{% render_value 'gfbio/general/project_type' %}\n</p>\n\n<p> \n\t<b>1.5 Provide your project abstract or describe your work and the data involved.<b>\n</p>\n<p>\n{% render_value 'gfbio/general/project_abstract' %}\n</p>\n\n<p> \n\t<b>1.6 Who is the point of contact for the project data?</b>\n</p>\n<p>\n <em>{% render_value 'gfbio/general/point_of_contact/contact_person_name' %}</em> /\n <em>Phone number:</em> {% render_value 'gfbio/general/point_of_contact/phone_number' %} /\n <em>E-mail:</em> {% render_value 'gfbio/general/point_of_contact/email' %}\n</p>\n\n<p> \n\t<b>1.7 For which funding are you applying?<b>\n {% for funding in funding %}\n</p>\n    {% render_set_value funding 'gfbio/general/funder_or_programm_title' %}\n</p>\n{% endfor %}\n\n <p>\n \t<b>1.8 Which policies or guidelines for research data management will you follow?</b>\n</p>\n{% for policy in policies %}\n<p>\n    {% render_set_value category 'gfbio/general/policies_or_guidelines/type' %}\n</p>\n{% endfor %}\n\n</p>\n\n<h2>2. Data Collection</h2>\n\n<p> \n\t<b>2.1 Do you want to submit physical objects along with your data?<b>\n</p>\n<p>\n{% render_value 'gfbio/data_collection/object/physical_object_yesno' %}\n</p>\n\n<p>\n\t<b>2.2 Is your object dead or alive?</b>\n    \n{% render_value 'gfbio/data_collection/object_1/object_dead_or_alive' %}\n</p>\n\n<p>\n\t<b>2.3 Is your object taxon-based?</b>\n</p>\n<p>\n{% render_value 'gfbio/data_collection/object_2/taxon_yesno' %}\n</p>\n\n<p>\n\t<b>2.4 Do you have mainly sequence data?</b>\n    </p>\n<p>\n{% render_value 'gfbio/data_collection/data_type/sequence_data' %}\n</p>\n\n<p> \n\t<b>2.5 What type of data will you create?<b>\n</p>\n{% for datatype in datatypes %}\n<p>\n    {% render_set_value datatype 'gfbio/data_collection/data_type/will_be_created' %}\n</p>\n{% endfor %}\n\n<p>\n\t<b>2.6 What file formats will you create?</b>\n</p>\n<p>\n{% render_value 'gfbio/data_collection/data_type/file_formats' %}\n</p>\n\n<p> \n\t<b>2.7 Please estimate the data volume you will create</b>\n</p>\n<p>\n{% render_value 'gfbio/data_collection/data_volume/estimated' %}\n</p>\n\n<h2>3. Documentation and Metadata</h2>\n\n<p>\n\t<b>3.1 Which metadata schema does your data support (if any)?<b>\n </p>\n<p>\n{% render_value 'gfbio/documentation_and_metadata/metadata_schema_type' %}\n</p>\n\n<h2>4. Ethics and legal compliance</h2>\n\n<p> \n\t<b>4.1 Which legal requirements will your research data meet?<b>\n</p>\n{% for legalrequirement in legalrequirements %}\n<p>\n    {% render_set_value legalrequirement 'gfbio/ethics_and_legal_compliance/legal_requirement_type' %}\n</p>\n{% endfor %}\n\n<p> \n\t<b>4.2 How will your data be licensed for reuse?<b>\n\n{% for license in licenses %}\n<p>\n    {% render_set_value license 'gfbio/ethics_and_legal_compliance/license_type' %}\n</p>\n{% endfor %}\n\n<p> \n\t<b>4.3  Do you need access restriction for your data?<b>\n</p>\n<p>\n{% render_value 'gfbio/ethics_and_legal_compliance/acces_restriction_to_data' %}\n</p>\n\n<p> \n\t<b>4.4  For how long do you need exclusive use of the data?<b>\n</p>\n<p>\n{% render_value 'gfbio/ethics_and_legal_compliance/acces_restriction_to_data/lenght_of_access_restriction' %}\n</p>\n\n<h2>5. Preservation and Sharing</h2>\n\n<p> \n\t<b>5.1 When will your data be submitted to GFBio?<b>\n</p>\n{% for datasubmission in datasubmissions %}\n<p>\n    {% render_set_value datasubmission 'gfbio/preservation_and_sharing/data_submission_to_GFBio' %}\n</p>\n{% endfor %}\n\n<p> \n\t<b>5.2 Where will your data be long-term archived?<b>\n</p>\n{% for archive in archiving %}\n<p>\n    {% render_set_value archive 'gfbio/preservation_and_sharing/place_long_term_archiving' %}\n</p>\n{% endfor %}\n\n<p> \n\t<b>5.3 Do you need a persistent identifier (e.g. ePIC PID / DOI) for your data?<b>\n</p>\n{% for dataidentifier in dataidentifiers %}\n<p>\n    {% render_set_value dataidentifier 'gfbio/preservation_and_sharing/persistent_identifier_for_data' %}\n</p>\n{% endfor %}\n\n</p>	http://example.com/terms/views/Jimena_test	http://example.com/terms	nur zum Testen	only for testing	Jimena's	Jimena's							t	f
\.


--
-- Data for Name: views_view_catalogs; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.views_view_catalogs (id, view_id, catalog_id) FROM stdin;
\.


--
-- Data for Name: views_view_groups; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.views_view_groups (id, view_id, group_id) FROM stdin;
\.


--
-- Data for Name: views_view_sites; Type: TABLE DATA; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

COPY public.views_view_sites (id, view_id, site_id) FROM stdin;
1	1	1
2	2	1
3	3	1
4	4	1
5	5	1
6	6	1
7	7	1
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 1, true);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: accounts_additionalfield_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.accounts_additionalfield_id_seq', 1, false);


--
-- Name: accounts_additionalfieldvalue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.accounts_additionalfieldvalue_id_seq', 1, false);


--
-- Name: accounts_consentfieldvalue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.accounts_consentfieldvalue_id_seq', 1, false);


--
-- Name: accounts_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.accounts_role_id_seq', 1, true);


--
-- Name: accounts_role_manager_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.accounts_role_manager_id_seq', 1, false);


--
-- Name: accounts_role_member_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.accounts_role_member_id_seq', 1, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 3, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 119, true);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 180, true);


--
-- Name: conditions_condition_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.conditions_condition_id_seq', 19, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 7, true);


--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.django_celery_beat_clockedschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.django_celery_beat_crontabschedule_id_seq', 1, true);


--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.django_celery_beat_intervalschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.django_celery_beat_periodictask_id_seq', 1, true);


--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.django_celery_beat_solarschedule_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 45, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 331, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, false);


--
-- Name: domain_attributeentity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.domain_attributeentity_id_seq', 287, true);


--
-- Name: options_option_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.options_option_id_seq', 337, true);


--
-- Name: options_optionset_conditions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.options_optionset_conditions_id_seq', 1, false);


--
-- Name: options_optionset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.options_optionset_id_seq', 60, true);


--
-- Name: overlays_overlay_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.overlays_overlay_id_seq', 2, true);


--
-- Name: projects_continuation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.projects_continuation_id_seq', 1, false);


--
-- Name: projects_integration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.projects_integration_id_seq', 1, false);


--
-- Name: projects_integrationoption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.projects_integrationoption_id_seq', 1, false);


--
-- Name: projects_invite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.projects_invite_id_seq', 1, false);


--
-- Name: projects_issue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.projects_issue_id_seq', 11, true);


--
-- Name: projects_issueresource_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.projects_issueresource_id_seq', 1, false);


--
-- Name: projects_membership_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.projects_membership_id_seq', 1, true);


--
-- Name: projects_project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.projects_project_id_seq', 1, true);


--
-- Name: projects_project_views_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.projects_project_views_id_seq', 7, true);


--
-- Name: projects_snapshot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.projects_snapshot_id_seq', 1, true);


--
-- Name: projects_value_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.projects_value_id_seq', 1, false);


--
-- Name: questions_catalog_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.questions_catalog_groups_id_seq', 1, true);


--
-- Name: questions_catalog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.questions_catalog_id_seq', 22, true);


--
-- Name: questions_catalog_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.questions_catalog_sites_id_seq', 3, true);


--
-- Name: questions_questionitem_conditions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.questions_questionitem_conditions_id_seq', 9, true);


--
-- Name: questions_questionitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.questions_questionitem_id_seq', 577, true);


--
-- Name: questions_questionitem_optionsets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.questions_questionitem_optionsets_id_seq', 89, true);


--
-- Name: questions_questionset_conditions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.questions_questionset_conditions_id_seq', 21, true);


--
-- Name: questions_questionset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.questions_questionset_id_seq', 263, true);


--
-- Name: questions_section_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.questions_section_id_seq', 73, true);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: tasks_task_catalogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.tasks_task_catalogs_id_seq', 1, false);


--
-- Name: tasks_task_conditions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.tasks_task_conditions_id_seq', 4, true);


--
-- Name: tasks_task_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.tasks_task_groups_id_seq', 1, false);


--
-- Name: tasks_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.tasks_task_id_seq', 13, true);


--
-- Name: tasks_task_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.tasks_task_sites_id_seq', 11, true);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 3, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.users_user_id_seq', 1, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 180, true);


--
-- Name: views_view_catalogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.views_view_catalogs_id_seq', 1, false);


--
-- Name: views_view_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.views_view_groups_id_seq', 1, false);


--
-- Name: views_view_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.views_view_id_seq', 9, true);


--
-- Name: views_view_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

SELECT pg_catalog.setval('public.views_view_sites_id_seq', 7, true);


--
-- Name: account_emailaddress account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: accounts_additionalfield accounts_additionalfield_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_additionalfield
    ADD CONSTRAINT accounts_additionalfield_pkey PRIMARY KEY (id);


--
-- Name: accounts_additionalfieldvalue accounts_additionalfieldvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_additionalfieldvalue
    ADD CONSTRAINT accounts_additionalfieldvalue_pkey PRIMARY KEY (id);


--
-- Name: accounts_consentfieldvalue accounts_consentfieldvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_consentfieldvalue
    ADD CONSTRAINT accounts_consentfieldvalue_pkey PRIMARY KEY (id);


--
-- Name: accounts_consentfieldvalue accounts_consentfieldvalue_user_id_key; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_consentfieldvalue
    ADD CONSTRAINT accounts_consentfieldvalue_user_id_key UNIQUE (user_id);


--
-- Name: accounts_role_manager accounts_role_manager_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role_manager
    ADD CONSTRAINT accounts_role_manager_pkey PRIMARY KEY (id);


--
-- Name: accounts_role_manager accounts_role_manager_role_id_site_id_bb910a39_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role_manager
    ADD CONSTRAINT accounts_role_manager_role_id_site_id_bb910a39_uniq UNIQUE (role_id, site_id);


--
-- Name: accounts_role_member accounts_role_member_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role_member
    ADD CONSTRAINT accounts_role_member_pkey PRIMARY KEY (id);


--
-- Name: accounts_role_member accounts_role_member_role_id_site_id_0e6981c4_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role_member
    ADD CONSTRAINT accounts_role_member_role_id_site_id_0e6981c4_uniq UNIQUE (role_id, site_id);


--
-- Name: accounts_role accounts_role_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role
    ADD CONSTRAINT accounts_role_pkey PRIMARY KEY (id);


--
-- Name: accounts_role accounts_role_user_id_key; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role
    ADD CONSTRAINT accounts_role_user_id_key UNIQUE (user_id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: conditions_condition conditions_condition_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.conditions_condition
    ADD CONSTRAINT conditions_condition_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_clockedschedule django_celery_beat_clockedschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule
    ADD CONSTRAINT django_celery_beat_clockedschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_crontabschedule django_celery_beat_crontabschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule
    ADD CONSTRAINT django_celery_beat_crontabschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_intervalschedule django_celery_beat_intervalschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule
    ADD CONSTRAINT django_celery_beat_intervalschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_name_key; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_name_key UNIQUE (name);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictasks django_celery_beat_periodictasks_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_periodictasks
    ADD CONSTRAINT django_celery_beat_periodictasks_pkey PRIMARY KEY (ident);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq UNIQUE (event, latitude, longitude);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solarschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solarschedule_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: domain_attribute domain_attributeentity_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.domain_attribute
    ADD CONSTRAINT domain_attributeentity_pkey PRIMARY KEY (id);


--
-- Name: options_option options_option_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.options_option
    ADD CONSTRAINT options_option_pkey PRIMARY KEY (id);


--
-- Name: options_optionset_conditions options_optionset_condit_optionset_id_condition_i_9c16564c_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.options_optionset_conditions
    ADD CONSTRAINT options_optionset_condit_optionset_id_condition_i_9c16564c_uniq UNIQUE (optionset_id, condition_id);


--
-- Name: options_optionset_conditions options_optionset_conditions_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.options_optionset_conditions
    ADD CONSTRAINT options_optionset_conditions_pkey PRIMARY KEY (id);


--
-- Name: options_optionset options_optionset_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.options_optionset
    ADD CONSTRAINT options_optionset_pkey PRIMARY KEY (id);


--
-- Name: overlays_overlay overlays_overlay_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.overlays_overlay
    ADD CONSTRAINT overlays_overlay_pkey PRIMARY KEY (id);


--
-- Name: projects_continuation projects_continuation_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_continuation
    ADD CONSTRAINT projects_continuation_pkey PRIMARY KEY (id);


--
-- Name: projects_integration projects_integration_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_integration
    ADD CONSTRAINT projects_integration_pkey PRIMARY KEY (id);


--
-- Name: projects_integrationoption projects_integrationoption_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_integrationoption
    ADD CONSTRAINT projects_integrationoption_pkey PRIMARY KEY (id);


--
-- Name: projects_invite projects_invite_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_invite
    ADD CONSTRAINT projects_invite_pkey PRIMARY KEY (id);


--
-- Name: projects_issue projects_issue_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_issue
    ADD CONSTRAINT projects_issue_pkey PRIMARY KEY (id);


--
-- Name: projects_issueresource projects_issueresource_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_issueresource
    ADD CONSTRAINT projects_issueresource_pkey PRIMARY KEY (id);


--
-- Name: projects_membership projects_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_membership
    ADD CONSTRAINT projects_membership_pkey PRIMARY KEY (id);


--
-- Name: projects_project projects_project_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_project
    ADD CONSTRAINT projects_project_pkey PRIMARY KEY (id);


--
-- Name: projects_project_views projects_project_views_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_project_views
    ADD CONSTRAINT projects_project_views_pkey PRIMARY KEY (id);


--
-- Name: projects_project_views projects_project_views_project_id_view_id_79f0cf0f_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_project_views
    ADD CONSTRAINT projects_project_views_project_id_view_id_79f0cf0f_uniq UNIQUE (project_id, view_id);


--
-- Name: projects_snapshot projects_snapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_snapshot
    ADD CONSTRAINT projects_snapshot_pkey PRIMARY KEY (id);


--
-- Name: projects_value projects_value_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_value
    ADD CONSTRAINT projects_value_pkey PRIMARY KEY (id);


--
-- Name: questions_catalog_groups questions_catalog_groups_catalog_id_group_id_0f013c1b_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_catalog_groups
    ADD CONSTRAINT questions_catalog_groups_catalog_id_group_id_0f013c1b_uniq UNIQUE (catalog_id, group_id);


--
-- Name: questions_catalog_groups questions_catalog_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_catalog_groups
    ADD CONSTRAINT questions_catalog_groups_pkey PRIMARY KEY (id);


--
-- Name: questions_catalog questions_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_catalog
    ADD CONSTRAINT questions_catalog_pkey PRIMARY KEY (id);


--
-- Name: questions_catalog_sites questions_catalog_sites_catalog_id_site_id_23367073_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_catalog_sites
    ADD CONSTRAINT questions_catalog_sites_catalog_id_site_id_23367073_uniq UNIQUE (catalog_id, site_id);


--
-- Name: questions_catalog_sites questions_catalog_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_catalog_sites
    ADD CONSTRAINT questions_catalog_sites_pkey PRIMARY KEY (id);


--
-- Name: questions_question_conditions questions_questionitem_c_questionitem_id_conditio_b9862fd2_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question_conditions
    ADD CONSTRAINT questions_questionitem_c_questionitem_id_conditio_b9862fd2_uniq UNIQUE (question_id, condition_id);


--
-- Name: questions_question_conditions questions_questionitem_conditions_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question_conditions
    ADD CONSTRAINT questions_questionitem_conditions_pkey PRIMARY KEY (id);


--
-- Name: questions_question_optionsets questions_questionitem_o_questionitem_id_optionse_44b8e4c7_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question_optionsets
    ADD CONSTRAINT questions_questionitem_o_questionitem_id_optionse_44b8e4c7_uniq UNIQUE (question_id, optionset_id);


--
-- Name: questions_question_optionsets questions_questionitem_optionsets_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question_optionsets
    ADD CONSTRAINT questions_questionitem_optionsets_pkey PRIMARY KEY (id);


--
-- Name: questions_question questions_questionitem_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question
    ADD CONSTRAINT questions_questionitem_pkey PRIMARY KEY (id);


--
-- Name: questions_questionset_conditions questions_questionset_co_questionset_id_condition_f886f556_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_questionset_conditions
    ADD CONSTRAINT questions_questionset_co_questionset_id_condition_f886f556_uniq UNIQUE (questionset_id, condition_id);


--
-- Name: questions_questionset_conditions questions_questionset_conditions_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_questionset_conditions
    ADD CONSTRAINT questions_questionset_conditions_pkey PRIMARY KEY (id);


--
-- Name: questions_questionset questions_questionset_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_questionset
    ADD CONSTRAINT questions_questionset_pkey PRIMARY KEY (id);


--
-- Name: questions_section questions_section_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_section
    ADD CONSTRAINT questions_section_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: tasks_task_catalogs tasks_task_catalogs_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_catalogs
    ADD CONSTRAINT tasks_task_catalogs_pkey PRIMARY KEY (id);


--
-- Name: tasks_task_catalogs tasks_task_catalogs_task_id_catalog_id_77e80319_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_catalogs
    ADD CONSTRAINT tasks_task_catalogs_task_id_catalog_id_77e80319_uniq UNIQUE (task_id, catalog_id);


--
-- Name: tasks_task_conditions tasks_task_conditions_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_conditions
    ADD CONSTRAINT tasks_task_conditions_pkey PRIMARY KEY (id);


--
-- Name: tasks_task_conditions tasks_task_conditions_task_id_condition_id_458aadbb_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_conditions
    ADD CONSTRAINT tasks_task_conditions_task_id_condition_id_458aadbb_uniq UNIQUE (task_id, condition_id);


--
-- Name: tasks_task_groups tasks_task_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_groups
    ADD CONSTRAINT tasks_task_groups_pkey PRIMARY KEY (id);


--
-- Name: tasks_task_groups tasks_task_groups_task_id_group_id_75c9cf21_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_groups
    ADD CONSTRAINT tasks_task_groups_task_id_group_id_75c9cf21_uniq UNIQUE (task_id, group_id);


--
-- Name: tasks_task tasks_task_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task
    ADD CONSTRAINT tasks_task_pkey PRIMARY KEY (id);


--
-- Name: tasks_task_sites tasks_task_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_sites
    ADD CONSTRAINT tasks_task_sites_pkey PRIMARY KEY (id);


--
-- Name: tasks_task_sites tasks_task_sites_task_id_site_id_f76cefa2_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_sites
    ADD CONSTRAINT tasks_task_sites_task_id_site_id_f76cefa2_uniq UNIQUE (task_id, site_id);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: views_view_catalogs views_view_catalogs_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_catalogs
    ADD CONSTRAINT views_view_catalogs_pkey PRIMARY KEY (id);


--
-- Name: views_view_catalogs views_view_catalogs_view_id_catalog_id_5655e154_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_catalogs
    ADD CONSTRAINT views_view_catalogs_view_id_catalog_id_5655e154_uniq UNIQUE (view_id, catalog_id);


--
-- Name: views_view_groups views_view_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_groups
    ADD CONSTRAINT views_view_groups_pkey PRIMARY KEY (id);


--
-- Name: views_view_groups views_view_groups_view_id_group_id_01a6f119_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_groups
    ADD CONSTRAINT views_view_groups_view_id_group_id_01a6f119_uniq UNIQUE (view_id, group_id);


--
-- Name: views_view views_view_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view
    ADD CONSTRAINT views_view_pkey PRIMARY KEY (id);


--
-- Name: views_view_sites views_view_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_sites
    ADD CONSTRAINT views_view_sites_pkey PRIMARY KEY (id);


--
-- Name: views_view_sites views_view_sites_view_id_site_id_4e753f19_uniq; Type: CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_sites
    ADD CONSTRAINT views_view_sites_view_id_site_id_4e753f19_uniq UNIQUE (view_id, site_id);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: accounts_additionalfield_key_d1349cbf; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX accounts_additionalfield_key_d1349cbf ON public.accounts_additionalfield USING btree (key);


--
-- Name: accounts_additionalfield_key_d1349cbf_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX accounts_additionalfield_key_d1349cbf_like ON public.accounts_additionalfield USING btree (key varchar_pattern_ops);


--
-- Name: accounts_additionalfieldvalue_field_id_cc9d73e8; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX accounts_additionalfieldvalue_field_id_cc9d73e8 ON public.accounts_additionalfieldvalue USING btree (field_id);


--
-- Name: accounts_additionalfieldvalue_user_id_47b62e3e; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX accounts_additionalfieldvalue_user_id_47b62e3e ON public.accounts_additionalfieldvalue USING btree (user_id);


--
-- Name: accounts_role_manager_role_id_02c65153; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX accounts_role_manager_role_id_02c65153 ON public.accounts_role_manager USING btree (role_id);


--
-- Name: accounts_role_manager_site_id_efa6e5eb; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX accounts_role_manager_site_id_efa6e5eb ON public.accounts_role_manager USING btree (site_id);


--
-- Name: accounts_role_member_role_id_76758add; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX accounts_role_member_role_id_76758add ON public.accounts_role_member USING btree (role_id);


--
-- Name: accounts_role_member_site_id_e6735be7; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX accounts_role_member_site_id_e6735be7 ON public.accounts_role_member USING btree (site_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: conditions_condition_key_0a42bd68; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX conditions_condition_key_0a42bd68 ON public.conditions_condition USING btree (key);


--
-- Name: conditions_condition_key_0a42bd68_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX conditions_condition_key_0a42bd68_like ON public.conditions_condition USING btree (key varchar_pattern_ops);


--
-- Name: conditions_condition_source_id_5a46e7d9; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX conditions_condition_source_id_5a46e7d9 ON public.conditions_condition USING btree (source_id);


--
-- Name: conditions_condition_target_option_id_4878a816; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX conditions_condition_target_option_id_4878a816 ON public.conditions_condition USING btree (target_option_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_celery_beat_periodictask_clocked_id_47a69f82; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX django_celery_beat_periodictask_clocked_id_47a69f82 ON public.django_celery_beat_periodictask USING btree (clocked_id);


--
-- Name: django_celery_beat_periodictask_crontab_id_d3cba168; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX django_celery_beat_periodictask_crontab_id_d3cba168 ON public.django_celery_beat_periodictask USING btree (crontab_id);


--
-- Name: django_celery_beat_periodictask_interval_id_a8ca27da; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX django_celery_beat_periodictask_interval_id_a8ca27da ON public.django_celery_beat_periodictask USING btree (interval_id);


--
-- Name: django_celery_beat_periodictask_name_265a36b7_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX django_celery_beat_periodictask_name_265a36b7_like ON public.django_celery_beat_periodictask USING btree (name varchar_pattern_ops);


--
-- Name: django_celery_beat_periodictask_solar_id_a87ce72c; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX django_celery_beat_periodictask_solar_id_a87ce72c ON public.django_celery_beat_periodictask USING btree (solar_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: domain_attributeentity_full_title_eec36655; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX domain_attributeentity_full_title_eec36655 ON public.domain_attribute USING btree (path);


--
-- Name: domain_attributeentity_full_title_eec36655_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX domain_attributeentity_full_title_eec36655_like ON public.domain_attribute USING btree (path varchar_pattern_ops);


--
-- Name: domain_attributeentity_key_650b21ed; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX domain_attributeentity_key_650b21ed ON public.domain_attribute USING btree (key);


--
-- Name: domain_attributeentity_key_650b21ed_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX domain_attributeentity_key_650b21ed_like ON public.domain_attribute USING btree (key varchar_pattern_ops);


--
-- Name: domain_attributeentity_parent_entity_id_5037e625; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX domain_attributeentity_parent_entity_id_5037e625 ON public.domain_attribute USING btree (parent_id);


--
-- Name: domain_attributeentity_tree_id_7279dbd2; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX domain_attributeentity_tree_id_7279dbd2 ON public.domain_attribute USING btree (tree_id);


--
-- Name: options_option_key_3b039e41; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX options_option_key_3b039e41 ON public.options_option USING btree (key);


--
-- Name: options_option_key_3b039e41_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX options_option_key_3b039e41_like ON public.options_option USING btree (key varchar_pattern_ops);


--
-- Name: options_option_optionset_id_442daa42; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX options_option_optionset_id_442daa42 ON public.options_option USING btree (optionset_id);


--
-- Name: options_option_path_b1189f5e; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX options_option_path_b1189f5e ON public.options_option USING btree (path);


--
-- Name: options_option_path_b1189f5e_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX options_option_path_b1189f5e_like ON public.options_option USING btree (path varchar_pattern_ops);


--
-- Name: options_optionset_conditions_condition_id_b595e3cf; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX options_optionset_conditions_condition_id_b595e3cf ON public.options_optionset_conditions USING btree (condition_id);


--
-- Name: options_optionset_conditions_optionset_id_86fe6bbd; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX options_optionset_conditions_optionset_id_86fe6bbd ON public.options_optionset_conditions USING btree (optionset_id);


--
-- Name: options_optionset_key_7df9430b; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX options_optionset_key_7df9430b ON public.options_optionset USING btree (key);


--
-- Name: options_optionset_key_7df9430b_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX options_optionset_key_7df9430b_like ON public.options_optionset USING btree (key varchar_pattern_ops);


--
-- Name: options_optionset_provider_key_620e7548; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX options_optionset_provider_key_620e7548 ON public.options_optionset USING btree (provider_key);


--
-- Name: options_optionset_provider_key_620e7548_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX options_optionset_provider_key_620e7548_like ON public.options_optionset USING btree (provider_key varchar_pattern_ops);


--
-- Name: overlays_overlay_current_e1e7c588; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX overlays_overlay_current_e1e7c588 ON public.overlays_overlay USING btree (current);


--
-- Name: overlays_overlay_current_e1e7c588_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX overlays_overlay_current_e1e7c588_like ON public.overlays_overlay USING btree (current varchar_pattern_ops);


--
-- Name: overlays_overlay_site_id_72843dad; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX overlays_overlay_site_id_72843dad ON public.overlays_overlay USING btree (site_id);


--
-- Name: overlays_overlay_url_name_25575ab2; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX overlays_overlay_url_name_25575ab2 ON public.overlays_overlay USING btree (url_name);


--
-- Name: overlays_overlay_url_name_25575ab2_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX overlays_overlay_url_name_25575ab2_like ON public.overlays_overlay USING btree (url_name varchar_pattern_ops);


--
-- Name: overlays_overlay_user_id_4894410e; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX overlays_overlay_user_id_4894410e ON public.overlays_overlay USING btree (user_id);


--
-- Name: projects_continuation_project_id_b85db9fb; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_continuation_project_id_b85db9fb ON public.projects_continuation USING btree (project_id);


--
-- Name: projects_continuation_questionset_id_4c5383a3; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_continuation_questionset_id_4c5383a3 ON public.projects_continuation USING btree (questionset_id);


--
-- Name: projects_continuation_user_id_7291fa2d; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_continuation_user_id_7291fa2d ON public.projects_continuation USING btree (user_id);


--
-- Name: projects_integration_project_id_fb6544d8; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_integration_project_id_fb6544d8 ON public.projects_integration USING btree (project_id);


--
-- Name: projects_integrationoption_integration_id_42fb0721; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_integrationoption_integration_id_42fb0721 ON public.projects_integrationoption USING btree (integration_id);


--
-- Name: projects_integrationoption_key_76091513; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_integrationoption_key_76091513 ON public.projects_integrationoption USING btree (key);


--
-- Name: projects_integrationoption_key_76091513_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_integrationoption_key_76091513_like ON public.projects_integrationoption USING btree (key varchar_pattern_ops);


--
-- Name: projects_invite_project_id_5930e2f3; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_invite_project_id_5930e2f3 ON public.projects_invite USING btree (project_id);


--
-- Name: projects_invite_user_id_b2bee14c; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_invite_user_id_b2bee14c ON public.projects_invite USING btree (user_id);


--
-- Name: projects_issue_project_id_f8e6d9c2; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_issue_project_id_f8e6d9c2 ON public.projects_issue USING btree (project_id);


--
-- Name: projects_issue_task_id_af165a16; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_issue_task_id_af165a16 ON public.projects_issue USING btree (task_id);


--
-- Name: projects_issueresource_integration_id_654cd5fa; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_issueresource_integration_id_654cd5fa ON public.projects_issueresource USING btree (integration_id);


--
-- Name: projects_issueresource_issue_id_4c66a485; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_issueresource_issue_id_4c66a485 ON public.projects_issueresource USING btree (issue_id);


--
-- Name: projects_membership_project_id_5f65bf3f; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_membership_project_id_5f65bf3f ON public.projects_membership USING btree (project_id);


--
-- Name: projects_membership_user_id_13374535; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_membership_user_id_13374535 ON public.projects_membership USING btree (user_id);


--
-- Name: projects_project_catalog_id_1f49c049; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_project_catalog_id_1f49c049 ON public.projects_project USING btree (catalog_id);


--
-- Name: projects_project_parent_id_9f73ad2b; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_project_parent_id_9f73ad2b ON public.projects_project USING btree (parent_id);


--
-- Name: projects_project_site_id_81d4030f; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_project_site_id_81d4030f ON public.projects_project USING btree (site_id);


--
-- Name: projects_project_tree_id_4008d87b; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_project_tree_id_4008d87b ON public.projects_project USING btree (tree_id);


--
-- Name: projects_project_views_project_id_a111668b; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_project_views_project_id_a111668b ON public.projects_project_views USING btree (project_id);


--
-- Name: projects_project_views_view_id_f4e5d854; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_project_views_view_id_f4e5d854 ON public.projects_project_views USING btree (view_id);


--
-- Name: projects_snapshot_project_id_b0587441; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_snapshot_project_id_b0587441 ON public.projects_snapshot USING btree (project_id);


--
-- Name: projects_value_attribute_id_524d090f; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_value_attribute_id_524d090f ON public.projects_value USING btree (attribute_id);


--
-- Name: projects_value_option_id_37fcfa86; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_value_option_id_37fcfa86 ON public.projects_value USING btree (option_id);


--
-- Name: projects_value_project_id_030f64a4; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_value_project_id_030f64a4 ON public.projects_value USING btree (project_id);


--
-- Name: projects_value_snapshot_id_5edd5409; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX projects_value_snapshot_id_5edd5409 ON public.projects_value USING btree (snapshot_id);


--
-- Name: questions_catalog_groups_catalog_id_166ff114; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_catalog_groups_catalog_id_166ff114 ON public.questions_catalog_groups USING btree (catalog_id);


--
-- Name: questions_catalog_groups_group_id_42389cad; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_catalog_groups_group_id_42389cad ON public.questions_catalog_groups USING btree (group_id);


--
-- Name: questions_catalog_key_6b6ed752; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_catalog_key_6b6ed752 ON public.questions_catalog USING btree (key);


--
-- Name: questions_catalog_key_6b6ed752_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_catalog_key_6b6ed752_like ON public.questions_catalog USING btree (key varchar_pattern_ops);


--
-- Name: questions_catalog_sites_catalog_id_b6cd1bff; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_catalog_sites_catalog_id_b6cd1bff ON public.questions_catalog_sites USING btree (catalog_id);


--
-- Name: questions_catalog_sites_site_id_62b449b4; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_catalog_sites_site_id_62b449b4 ON public.questions_catalog_sites USING btree (site_id);


--
-- Name: questions_question_default_option_id_e4ccc44b; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_question_default_option_id_e4ccc44b ON public.questions_question USING btree (default_option_id);


--
-- Name: questions_questionitem_attribute_entity_id_b8a92417; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionitem_attribute_entity_id_b8a92417 ON public.questions_question USING btree (attribute_id);


--
-- Name: questions_questionitem_conditions_condition_id_6de228f1; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionitem_conditions_condition_id_6de228f1 ON public.questions_question_conditions USING btree (condition_id);


--
-- Name: questions_questionitem_conditions_questionitem_id_ea115af2; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionitem_conditions_questionitem_id_ea115af2 ON public.questions_question_conditions USING btree (question_id);


--
-- Name: questions_questionitem_key_3ab20858; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionitem_key_3ab20858 ON public.questions_question USING btree (key);


--
-- Name: questions_questionitem_key_3ab20858_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionitem_key_3ab20858_like ON public.questions_question USING btree (key varchar_pattern_ops);


--
-- Name: questions_questionitem_optionsets_optionset_id_08567fe3; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionitem_optionsets_optionset_id_08567fe3 ON public.questions_question_optionsets USING btree (optionset_id);


--
-- Name: questions_questionitem_optionsets_questionitem_id_d50f9161; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionitem_optionsets_questionitem_id_d50f9161 ON public.questions_question_optionsets USING btree (question_id);


--
-- Name: questions_questionitem_questionset_id_8eba2e9e; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionitem_questionset_id_8eba2e9e ON public.questions_question USING btree (questionset_id);


--
-- Name: questions_questionset_attribute_entity_id_d6ce0c48; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionset_attribute_entity_id_d6ce0c48 ON public.questions_questionset USING btree (attribute_id);


--
-- Name: questions_questionset_conditions_condition_id_85c6f853; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionset_conditions_condition_id_85c6f853 ON public.questions_questionset_conditions USING btree (condition_id);


--
-- Name: questions_questionset_conditions_questionset_id_2fc4bcab; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionset_conditions_questionset_id_2fc4bcab ON public.questions_questionset_conditions USING btree (questionset_id);


--
-- Name: questions_questionset_key_219796ac; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionset_key_219796ac ON public.questions_questionset USING btree (key);


--
-- Name: questions_questionset_key_219796ac_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionset_key_219796ac_like ON public.questions_questionset USING btree (key varchar_pattern_ops);


--
-- Name: questions_questionset_section_id_2dfdee75; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_questionset_section_id_2dfdee75 ON public.questions_questionset USING btree (section_id);


--
-- Name: questions_section_catalog_id_5612b1ce; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_section_catalog_id_5612b1ce ON public.questions_section USING btree (catalog_id);


--
-- Name: questions_section_key_271dbde8; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_section_key_271dbde8 ON public.questions_section USING btree (key);


--
-- Name: questions_section_key_271dbde8_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX questions_section_key_271dbde8_like ON public.questions_section USING btree (key varchar_pattern_ops);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: tasks_task_catalogs_catalog_id_b165d5f4; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX tasks_task_catalogs_catalog_id_b165d5f4 ON public.tasks_task_catalogs USING btree (catalog_id);


--
-- Name: tasks_task_catalogs_task_id_191664fa; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX tasks_task_catalogs_task_id_191664fa ON public.tasks_task_catalogs USING btree (task_id);


--
-- Name: tasks_task_conditions_condition_id_d9e4b35d; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX tasks_task_conditions_condition_id_d9e4b35d ON public.tasks_task_conditions USING btree (condition_id);


--
-- Name: tasks_task_conditions_task_id_42f67f26; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX tasks_task_conditions_task_id_42f67f26 ON public.tasks_task_conditions USING btree (task_id);


--
-- Name: tasks_task_end_attribute_id_0e564a20; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX tasks_task_end_attribute_id_0e564a20 ON public.tasks_task USING btree (end_attribute_id);


--
-- Name: tasks_task_groups_group_id_37c9dd38; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX tasks_task_groups_group_id_37c9dd38 ON public.tasks_task_groups USING btree (group_id);


--
-- Name: tasks_task_groups_task_id_84269289; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX tasks_task_groups_task_id_84269289 ON public.tasks_task_groups USING btree (task_id);


--
-- Name: tasks_task_key_34e66bd7; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX tasks_task_key_34e66bd7 ON public.tasks_task USING btree (key);


--
-- Name: tasks_task_key_34e66bd7_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX tasks_task_key_34e66bd7_like ON public.tasks_task USING btree (key varchar_pattern_ops);


--
-- Name: tasks_task_sites_site_id_d03d8f1d; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX tasks_task_sites_site_id_d03d8f1d ON public.tasks_task_sites USING btree (site_id);


--
-- Name: tasks_task_sites_task_id_4f3a2bf5; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX tasks_task_sites_task_id_4f3a2bf5 ON public.tasks_task_sites USING btree (task_id);


--
-- Name: tasks_task_start_attribute_id_d519055d; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX tasks_task_start_attribute_id_d519055d ON public.tasks_task USING btree (start_attribute_id);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: views_view_catalogs_catalog_id_5e15127c; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX views_view_catalogs_catalog_id_5e15127c ON public.views_view_catalogs USING btree (catalog_id);


--
-- Name: views_view_catalogs_view_id_1f033a7d; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX views_view_catalogs_view_id_1f033a7d ON public.views_view_catalogs USING btree (view_id);


--
-- Name: views_view_groups_group_id_0c159c5a; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX views_view_groups_group_id_0c159c5a ON public.views_view_groups USING btree (group_id);


--
-- Name: views_view_groups_view_id_d755fd03; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX views_view_groups_view_id_d755fd03 ON public.views_view_groups USING btree (view_id);


--
-- Name: views_view_key_0bd806c8; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX views_view_key_0bd806c8 ON public.views_view USING btree (key);


--
-- Name: views_view_key_0bd806c8_like; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX views_view_key_0bd806c8_like ON public.views_view USING btree (key varchar_pattern_ops);


--
-- Name: views_view_sites_site_id_ff85e832; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX views_view_sites_site_id_ff85e832 ON public.views_view_sites USING btree (site_id);


--
-- Name: views_view_sites_view_id_7a296525; Type: INDEX; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

CREATE INDEX views_view_sites_view_id_7a296525 ON public.views_view_sites USING btree (view_id);


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_additionalfieldvalue accounts_additionalf_field_id_cc9d73e8_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_additionalfieldvalue
    ADD CONSTRAINT accounts_additionalf_field_id_cc9d73e8_fk_accounts_ FOREIGN KEY (field_id) REFERENCES public.accounts_additionalfield(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_additionalfieldvalue accounts_additionalfieldvalue_user_id_47b62e3e_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_additionalfieldvalue
    ADD CONSTRAINT accounts_additionalfieldvalue_user_id_47b62e3e_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_consentfieldvalue accounts_consentfieldvalue_user_id_71727b1c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_consentfieldvalue
    ADD CONSTRAINT accounts_consentfieldvalue_user_id_71727b1c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_role_manager accounts_role_manager_role_id_02c65153_fk_accounts_role_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role_manager
    ADD CONSTRAINT accounts_role_manager_role_id_02c65153_fk_accounts_role_id FOREIGN KEY (role_id) REFERENCES public.accounts_role(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_role_manager accounts_role_manager_site_id_efa6e5eb_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role_manager
    ADD CONSTRAINT accounts_role_manager_site_id_efa6e5eb_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_role_member accounts_role_member_role_id_76758add_fk_accounts_role_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role_member
    ADD CONSTRAINT accounts_role_member_role_id_76758add_fk_accounts_role_id FOREIGN KEY (role_id) REFERENCES public.accounts_role(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_role_member accounts_role_member_site_id_e6735be7_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role_member
    ADD CONSTRAINT accounts_role_member_site_id_e6735be7_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_role accounts_role_user_id_a498ef00_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.accounts_role
    ADD CONSTRAINT accounts_role_user_id_a498ef00_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_clocked_id_47a69f82_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_clocked_id_47a69f82_fk_django_ce FOREIGN KEY (clocked_id) REFERENCES public.django_celery_beat_clockedschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_crontab_id_d3cba168_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_crontab_id_d3cba168_fk_django_ce FOREIGN KEY (crontab_id) REFERENCES public.django_celery_beat_crontabschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_interval_id_a8ca27da_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_interval_id_a8ca27da_fk_django_ce FOREIGN KEY (interval_id) REFERENCES public.django_celery_beat_intervalschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_solar_id_a87ce72c_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_solar_id_a87ce72c_fk_django_ce FOREIGN KEY (solar_id) REFERENCES public.django_celery_beat_solarschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: domain_attribute domain_attribute_parent_id_abc616e2_fk_domain_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.domain_attribute
    ADD CONSTRAINT domain_attribute_parent_id_abc616e2_fk_domain_attribute_id FOREIGN KEY (parent_id) REFERENCES public.domain_attribute(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: options_option options_option_optionset_id_442daa42_fk_options_optionset_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.options_option
    ADD CONSTRAINT options_option_optionset_id_442daa42_fk_options_optionset_id FOREIGN KEY (optionset_id) REFERENCES public.options_optionset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: options_optionset_conditions options_optionset_co_condition_id_b595e3cf_fk_condition; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.options_optionset_conditions
    ADD CONSTRAINT options_optionset_co_condition_id_b595e3cf_fk_condition FOREIGN KEY (condition_id) REFERENCES public.conditions_condition(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: options_optionset_conditions options_optionset_co_optionset_id_86fe6bbd_fk_options_o; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.options_optionset_conditions
    ADD CONSTRAINT options_optionset_co_optionset_id_86fe6bbd_fk_options_o FOREIGN KEY (optionset_id) REFERENCES public.options_optionset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: overlays_overlay overlays_overlay_site_id_72843dad_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.overlays_overlay
    ADD CONSTRAINT overlays_overlay_site_id_72843dad_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: overlays_overlay overlays_overlay_user_id_4894410e_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.overlays_overlay
    ADD CONSTRAINT overlays_overlay_user_id_4894410e_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_continuation projects_continuatio_project_id_b85db9fb_fk_projects_; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_continuation
    ADD CONSTRAINT projects_continuatio_project_id_b85db9fb_fk_projects_ FOREIGN KEY (project_id) REFERENCES public.projects_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_continuation projects_continuatio_questionset_id_4c5383a3_fk_questions; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_continuation
    ADD CONSTRAINT projects_continuatio_questionset_id_4c5383a3_fk_questions FOREIGN KEY (questionset_id) REFERENCES public.questions_questionset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_continuation projects_continuation_user_id_7291fa2d_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_continuation
    ADD CONSTRAINT projects_continuation_user_id_7291fa2d_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_integrationoption projects_integration_integration_id_42fb0721_fk_projects_; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_integrationoption
    ADD CONSTRAINT projects_integration_integration_id_42fb0721_fk_projects_ FOREIGN KEY (integration_id) REFERENCES public.projects_integration(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_integration projects_integration_project_id_fb6544d8_fk_projects_project_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_integration
    ADD CONSTRAINT projects_integration_project_id_fb6544d8_fk_projects_project_id FOREIGN KEY (project_id) REFERENCES public.projects_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_invite projects_invite_project_id_5930e2f3_fk_projects_project_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_invite
    ADD CONSTRAINT projects_invite_project_id_5930e2f3_fk_projects_project_id FOREIGN KEY (project_id) REFERENCES public.projects_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_invite projects_invite_user_id_b2bee14c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_invite
    ADD CONSTRAINT projects_invite_user_id_b2bee14c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_issue projects_issue_project_id_f8e6d9c2_fk_projects_project_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_issue
    ADD CONSTRAINT projects_issue_project_id_f8e6d9c2_fk_projects_project_id FOREIGN KEY (project_id) REFERENCES public.projects_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_issue projects_issue_task_id_af165a16_fk_tasks_task_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_issue
    ADD CONSTRAINT projects_issue_task_id_af165a16_fk_tasks_task_id FOREIGN KEY (task_id) REFERENCES public.tasks_task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_issueresource projects_issueresour_integration_id_654cd5fa_fk_projects_; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_issueresource
    ADD CONSTRAINT projects_issueresour_integration_id_654cd5fa_fk_projects_ FOREIGN KEY (integration_id) REFERENCES public.projects_integration(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_issueresource projects_issueresource_issue_id_4c66a485_fk_projects_issue_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_issueresource
    ADD CONSTRAINT projects_issueresource_issue_id_4c66a485_fk_projects_issue_id FOREIGN KEY (issue_id) REFERENCES public.projects_issue(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_membership projects_membership_project_id_5f65bf3f_fk_projects_project_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_membership
    ADD CONSTRAINT projects_membership_project_id_5f65bf3f_fk_projects_project_id FOREIGN KEY (project_id) REFERENCES public.projects_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_membership projects_membership_user_id_13374535_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_membership
    ADD CONSTRAINT projects_membership_user_id_13374535_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_project projects_project_catalog_id_1f49c049_fk_questions_catalog_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_project
    ADD CONSTRAINT projects_project_catalog_id_1f49c049_fk_questions_catalog_id FOREIGN KEY (catalog_id) REFERENCES public.questions_catalog(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_project projects_project_parent_id_9f73ad2b_fk_projects_project_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_project
    ADD CONSTRAINT projects_project_parent_id_9f73ad2b_fk_projects_project_id FOREIGN KEY (parent_id) REFERENCES public.projects_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_project projects_project_site_id_81d4030f_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_project
    ADD CONSTRAINT projects_project_site_id_81d4030f_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_project_views projects_project_vie_project_id_a111668b_fk_projects_; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_project_views
    ADD CONSTRAINT projects_project_vie_project_id_a111668b_fk_projects_ FOREIGN KEY (project_id) REFERENCES public.projects_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_project_views projects_project_views_view_id_f4e5d854_fk_views_view_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_project_views
    ADD CONSTRAINT projects_project_views_view_id_f4e5d854_fk_views_view_id FOREIGN KEY (view_id) REFERENCES public.views_view(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_snapshot projects_snapshot_project_id_b0587441_fk_projects_project_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_snapshot
    ADD CONSTRAINT projects_snapshot_project_id_b0587441_fk_projects_project_id FOREIGN KEY (project_id) REFERENCES public.projects_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_value projects_value_attribute_id_524d090f_fk_domain_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_value
    ADD CONSTRAINT projects_value_attribute_id_524d090f_fk_domain_attribute_id FOREIGN KEY (attribute_id) REFERENCES public.domain_attribute(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_value projects_value_option_id_37fcfa86_fk_options_option_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_value
    ADD CONSTRAINT projects_value_option_id_37fcfa86_fk_options_option_id FOREIGN KEY (option_id) REFERENCES public.options_option(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_value projects_value_project_id_030f64a4_fk_projects_project_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_value
    ADD CONSTRAINT projects_value_project_id_030f64a4_fk_projects_project_id FOREIGN KEY (project_id) REFERENCES public.projects_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_value projects_value_snapshot_id_5edd5409_fk_projects_snapshot_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.projects_value
    ADD CONSTRAINT projects_value_snapshot_id_5edd5409_fk_projects_snapshot_id FOREIGN KEY (snapshot_id) REFERENCES public.projects_snapshot(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_catalog_groups questions_catalog_gr_catalog_id_166ff114_fk_questions; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_catalog_groups
    ADD CONSTRAINT questions_catalog_gr_catalog_id_166ff114_fk_questions FOREIGN KEY (catalog_id) REFERENCES public.questions_catalog(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_catalog_groups questions_catalog_groups_group_id_42389cad_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_catalog_groups
    ADD CONSTRAINT questions_catalog_groups_group_id_42389cad_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_catalog_sites questions_catalog_si_catalog_id_b6cd1bff_fk_questions; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_catalog_sites
    ADD CONSTRAINT questions_catalog_si_catalog_id_b6cd1bff_fk_questions FOREIGN KEY (catalog_id) REFERENCES public.questions_catalog(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_catalog_sites questions_catalog_sites_site_id_62b449b4_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_catalog_sites
    ADD CONSTRAINT questions_catalog_sites_site_id_62b449b4_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_question questions_question_attribute_id_adfc0b01_fk_domain_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question
    ADD CONSTRAINT questions_question_attribute_id_adfc0b01_fk_domain_attribute_id FOREIGN KEY (attribute_id) REFERENCES public.domain_attribute(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_question_conditions questions_question_c_condition_id_04ec243f_fk_condition; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question_conditions
    ADD CONSTRAINT questions_question_c_condition_id_04ec243f_fk_condition FOREIGN KEY (condition_id) REFERENCES public.conditions_condition(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_question_conditions questions_question_c_question_id_5eb2022e_fk_questions; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question_conditions
    ADD CONSTRAINT questions_question_c_question_id_5eb2022e_fk_questions FOREIGN KEY (question_id) REFERENCES public.questions_question(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_question questions_question_default_option_id_e4ccc44b_fk_options_o; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question
    ADD CONSTRAINT questions_question_default_option_id_e4ccc44b_fk_options_o FOREIGN KEY (default_option_id) REFERENCES public.options_option(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_question_optionsets questions_question_o_optionset_id_9dfc06f4_fk_options_o; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question_optionsets
    ADD CONSTRAINT questions_question_o_optionset_id_9dfc06f4_fk_options_o FOREIGN KEY (optionset_id) REFERENCES public.options_optionset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_question_optionsets questions_question_o_question_id_087eb80e_fk_questions; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question_optionsets
    ADD CONSTRAINT questions_question_o_question_id_087eb80e_fk_questions FOREIGN KEY (question_id) REFERENCES public.questions_question(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_question questions_questionit_questionset_id_8eba2e9e_fk_questions; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_question
    ADD CONSTRAINT questions_questionit_questionset_id_8eba2e9e_fk_questions FOREIGN KEY (questionset_id) REFERENCES public.questions_questionset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_questionset questions_questionse_attribute_id_30ee3ea9_fk_domain_at; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_questionset
    ADD CONSTRAINT questions_questionse_attribute_id_30ee3ea9_fk_domain_at FOREIGN KEY (attribute_id) REFERENCES public.domain_attribute(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_questionset_conditions questions_questionse_condition_id_85c6f853_fk_condition; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_questionset_conditions
    ADD CONSTRAINT questions_questionse_condition_id_85c6f853_fk_condition FOREIGN KEY (condition_id) REFERENCES public.conditions_condition(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_questionset_conditions questions_questionse_questionset_id_2fc4bcab_fk_questions; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_questionset_conditions
    ADD CONSTRAINT questions_questionse_questionset_id_2fc4bcab_fk_questions FOREIGN KEY (questionset_id) REFERENCES public.questions_questionset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_questionset questions_questionse_section_id_2dfdee75_fk_questions; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_questionset
    ADD CONSTRAINT questions_questionse_section_id_2dfdee75_fk_questions FOREIGN KEY (section_id) REFERENCES public.questions_section(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_section questions_section_catalog_id_5612b1ce_fk_questions_catalog_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.questions_section
    ADD CONSTRAINT questions_section_catalog_id_5612b1ce_fk_questions_catalog_id FOREIGN KEY (catalog_id) REFERENCES public.questions_catalog(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tasks_task_catalogs tasks_task_catalogs_catalog_id_b165d5f4_fk_questions_catalog_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_catalogs
    ADD CONSTRAINT tasks_task_catalogs_catalog_id_b165d5f4_fk_questions_catalog_id FOREIGN KEY (catalog_id) REFERENCES public.questions_catalog(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tasks_task_catalogs tasks_task_catalogs_task_id_191664fa_fk_tasks_task_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_catalogs
    ADD CONSTRAINT tasks_task_catalogs_task_id_191664fa_fk_tasks_task_id FOREIGN KEY (task_id) REFERENCES public.tasks_task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tasks_task_conditions tasks_task_condition_condition_id_d9e4b35d_fk_condition; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_conditions
    ADD CONSTRAINT tasks_task_condition_condition_id_d9e4b35d_fk_condition FOREIGN KEY (condition_id) REFERENCES public.conditions_condition(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tasks_task_conditions tasks_task_conditions_task_id_42f67f26_fk_tasks_task_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_conditions
    ADD CONSTRAINT tasks_task_conditions_task_id_42f67f26_fk_tasks_task_id FOREIGN KEY (task_id) REFERENCES public.tasks_task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tasks_task tasks_task_end_attribute_id_0e564a20_fk_domain_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task
    ADD CONSTRAINT tasks_task_end_attribute_id_0e564a20_fk_domain_attribute_id FOREIGN KEY (end_attribute_id) REFERENCES public.domain_attribute(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tasks_task_groups tasks_task_groups_group_id_37c9dd38_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_groups
    ADD CONSTRAINT tasks_task_groups_group_id_37c9dd38_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tasks_task_groups tasks_task_groups_task_id_84269289_fk_tasks_task_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_groups
    ADD CONSTRAINT tasks_task_groups_task_id_84269289_fk_tasks_task_id FOREIGN KEY (task_id) REFERENCES public.tasks_task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tasks_task_sites tasks_task_sites_site_id_d03d8f1d_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_sites
    ADD CONSTRAINT tasks_task_sites_site_id_d03d8f1d_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tasks_task_sites tasks_task_sites_task_id_4f3a2bf5_fk_tasks_task_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task_sites
    ADD CONSTRAINT tasks_task_sites_task_id_4f3a2bf5_fk_tasks_task_id FOREIGN KEY (task_id) REFERENCES public.tasks_task(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tasks_task tasks_task_start_attribute_id_d519055d_fk_domain_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.tasks_task
    ADD CONSTRAINT tasks_task_start_attribute_id_d519055d_fk_domain_attribute_id FOREIGN KEY (start_attribute_id) REFERENCES public.domain_attribute(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: views_view_catalogs views_view_catalogs_catalog_id_5e15127c_fk_questions_catalog_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_catalogs
    ADD CONSTRAINT views_view_catalogs_catalog_id_5e15127c_fk_questions_catalog_id FOREIGN KEY (catalog_id) REFERENCES public.questions_catalog(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: views_view_catalogs views_view_catalogs_view_id_1f033a7d_fk_views_view_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_catalogs
    ADD CONSTRAINT views_view_catalogs_view_id_1f033a7d_fk_views_view_id FOREIGN KEY (view_id) REFERENCES public.views_view(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: views_view_groups views_view_groups_group_id_0c159c5a_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_groups
    ADD CONSTRAINT views_view_groups_group_id_0c159c5a_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: views_view_groups views_view_groups_view_id_d755fd03_fk_views_view_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_groups
    ADD CONSTRAINT views_view_groups_view_id_d755fd03_fk_views_view_id FOREIGN KEY (view_id) REFERENCES public.views_view(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: views_view_sites views_view_sites_site_id_ff85e832_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_sites
    ADD CONSTRAINT views_view_sites_site_id_ff85e832_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: views_view_sites views_view_sites_view_id_7a296525_fk_views_view_id; Type: FK CONSTRAINT; Schema: public; Owner: jyBjOrOdIfFTrfROhgEDQpYrLHbxdGlX
--

ALTER TABLE ONLY public.views_view_sites
    ADD CONSTRAINT views_view_sites_view_id_7a296525_fk_views_view_id FOREIGN KEY (view_id) REFERENCES public.views_view(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

